package com.cardif.framework.controller;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.seguridad.controller.LoginController;
import com.cardif.satelite.tesoreria.controller.LoginFirmanteController;
import com.cardif.satelite.tesoreria.controller.LoginSunController;
import com.cardif.satelite.tesoreria.model.Firmante;
import com.cardif.satelite.tesoreria.service.ChequeService;
import com.cardif.satelite.util.customtag.HtmlIncludeView;
import com.cardif.sunsystems.util.ConstantesSun;

@Controller("panelMenu")
@Scope("session")
public class PanelMenuController extends BaseController {
	public static final Logger log = Logger.getLogger(PanelMenuController.class);
	private String current = "/paginas/blank.xhtml";
	private boolean singleMode;

	HttpSession session;

	/*
	 * BSC 04/06/2019
	 * Como la clase org.ajax4jsf.component.html.Include fue eliminada en RichFaces 4.x, se reemplaza por una cadena.
	 * También fue removido el Tag a4j:include. Para simular sus características, se creó un tag personalizado includeView.
	 * Para actualizar el contenido, quedará así:
	 * Antes:
	 *   <a4j:include binding="#{panelMenu.include}" viewId="/paginas/inicio.xhtml" id="principal" />
	 *   En el controller, se cambiaba la propiedad viewId del include: include.setViewId("<página>");
	 * Ahora:
	 *   <custom:includeView id="principal" viewId="#{panelMenu.include}"/>
	 *   En el controller, bastará con cambiar el valor del propio include que ya es una cadena: setInclude("<página>") o include = "<página>";
	 */
	private String include = "/paginas/inicio.xhtml";

	@Autowired
	private LoginController loginController;

	@Autowired
	private LoginSunController loginSunController;

	@Autowired
	private LoginFirmanteController loginFirmanteController;

	@Autowired
	private ChequeService chequeService;

	@Override
	public String inicio() {
		log.info("[ Inicio ]");
		String respuesta = null;
		if (!tieneAcceso()) {
			log.debug("[ No tiene los accesos suficientes ]");
			return "accesoDenegado";
		}
		log.info("[ fin ]");
		return respuesta;
	}

	public String getInclude() {
		return include;
	}

	public void setInclude(String include) {
		this.include = include;
	}

	public void reset() {
		include = "/paginas/blank.xhtml";
	}

	public boolean isSingleMode() {
		return singleMode;
	}

	public void setSingleMode(boolean singleMode) {
		this.singleMode = singleMode;
	}

	public PanelMenuController() {
	}

	public String getCurrent() {
		return this.current;
	}

	public void setCurrent(String current) {
		this.current = current;
	}

	public String updateCurrent() {
		FacesContext context = FacesContext.getCurrentInstance();
		setCurrent(context.getExternalContext().getRequestParameterMap().get("current"));
		String opcion = context.getExternalContext().getRequestParameterMap().get("opcion");
		session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
		if (session != null) {
			session.setAttribute("opcion", opcion);
		}

		log.info("### OPCION SELECCIONADA ###" + session.getAttribute("opcion"));

		/* INICIO JARIASS SYNCCON 03/03/2015 */

		if (opcion.equals("915") || opcion.equals("903") || opcion.equals("904") || opcion.equals("905")
				|| opcion.equals("911") || opcion.equals(ConstantesSun.TES_OPCION_MENU_PAGO_BANCARIO)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_MODULO_PAGO)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_MODULO_OTROS_PAGOS) //PSS PERU 12-SET-2020
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_HISTORIAL_OTROS_PAGOS) //PSS PERU 12-SET-2020
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_HISTORIAL_ASIENTO_LIBRE)  //PSS PERU 12-SET-2020
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_CONFIGURACION_TIPO_DIARIO)  //PSS PERU 12-SET-2020
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_REGISTRO_ASIENTO_LIBRE)  //PSS PERU 12-SET-2020
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_TRANSFER_ENTRE_CUENTAS)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_COMISION_E_ITF)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_ASIGNACION_FIRMANTES)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_GENERAR_CERT_RETENCION)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_ANULAR_CERT_RETENCION)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_REVERSAR_CERT_RETENCION)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_GENERAR_REPORTE_SBS_MODELO_UNO)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_GENERAR_REPORTE_SBS_MODELO_UNO_LISTADO)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_MANTENIMIENTO_CHEQUES)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_RECAUDO_COMISION_E_ITF)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_PROPUESTA_PAGO)
				|| opcion.equals(ConstantesSun.OPCION_MENU_MANT_PERIODOS_OPERATIVOS)
				|| opcion.equals(ConstantesSun.OPCION_MENU_PROCESAMIENTO_ARCHIVOS)
				|| opcion.equals(ConstantesSun.OPCION_MENU_MANT_ASIENTOS)
				|| opcion.equals(ConstantesSun.OPCION_MENU_GENENERAR_REPORTES_ANEXOS_SBS)
                || opcion.equals(ConstantesSun.CONTA_OPCION_MENU_REVERSA_ASIENTOS)
                || opcion.equals(ConstantesSun.CONTA_OPCION_MENU_CUADROCONTABLE)
				|| opcion.equals(ConstantesSun.CONTA_OPCION_MENU_CARGA_RESERVAS)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_GEN_ASIENTOS_INVERSION)
				|| opcion.equals(ConstantesSun.TES_OPCION_MENU_REP_HISTORICO)
				//|| opcion.equals(ConstantesSun.OPCION_MENU_CPE_REPORTES)

		) {

			if (!loginSunController.isLoged()) {
				log.info("No está logueado en SUN");
				// setInclude("accesoDenegado.xhtml");

				include = "/paginas/tesoreria/loginSun.xhtml";

				return null;
			} else {
				context.getExternalContext().getSessionMap().put(Constantes.MDP_AUTH_SUNSYSTEMS_TOKEN,
						loginSunController.getToken());
			}
		}

		if (opcion.equals("912") || opcion.equals("913") || // AM
				opcion.equals("413002") || opcion.equals("413004") // AMER
		) {

			if (!loginFirmanteController.isLogged()) {

				String usuario = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
				Firmante firmante = chequeService.buscarFirmante(usuario);
				if (firmante != null) {
					if (firmante.getClave() == null) {
						log.info("El firmante no cuenta con clave, debe configurar una");

						include = "/paginas/tesoreria/configurarClave.xhtml";
					} else {
						log.info("El firmante no esta logeado");

						include = "/paginas/tesoreria/loginFirmante.xhtml";
					}
				} else {
					include = "/paginas/accesoDenegado.xhtml";
				}

				return null;
			}
		}

		/* FIN JARIASS SYNCCON 03/03/2015 */

		/* if (tieneAcceso()) { */
		this.include = current;
		this.loginController.setCurrent(current);
		/*
		 * } else { setInclude("accesoDenegado.xhtml"); }
		 */
		return null;
	}
}
