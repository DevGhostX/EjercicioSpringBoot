package com.cardif.framework.excepcion;

public class SateliteServiceException extends  Exception{
    private ErrorBean errorBean = null;

    public SateliteServiceException(String message){
        super(message);
        errorBean = new ErrorBean();
        errorBean.setDescripcion(message);
    }
    public SateliteServiceException(String codigo, String message){
        super(codigo);
        errorBean = new ErrorBean();
        errorBean.setCodigo(codigo);
        errorBean.setDescripcion(message);
    }

    @Override
    public String getMessage() {
        return errorBean.getDescripcion();
    }

    public ErrorBean getErrorBean() {
        return errorBean;
    }

    public void setErrorBean(ErrorBean errorBean) {
        this.errorBean = errorBean;
    }
}
