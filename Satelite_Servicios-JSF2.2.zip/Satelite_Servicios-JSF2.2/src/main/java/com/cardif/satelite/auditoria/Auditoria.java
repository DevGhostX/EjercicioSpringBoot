package com.cardif.satelite.auditoria;

import static com.cardif.satelite.constantes.ErrorConstants.COD_ERROR_BD_INSERTAR;

import java.util.Calendar;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.security.core.context.SecurityContextHolder;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.model.SiniSiniestro;
import com.cardif.satelite.model.SiniSiniestroAuditoria;
import com.cardif.satelite.siniestro.service.SiniSiniestroAuditoriaService;
import com.cardif.satelite.siniestro.service.impl.SiniSiniestroServiceImpl;

public class Auditoria {
	
	public static final Logger log = Logger.getLogger(Auditoria.class);
	
	public void guardarAuditoriaSiniestro(SiniSiniestroAuditoriaService service, String nroSiniestro, Long idBeneficiario, String menu, String accion, int opAccion, String valProceso) throws SyncconException {
		/* opAccion=1 -> INSERT , opAccion=2 -> UPDATE , opAccion=3 -> DELETE , opAccion=4 -> OTROS (REPORTES, CARGAS, PROCESOS) */
		log.info("Inicio Auditoria");
		try {
			SiniSiniestroAuditoria siniSiniestroAuditoria = new SiniSiniestroAuditoria();
			siniSiniestroAuditoria.setNroSiniestro(nroSiniestro);
			siniSiniestroAuditoria.setIdBeneficiario(idBeneficiario);
			siniSiniestroAuditoria.setOpAccion(opAccion);
			siniSiniestroAuditoria.setValAccion(accion);
			siniSiniestroAuditoria.setValProceso(valProceso);
			siniSiniestroAuditoria.setValMenu(menu);
			HttpServletRequest request = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
			String ipAdress = request.getHeader("X-FORWARDED-FOR");
			siniSiniestroAuditoria.setValIp(((ipAdress==null)?request.getRemoteAddr():ipAdress));
			String uidUsuario = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
			String nombreUsuario = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("NOMUSUARIO").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("NOMUSUARIO").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
			siniSiniestroAuditoria.setValUsuario(uidUsuario);
			siniSiniestroAuditoria.setValNomUsuario(nombreUsuario);
			siniSiniestroAuditoria.setFecRegistro(Calendar.getInstance().getTime());
			service.insertarSiniSiniestroAuditoria(siniSiniestroAuditoria);
		} catch (Exception e) {
			log.error("Error al insertar en la tabla SINI_AUDITORIA - "+e.getMessage(), e);
			throw new SyncconException(COD_ERROR_BD_INSERTAR);
		}
		log.info("Fin Auditoria");
	}
}
