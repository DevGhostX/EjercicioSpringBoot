package com.cardif.satelite.bof.bean;

import java.math.BigDecimal;
import java.util.Date;

public class BofCargaDiDpf {
    private String codCardpf;
    private String perCarga;
    private String verCarga;
    private String nomArchivo;
    private String tipInstru;
    private String entidad;
    private String moneda;
    private String empresa;
    private Integer plazo;
    private Date fApertura;
    private Date fVcto;
    private BigDecimal tasa;
    private BigDecimal principal;
    private BigDecimal montFinal;
    private BigDecimal intMes;
    private BigDecimal intxCobrar;
    private String tipoOper;
    private String isin;
    private BigDecimal intMesanterAcum;
    private BigDecimal operBancaria;
    private Integer estEnvio;
    private Integer numRegistro;
    private Date fecRegistro;

    public String getCodCardpf() {
        return codCardpf;
    }

    public void setCodCardpf(String codCardpf) {
        this.codCardpf = codCardpf;
    }

    public String getPerCarga() {
        return perCarga;
    }

    public void setPerCarga(String perCarga) {
        this.perCarga = perCarga;
    }

    public String getVerCarga() {
        return verCarga;
    }

    public void setVerCarga(String verCarga) {
        this.verCarga = verCarga;
    }

    public String getNomArchivo() {
        return nomArchivo;
    }

    public void setNomArchivo(String nomArchivo) {
        this.nomArchivo = nomArchivo;
    }

    public String getTipInstru() {
        return tipInstru;
    }

    public void setTipInstru(String tipInstru) {
        this.tipInstru = tipInstru;
    }

    public String getEntidad() {
        return entidad;
    }

    public void setEntidad(String entidad) {
        this.entidad = entidad;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public Integer getPlazo() {
        return plazo;
    }

    public void setPlazo(Integer plazo) {
        this.plazo = plazo;
    }

    public Date getfApertura() {
        return fApertura;
    }

    public void setfApertura(Date fApertura) {
        this.fApertura = fApertura;
    }

    public Date getfVcto() {
        return fVcto;
    }

    public void setfVcto(Date fVcto) {
        this.fVcto = fVcto;
    }

    public BigDecimal getTasa() {
        return tasa;
    }

    public void setTasa(BigDecimal tasa) {
        this.tasa = tasa;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public void setPrincipal(BigDecimal principal) {
        this.principal = principal;
    }

    public BigDecimal getMontFinal() {
        return montFinal;
    }

    public void setMontFinal(BigDecimal montFinal) {
        this.montFinal = montFinal;
    }

    public BigDecimal getIntMes() {
        return intMes;
    }

    public void setIntMes(BigDecimal intMes) {
        this.intMes = intMes;
    }

    public BigDecimal getIntxCobrar() {
        return intxCobrar;
    }

    public void setIntxCobrar(BigDecimal intxCobrar) {
        this.intxCobrar = intxCobrar;
    }

    public String getTipoOper() {
        return tipoOper;
    }

    public void setTipoOper(String tipoOper) {
        this.tipoOper = tipoOper;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public BigDecimal getIntMesanterAcum() {
        return intMesanterAcum;
    }

    public void setIntMesanterAcum(BigDecimal intMesanterAcum) {
        this.intMesanterAcum = intMesanterAcum;
    }


    public BigDecimal getOperBancaria() {
        return operBancaria;
    }

    public void setOperBancaria(BigDecimal operBancaria) {
        this.operBancaria = operBancaria;
    }

    public Integer getEstEnvio() {
        return estEnvio;
    }

    public void setEstEnvio(Integer estEnvio) {
        this.estEnvio = estEnvio;
    }

    public Integer getNumRegistro() {
        return numRegistro;
    }

    public void setNumRegistro(Integer numRegistro) {
        this.numRegistro = numRegistro;
    }

    public Date getFecRegistro() {
        return fecRegistro;
    }

    public void setFecRegistro(Date fecRegistro) {
        this.fecRegistro = fecRegistro;
    }
}