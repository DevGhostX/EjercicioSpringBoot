package com.cardif.satelite.bof.bean;

import java.math.BigDecimal;
import java.util.Date;

public class BofCargaDiVarios {
    private String codCardvar;

    private String perCarga;

    private String verCarga;

    private String nomArchivo;

    private String tipInstru;

    private String emisor;

    private String moneda;

    private String empresa;

    private Date fNegociacion;

    private Date fLiquidacion;

    private Date fVencimiento;

    private String contraparte;

    private BigDecimal nominal;

    private BigDecimal montovpComis;

    private BigDecimal costosTransac;

    private BigDecimal precsucComven;

    private String operacion;

    private String isin;

    private BigDecimal intMesanterAcum;

    private String nemotecnico;
    private BigDecimal operBancaria;
    private BigDecimal gananVenta;
    private BigDecimal gananNoAcum;

    private Integer estEnvio;
    private Integer numRegistro;
    private Date fecRegistro;

    public String getCodCardvar() {
        return codCardvar;
    }

    public void setCodCardvar(String codCardvar) {
        this.codCardvar = codCardvar;
    }

    public String getPerCarga() {
        return perCarga;
    }

    public void setPerCarga(String perCarga) {
        this.perCarga = perCarga;
    }

    public String getVerCarga() {
        return verCarga;
    }

    public void setVerCarga(String verCarga) {
        this.verCarga = verCarga;
    }

    public String getNomArchivo() {
        return nomArchivo;
    }

    public void setNomArchivo(String nomArchivo) {
        this.nomArchivo = nomArchivo;
    }

    public String getTipInstru() {
        return tipInstru;
    }

    public void setTipInstru(String tipInstru) {
        this.tipInstru = tipInstru;
    }

    public String getEmisor() {
        return emisor;
    }

    public void setEmisor(String emisor) {
        this.emisor = emisor;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public Date getfNegociacion() {
        return fNegociacion;
    }

    public void setfNegociacion(Date fNegociacion) {
        this.fNegociacion = fNegociacion;
    }

    public Date getfLiquidacion() {
        return fLiquidacion;
    }

    public void setfLiquidacion(Date fLiquidacion) {
        this.fLiquidacion = fLiquidacion;
    }

    public Date getfVencimiento() {
        return fVencimiento;
    }

    public void setfVencimiento(Date fVencimiento) {
        this.fVencimiento = fVencimiento;
    }

    public String getContraparte() {
        return contraparte;
    }

    public void setContraparte(String contraparte) {
        this.contraparte = contraparte;
    }

    public BigDecimal getNominal() {
        return nominal;
    }

    public void setNominal(BigDecimal nominal) {
        this.nominal = nominal;
    }

    public BigDecimal getMontovpComis() {
        return montovpComis;
    }

    public void setMontovpComis(BigDecimal montovpComis) {
        this.montovpComis = montovpComis;
    }

    public BigDecimal getCostosTransac() {
        return costosTransac;
    }

    public void setCostosTransac(BigDecimal costosTransac) {
        this.costosTransac = costosTransac;
    }

    public BigDecimal getPrecsucComven() {
        return precsucComven;
    }

    public void setPrecsucComven(BigDecimal precsucComven) {
        this.precsucComven = precsucComven;
    }

    public String getOperacion() {
        return operacion;
    }

    public void setOperacion(String operacion) {
        this.operacion = operacion;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public BigDecimal getIntMesanterAcum() {
        return intMesanterAcum;
    }

    public void setIntMesanterAcum(BigDecimal intMesanterAcum) {
        this.intMesanterAcum = intMesanterAcum;
    }

    public String getNemotecnico() {
        return nemotecnico;
    }

    public void setNemotecnico(String nemotecnico) {
        this.nemotecnico = nemotecnico;
    }

    public BigDecimal getOperBancaria() {
        return operBancaria;
    }

    public void setOperBancaria(BigDecimal operBancaria) {
        this.operBancaria = operBancaria;
    }

    public BigDecimal getGananVenta() {
        return gananVenta;
    }

    public void setGananVenta(BigDecimal gananVenta) {
        this.gananVenta = gananVenta;
    }

    public BigDecimal getGananNoAcum() {
        return gananNoAcum;
    }

    public void setGananNoAcum(BigDecimal gananNoAcum) {
        this.gananNoAcum = gananNoAcum;
    }

    public Integer getEstEnvio() {
        return estEnvio;
    }

    public void setEstEnvio(Integer estEnvio) {
        this.estEnvio = estEnvio;
    }

    public Integer getNumRegistro() {
        return numRegistro;
    }

    public void setNumRegistro(Integer numRegistro) {
        this.numRegistro = numRegistro;
    }

    public Date getFecRegistro() {
        return fecRegistro;
    }

    public void setFecRegistro(Date fecRegistro) {
        this.fecRegistro = fecRegistro;
    }
}