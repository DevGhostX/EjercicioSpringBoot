package com.cardif.satelite.bof.bean;

import java.math.BigDecimal;
import java.util.Date;

public class BofCargaMensual {
    private String codCargam;

    private String perCarga;

    private String nomArchivo;

    private String verCarga;

    private String tipoInstru;

    private String emisor;

    private String isin;

    private String nemotec;

    private String rating;

    private Date fCompra;

    private Date fLiqu;

    private Date fVcto;

    private BigDecimal unidades;

    private BigDecimal valNomin;

    private BigDecimal valpPlim;

    private BigDecimal valpCupcor;

    private BigDecimal valpAmorcup;

    private BigDecimal valpPretot;

    private BigDecimal intAmorAjupre;

    private BigDecimal valmPlim;

    private BigDecimal valmValormcdo;

    private BigDecimal provFlucAcum;

    private BigDecimal ajusValRazona;

    private Date fPagocup;

    private BigDecimal valMesprev;

    private BigDecimal vamcdoMesprev;

    private BigDecimal colAa;

    private BigDecimal colAb;

    private BigDecimal dur;

    private BigDecimal vpDur;

    private BigDecimal tirComp;

    private BigDecimal vpTircomp;

    private BigDecimal vpDurtircomp;

    private BigDecimal vpTircomp2;

    private BigDecimal durMod;

    private BigDecimal vpDurmodf;

    private BigDecimal tirMcdo;

    private BigDecimal vmTirMcdo;

    private BigDecimal vmcdoDur;

    private BigDecimal vmDurmodif;

    private BigDecimal tasaCupon;

    private String clasiRiesgo;

    private Integer estEnvio;

    private Integer numRegistro;

    private Date fecRegistro;

    public String getCodCargam() {
        return codCargam;
    }

    public void setCodCargam(String codCargam) {
        this.codCargam = codCargam;
    }

    public String getPerCarga() {
        return perCarga;
    }

    public void setPerCarga(String perCarga) {
        this.perCarga = perCarga;
    }

    public String getNomArchivo() {
        return nomArchivo;
    }

    public void setNomArchivo(String nomArchivo) {
        this.nomArchivo = nomArchivo;
    }

    public String getVerCarga() {
        return verCarga;
    }

    public void setVerCarga(String verCarga) {
        this.verCarga = verCarga;
    }

    public String getTipoInstru() {
        return tipoInstru;
    }

    public void setTipoInstru(String tipoInstru) {
        this.tipoInstru = tipoInstru;
    }

    public String getEmisor() {
        return emisor;
    }

    public void setEmisor(String emisor) {
        this.emisor = emisor;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public String getNemotec() {
        return nemotec;
    }

    public void setNemotec(String nemotec) {
        this.nemotec = nemotec;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public Date getfCompra() {
        return fCompra;
    }

    public void setfCompra(Date fCompra) {
        this.fCompra = fCompra;
    }

    public Date getfLiqu() {
        return fLiqu;
    }

    public void setfLiqu(Date fLiqu) {
        this.fLiqu = fLiqu;
    }

    public Date getfVcto() {
        return fVcto;
    }

    public void setfVcto(Date fVcto) {
        this.fVcto = fVcto;
    }

    public BigDecimal getUnidades() {
        return unidades;
    }

    public void setUnidades(BigDecimal unidades) {
        this.unidades = unidades;
    }

    public BigDecimal getValNomin() {
        return valNomin;
    }

    public void setValNomin(BigDecimal valNomin) {
        this.valNomin = valNomin;
    }

    public BigDecimal getValpPlim() {
        return valpPlim;
    }

    public void setValpPlim(BigDecimal valpPlim) {
        this.valpPlim = valpPlim;
    }

    public BigDecimal getValpCupcor() {
        return valpCupcor;
    }

    public void setValpCupcor(BigDecimal valpCupcor) {
        this.valpCupcor = valpCupcor;
    }

    public BigDecimal getValpAmorcup() {
        return valpAmorcup;
    }

    public void setValpAmorcup(BigDecimal valpAmorcup) {
        this.valpAmorcup = valpAmorcup;
    }

    public BigDecimal getValpPretot() {
        return valpPretot;
    }

    public void setValpPretot(BigDecimal valpPretot) {
        this.valpPretot = valpPretot;
    }

    public BigDecimal getIntAmorAjupre() {
        return intAmorAjupre;
    }

    public void setIntAmorAjupre(BigDecimal intAmorAjupre) {
        this.intAmorAjupre = intAmorAjupre;
    }

    public BigDecimal getValmPlim() {
        return valmPlim;
    }

    public void setValmPlim(BigDecimal valmPlim) {
        this.valmPlim = valmPlim;
    }

    public BigDecimal getValmValormcdo() {
        return valmValormcdo;
    }

    public void setValmValormcdo(BigDecimal valmValormcdo) {
        this.valmValormcdo = valmValormcdo;
    }

    public BigDecimal getProvFlucAcum() {
        return provFlucAcum;
    }

    public void setProvFlucAcum(BigDecimal provFlucAcum) {
        this.provFlucAcum = provFlucAcum;
    }

    public BigDecimal getAjusValRazona() {
        return ajusValRazona;
    }

    public void setAjusValRazona(BigDecimal ajusValRazona) {
        this.ajusValRazona = ajusValRazona;
    }

    public Date getfPagocup() {
        return fPagocup;
    }

    public void setfPagocup(Date fPagocup) {
        this.fPagocup = fPagocup;
    }

    public BigDecimal getValMesprev() {
        return valMesprev;
    }

    public void setValMesprev(BigDecimal valMesprev) {
        this.valMesprev = valMesprev;
    }

    public BigDecimal getVamcdoMesprev() {
        return vamcdoMesprev;
    }

    public void setVamcdoMesprev(BigDecimal vamcdoMesprev) {
        this.vamcdoMesprev = vamcdoMesprev;
    }

    public BigDecimal getColAa() {
        return colAa;
    }

    public void setColAa(BigDecimal colAa) {
        this.colAa = colAa;
    }

    public BigDecimal getColAb() {
        return colAb;
    }

    public void setColAb(BigDecimal colAb) {
        this.colAb = colAb;
    }

    public BigDecimal getDur() {
        return dur;
    }

    public void setDur(BigDecimal dur) {
        this.dur = dur;
    }

    public BigDecimal getVpDur() {
        return vpDur;
    }

    public void setVpDur(BigDecimal vpDur) {
        this.vpDur = vpDur;
    }

    public BigDecimal getTirComp() {
        return tirComp;
    }

    public void setTirComp(BigDecimal tirComp) {
        this.tirComp = tirComp;
    }

    public BigDecimal getVpTircomp() {
        return vpTircomp;
    }

    public void setVpTircomp(BigDecimal vpTircomp) {
        this.vpTircomp = vpTircomp;
    }

    public BigDecimal getVpDurtircomp() {
        return vpDurtircomp;
    }

    public void setVpDurtircomp(BigDecimal vpDurtircomp) {
        this.vpDurtircomp = vpDurtircomp;
    }

    public BigDecimal getVpTircomp2() {
        return vpTircomp2;
    }

    public void setVpTircomp2(BigDecimal vpTircomp2) {
        this.vpTircomp2 = vpTircomp2;
    }

    public BigDecimal getDurMod() {
        return durMod;
    }

    public void setDurMod(BigDecimal durMod) {
        this.durMod = durMod;
    }

    public BigDecimal getVpDurmodf() {
        return vpDurmodf;
    }

    public void setVpDurmodf(BigDecimal vpDurmodf) {
        this.vpDurmodf = vpDurmodf;
    }

    public BigDecimal getTirMcdo() {
        return tirMcdo;
    }

    public void setTirMcdo(BigDecimal tirMcdo) {
        this.tirMcdo = tirMcdo;
    }

    public BigDecimal getVmTirMcdo() {
        return vmTirMcdo;
    }

    public void setVmTirMcdo(BigDecimal vmTirMcdo) {
        this.vmTirMcdo = vmTirMcdo;
    }

    public BigDecimal getVmcdoDur() {
        return vmcdoDur;
    }

    public void setVmcdoDur(BigDecimal vmcdoDur) {
        this.vmcdoDur = vmcdoDur;
    }

    public BigDecimal getVmDurmodif() {
        return vmDurmodif;
    }

    public void setVmDurmodif(BigDecimal vmDurmodif) {
        this.vmDurmodif = vmDurmodif;
    }

    public BigDecimal getTasaCupon() {
        return tasaCupon;
    }

    public void setTasaCupon(BigDecimal tasaCupon) {
        this.tasaCupon = tasaCupon;
    }

    public String getClasiRiesgo() {
        return clasiRiesgo;
    }

    public void setClasiRiesgo(String clasiRiesgo) {
        this.clasiRiesgo = clasiRiesgo;
    }

    public Integer getEstEnvio() {
        return estEnvio;
    }

    public void setEstEnvio(Integer estEnvio) {
        this.estEnvio = estEnvio;
    }

    public Integer getNumRegistro() {
        return numRegistro;
    }

    public void setNumRegistro(Integer numRegistro) {
        this.numRegistro = numRegistro;
    }

    public Date getFecRegistro() {
        return fecRegistro;
    }

    public void setFecRegistro(Date fecRegistro) {
        this.fecRegistro = fecRegistro;
    }
}