package com.cardif.satelite.bof.bean;

import java.io.Serializable;

public class BofCargasLayout implements Serializable{
	private static final long serialVersionUID = 1L;

	private Integer idTabla;
	private Integer idColumna;
	private String nombreTabla;
	private String nombreColumna;
	private Integer numOrdenCampo;
	private String tipoDato;
	private String formatoColumna;
	private boolean campoObligatorio;

	public Integer getIdTabla() {
		return idTabla;
	}

	public void setIdTabla(Integer idTabla) {
		this.idTabla = idTabla;
	}

	public Integer getIdColumna() {
		return idColumna;
	}

	public void setIdColumna(Integer idColumna) {
		this.idColumna = idColumna;
	}

	public String getNombreTabla() {
		return nombreTabla;
	}

	public void setNombreTabla(String nombreTabla) {
		this.nombreTabla = nombreTabla;
	}

	public String getNombreColumna() {
		return nombreColumna;
	}

	public void setNombreColumna(String nombreColumna) {
		this.nombreColumna = nombreColumna;
	}

	public String getTipoDato() {
		return tipoDato;
	}

	public void setTipoDato(String tipoDato) {
		this.tipoDato = tipoDato;
	}

	public String getFormatoColumna() {
		return formatoColumna;
	}

	public void setFormatoColumna(String formatoColumna) {
		this.formatoColumna = formatoColumna;
	}

	public Integer getNumOrdenCampo() {
		return numOrdenCampo;
	}

	public void setNumOrdenCampo(Integer numOrdenCampo) {
		this.numOrdenCampo = numOrdenCampo;
	}

	public boolean isCampoObligatorio() {
		return campoObligatorio;
	}

	public void setCampoObligatorio(boolean campoObligatorio) {
		this.campoObligatorio = campoObligatorio;
	}

}
