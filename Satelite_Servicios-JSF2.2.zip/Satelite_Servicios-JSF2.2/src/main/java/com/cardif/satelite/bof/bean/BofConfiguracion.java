package com.cardif.satelite.bof.bean;

import java.io.Serializable;
import java.util.Date;

public class BofConfiguracion implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer codRegistro;
	private Integer codTable;
	private String codConfig;
	private String descripcion;
	private boolean activo;
	private Date fechaRegistro;
	private Date fechaModificacion;
	private String usuarioRegistro;
	private String usuarioModificacion;
	
	private boolean idCheck;
	private boolean idSelectCheck;
	
	public Integer getCodRegistro() {
		return codRegistro;
	}
	public void setCodRegistro(Integer codRegistro) {
		this.codRegistro = codRegistro;
	}
	public Integer getCodTable() {
		return codTable;
	}
	public void setCodTable(Integer codTable) {
		this.codTable = codTable;
	}
	public String getCodConfig() {
		return codConfig;
	}
	public void setCodConfig(String codConfig) {
		this.codConfig = codConfig;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	public String getUsuarioRegistro() {
		return usuarioRegistro;
	}
	public void setUsuarioRegistro(String usuarioRegistro) {
		this.usuarioRegistro = usuarioRegistro;
	}
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}
	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}
	public boolean isIdCheck() {
		return idCheck;
	}
	public void setIdCheck(boolean idCheck) {
		this.idCheck = idCheck;
	}
	public boolean isIdSelectCheck() {
		return idSelectCheck;
	}
	public void setIdSelectCheck(boolean idSelectCheck) {
		this.idSelectCheck = idSelectCheck;
	}
}
