package com.cardif.satelite.bof.bean;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class BofLoteAsientos implements Comparable<BofLoteAsientos> {
    private Integer codDeta;
    private String idCabLote;
    private String ctaContable;
    private String nomCtaContable;
    private BigDecimal importeTran;
    private String moneda;
    private String refTransaccion;
    private String glosa;
    private String centroCosto;
    private String socioProd;
    private String canal;
    private BigDecimal tasaBase;
    private String proveedorEmpleado;
    private String rucDni;
    private String polizaCliente;
    private String comprobanteSunat;
    private String medioPago;
    private String debitoCredito;
    private String fechaVencimiento;
    private String tipoDiario;
    private String fechaTransaccion;
    private String periodo;
    private Integer estEnvio;
    private Date fecEnvio;
    private String usuRegistro;
    private Date fecRegistro;
    /**
     * JournalNumber
     */
    private String numeroDiario;
    private String tabOrigen;
    private String tipoOperacion;
    private String lineNumber;
    private String glosaEnvio;

    public Integer getCodDeta() {
        return codDeta;
    }

    public void setCodDeta(Integer codDeta) {
        this.codDeta = codDeta;
    }

    public String getIdCabLote() {
        return idCabLote;
    }

    public void setIdCabLote(String idCabLote) {
        this.idCabLote = idCabLote;
    }

    public String getCtaContable() {
        return ctaContable;
    }

    public void setCtaContable(String ctaContable) {
        this.ctaContable = ctaContable;
    }

    public String getNomCtaContable() {
        return nomCtaContable;
    }

    public void setNomCtaContable(String nomCtaContable) {
        this.nomCtaContable = nomCtaContable;
    }

    public BigDecimal getImporteTran() {
        return importeTran;
    }

    public void setImporteTran(BigDecimal importeTran) {
        this.importeTran = importeTran;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getRefTransaccion() {
        return refTransaccion;
    }

    public void setRefTransaccion(String refTransaccion) {
        this.refTransaccion = refTransaccion;
    }

    public String getGlosa() {
        return glosa;
    }

    public void setGlosa(String glosa) {
        this.glosa = glosa;
    }

    public String getCentroCosto() {
        return centroCosto;
    }

    public void setCentroCosto(String centroCosto) {
        this.centroCosto = centroCosto;
    }

    public String getSocioProd() {
        return socioProd;
    }

    public void setSocioProd(String socioProd) {
        this.socioProd = socioProd;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public BigDecimal getTasaBase() {
        return tasaBase;
    }

    public void setTasaBase(BigDecimal tasaBase) {
        this.tasaBase = tasaBase;
    }

    public String getProveedorEmpleado() {
        return proveedorEmpleado;
    }

    public void setProveedorEmpleado(String proveedorEmpleado) {
        this.proveedorEmpleado = proveedorEmpleado;
    }

    public String getRucDni() {
        return rucDni;
    }

    public void setRucDni(String rucDni) {
        this.rucDni = rucDni;
    }

    public String getPolizaCliente() {
        return polizaCliente;
    }

    public void setPolizaCliente(String polizaCliente) {
        this.polizaCliente = polizaCliente;
    }

    public String getComprobanteSunat() {
        return comprobanteSunat;
    }

    public void setComprobanteSunat(String comprobanteSunat) {
        this.comprobanteSunat = comprobanteSunat;
    }

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        this.medioPago = medioPago;
    }

    public String getDebitoCredito() {
        return debitoCredito;
    }

    public void setDebitoCredito(String debitoCredito) {
        this.debitoCredito = debitoCredito;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getTipoDiario() {
        return tipoDiario;
    }

    public void setTipoDiario(String tipoDiario) {
        this.tipoDiario = tipoDiario;
    }

    public String getFechaTransaccion() {
        return fechaTransaccion;
    }

    public void setFechaTransaccion(String fechaTransaccion) {
        this.fechaTransaccion = fechaTransaccion;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public Integer getEstEnvio() {
        return estEnvio;
    }

    public void setEstEnvio(Integer estEnvio) {
        this.estEnvio = estEnvio;
    }

    public String getUsuRegistro() {
        return usuRegistro;
    }

    public void setUsuRegistro(String usuRegistro) {
        this.usuRegistro = usuRegistro;
    }

    public Date getFecRegistro() {
        return fecRegistro;
    }

    public void setFecRegistro(Date fecRegistro) {
        this.fecRegistro = fecRegistro;
    }

    public Date getFecEnvio() {
        return fecEnvio;
    }

    public void setFecEnvio(Date fecEnvio) {
        this.fecEnvio = fecEnvio;
    }

    public String getNumeroDiario() {
        return numeroDiario;
    }

    public void setNumeroDiario(String numeroDiario) {
        this.numeroDiario = numeroDiario;
    }

    public String getTabOrigen() {
        return tabOrigen;
    }

    public void setTabOrigen(String tabOrigen) {
        this.tabOrigen = tabOrigen;
    }

    public String getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(String tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    public void voidSetFormatFechaTransaccion(String fechaTransaccion) {
        SimpleDateFormat f1 = new SimpleDateFormat("ddMMyyyy");
        SimpleDateFormat f2 = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date fParsed = f1.parse(fechaTransaccion);
            this.fechaTransaccion = f2.format(fParsed);
        } catch (ParseException e) {
            e.printStackTrace();
            this.fechaTransaccion = "";
        }
    }

    @Override
    public int compareTo(BofLoteAsientos o) {
        int ndiario1 = Integer.parseInt(this.numeroDiario);
        int ndiario2 = Integer.parseInt(o.getNumeroDiario());
        if (ndiario1 == ndiario2)
            return 0;
        else if (ndiario1 > ndiario2)
            return 1;
        else
            return -1;
    }

    public BofLoteAsientos Clone(){
        BofLoteAsientos clon = new BofLoteAsientos();
        clon.setCodDeta(this.codDeta);
        clon.setIdCabLote(this.idCabLote);
        clon.setCtaContable(this.ctaContable);
        clon.setNomCtaContable(this.nomCtaContable);
        clon.setImporteTran(this.importeTran);
        clon.setMoneda(this.moneda);
        clon.setRefTransaccion(this.refTransaccion);
        clon.setGlosa(this.glosa);
        clon.setCentroCosto(this.centroCosto);
        clon.setSocioProd(this.socioProd);
        clon.setCanal(this.canal);
        clon.setTasaBase(this.tasaBase);
        clon.setProveedorEmpleado(this.proveedorEmpleado);
        clon.setRucDni(this.rucDni);
        clon.setPolizaCliente(this.polizaCliente);
        clon.setComprobanteSunat(this.comprobanteSunat);
        clon.setMedioPago(this.medioPago);
        clon.setDebitoCredito(this.debitoCredito);
        clon.setFechaVencimiento(this.fechaVencimiento);
        clon.setTipoDiario(this.tipoDiario);
        clon.setFechaTransaccion(this.fechaTransaccion);
        clon.setPeriodo(this.periodo);
        clon.setEstEnvio(this.estEnvio);
        clon.setFecEnvio(this.fecEnvio);
        clon.setUsuRegistro(this.usuRegistro);
        clon.setFecRegistro(this.fecRegistro);
        clon.setNumeroDiario(this.numeroDiario);
        clon.setTabOrigen(this.tabOrigen);
        clon.setTipoOperacion(this.tipoOperacion);
        return clon;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getGlosaEnvio() {
        return glosaEnvio;
    }

    public void setGlosaEnvio(String glosaEnvio) {
        this.glosaEnvio = glosaEnvio;
    }
}