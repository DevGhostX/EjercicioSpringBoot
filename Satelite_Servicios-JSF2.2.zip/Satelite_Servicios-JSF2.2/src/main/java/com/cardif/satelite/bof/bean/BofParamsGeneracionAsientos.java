package com.cardif.satelite.bof.bean;

import java.util.Date;

public class BofParamsGeneracionAsientos {
    private String periodoCarga;
    private String tipoCarga;
    private String tipoOperacion;
    private Date fechaProcesoMensual;
    private String usuarioGenera;
    private String tipoDiario;


    public String getPeriodoCarga() {
        return periodoCarga;
    }

    public void setPeriodoCarga(String periodoCarga) {
        this.periodoCarga = periodoCarga;
    }

    public String getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(String tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    public Date getFechaProcesoMensual() {
        return fechaProcesoMensual;
    }

    public void setFechaProcesoMensual(Date fechaProcesoMensual) {
        this.fechaProcesoMensual = fechaProcesoMensual;
    }

    public String getUsuarioGenera() {
        return usuarioGenera;
    }

    public void setUsuarioGenera(String usuarioGenera) {
        this.usuarioGenera = usuarioGenera;
    }

    public String getTipoCarga() {
        return tipoCarga;
    }

    public void setTipoCarga(String tipoCarga) {
        this.tipoCarga = tipoCarga;
    }

    public String getTipoDiario() {
        return tipoDiario;
    }

    public void setTipoDiario(String tipoDiario) {
        this.tipoDiario = tipoDiario;
    }
}
