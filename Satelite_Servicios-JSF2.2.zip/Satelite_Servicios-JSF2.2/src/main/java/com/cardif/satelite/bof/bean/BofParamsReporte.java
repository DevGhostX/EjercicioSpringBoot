package com.cardif.satelite.bof.bean;

import java.util.Date;

public class BofParamsReporte {
    private Date fecInicio;
    private Date fecFin;
    private String perIni;
    private String perFin;
    private  String tipodiario;

    public Date getFecInicio() {
        return fecInicio;
    }

    public void setFecInicio(Date fecInicio) {
        this.fecInicio = fecInicio;
    }

    public Date getFecFin() {
        return fecFin;
    }

    public void setFecFin(Date fecFin) {
        this.fecFin = fecFin;
    }

    public String getPerIni() {
        return perIni;
    }

    public void setPerIni(String perIni) {
        this.perIni = perIni;
    }

    public String getPerFin() {
        return perFin;
    }

    public void setPerFin(String perFin) {
        this.perFin = perFin;
    }

    public String getTipodiario() {
        return tipodiario;
    }

    public void setTipodiario(String tipodiario) {
        this.tipodiario = tipodiario;
    }
}
