package com.cardif.satelite.bof.controller;

public class BofCargaDiarioVarios {

}
