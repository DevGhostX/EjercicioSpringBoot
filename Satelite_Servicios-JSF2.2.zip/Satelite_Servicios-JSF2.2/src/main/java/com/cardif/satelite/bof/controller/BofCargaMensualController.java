package com.cardif.satelite.bof.controller;

import org.apache.log4j.Logger;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.bof.bean.BofCargaMensual;
import com.cardif.satelite.bof.service.impl.BofCampoLayoutServiceImpl;
import com.cardif.satelite.bof.service.impl.BofCargaMensualServiceImpl;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.SateliteUtil;

@Controller("bofCargaMensualController")
@Scope("session")
public class BofCargaMensualController extends BaseController {

    public static final Logger logger = Logger.getLogger(BofCargaMensualController.class);

    @Autowired
    private BofCampoLayoutServiceImpl bofCampoLayoutServiceImpl;

    @Autowired
    private BofCargaMensualServiceImpl bofCargaMensualServiceImpl;
    private List<BofCargaMensual> listaCargaMensual;
    private List<String> listaPeriodos;
    private List<SelectItem> itemPeriodosCbo;

    private String mensajeValidacionUploadFile;
    private UploadedFile archivo;
    private String nombreArchivo;
    private Boolean disabledCargar;

    private String usuarioDb;
    private String numeroCarga;
    private String periodoCarga;


    private String idFileUploadComponent;

    @Override
    @PostConstruct
    public String inicio() {
        // TODO Auto-generated method stub
        String returnValue = null;
        listaCargaMensual = new ArrayList<BofCargaMensual>();
        listaPeriodos = new ArrayList<String>();
        setItemPeriodosCbo(new ArrayList<SelectItem>());

        listaPeriodos = bofCargaMensualServiceImpl.listarPeriodos();

        itemPeriodosCbo.add(new SelectItem("", "- Seleccionar -"));
        for (String periodo : listaPeriodos) {
            itemPeriodosCbo.add(new SelectItem(periodo, periodo));
        }


        usuarioDb = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ?
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() :
                SecurityContextHolder.getContext().getAuthentication().getName();
        return returnValue;
    }

    public List<BofCargaMensual> getListaCargaMensual() {
        return listaCargaMensual;
    }

    public void setListaCargaMensual(List<BofCargaMensual> listaCargaMensual) {
        this.listaCargaMensual = listaCargaMensual;
    }


    public String listenerOnline(FileUploadEvent event) {
        String respuesta = null;
        try {
            disabledCargar = true;
            mensajeValidacionUploadFile = "";
            nombreArchivo = new String();
            UploadedFile archivoFile = event.getUploadedFile();
            nombreArchivo = archivoFile.getName().substring(archivoFile.getName().lastIndexOf("\\") + 1);
            archivo = archivoFile;

            mensajeValidacionUploadFile = bofCampoLayoutServiceImpl.validarCamposLayout(archivoFile, SateliteConstants.NOM_TABLA_BOF_CARGAMENSUAL, archivoFile.getName());
            if (mensajeValidacionUploadFile != null) {
                clearUpload();
                return null;
            } else {
                mensajeValidacionUploadFile = null;
                disabledCargar = false;
                listaCargaMensual = FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
                        .get(Constantes.KEY_LIST_MENSUAL_XLSX) == null ? new ArrayList<BofCargaMensual>() : (List<BofCargaMensual>) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(Constantes.KEY_LIST_MENSUAL_XLSX);
                numeroCarga = String.valueOf(listaCargaMensual.size());
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            mensajeValidacionUploadFile = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_CARGA_EXCEL);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
                    null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = ErrorConstants.MSJ_ERROR;
            clearUpload();
        }
        return respuesta;
    }

    public String clearUpload() {

        String respuesta = null;
        try {
            if (archivo != null) {
                archivo.delete();
                archivo = null;
            }
            this.nombreArchivo = null;
            this.disabledCargar = true;
            this.listaCargaMensual = new ArrayList<>();
            numeroCarga = "0";
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
                    null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = ErrorConstants.MSJ_ERROR;
        }
        return respuesta;
    }


    public String mostrarMensajeUploadFile() {
        String respuesta = null;
        try {
            if (mensajeValidacionUploadFile != null) {
                clearUpload();
                SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO, mensajeValidacionUploadFile);
                mensajeValidacionUploadFile = null;
                setIdFileUploadComponent("uploader");
                respuesta = ErrorConstants.MSJ_ERROR;
            } else {
                setIdFileUploadComponent("txtHidden");
                respuesta = Constantes.MSG_CARGA_OK;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
                    null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = ErrorConstants.MSJ_ERROR;
            clearUpload();
        }
        return respuesta;
    }

    public String procesar() {
        logger.info("[procesar bof carga mensual] Inicio");
        String respuesta = null;
        try {
            if (periodoCarga.equals("")) {
                SateliteUtil.mostrarMensaje("Debe seleccionar un periodo de carga");
                return respuesta;
            }
            if (listaCargaMensual.size() != 0) {
                for (BofCargaMensual item : listaCargaMensual) {
                    item.setNomArchivo(this.nombreArchivo);
                }
                bofCargaMensualServiceImpl.InsertarCargaMensual(listaCargaMensual, periodoCarga);
                listaCargaMensual.clear();
                SateliteUtil.mostrarMensaje(PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_PROCESO_CARGA_EXITOSA));
                setNumeroCarga("0");
            } else {
                SateliteUtil.mostrarMensaje(PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_NO_REGISTROS_GRILLA));
            }
        } catch (DuplicateKeyException e) {
            log.error(e.getMessage(), e);
            SateliteUtil.mostrarMensaje(PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_NOMBRE_GENERADO)
                    .replace("@nombreGenerado", e.getLocalizedMessage()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
                    null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = ErrorConstants.MSJ_ERROR;
        } finally {
            clearUpload();
        }
        logger.info("[procesar bof carga mensual] Fin");
        return respuesta;
    }

    public String getIdFileUploadComponent() {
        return idFileUploadComponent;
    }

    public void setIdFileUploadComponent(String idFileUploadComponent) {
        this.idFileUploadComponent = idFileUploadComponent;
    }

    public String getNumeroCarga() {
        return numeroCarga;
    }

    public void setNumeroCarga(String numeroCarga) {
        this.numeroCarga = numeroCarga;
    }


    public String getPeriodoCarga() {
        return periodoCarga;
    }

    public void setPeriodoCarga(String periodoCarga) {
        this.periodoCarga = periodoCarga;
    }

    public List<String> getListaPeriodos() {
        return listaPeriodos;
    }

    public void setListaPeriodos(List<String> listaPeriodos) {
        this.listaPeriodos = listaPeriodos;
    }

    public List<SelectItem> getItemPeriodosCbo() {
        return itemPeriodosCbo;
    }

    public void setItemPeriodosCbo(List<SelectItem> itemPeriodosCbo) {
        this.itemPeriodosCbo = itemPeriodosCbo;
    }
}
