package com.cardif.satelite.bof.controller;

import static com.cardif.satelite.constantes.ErrorConstants.ERROR_SYNCCON;
import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR;
import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.richfaces.component.AbstractExtendedDataTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.bof.bean.BofConfiguracion;
import com.cardif.satelite.bof.service.BofConfiguracionService;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.model.Parametro;

import com.cardif.satelite.util.SateliteUtil;

@Controller("bofconfigController")
@Scope("session")
public class BofConfigController extends BaseController {

    public static final Logger logger = Logger.getLogger(BofConfigController.class);

    @Autowired
    private BofConfiguracionService bofConfiguracionService;
    @Autowired
    private ParametroService parametroService;

    private Collection<Integer> selection;
    private List<BofConfiguracion> varlista;
    private List<BofConfiguracion> listaConfiguracion;

    private List<BofConfiguracion> selectionItems;
    private Collection<Object> selectedRows;


    private List<SelectItem> listaTipoConfiguracion;
    private String codigoTabla;
    private String descripcion;
    private String estadoConfiguracion;
    private String usuarioDB;
    private String codConfig;
    private int numero;
    private int codRegistroConfig;

    private boolean updateMode;

    @Override
    @PostConstruct
    public String inicio() {
        // TODO Auto-generated method stub
        String respuesta = null;
        codigoTabla = "0";
        listaConfiguracion = new ArrayList<BofConfiguracion>();
        logger.info("inicio BOF carga de datos configuracion");
        if (!tieneAcceso()) {
            logger.debug("No cuenta con los accesos necesarios");
            return "accesoDenegado";
        }
        setListaTipoConfiguracion(new ArrayList<SelectItem>());
        selectionItems = new ArrayList<>();
        selectedRows = new ArrayList<>();
        try {
            List<Parametro> tablasBofconfig = null;
            tablasBofconfig = parametroService.buscar(Constantes.COD_VALOR_BOFCONF, Constantes.TIP_PARAM_DETALLE);

            getListaTipoConfiguracion().add(new SelectItem("", "- Seleccionar -"));
            for (Parametro p : tablasBofconfig) {
                getListaTipoConfiguracion().add(new SelectItem(p.getCodValor(), p.getNomValor()));
            }

            usuarioDB = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString()
                    .length() > 1)
                    ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID")
                    .toString()
                    : SecurityContextHolder.getContext().getAuthentication().getName();

        } catch (SyncconException ex) {
            logger.error(ERROR_SYNCCON + ex.getMessageComplete());
            FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = MSJ_ERROR;
        }
        logger.info("fin BOF carga de datos configuracion");
        return respuesta;
    }

    public String listarConfiguracion() {
        String respuesta = "";
        varlista = new ArrayList<BofConfiguracion>();
        log.info("Inicio buscar BOF configuracion");
        try {
            if (this.codigoTabla.equals("")) {
                SateliteUtil.mostrarMensaje("Debe seleccionar el tipo de parametro");
                return respuesta;
            }
            listaConfiguracion = bofConfiguracionService.listarConfiguracion(Integer.parseInt(this.codigoTabla));
            numero = listaConfiguracion.size();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = MSJ_ERROR;
        }
        log.info("Fin buscar BOF configuracion");
        return respuesta;
    }

    public String limpiar() {
        String respuesta = null;
        try {
            setVarlista(new ArrayList<BofConfiguracion>());
            setSelection(new ArrayList<Integer>());
            listaConfiguracion = new ArrayList<BofConfiguracion>();
            this.setDescripcion(null);
            this.setEstadoConfiguracion("0");
            this.setCodConfig(null);
            numero = 0;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = MSJ_ERROR;
        }
        return respuesta;
    }

    public String registrarConfiguracion() {

        String respuesta = null;
        String msgValidacion = "";
        try {
            msgValidacion = validarParametros();
            if (!msgValidacion.equals("")) {
                SateliteUtil.mostrarMensaje(msgValidacion);
                return respuesta;
            }
            if (this.isUpdateMode()) {
                respuesta = modificarConfiguracion();
            } else {
                BofConfiguracion configuracion = new BofConfiguracion();
                configuracion.setCodConfig(this.getCodConfig());
                configuracion.setCodTable(Integer.parseInt(this.getCodigoTabla()));
                configuracion.setDescripcion(this.getDescripcion());
                configuracion.setActivo(this.getEstadoConfiguracion().equals("1"));
                configuracion.setUsuarioRegistro(this.usuarioDB);
                bofConfiguracionService.crearBofConfiguracion(configuracion);
                limpiar();
                listaConfiguracion = bofConfiguracionService.listarConfiguracion(Integer.parseInt(this.codigoTabla));
                this.numero = listaConfiguracion.size();
                respuesta = "consultaBofParam";
            }
        } catch (DuplicateKeyException e) {
            log.error(e.getMessage(), e);
            SateliteUtil.mostrarMensaje("El codigo de parametro " +  this.getCodConfig() + " que se intenta registrar ya existe para otra configuración");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
                    null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = ErrorConstants.MSJ_ERROR;
        }
        logger.info("[procesar] Fin");
        return respuesta;
    }

    private String validarParametros() {
        String msgRespuesta = "";
        if (this.getCodConfig().equals("")) return "Debe ingresar el codigo de configuración";
        if (this.getDescripcion().equals("")) return "Debe ingresar la descripción";
        if (this.codigoTabla.equals("")) return "Debe seleccionar el tipo de Parametro";
        return msgRespuesta;
    }

    public String showRegistrarConfig() {
        this.setUpdateMode(false);
        return "registrar";
    }

    public String showModificarConfig() {
        if (listaConfiguracion.size() == 0) {
            SateliteUtil.mostrarMensaje("Debe realizar una busqueda y seleccionar un registro para realizar esta accion");
            return "";
        } else if (this.codRegistroConfig == 0) {
            SateliteUtil.mostrarMensaje("Debe seleccionar registro a modificar");
            return "";
        }
        this.setUpdateMode(true);
        BofConfiguracion c = selectionItems.get(0);
        this.setCodigoTabla(String.valueOf(c.getCodTable()));
        this.setDescripcion(c.getDescripcion());
        this.codConfig = c.getCodConfig();
        this.codRegistroConfig = c.getCodRegistro();
        this.setEstadoConfiguracion(c.isActivo() ? "1" : "0");
        return "editar";
    }

    public String cancelar() {
        this.limpiar();
        return "consultaBofParam";
    }

    public void selectionListener(AjaxBehaviorEvent event) {
        AbstractExtendedDataTable dataTable = (AbstractExtendedDataTable) event.getComponent();
        Object originalKey = dataTable.getRowKey();
        getSelectionItems().clear();
        for (Object selectionKey : getSelectedRows()) {
            dataTable.setRowKey(selectionKey);
            if (dataTable.isRowAvailable()) {
                getSelectionItems().add((BofConfiguracion) dataTable.getRowData());
            }
        }
        dataTable.setRowKey(originalKey);
        codRegistroConfig = selectionItems.get(0).getCodRegistro();
    }

    public String modificarConfiguracion() throws Exception {
        String respuesta = null;
        try {
            BofConfiguracion configuracion = new BofConfiguracion();

            configuracion.setCodRegistro(codRegistroConfig);
            configuracion.setCodConfig(this.getCodConfig());
            configuracion.setDescripcion(this.getDescripcion());
            configuracion.setActivo(this.getEstadoConfiguracion().equals("1"));
            configuracion.setUsuarioModificacion(this.usuarioDB);
            bofConfiguracionService.actualizarBofConfiguracion(configuracion);
            limpiar();
            listaConfiguracion = bofConfiguracionService.listarConfiguracion(Integer.parseInt(this.codigoTabla));
            this.numero = listaConfiguracion.size();
            respuesta = "consultaBofParam";
        }catch (DuplicateKeyException e) {
            log.error(e.getMessage(), e);
            SateliteUtil.mostrarMensaje("El codigo de parametro " +  this.getCodConfig() + " que se intenta registrar ya existe para otra configuración");
        }catch (Exception e) {
            throw e;
        }
        return respuesta;
    }

    public String eliminarConfig() {
        String respuesta = null;
        if (listaConfiguracion.size() == 0) {
            SateliteUtil.mostrarMensaje("Debe realizar una busqueda y seleccionar yn registro para realizar esta accion");
            return "";
        } else if (this.codRegistroConfig == 0) {
            SateliteUtil.mostrarMensaje("Debe seleccionar registro a modificar");
            return "";
        }
        try {
            BofConfiguracion configuracion = new BofConfiguracion();
            configuracion.setCodRegistro(codRegistroConfig);
            configuracion.setUsuarioModificacion(usuarioDB);
            bofConfiguracionService.eliminarBofConfiguracion(configuracion);
            limpiar();
            listaConfiguracion = bofConfiguracionService.listarConfiguracion(Integer.parseInt(this.codigoTabla));
            this.numero = listaConfiguracion.size();
        } catch (DuplicateKeyException e) {
            log.error(e.getMessage(), e);
            SateliteUtil.mostrarMensaje(PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_NOMBRE_GENERADO)
                    .replace("@nombreGenerado", e.getLocalizedMessage()));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
                    null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = ErrorConstants.MSJ_ERROR;
        }

        return respuesta;
    }


    //region getters y setters
    public String getCodigoTabla() {
        return codigoTabla;
    }

    public void setCodigoTabla(String codigoTabla) {
        this.codigoTabla = codigoTabla;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<SelectItem> getListaTipoConfiguracion() {
        return listaTipoConfiguracion;
    }

    public void setListaTipoConfiguracion(List<SelectItem> listaTipoConfiguracion) {
        this.listaTipoConfiguracion = listaTipoConfiguracion;
    }

    public List<BofConfiguracion> getVarlista() {
        return varlista;
    }

    public void setVarlista(List<BofConfiguracion> varlista) {
        this.varlista = varlista;
    }

    public List<BofConfiguracion> getListaConfiguracion() {
        return listaConfiguracion;
    }

    public void setListaConfiguracion(List<BofConfiguracion> listaConfiguracion) {
        this.listaConfiguracion = listaConfiguracion;
    }

    public Collection<Integer> getSelection() {
        return selection;
    }

    public void setSelection(Collection<Integer> selection) {
        this.selection = selection;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstadoConfiguracion() {
        return estadoConfiguracion;
    }

    public void setEstadoConfiguracion(String estadoConfiguracion) {
        this.estadoConfiguracion = estadoConfiguracion;
    }

    public boolean isUpdateMode() {
        return updateMode;
    }

    public void setUpdateMode(boolean updateMode) {
        this.updateMode = updateMode;
    }

    public String getCodConfig() {
        return codConfig;
    }

    public void setCodConfig(String codConfig) {
        this.codConfig = codConfig;
    }

    public List<BofConfiguracion> getSelectionItems() {
        return selectionItems;
    }

    public void setSelectionItems(List<BofConfiguracion> selectionItems) {
        this.selectionItems = selectionItems;
    }

    public Collection<Object> getSelectedRows() {
        return selectedRows;
    }

    public void setSelectedRows(Collection<Object> selectedRows) {
        this.selectedRows = selectedRows;
    }

    //endregion
}
