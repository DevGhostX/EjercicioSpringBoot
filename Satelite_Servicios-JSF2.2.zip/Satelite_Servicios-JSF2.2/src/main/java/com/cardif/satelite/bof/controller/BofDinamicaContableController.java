package com.cardif.satelite.bof.controller;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import com.cardif.satelite.util.SateliteUtil;
import org.apache.log4j.Logger;
import org.richfaces.component.AbstractExtendedDataTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.satelite.bof.bean.BofConfiguracion;
import com.cardif.satelite.bof.bean.BofDinamicaContable;
import com.cardif.satelite.bof.model.ConsultaDinamicaModel;
import com.cardif.satelite.bof.model.DinamicaContableModel;
import com.cardif.satelite.bof.service.BofConfiguracionService;
import com.cardif.satelite.bof.service.BofDinamicaContableService;

@Controller("bofDinamicaContableController")
@Scope("session")
public class BofDinamicaContableController extends BaseController {

    public static final Logger logger = Logger.getLogger(BofDinamicaContableController.class);

    @Autowired
    private BofDinamicaContableService dinamicaService;

    @Autowired
    private BofConfiguracionService configService;

    private BofDinamicaContable dinamicaContable;
    private ConsultaDinamicaModel consultaModel;
    private List<DinamicaContableModel> listaDinamicaContable;
    private int numeroRegistros;
    private String currentUser;
    private boolean updateMode;

    private List<SelectItem> listaInstrumento;
    private List<SelectItem> listaOperacion;
    private List<SelectItem> listaEmisor;
    private Collection<Object> selectedRows;

    private List<SelectItem> listaCuentasContables;


    private List<DinamicaContableModel> selectionItems = new ArrayList<DinamicaContableModel>();

    @Override
    @PostConstruct
    public String inicio() {
        if (!tieneAcceso()) {
            logger.debug("No cuenta con los accesos necesarios");
            return "accesoDenegado";
        }
        dinamicaContable = new BofDinamicaContable();
        consultaModel = new ConsultaDinamicaModel();
        CargarListas();
        //cargarListaDinamicaContable();
        setListaDinamicaContable(new ArrayList<DinamicaContableModel>());
        currentUser = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString()
                .length() > 1)
                ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString()
                : SecurityContextHolder.getContext().getAuthentication().getName();

        return null;
    }

    private void CargarListas() {
        List<BofConfiguracion> tipoInstrumentoList;
        List<BofConfiguracion> tipoOperacionList;
        List<BofConfiguracion> emisorList;
        List<BofConfiguracion> cuentasContablesList;

        setListaInstrumento(new ArrayList<SelectItem>());
        setListaEmisor(new ArrayList<SelectItem>());
        setListaOperacion(new ArrayList<SelectItem>());
        setListaCuentasContables(new ArrayList<>());

        try {

            getListaInstrumento().add(new SelectItem("", "- Seleccionar -"));
            getListaEmisor().add(new SelectItem("", "- Seleccionar -"));
            getListaOperacion().add(new SelectItem("", "- Seleccionar -"));
            getListaCuentasContables().add(new SelectItem("", "- Seleccionar -"));

            tipoInstrumentoList = configService.listarConfiguracion(10);
            emisorList = configService.listarConfiguracion(40);
            tipoOperacionList = configService.listarConfiguracion(30);
            cuentasContablesList = configService.listarConfiguracion(50);

            for (BofConfiguracion config : tipoInstrumentoList) {
                if (config.isActivo())
                    getListaInstrumento().add(new SelectItem(config.getCodConfig(), config.getDescripcion()));
            }
            for (BofConfiguracion config : emisorList) {
                if (config.isActivo())
                    getListaEmisor().add(new SelectItem(config.getCodConfig(), config.getDescripcion()));
            }
            for (BofConfiguracion config : tipoOperacionList) {
                if (config.isActivo())
                    getListaOperacion().add(new SelectItem(config.getCodConfig(), config.getDescripcion()));
            }

            for (BofConfiguracion config : cuentasContablesList) {
                if (config.isActivo())
                    listaCuentasContables.add(new SelectItem(config.getCodConfig(), config.getCodConfig()));
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
    }

    public String mostrarRegistro() {
        String respuesta = null;
        respuesta = "registrar";
        this.updateMode = false;
        this.dinamicaContable = new BofDinamicaContable();
        return respuesta;
    }

    public String mostrarActualizacion() {
        String respuesta = null;
        if (this.listaDinamicaContable.size() == 0) {
            SateliteUtil.mostrarMensaje("Debe realizar una busqueda y seleccionar un registro para realizar esta accion");
            return "";
        } else if (this.selectionItems.size() == 0) {
            SateliteUtil.mostrarMensaje("Debe seleccionar registro a modificar");
            return "";
        }
        this.updateMode = true;
        DinamicaContableModel model = selectionItems.get(0);
        this.dinamicaContable = dinamicaService.obtenerPorId(model.getCodDinamica());
        respuesta = "editar";
        return respuesta;
    }

    public String cancelarOperacion() {
        String respuesta = null;

        respuesta = "cancela";
        this.updateMode = false;
        return respuesta;
    }

    public String registrarDinamica() {
        String respuesta = null;
        if (!this.updateMode) {
            try {
                String msgValidacion = validaDinamica();
                if (!msgValidacion.isEmpty()) {
                    SateliteUtil.mostrarMensaje(msgValidacion);
                    return null;
                }

                this.dinamicaContable.setUsuarioRegistro(currentUser);
                dinamicaService.RegistrarDinamicaContable(this.dinamicaContable);
                this.cargarListaDinamicaContable();
                this.dinamicaContable = new BofDinamicaContable();
                respuesta = "consultar";
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
                FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
                FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            }
        } else {
            return actualizarDinamica();
        }
        return respuesta;
    }

    private String validaDinamica() {
        String msg = "";
        if (this.dinamicaContable.getCodInstrumento().isEmpty()) return "Debe seleccionar el instrumento";
        if (this.dinamicaContable.getCodOperacion().isEmpty()) return "Debe seleccionar el tipo operacion";
        if (this.dinamicaContable.getNumeroCuenta().isEmpty()) return "Debe ingresar el numero de cuenta";
        if (this.dinamicaContable.getCreditoDebito().isEmpty()) return "Debe Ingresar debito/credito";
        if (this.dinamicaContable.getLineaAsiento() == 0) return "Debe Ingresar numero de linea";

        return msg;
    }

    public String actualizarDinamica() {
        String respuesta = null;
        try {
            String msgValidacion = validaDinamica();
            if (!msgValidacion.isEmpty()) {
                SateliteUtil.mostrarMensaje(msgValidacion);
                return null;
            }
            this.dinamicaContable.setUsuarioModif(currentUser);
            dinamicaService.ActualizaDinamicaContable(this.dinamicaContable);
            this.cargarListaDinamicaContable();
            this.dinamicaContable = new BofDinamicaContable();
            respuesta = "consultar";
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
        return respuesta;
    }

    public String elimicaDinamica() {
        String respuesta = null;
        if (this.listaDinamicaContable.size() == 0) {
            SateliteUtil.mostrarMensaje("Debe realizar una busqueda y seleccionar un registro para realizar esta accion");
            return "";
        } else if (this.selectionItems.size() == 0) {
            SateliteUtil.mostrarMensaje("Debe seleccionar registro a eliminar");
            return "";
        }
        try {
            DinamicaContableModel model = selectionItems.get(0);
            dinamicaService.InactivaDinamicaContable(model.getCodDinamica());
            this.cargarListaDinamicaContable();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
        return respuesta;
    }

    public void cargarListaDinamicaContable() {
        try {
            this.listaDinamicaContable = dinamicaService.listarDinamicaContable(this.consultaModel);
            this.numeroRegistros = this.listaDinamicaContable.size();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
    }

    public void selectionListener(AjaxBehaviorEvent event) {
        AbstractExtendedDataTable dataTable = (AbstractExtendedDataTable) event.getComponent();
        Object originalKey = dataTable.getRowKey();
        selectionItems.clear();
        for (Object selectionKey : selectedRows) {
            dataTable.setRowKey(selectionKey);
            if (dataTable.isRowAvailable()) {
                selectionItems.add((DinamicaContableModel) dataTable.getRowData());
            }
        }
        dataTable.setRowKey(originalKey);
    }


    // region getters y setters
    public BofDinamicaContable getDinamicaContable() {
        return dinamicaContable;
    }

    public void setDinamicaContable(BofDinamicaContable dinamicaContable) {
        this.dinamicaContable = dinamicaContable;
    }

    public List<DinamicaContableModel> getListaDinamicaContable() {
        return listaDinamicaContable;
    }

    public void setListaDinamicaContable(List<DinamicaContableModel> listaDinamicaContable) {
        this.listaDinamicaContable = listaDinamicaContable;
    }

    public int getNumeroRegistros() {
        return numeroRegistros;
    }

    public void setNumeroRegistros(int numeroRegistros) {
        this.numeroRegistros = numeroRegistros;
    }

    public List<SelectItem> getListaInstrumento() {
        return listaInstrumento;
    }

    public void setListaInstrumento(List<SelectItem> listaInstrumento) {
        this.listaInstrumento = listaInstrumento;
    }

    public List<SelectItem> getListaOperacion() {
        return listaOperacion;
    }

    public void setListaOperacion(List<SelectItem> listaOperacion) {
        this.listaOperacion = listaOperacion;
    }

    public List<SelectItem> getListaEmisor() {
        return listaEmisor;
    }

    public void setListaEmisor(List<SelectItem> listaEmisor) {
        this.listaEmisor = listaEmisor;
    }

    public ConsultaDinamicaModel getConsultaModel() {
        return consultaModel;
    }

    public void setConsultaModel(ConsultaDinamicaModel consultaModel) {
        this.consultaModel = consultaModel;
    }

    public Collection<Object> getSelectedRows() {
        return selectedRows;
    }

    public void setSelectedRows(Collection<Object> selectedRows) {
        this.selectedRows = selectedRows;
    }

    public boolean isUpdateMode() {
        return updateMode;
    }

    public void setUpdateMode(boolean updateMode) {
        this.updateMode = updateMode;
    }

    public List<SelectItem> getListaCuentasContables() {
        return listaCuentasContables;
    }

    public void setListaCuentasContables(List<SelectItem> listaCuentasContables) {
        this.listaCuentasContables = listaCuentasContables;
    }

    //endregion getters

}
