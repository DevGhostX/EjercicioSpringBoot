package com.cardif.satelite.bof.controller;

import java.util.ArrayList;
import java.util.List;

import com.cardif.framework.controller.BaseController;
import com.cardif.satelite.bof.bean.BofConfiguracion;
import com.cardif.satelite.bof.bean.BofLoteAsientos;
import com.cardif.satelite.bof.bean.BofParamsGeneracionAsientos;
import com.cardif.satelite.bof.model.GeneraAsientoError;
import com.cardif.satelite.bof.model.GeneraAsientoResult;
import com.cardif.satelite.bof.service.BofAsientoInversionService;
import com.cardif.satelite.bof.service.BofConfiguracionService;
import com.cardif.satelite.bof.service.impl.BofCargaMensualServiceImpl;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.SateliteUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

@Controller("bofGeneraAsientosInvController")
@Scope("session")
public class BofGeneraAsientosInvController extends BaseController {
    public static final Logger logger = Logger.getLogger(BofGeneraAsientosInvController.class);

    @Autowired
    private BofConfiguracionService configService;
    @Autowired
    private BofAsientoInversionService bofAsientoService;
    @Autowired
    private ParametroService parametroService;
    @Autowired
    private BofCargaMensualServiceImpl periodosService;

    private List<Parametro> listaTipoCarga;
    private List<BofConfiguracion> listaTipoOperacion;
    private List<BofConfiguracion> listaTipodiario;
    private List<String> listaPeriodos;

    private List<BofLoteAsientos> listaVistaPrevia;
    private List<GeneraAsientoError> listaNoGenerados;
    private List<BofLoteAsientos> listaNumDiario;
    private BofParamsGeneracionAsientos parametros;
    private List<SelectItem> listaSelectTipoCarga;
    private List<SelectItem> listaSelectOperacion;
    private List<SelectItem> listaSelectDiario;
    private List<SelectItem> listaSelectPeriodos;
    private String currentUser;
    private boolean calendarDisable;
    private boolean cbotipoDisable;

    private boolean errorEnvio;
    private int numeroRegistros;
    private boolean disableGenerar;
    private int numeroRegistrosNoGenerados;

    private boolean asientosEnviados;


    private void cargarListas() {
        setListaSelectTipoCarga(new ArrayList<SelectItem>());
        listaSelectPeriodos = new ArrayList<SelectItem>();
        listaSelectDiario = new ArrayList<SelectItem>();
        setListaSelectOperacion(new ArrayList<SelectItem>());
        try {
            getListaSelectTipoCarga().add(new SelectItem("", "- Seleccionar -"));
            listaTipoCarga = parametroService.buscar(Constantes.COD_VALOR_TIPOCARGA, Constantes.TIP_PARAM_DETALLE);
            for (Parametro config : listaTipoCarga) {
                getListaSelectTipoCarga().add(new SelectItem(config.getCodValor(), config.getNomValor()));
            }

            listaPeriodos = periodosService.listarPeriodos();
            listaTipodiario = configService.listarConfiguracion(20);

            listaSelectPeriodos.add(new SelectItem("", "- Seleccionar -"));
            listaSelectDiario.add(new SelectItem("", "- Seleccionar -"));
            for (String periodo : listaPeriodos) {
                listaSelectPeriodos.add(new SelectItem(periodo, periodo));
            }

            for (BofConfiguracion config : listaTipodiario) {
                if (config.isActivo())
                    listaSelectDiario.add(new SelectItem(config.getCodConfig(), config.getDescripcion()));
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
    }

    public void cargarListaTipoOperacion(ValueChangeEvent event) {
        String newValue = "";
        setListaSelectOperacion(new ArrayList<SelectItem>());
        if (this.getParametros().getTipoCarga().equals("")) return;
        getListaSelectOperacion().add(new SelectItem("", "- Seleccionar -"));

        try {
            newValue = (String) event.getNewValue();
            if (newValue.isEmpty()) return;
            listaTipoOperacion = configService.listarConfiguracion(30);
            if (newValue.equals("MOV")) {
                this.calendarDisable = false;
                this.cbotipoDisable = true;
                this.parametros.setTipoCarga("");
            } else {
                this.cbotipoDisable = false;
                this.calendarDisable = true;
                this.parametros.setFechaProcesoMensual(null);
            }

            for (BofConfiguracion config : listaTipoOperacion) {
                if (config.isActivo() && config.getCodConfig().startsWith(newValue))
                    getListaSelectOperacion().add(new SelectItem(config.getCodConfig(), config.getDescripcion()));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
    }

    public String generarAsientos() {
        String respuesta = "";
        GeneraAsientoResult result = new GeneraAsientoResult();
        setListaVistaPrevia(new ArrayList<>());
        this.asientosEnviados = false;
        this.listaNumDiario = new ArrayList<>();
        this.parametros.setUsuarioGenera(this.currentUser);
        if (this.parametros.getTipoOperacion() == null) this.parametros.setTipoOperacion("");
        try {
            String msgValidacion = validaGeneracion();
            if (!msgValidacion.isEmpty()) {
                SateliteUtil.mostrarMensaje(msgValidacion);
                return respuesta;
            }
            result = bofAsientoService.generarDetalleAsientos(this.parametros);
            this.setListaVistaPrevia(result.getAsientoGenerados());
            this.setListaNoGenerados(result.getAsientosNoGenerado());
            numeroRegistros = this.getListaVistaPrevia().size();
            numeroRegistrosNoGenerados = this.getListaNoGenerados().size();
            if (numeroRegistros == 0) {
                SateliteUtil.mostrarMensaje("No hay asientos por procesar con los parametros indicados");
                this.disableGenerar = false;
            } else {
                this.disableGenerar = true;
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
        return respuesta;
    }

    private String validaGeneracion() {
        String msg = "";
        if (this.getParametros().getTipoCarga().isEmpty()) return "Debe Seleccionar el tipo Carga";
        if (this.getParametros().getPeriodoCarga().isEmpty()) return "Debe seleccionar un periodo de carga";
        if (this.getParametros().getTipoDiario().isEmpty()) return "Debe seleccionar un tipo diario";

        if (this.getParametros().getTipoCarga().equals("MOV")) {
            if (this.getParametros().getFechaProcesoMensual() == null) return "Debe ingresar fecha proceso";
        } else {
            if (this.getParametros().getTipoOperacion().isEmpty()) return "Debe seleccionar un tipo de operacion";
        }
        return msg;
    }

    public String enviarAsientos() {
        String respuesta = "";
        try {
            if (this.getListaVistaPrevia().size() == 0) {
                SateliteUtil.mostrarMensaje("Para enviar asientos, debe primero generarlos");
                this.asientosEnviados = false;
                this.listaNumDiario = new ArrayList<>();
                return respuesta;
            }
            listaNumDiario = bofAsientoService.enviarDetalleAsientos(this.getListaVistaPrevia());
            if (listaNumDiario == null) {
                SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL);
                respuesta = "error";
                return respuesta;
            } else {
                for (BofLoteAsientos l : listaNumDiario) {
                    if (l.getEstEnvio().equals(SateliteConstants.BOF_EST_ASIENTO_ENVIADO_ERROR)) {
                        errorEnvio = true;
                        break;
                    }
                }
            }
            if (errorEnvio) {
                SateliteUtil.mostrarMensaje("Proceso finalizó con asiento(s) no enviado(s)");
            } else {
                SateliteUtil.mostrarMensaje("ASIENTOS ENVIADOS EXITOSAMENTE");
            }
            this.asientosEnviados = true;
            this.disableGenerar = false;
            this.disposeController();

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }
        return respuesta;
    }

    @Override
    @PostConstruct
    public String inicio() {
        if (!tieneAcceso()) {
            logger.debug("No cuenta con los accesos necesarios");
            return "accesoDenegado";
        }
        this.cargarListas();
        parametros = new BofParamsGeneracionAsientos();
        this.listaVistaPrevia = new ArrayList<>();
        this.listaNumDiario = new ArrayList<BofLoteAsientos>();
        currentUser = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString()
                .length() > 1)
                ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString()
                : SecurityContextHolder.getContext().getAuthentication().getName();

        this.disableGenerar = false;
        return null;
    }

    private void disposeController() {
        this.listaVistaPrevia = new ArrayList<>();
        this.parametros = new BofParamsGeneracionAsientos();
        this.numeroRegistros = 0;
        this.disableGenerar = false;
    }

    public String cancelar() {
        String msg = "";
        bofAsientoService.cancelaGeneracion(this.getParametros());
        disposeController();
        return msg;
    }

    //region getters setters

    public List<BofLoteAsientos> getListaVistaPrevia() {
        return listaVistaPrevia;
    }

    public void setListaVistaPrevia(List<BofLoteAsientos> listaVistaPrevia) {
        this.listaVistaPrevia = listaVistaPrevia;
    }

    public BofParamsGeneracionAsientos getParametros() {
        return parametros;
    }

    public void setParametros(BofParamsGeneracionAsientos parametros) {
        this.parametros = parametros;
    }

    public List<SelectItem> getListaSelectTipoCarga() {
        return listaSelectTipoCarga;
    }

    public void setListaSelectTipoCarga(List<SelectItem> listaSelectTipoCarga) {
        this.listaSelectTipoCarga = listaSelectTipoCarga;
    }

    public List<SelectItem> getListaSelectOperacion() {
        return listaSelectOperacion;
    }

    public void setListaSelectOperacion(List<SelectItem> listaSelectOperacion) {
        this.listaSelectOperacion = listaSelectOperacion;
    }

    public String getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(String currentUser) {
        this.currentUser = currentUser;
    }

    public List<SelectItem> getListaSelectPeriodos() {
        return listaSelectPeriodos;
    }

    public void setListaSelectPeriodos(List<SelectItem> listaSelectPeriodos) {
        this.listaSelectPeriodos = listaSelectPeriodos;
    }

    public boolean isCalendarDisable() {
        return calendarDisable;
    }

    public void setCalendarDisable(boolean calendarDisable) {
        this.calendarDisable = calendarDisable;
    }

    public boolean isCbotipoDisable() {
        return cbotipoDisable;
    }

    public void setCbotipoDisable(boolean cbotipoDisable) {
        this.cbotipoDisable = cbotipoDisable;
    }

    public List<SelectItem> getListaSelectDiario() {
        return listaSelectDiario;
    }

    public void setListaSelectDiario(List<SelectItem> listaSelectDiario) {
        this.listaSelectDiario = listaSelectDiario;
    }

    public List<BofLoteAsientos> getListaNumDiario() {
        return listaNumDiario;
    }

    public void setListaNumDiario(List<BofLoteAsientos> listaNumDiario) {
        this.listaNumDiario = listaNumDiario;
    }

    public boolean getErrorEnvio() {
        return errorEnvio;
    }

    public void setErrorEnvio(boolean errorEnvio) {
        this.errorEnvio = errorEnvio;
    }

    public int getNumeroRegistros() {
        return numeroRegistros;
    }

    public void setNumeroRegistros(int numeroRegistros) {
        this.numeroRegistros = numeroRegistros;
    }

    public boolean isDisableGenerar() {
        return disableGenerar;
    }

    public void setDisableGenerar(boolean disableGenerar) {
        this.disableGenerar = disableGenerar;
    }

    public List<GeneraAsientoError> getListaNoGenerados() {
        return listaNoGenerados;
    }

    public void setListaNoGenerados(List<GeneraAsientoError> listaNoGenerados) {
        this.listaNoGenerados = listaNoGenerados;
    }

    public int getNumeroRegistrosNoGenerados() {
        return numeroRegistrosNoGenerados;
    }

    public void setNumeroRegistrosNoGenerados(int numeroRegistrosNoGenerados) {
        this.numeroRegistrosNoGenerados = numeroRegistrosNoGenerados;
    }

    public boolean isAsientosEnviados() {
        return asientosEnviados;
    }

    public void setAsientosEnviados(boolean asientosEnviados) {
        this.asientosEnviados = asientosEnviados;
    }


    //endregion getters setters

}
