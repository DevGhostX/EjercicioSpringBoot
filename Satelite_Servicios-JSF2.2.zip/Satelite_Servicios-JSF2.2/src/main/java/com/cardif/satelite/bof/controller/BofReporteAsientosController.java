package com.cardif.satelite.bof.controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.bof.bean.BofConfiguracion;
import com.cardif.satelite.bof.bean.BofLoteAsientos;
import com.cardif.satelite.bof.bean.BofParamsReporte;
import com.cardif.satelite.bof.service.BofAsientoInversionService;
import com.cardif.satelite.bof.service.BofConfiguracionService;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.omg.IOP.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR;
import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;


@Controller("bofReporteAsientosController")
@Scope("session")
public class BofReporteAsientosController extends BaseController {
    public static final Logger logger = Logger.getLogger(BofReporteAsientosController.class);

    @Autowired
    private BofAsientoInversionService bofAsientoService;

    @Autowired
    private BofConfiguracionService configService;

    private Date fechaEnvioSun;

    private List<BofLoteAsientos> datosReporte;

    private List<SelectItem> listaSelectDiario;
    private List<BofConfiguracion> listaTipodiario;

    private  int numeroRegistros;
    private BofParamsReporte paramsReporte;

    private Map<String, Object> params;
    JasperReport report;
    ServletOutputStream out;

    public String consultaDatosReporte(){
        String respuesta ="";
        try{
            setDatosReporte(new ArrayList<>());
            String msgValidacion = validarParametros();
            if(msgValidacion.equals("")) {
                setDatosReporte(bofAsientoService.generaReporteFechaEnvioSun(this.getParamsReporte()));
                numeroRegistros = this.datosReporte.size();
                if(numeroRegistros==0)SateliteUtil.mostrarMensaje("No se encontraron registros con los filtros ingresados");
            }
            else
                SateliteUtil.mostrarMensaje(msgValidacion);

        }catch (Exception e){
            throw e;
        }
        return  respuesta;
    }

    private String validarParametros() {
        String message = "";
        if(paramsReporte.getFecInicio() == null && paramsReporte.getFecFin()!=null)
            return "Debe ingresar la fecha transacción desde";
        if(paramsReporte.getFecFin() == null && paramsReporte.getFecInicio() != null)
            return "Debe ingresar la fecha transacción hasta";

        if(paramsReporte.getPerIni().equals("") && !paramsReporte.getPerFin().equals(""))
            return "Debe ingresar el periodo inicial [PPPAAAA]";
        if(paramsReporte.getPerFin().equals("") && !paramsReporte.getPerIni().equals(""))
            return "Debe ingresar el periodo final [PPPAAAA]";

        if (paramsReporte.getFecInicio() != null && paramsReporte.getFecFin()!=null) {
            if(!Utilitarios.validarFechasInicioFin(paramsReporte.getFecInicio(), paramsReporte.getFecFin()))
                return "La fecha de inicio debe ser menor a la fecha termino";
        }

        if(paramsReporte.getTipodiario().isEmpty()) return "Debe seleccionar un tipo de diario";
        return message;
    }

    public String exportaExcel(){
        String respuesta = null;

        Map<String, Object> beans = new HashMap<String, Object>();
        try{
            if(this.datosReporte.size()==0){
                SateliteUtil.mostrarMensaje("Debe realizar una busqueda antes de exportar a Excel");
                return "";
            }
            beans.put("exportar", this.datosReporte);
            String rutaTemp = System.getProperty("java.io.tmpdir") + "historial-asientos" + System.currentTimeMillis() + ".xls";
            logger.debug("Ruta Archivo: " + rutaTemp);

            ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();
            FacesContext fc = FacesContext.getCurrentInstance();
            ServletContext sc = (ServletContext) fc.getExternalContext().getContext();
            String rutaTemplate = sc.getRealPath(File.separator + "excel" + File.separator + "template-historial-asientosbof.xls");

            XLSTransformer transformer = new XLSTransformer();
            transformer.transformXLS(rutaTemplate, beans, rutaTemp);
            File archivoResp = new File(rutaTemp);
            FileInputStream in = new FileInputStream(archivoResp);
            HttpServletResponse response = (HttpServletResponse) contexto.getResponse();
            byte[] loader = new byte[(int) archivoResp.length()];
            response.addHeader("Content-Disposition","attachment;filename=" + "HistorialAsientos.xls");
            response.setContentType("application/vnd.ms-excel");
            ServletOutputStream out = response.getOutputStream();

            while ((in.read(loader)) > 0) {
                out.write(loader, 0, loader.length);
            }
            in.close();
            out.close();
            FacesContext.getCurrentInstance().responseComplete();
        }catch (Exception e) {
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
                    null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }


        return respuesta;
    }

    public String exportaPdf(){
        String respuesta = "";
        try{
            if(this.datosReporte.size()==0){
                SateliteUtil.mostrarMensaje("Debe realizar una busqueda antes de exportar a PDF");
                return "";
            }
            iniciaGeneraPlantilla("historial-asientosbof.jasper");
            //iniciaGeneraPlantilla("PlantillaAnalisis.jasper");
            terminaGeneraPlantilla("historial-asientos");
        }catch(Exception e){
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
            respuesta = MSJ_ERROR;
        }
        return respuesta;
    }

    private void iniciaGeneraPlantilla(String planilla) throws Exception {

        FacesContext fc = FacesContext.getCurrentInstance();
        params = new HashMap<>();
        ExternalContext externalContext = fc.getExternalContext();
        HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();
        ServletContext sc = (ServletContext) externalContext.getContext();
        InputStream jasperStream = externalContext.getResourceAsStream("/jasper/" + planilla);
        //InputStream jasperStream = TransactionService.class.getResourceAsStream(externalContext.getRealPath("jasper") +"/"+ planilla);
        out = response.getOutputStream();
        report = (JasperReport) JRLoader.loadObject(jasperStream);
        params = new HashMap<String, Object>();
    }

    private void terminaGeneraPlantilla(String namePlantilla) throws Exception {

        FacesContext fc = FacesContext.getCurrentInstance();


        ExternalContext externalContext = fc.getExternalContext();
        HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

        out = response.getOutputStream();
        File pdfFile = new File(System.getProperty("java.io.tmpdir") + namePlantilla + ".pdf");
        if (!pdfFile.exists()) {
            pdfFile.createNewFile();
        }
        FileInputStream pdfIn = new FileInputStream(pdfFile);
        IOUtils.copy(pdfIn, out);
        response.addHeader("Content-Disposition", "attachment;filename=" + pdfFile.getName());
        response.setContentType("application/pdf");
        pdfIn.close();
        JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(this.datosReporte);
        ds.moveFirst();
        params.put("ds",ds);
        JasperPrint print = JasperFillManager.fillReport(report, params, new JREmptyDataSource());
        JasperExportManager.exportReportToPdfStream(print, out);
        FacesContext.getCurrentInstance().responseComplete();
        pdfFile.delete();
    }

    @Override
    @PostConstruct
    public String inicio() {
        if (!tieneAcceso()) {
            logger.debug("No cuenta con los accesos necesarios");
            return "accesoDenegado";
        }
        this.setDatosReporte(new ArrayList<>());
        this.setFechaEnvioSun(new Date());
        listaSelectDiario = new ArrayList<SelectItem>();
        listaSelectDiario.add(new SelectItem("", "- Seleccionar -"));

        try {
            listaTipodiario = configService.listarConfiguracion(20);
            for (BofConfiguracion config : listaTipodiario) {
                if (config.isActivo())
                    listaSelectDiario.add(new SelectItem(config.getCodConfig(), config.getDescripcion()));
            }
        }catch (Exception e){
            logger.error(e.getMessage(), e);
            FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
            FacesContext.getCurrentInstance().addMessage(null, facesMsg);
        }


        this.paramsReporte= new BofParamsReporte();
        return null;
    }

    public Date getFechaEnvioSun() {
        return fechaEnvioSun;
    }

    public void setFechaEnvioSun(Date fechaEnvioSun) {
        this.fechaEnvioSun = fechaEnvioSun;
    }

    public List<BofLoteAsientos> getDatosReporte() {
        return datosReporte;
    }

    public void setDatosReporte(List<BofLoteAsientos> datosReporte) {
        this.datosReporte = datosReporte;
    }

    public int getNumeroRegistros() {
        return numeroRegistros;
    }

    public void setNumeroRegistros(int numeroRegistros) {
        this.numeroRegistros = numeroRegistros;
    }

    public BofParamsReporte getParamsReporte() {
        return paramsReporte;
    }

    public void setParamsReporte(BofParamsReporte paramsReporte) {
        this.paramsReporte = paramsReporte;
    }

    public List<SelectItem> getListaSelectDiario() {
        return listaSelectDiario;
    }

    public void setListaSelectDiario(List<SelectItem> listaSelectDiario) {
        this.listaSelectDiario = listaSelectDiario;
    }
}
