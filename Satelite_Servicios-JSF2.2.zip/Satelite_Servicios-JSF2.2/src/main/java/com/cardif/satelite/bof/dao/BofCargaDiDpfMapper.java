package com.cardif.satelite.bof.dao;

import com.cardif.satelite.bof.bean.BofCargaDiDpf;
import com.cardif.satelite.bof.bean.BofParamsGeneracionAsientos;

import java.util.List;

public interface BofCargaDiDpfMapper {
    int deleteByPrimaryKey(String codCardpf);

    int insert(BofCargaDiDpf record);

    int insertSelective(BofCargaDiDpf record);

    BofCargaDiDpf selectByPrimaryKey(String codCardpf);

    int updateByPrimaryKeySelective(BofCargaDiDpf record);

    int updateByPrimaryKey(BofCargaDiDpf record);

    String countAll(String periodoCarga);

    List<BofCargaDiDpf> obtenerLoteDpf(BofParamsGeneracionAsientos paramsGeneracionAsientos);
}