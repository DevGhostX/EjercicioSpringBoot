package com.cardif.satelite.bof.dao;

import com.cardif.satelite.bof.bean.BofCargaDiVarios;
import com.cardif.satelite.bof.bean.BofParamsGeneracionAsientos;

import java.util.List;

public interface BofCargaDiVariosMapper {
    int deleteByPrimaryKey(String codCardvar);

    int insert(BofCargaDiVarios record);

    int insertSelective(BofCargaDiVarios record);

    BofCargaDiVarios selectByPrimaryKey(String codCardvar);

    int updateByPrimaryKeySelective(BofCargaDiVarios record);

    int updateByPrimaryKey(BofCargaDiVarios record);

    String countAll(String periodoCarga);

    List<BofCargaDiVarios> obtenerLoteVarios (BofParamsGeneracionAsientos paramsGeneracionAsientos);
}