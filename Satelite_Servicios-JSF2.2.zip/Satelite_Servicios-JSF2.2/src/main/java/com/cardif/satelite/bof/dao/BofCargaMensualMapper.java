package com.cardif.satelite.bof.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.bof.bean.BofCargaMensual;



public interface BofCargaMensualMapper {
	

	int deleteByPrimaryKey(String codCargam);


	int insert(BofCargaMensual record);


	int insertSelective(BofCargaMensual record);


	BofCargaMensual selectByPrimaryKey(String codCargam);


	int updateByPrimaryKeySelective(BofCargaMensual record);


	int updateByPrimaryKey(BofCargaMensual record);

	String countAll(String periodoCarga);

	List<BofCargaMensual> obtenerLoteMensual(String periodoCarga);
}
