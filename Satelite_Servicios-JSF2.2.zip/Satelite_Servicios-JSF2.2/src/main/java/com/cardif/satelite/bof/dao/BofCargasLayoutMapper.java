package com.cardif.satelite.bof.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.bof.bean.BofCargasLayout;


public interface BofCargasLayoutMapper {
	final String SELECT_LIST_POR_NOMBRE_TABLA = "SELECT ID_TABLA, ID_COLUMNA, NOMBRE_TABLA, NOMBRE_COLUMNA, "
			+ "NUM_ORDEN_CAMPO, TIPO_DATO, FORMATO_COLUMNA, CAMPO_OBLIGATORIO FROM BOF_CAMPO_LAYOUT "
			+ "WHERE NOMBRE_TABLA = #{nombreTabla, jdbcType=VARCHAR} ORDER BY NUM_ORDEN_CAMPO";
	
	@Select(SELECT_LIST_POR_NOMBRE_TABLA)
	@ResultMap("bofCargaMensualCampoLayout")
	List<BofCargasLayout> listarPorNombreTabla(@Param("nombreTabla") String nombreTabla);
}
