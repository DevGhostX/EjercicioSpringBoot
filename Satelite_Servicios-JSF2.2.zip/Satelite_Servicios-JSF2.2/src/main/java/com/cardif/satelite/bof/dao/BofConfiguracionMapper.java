package com.cardif.satelite.bof.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.bof.bean.BofConfiguracion;

public interface BofConfiguracionMapper {
	
	final String LISTA_CONFIGURACION_TODOS = "SELECT * FROM dbo.BOF_CONFIGURACION WHERE COD_TABLA = #{codTablaConfig}";
	final String OBTENER_CONFIGURACION = "SELECT * FROM dbo.BOF_CONFIGURACION WHERE COD_CONFIG = #{codConfig}";


	List<BofConfiguracion> listarTablaConfiguracion(@Param("codTablaConfig") int codTablaConfig);
	
	@Select(OBTENER_CONFIGURACION)
	@ResultMap(value = "BaseResultMap")
	BofConfiguracion obtenerConfiguracion(@Param("codConfig") int codConfig);
	
	int insertarBofConfiguracion(BofConfiguracion record);
	
	int actualizarBofConfiguracion(BofConfiguracion record);
	
	int eliminarBofConfiguracion(BofConfiguracion record);

}
