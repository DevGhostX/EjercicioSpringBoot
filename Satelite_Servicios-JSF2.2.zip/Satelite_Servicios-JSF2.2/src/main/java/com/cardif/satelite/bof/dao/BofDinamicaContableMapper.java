package com.cardif.satelite.bof.dao;

import java.util.List;

import com.cardif.satelite.bof.bean.BofConfiguracion;
import com.cardif.satelite.bof.bean.BofDinamicaContable;
import com.cardif.satelite.bof.model.ConsultaDinamicaModel;
import com.cardif.satelite.bof.model.DinamicaContableModel;

public interface BofDinamicaContableMapper {
    int deleteByPrimaryKey(Integer codDinamica);

	int insert(BofDinamicaContable record);

	int insertSelective(BofDinamicaContable record);

	BofDinamicaContable selectByPrimaryKey(Integer codDinamica);

	int updateByPrimaryKeySelective(BofDinamicaContable record);

	int updateByPrimaryKey(BofDinamicaContable record);	
    
    List<DinamicaContableModel> selectAll(ConsultaDinamicaModel queryParams);

	DinamicaContableModel obtenerDinamica(BofDinamicaContable dinamicaContable);
}