package com.cardif.satelite.bof.dao;

import com.cardif.satelite.bof.bean.BofLoteAsientos;
import com.cardif.satelite.bof.bean.BofParamsGeneracionAsientos;
import com.cardif.satelite.bof.bean.BofParamsReporte;

import java.util.Date;
import java.util.List;

public interface BofLoteAsientosMapper {
    int deleteByPrimaryKey(Integer codDeta);

    int insert(BofLoteAsientos record);

    int insertSelective(BofLoteAsientos record);

    BofLoteAsientos selectByPrimaryKey(Integer codDeta);

    int updateByPrimaryKeySelective(BofLoteAsientos record);

    int updateByPrimaryKey(BofLoteAsientos record);

    List<BofLoteAsientos> generarAsientos(BofParamsGeneracionAsientos params);

    List<BofLoteAsientos> selectReporte(BofParamsReporte paramsReporte);
}