package com.cardif.satelite.bof.model;

public class ConsultaDinamicaModel {
	public String getCodInstrumento() {
		return codInstrumento;
	}
	public void setCodInstrumento(String codInstrumento) {
		this.codInstrumento = codInstrumento;
	}
	public String getCodOperacion() {
		return codOperacion;
	}
	public void setCodOperacion(String codOperacion) {
		this.codOperacion = codOperacion;
	}
	public String getCodEmisor() {
		return codEmisor;
	}
	public void setCodEmisor(String codEmisor) {
		this.codEmisor = codEmisor;
	}
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	public String getCreditoDebito() {
		return creditoDebito;
	}
	public void setCreditoDebito(String creditoDebito) {
		this.creditoDebito = creditoDebito;
	}
	private String codInstrumento;
	private String codOperacion;
	private String codEmisor;
	private String numeroCuenta;
	private String creditoDebito;
	private Integer lineaAsiento;


	public Integer getLineaAsiento() {
		return lineaAsiento;
	}

	public void setLineaAsiento(Integer lineaAsiento) {
		this.lineaAsiento = lineaAsiento;
	}
}
