package com.cardif.satelite.bof.model;

import java.util.Date;

public class DinamicaContableModel {

    private Integer codDinamica;

    private String instrumento;

    private String emisor;

    private String operacion;

    private String numeroCuenta;

    private String descripCuenta;

    private String creditoDebito;

    private Boolean esVariable;

    private Integer lineaAsiento;

    private Date fechaRegistro;

    private String usuarioRegistro;

    private Date fechaModificacion;

    private String usuarioModif;

    private Boolean estRegistro;

	public Integer getCodDinamica() {
		return codDinamica;
	}

	public void setCodDinamica(Integer codDinamica) {
		this.codDinamica = codDinamica;
	}

	public String getInstrumento() {
		return instrumento;
	}

	public void setInstrumento(String instrumento) {
		this.instrumento = instrumento;
	}

	public String getEmisor() {
		return emisor;
	}

	public void setEmisor(String emisor) {
		this.emisor = emisor;
	}

	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getCreditoDebito() {
		return creditoDebito;
	}

	public void setCreditoDebito(String creditoDebito) {
		this.creditoDebito = creditoDebito;
	}

	public Boolean getEsVariable() {
		return esVariable;
	}

	public void setEsVariable(Boolean esVariable) {
		this.esVariable = esVariable;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getUsuarioRegistro() {
		return usuarioRegistro;
	}

	public void setUsuarioRegistro(String usuarioRegistro) {
		this.usuarioRegistro = usuarioRegistro;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getUsuarioModif() {
		return usuarioModif;
	}

	public void setUsuarioModif(String usuarioModif) {
		this.usuarioModif = usuarioModif;
	}

	public Boolean getEstRegistro() {
		return estRegistro;
	}

	public void setEstRegistro(Boolean estRegistro) {
		this.estRegistro = estRegistro;
	}

	public Integer getLineaAsiento() {
		return lineaAsiento;
	}

	public void setLineaAsiento(Integer lineaAsiento) {
		this.lineaAsiento = lineaAsiento;
	}

	public String getDescripCuenta() {
		return descripCuenta;
	}

	public void setDescripCuenta(String descripCuenta) {
		this.descripCuenta = descripCuenta;
	}
}
