package com.cardif.satelite.bof.model;

import java.util.Date;

public class GeneraAsientoError {
    private String nombreArchivo;
    private Integer numLinea;
    private Date fecCarga;

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public Integer getNumLinea() {
        return numLinea;
    }

    public void setNumLinea(Integer numLinea) {
        this.numLinea = numLinea;
    }

    public Date getFecCarga() {
        return fecCarga;
    }

    public void setFecCarga(Date fecCarga) {
        this.fecCarga = fecCarga;
    }
}
