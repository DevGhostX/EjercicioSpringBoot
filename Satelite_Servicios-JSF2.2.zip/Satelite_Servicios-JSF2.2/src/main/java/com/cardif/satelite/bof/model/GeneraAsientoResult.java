package com.cardif.satelite.bof.model;

import com.cardif.satelite.bof.bean.BofLoteAsientos;

import java.util.ArrayList;
import java.util.List;

public class GeneraAsientoResult {
    private List<BofLoteAsientos> asientoGenerados;
    private List<GeneraAsientoError> asientosNoGenerado;

    public GeneraAsientoResult(){
        this.asientoGenerados = new ArrayList<>();
        this.asientosNoGenerado = new ArrayList<>();
    }

    public List<BofLoteAsientos> getAsientoGenerados() {
        return asientoGenerados;
    }

    public void setAsientoGenerados(List<BofLoteAsientos> asientoGenerados) {
        this.asientoGenerados = asientoGenerados;
    }

    public List<GeneraAsientoError> getAsientosNoGenerado() {
        return asientosNoGenerado;
    }

    public void setAsientosNoGenerado(List<GeneraAsientoError> asientosNoGenerado) {
        this.asientosNoGenerado = asientosNoGenerado;
    }
}
