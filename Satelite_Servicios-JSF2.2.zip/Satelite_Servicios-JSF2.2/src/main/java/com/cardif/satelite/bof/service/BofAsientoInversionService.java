package com.cardif.satelite.bof.service;

import com.cardif.framework.excepcion.SateliteServiceException;
import com.cardif.satelite.bof.bean.BofLoteAsientos;
import com.cardif.satelite.bof.bean.BofParamsGeneracionAsientos;
import com.cardif.satelite.bof.bean.BofParamsReporte;
import com.cardif.satelite.bof.model.GeneraAsientoResult;


import java.util.List;

public interface BofAsientoInversionService {
    GeneraAsientoResult generarDetalleAsientos(BofParamsGeneracionAsientos params);

    List<BofLoteAsientos> enviarDetalleAsientos(List<BofLoteAsientos> loteAsientos);

    List<BofLoteAsientos> generaReporteFechaEnvioSun(BofParamsReporte paramsReporte);

    void cancelaGeneracion(BofParamsGeneracionAsientos params);

}
