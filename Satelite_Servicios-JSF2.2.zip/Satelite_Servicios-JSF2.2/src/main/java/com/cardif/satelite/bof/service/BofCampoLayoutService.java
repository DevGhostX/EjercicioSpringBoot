package com.cardif.satelite.bof.service;

import java.util.List;

import org.richfaces.model.UploadedFile;

import com.cardif.satelite.bof.bean.BofCargasLayout;


public interface BofCampoLayoutService {
	
	List<BofCargasLayout> listarPorNombreTabla(String nombreTabla);

	String validarCamposLayout(UploadedFile archivoExcel, String nombreLayout, String nombreArchivo) throws Exception;
	
	String validarCamposLayoutDpf(UploadedFile archivoExcel, String nombreLayout, String nombreArchivo) throws Exception;
	
	String validarCamposLayoutVarios(UploadedFile archivoExcel, String nombreLayout, String nombreArchivo) throws Exception;

}
