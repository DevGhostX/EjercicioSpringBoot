package com.cardif.satelite.bof.service;

import java.util.List;

import com.cardif.satelite.bof.bean.BofCargaDiDpf;

public interface BofCargaDpfService {

	public void InsertarCargaDpf(List<BofCargaDiDpf> listaCargaDpf, String periodo);
	
	public List<BofCargaDiDpf> listarCargaDpf(String codigoCarga);

	public List<String> listarPeriodos();
}
