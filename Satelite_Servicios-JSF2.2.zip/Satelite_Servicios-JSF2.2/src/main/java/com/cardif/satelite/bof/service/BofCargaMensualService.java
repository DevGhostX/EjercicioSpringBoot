package com.cardif.satelite.bof.service;

import java.util.List;

import com.cardif.satelite.bof.bean.BofCargaMensual;


public interface BofCargaMensualService {

	public void InsertarCargaMensual(List<BofCargaMensual> listaCargaMensual, String periodo);
	
	public List<BofCargaMensual> ListarCargaMensual(String codigoCarga);

	public List<String> listarPeriodos();
}
