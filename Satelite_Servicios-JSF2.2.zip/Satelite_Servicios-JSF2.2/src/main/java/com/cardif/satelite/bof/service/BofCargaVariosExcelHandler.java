package com.cardif.satelite.bof.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.bof.bean.BofCargaDiDpf;
import com.cardif.satelite.bof.bean.BofCargaDiVarios;
import com.cardif.satelite.bof.bean.BofCargasLayout;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.SateliteUtil;

public class BofCargaVariosExcelHandler implements SheetContentsHandler {

    private static final Logger logger = Logger.getLogger(BofCargaVariosExcelHandler.class);

    private int contFilas = 0;
    private boolean leerCabecera = false;
    private boolean leerCuerpo = false;
    private int col = 0;
    private HashMap<String, String> mapColumnsValues;
    private List<BofCargasLayout> listaCamposLayout;
    private List<BofCargaDiVarios> listaCargaVarios;

    public BofCargaVariosExcelHandler() {
        super();
        mapColumnsValues = new HashMap<String, String>();
        listaCargaVarios = new ArrayList<BofCargaDiVarios>();
    }

    public BofCargaVariosExcelHandler(List<BofCargasLayout> mListaCamposLayout) {
        super();
        listaCamposLayout = mListaCamposLayout;
        mapColumnsValues = new HashMap<String, String>();
        listaCargaVarios = new ArrayList<BofCargaDiVarios>();
    }

    @Override
    public void startRow(int rowNum) {
        try {
            setContFilas(getContFilas() + 1);
            setColumnValueHeaders();
            if (rowNum == 0) {
                leerCabecera = true;
            }

            if (rowNum == 1) {
                leerCuerpo = true;
                leerCabecera = false;
                col = 0;
            }
        } catch (Exception e) {
            throw new RuntimeException(
                    PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL));
        }

    }

    @Override
    public void endRow() {
        if (leerCuerpo) {
            for (int i = 0; i < getListaCamposLayout().size(); i++) {
                if (getListaCamposLayout().get(i).isCampoObligatorio()) {
                    boolean validacion = validarCampoObligatorio(getListaCamposLayout().get(i),
                            mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
                    if (!validacion) {
                        throw new RuntimeException(
                                PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
                    }
                } else {
                    boolean validacion = validarCampoNoObligatorio(getListaCamposLayout().get(i),
                            mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
                    if (!validacion) {
                        throw new RuntimeException(
                                PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
                    }
                }
            }
            listaCargaVarios.add(getVariosFromMap(mapColumnsValues));
            mapColumnsValues.clear();
        }
    }

    private BofCargaDiVarios getVariosFromMap(HashMap<String, String> blobObjectMap) {
        BofCargaDiVarios rowReturn = new BofCargaDiVarios();
        rowReturn.setNumRegistro(Integer.parseInt(blobObjectMap.get("A")));
        rowReturn.setTipInstru(blobObjectMap.get("B"));
        rowReturn.setEmisor(blobObjectMap.get("C"));
        rowReturn.setMoneda(blobObjectMap.get("D"));
        rowReturn.setEmpresa(blobObjectMap.get("E"));
        rowReturn.setfNegociacion(dateFromString(blobObjectMap.get("F"), "dd-MMM-yy"));
        rowReturn.setfLiquidacion(dateFromString(blobObjectMap.get("G"), "dd-MMM-yy"));
        rowReturn.setfVencimiento(dateFromString(blobObjectMap.get("H"), "dd-MMM-yy"));
        rowReturn.setContraparte(blobObjectMap.get("I"));
        rowReturn.setNominal(getBdFromString(blobObjectMap.get("J")));
        rowReturn.setMontovpComis(getBdFromString(blobObjectMap.get("K")));
        rowReturn.setCostosTransac(getBdFromString(blobObjectMap.get("L")));
        rowReturn.setPrecsucComven(getBdFromString(blobObjectMap.get("M")));
        rowReturn.setOperacion(blobObjectMap.get("N"));
        rowReturn.setIsin(blobObjectMap.get("O"));
        rowReturn.setNemotecnico(blobObjectMap.get("P"));
        rowReturn.setIntMesanterAcum(getBdFromString(blobObjectMap.get("Q")));

        rowReturn.setOperBancaria(getBdFromString(blobObjectMap.get("R")));
        rowReturn.setGananVenta(getBdFromString(blobObjectMap.get("S")));
        rowReturn.setGananNoAcum(getBdFromString(blobObjectMap.get("T")));

        DateFormat dateFormat = new SimpleDateFormat("MMyyyy");
        rowReturn.setPerCarga("0" + dateFormat.format(new Date()));

        return rowReturn;
    }

    private Date dateFromString(String value, String format) {
        DateFormat df = new SimpleDateFormat(format);
        if (value == null || value == "" || value == "-")
            return null;
        Date date = null;
        try {
            date = df.parse(value);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    private BigDecimal getBdFromString(String stringValue) {
        BigDecimal valueReturn = new BigDecimal(0);
        stringValue = stringValue == null? "" : stringValue;
        stringValue = stringValue.trim();
        if (stringValue == null || stringValue == "" || stringValue == "-")
            return valueReturn;
        else {
            if (stringValue.startsWith("-")) {
                stringValue = stringValue.substring(1);
                valueReturn = new BigDecimal(stringValue);
                return valueReturn.negate();
            } else
                return new BigDecimal(stringValue);
        }
    }

    @Override
    public void cell(String cellReference, String formattedValue) {
        String column = "";
        if (leerCabecera) {
            boolean esCabeceraValida = validarCabeceraOrdenYNombreCol(getListaCamposLayout(), col, formattedValue);
            if (!esCabeceraValida) {
                throw new RuntimeException(
                        PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAB_EXCEL));
            }
            col++;
        } else if (leerCuerpo) {
            if (!getLength(cellReference)) {
                int cellLen = cellReference.length();
                //column = cellReference.substring(0, cellLen == 2 ? 1 : 2);
                column = cellReference.substring(0, 1);
                mapColumnsValues.put(column, formattedValue);
            } else {
                column = cellReference.substring(0, 2);
            }
        }

    }

    @Override
    public void headerFooter(String text, boolean isHeader, String tagName) {
        // TODO Auto-generated method stub

    }

    private boolean validarCabeceraOrdenYNombreCol(List<BofCargasLayout> listaCamposLayout, int nroOrdenCampo,
                                                   String nombreColumna) {
        if (listaCamposLayout.get(nroOrdenCampo).getNombreColumna().trim().equalsIgnoreCase(nombreColumna)) {
            return true;
        }
        return false;
    }

    private boolean validarCampoObligatorio(BofCargasLayout campo, String valorCelda) {
        try {
            if (valorCelda == null || valorCelda.trim().length() == 0) {
                return false;
            } else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_ALFANUMERICO)) {
                return valorCelda == null ? false : valorCelda.trim().length() == 0 ? false : true;
            } else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {
                Double.parseDouble(valorCelda);
                return true;
            } else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
                SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoColumna());
                sdf.format(sdf.parse(valorCelda));
                return true;
            }
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    private boolean validarCampoNoObligatorio(BofCargasLayout campo, String valorCelda) {
        try {
            if (valorCelda != null && valorCelda.trim().length() > 0) {
                if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {

					/*DecimalFormat df = new DecimalFormat();
					DecimalFormatSymbols dfs = new DecimalFormatSymbols();
					dfs.setDecimalSeparator('.');
					dfs.setGroupingSeparator(',');
					df.setDecimalFormatSymbols(dfs);
					df.parse(valorCelda);*/
                    Double.parseDouble(valorCelda);

                    return true;
                } else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoColumna());
                    sdf.format(sdf.parse(valorCelda));
                    return true;
                }
            }
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }
    }

    private static synchronized boolean getLength(String cell) {
        boolean res = false;
        int sum = cell.replaceAll("(?i)[^AEIOU]", "").length()
                + cell.replaceAll("(?i)[^BCDFGHJKLMNPQRSTVWXYZ]", "").length();
        if (sum == 2) {
            res = true;
        }
        return res;
    }

    private void setColumnValueHeaders() {
        mapColumnsValues.put("A", "");
        mapColumnsValues.put("B", "");
        mapColumnsValues.put("C", "");
        mapColumnsValues.put("D", "");
        mapColumnsValues.put("E", "");
        mapColumnsValues.put("F", "");
        mapColumnsValues.put("G", "");
        mapColumnsValues.put("H", "");
        mapColumnsValues.put("I", "");
        mapColumnsValues.put("J", "");
        mapColumnsValues.put("K", "");
        mapColumnsValues.put("L", "");
        mapColumnsValues.put("M", "");
        mapColumnsValues.put("N", "");
        mapColumnsValues.put("O", "");
        mapColumnsValues.put("P", "");
        mapColumnsValues.put("Q", "");
        mapColumnsValues.put("R", "");
        mapColumnsValues.put("S", "");
    }

    public int getContFilas() {
        return contFilas;
    }

    public void setContFilas(int contFilas) {
        this.contFilas = contFilas;
    }

    public List<BofCargasLayout> getListaCamposLayout() {
        return listaCamposLayout;
    }

    public void setListaCamposLayout(List<BofCargasLayout> listaCamposLayout) {
        this.listaCamposLayout = listaCamposLayout;
    }

    public List<BofCargaDiVarios> getListaCargaVarios() {
        return listaCargaVarios;
    }

    public void setListaCargaVarios(List<BofCargaDiVarios> listaCargaVarios) {
        this.listaCargaVarios = listaCargaVarios;
    }

}
