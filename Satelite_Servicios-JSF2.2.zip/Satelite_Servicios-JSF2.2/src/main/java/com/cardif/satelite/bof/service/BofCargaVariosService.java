package com.cardif.satelite.bof.service;
import java.util.List;

import com.cardif.satelite.bof.bean.BofCargaDiVarios;
public interface BofCargaVariosService {
	
	public void InsertarCargaVarios(List<BofCargaDiVarios> listaVarios, String periodo);
	
	public List<BofCargaDiVarios> listarCargaVarios(String codigoCargaVarios);

	public List<String> listarPeriodos();
}
