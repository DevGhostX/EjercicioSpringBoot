package com.cardif.satelite.bof.service;

import java.util.List;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.bof.bean.BofConfiguracion;

public interface BofConfiguracionService {
	
	public List<BofConfiguracion> listarConfiguracion(int codigoTabla) throws SyncconException;
	
	public BofConfiguracion getConfiguracion(int codigoConfiguracion) throws SyncconException;
	
	public int crearBofConfiguracion(BofConfiguracion configuracion) throws SyncconException;
	
	public int actualizarBofConfiguracion(BofConfiguracion configuracion) throws SyncconException;
	
	public int eliminarBofConfiguracion(BofConfiguracion configuracion) throws SyncconException;
}
