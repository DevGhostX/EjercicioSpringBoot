package com.cardif.satelite.bof.service;

import java.util.List;

import com.cardif.satelite.bof.bean.BofDinamicaContable;
import com.cardif.satelite.bof.model.ConsultaDinamicaModel;
import com.cardif.satelite.bof.model.DinamicaContableModel;

public interface BofDinamicaContableService {
	public List<DinamicaContableModel> listarDinamicaContable(ConsultaDinamicaModel params);
	public int RegistrarDinamicaContable(BofDinamicaContable dinamica);
	public int ActualizaDinamicaContable(BofDinamicaContable dinamica);
	public int InactivaDinamicaContable(int codDinamica);
	public BofDinamicaContable obtenerPorId(int codDinamica);
}
