package com.cardif.satelite.bof.service;

import com.cardif.satelite.bof.bean.BofLoteAsientos;
import com.cardif.satelite.bof.bean.BofParamsReporte;
import sun.util.locale.provider.DateFormatProviderImpl;

import javax.xml.bind.JAXBException;
import java.util.Date;
import java.util.List;

public interface BofSunSystemService {



    List<BofLoteAsientos> registrarAsiento(List<BofLoteAsientos> bofDetLoteAsientos) throws Exception;

    List<BofLoteAsientos> consultarAsientosReporte(BofParamsReporte params);

}
