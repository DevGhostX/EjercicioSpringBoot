package com.cardif.satelite.bof.service.impl;

import com.cardif.framework.excepcion.SateliteServiceException;
import com.cardif.satelite.bof.bean.*;
import com.cardif.satelite.bof.dao.*;
import com.cardif.satelite.bof.model.DinamicaContableModel;
import com.cardif.satelite.bof.model.GeneraAsientoError;
import com.cardif.satelite.bof.model.GeneraAsientoResult;
import com.cardif.satelite.bof.service.BofAsientoInversionService;
import com.cardif.satelite.bof.service.BofSunSystemService;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.Utilitarios;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

@Service("bofAsientoInversionServiceImpl")
public class BofAsientoInversionServiceImpl implements BofAsientoInversionService {
    public static final Logger log = Logger.getLogger(BofAsientoInversionServiceImpl.class);

    @Autowired
    BofLoteAsientosMapper loteDao;
    @Autowired
    BofCargaMensualMapper menDao;
    @Autowired
    BofCargaDiDpfMapper dpfDao;
    @Autowired
    BofCargaDiVariosMapper varDato;
    @Autowired
    BofDinamicaContableMapper dinamicaContableMapper;
    @Autowired
    BofConfiguracionMapper daoConfig;

    @Autowired
    ParametroService parametroService;
    BofSunSystemService sunSystemService;
    private HashMap<String, String> datosCuenta;

    @Override
    public GeneraAsientoResult generarDetalleAsientos(BofParamsGeneracionAsientos params) {
        try {
            log.info("Inicio Generar Asientos Inversion");
            log.info("PERIODO: " + params.getPeriodoCarga());
            log.info("OPERACION: " + params.getTipoOperacion());
            List<BofLoteAsientos> asientosGenerados = new ArrayList<>();
            GeneraAsientoResult result = new GeneraAsientoResult();

            switch (params.getTipoCarga()) {
                case Constantes.TAB_CARGA_MENSUAL:
                    result = this.generarAsientosMensuales(params);
                    break;
                case Constantes.TAB_CARGA_DPF:
                    result = this.generarAsientosDpf(params);
                    break;
                case Constantes.TAB_CARGA_VARIOS:
                    result = this.generarAsientosVarios(params);
                    break;
            }
            result.setAsientoGenerados(loteDao.generarAsientos(params));
            return result;

        } finally {
            log.info("Fin Generar Asientos Inversion");
        }
    }

    @Override
    public List<BofLoteAsientos> enviarDetalleAsientos(List<BofLoteAsientos> loteAsientos) {
        sunSystemService = new BofSunSystemServiceImpl();
        String idLote = "";
        HashMap<String, List<BofLoteAsientos>> hashMap = new HashMap<String, List<BofLoteAsientos>>();
        List<BofLoteAsientos> asientoActual;
        for (BofLoteAsientos lineaAsiento : loteAsientos) {
            idLote = lineaAsiento.getIdCabLote();
            if (hashMap.containsKey(idLote)) {
                hashMap.get(idLote).add(lineaAsiento);
            } else {
                List<BofLoteAsientos> list = new ArrayList<BofLoteAsientos>();
                list.add(lineaAsiento);
                hashMap.put(idLote, list);
            }
        }

        try {
            for (Map.Entry<String, List<BofLoteAsientos>> itemMap : hashMap.entrySet()) {
                asientoActual = itemMap.getValue();
                asientoActual = sunSystemService.registrarAsiento(asientoActual);
                if (asientoActual == null) throw new Exception(MSJ_ERROR_GENERAL);
                for (BofLoteAsientos item : asientoActual) {
                    item.setFecEnvio(Calendar.getInstance().getTime());
                    loteDao.updateByPrimaryKey(item);
                    //if (item.getEstEnvio() == SateliteConstants.BOF_EST_ASIENTO_ENVIADO) {
                    switch (item.getTabOrigen()) {
                        case Constantes.TAB_CARGA_MENSUAL:
                            BofCargaMensual m = new BofCargaMensual();
                            m.setCodCargam(item.getIdCabLote());
                            m.setEstEnvio(item.getEstEnvio());
                            menDao.updateByPrimaryKeySelective(m);
                            break;
                        case Constantes.TAB_CARGA_DPF:
                            BofCargaDiDpf d = new BofCargaDiDpf();
                            d.setCodCardpf(item.getIdCabLote());
                            d.setEstEnvio(item.getEstEnvio());
                            dpfDao.updateByPrimaryKeySelective(d);
                            break;
                        case Constantes.TAB_CARGA_VARIOS:
                            BofCargaDiVarios v = new BofCargaDiVarios();
                            v.setCodCardvar(item.getIdCabLote());
                            v.setEstEnvio(item.getEstEnvio());
                            varDato.updateByPrimaryKeySelective(v);
                            break;
                    }
                    //}
                }
            }
        } catch (Exception e) {
            log.error(e.getStackTrace(), e);
            return null;
        }
        return loteAsientos;
    }

    @Override
    public List<BofLoteAsientos> generaReporteFechaEnvioSun(BofParamsReporte paramsReporte) {
        sunSystemService = new BofSunSystemServiceImpl();
        List<BofLoteAsientos> listaReturn = new ArrayList<>();
        try {
            listaReturn = sunSystemService.consultarAsientosReporte(paramsReporte);
            for (BofLoteAsientos linea : listaReturn) {
                linea.setImporteTran(linea.getImporteTran().multiply(BigDecimal.valueOf(-1)));
            }
        } catch (Exception e) {
            log.error(e.getStackTrace(), e);
            throw e;
        }
        return listaReturn;
    }

    private DinamicaContableModel getCuentaContable(String instrumento, String operacion, Integer numeroLinea) {
        DinamicaContableModel cuentaContable;
        BofDinamicaContable dinamicaContable = new BofDinamicaContable();
        dinamicaContable.setCodInstrumento(instrumento);
        dinamicaContable.setCodOperacion(operacion);
        dinamicaContable.setLineaAsiento(numeroLinea);
        cuentaContable = dinamicaContableMapper.obtenerDinamica(dinamicaContable);
        if (cuentaContable == null) cuentaContable = new DinamicaContableModel();
        return cuentaContable;
    }

    private GeneraAsientoResult generarAsientosMensuales(BofParamsGeneracionAsientos params) {
        List<BofCargaMensual> loteMensual = new ArrayList<>();
        List<BofLoteAsientos> asiento = null;
        GeneraAsientoResult resultMensual = new GeneraAsientoResult();
        loteMensual = menDao.obtenerLoteMensual(params.getPeriodoCarga());
        DinamicaContableModel cuentaContable;

        for (BofCargaMensual record : loteMensual) {
            asiento = new ArrayList<>();
            BofLoteAsientos itemLote = new BofLoteAsientos();
            itemLote.setIdCabLote(record.getCodCargam());
            itemLote.setFechaTransaccion(Utilitarios.personalizarFecha(params.getFechaProcesoMensual(), "ddMMyyyy"));
            itemLote.setPeriodo(params.getPeriodoCarga());
            itemLote.setUsuRegistro(params.getUsuarioGenera());
            itemLote.setTipoDiario(params.getTipoDiario());
            itemLote.setTabOrigen(params.getTipoCarga());
            if (!(record.getIntAmorAjupre().compareTo(BigDecimal.ZERO) == 0)) {
                itemLote.setTipoOperacion("MOVI");
                cuentaContable = this.getCuentaContable(record.getTipoInstru(), itemLote.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(cuentaContable.getCreditoDebito());
                itemLote.setCtaContable(cuentaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(cuentaContable.getDescripCuenta());
                itemLote.setImporteTran(record.getIntAmorAjupre());
                itemLote.setRefTransaccion(record.getNemotec());
                itemLote.setGlosa("INTERES DEVENGADO " + itemLote.getRefTransaccion() + " " + Calendar.getInstance().get(Calendar.MONTH));
                asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                cuentaContable = this.getCuentaContable(record.getTipoInstru(), itemLote.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(cuentaContable.getCreditoDebito());
                itemLote.setCtaContable(cuentaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(cuentaContable.getDescripCuenta());
                itemLote.setImporteTran(record.getIntAmorAjupre().multiply(BigDecimal.valueOf(-1)));
                asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if (!(record.getAjusValRazona().compareTo(BigDecimal.ZERO) == 0)) {
                itemLote.setTipoOperacion("MOVA");
                cuentaContable = this.getCuentaContable(record.getTipoInstru(), itemLote.getTipoOperacion(), 3);
                if (cuentaContable == null)
                    cuentaContable = new DinamicaContableModel();//CUENTA NO CONFIGURADA EN DINAMICA
                itemLote.setDebitoCredito(cuentaContable.getCreditoDebito());
                itemLote.setCtaContable(cuentaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(cuentaContable.getDescripCuenta());
                itemLote.setImporteTran(record.getAjusValRazona());
                itemLote.setRefTransaccion(record.getNemotec());
                itemLote.setDebitoCredito(record.getAjusValRazona().compareTo(BigDecimal.valueOf(0)) == -1 ? "C" : "D");
                itemLote.setGlosa("AJUSTE VALOR RAZONABLE " + itemLote.getRefTransaccion() + " " + Calendar.getInstance().get(Calendar.MONTH));
                asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                cuentaContable = this.getCuentaContable(record.getTipoInstru(), itemLote.getTipoOperacion(), 4);
                if (cuentaContable == null)
                    cuentaContable = new DinamicaContableModel();//CUENTA NO CONFIGURADA EN DINAMICA CONTABLE
                itemLote.setDebitoCredito(cuentaContable.getCreditoDebito());
                itemLote.setCtaContable(cuentaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(cuentaContable.getDescripCuenta());
                itemLote.setDebitoCredito(record.getAjusValRazona().compareTo(BigDecimal.valueOf(0)) == -1 ? "D" : "C");
                itemLote.setImporteTran(record.getAjusValRazona().multiply(BigDecimal.valueOf(-1)));
                asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if (this.asientoNoCuadra(asiento)) {
                GeneraAsientoError asientoError = new GeneraAsientoError();
                asientoError.setFecCarga(record.getFecRegistro());
                asientoError.setNombreArchivo(record.getNomArchivo());
                asientoError.setNumLinea(record.getNumRegistro());
                resultMensual.getAsientosNoGenerado().add(asientoError);

                BofCargaMensual m = new BofCargaMensual();
                m.setCodCargam(record.getCodCargam());
                m.setEstEnvio(SateliteConstants.BOF_EST_ASIENTO_ENVIADO_ERROR);
                menDao.updateByPrimaryKeySelective(m);

            } else {
                for (BofLoteAsientos l : asiento) {
                    this.insertarItemLote(l);
                }
            }
        }
        return resultMensual;
    }

    private GeneraAsientoResult generarAsientosDpf(BofParamsGeneracionAsientos params) {
        List<BofCargaDiDpf> loteDpf = new ArrayList<>();
        List<BofLoteAsientos> asiento = null;
        loteDpf = dpfDao.obtenerLoteDpf(params);
        DinamicaContableModel dinamicaContable;
        GeneraAsientoResult resultDpf = new GeneraAsientoResult();
        for (BofCargaDiDpf record : loteDpf) {
            asiento = new ArrayList<>();
            BofLoteAsientos itemLote = new BofLoteAsientos();
            itemLote.setIdCabLote(record.getCodCardpf());
            itemLote.setPeriodo(params.getPeriodoCarga());
            itemLote.setUsuRegistro(params.getUsuarioGenera());
            itemLote.setTipoDiario(params.getTipoDiario());
            itemLote.setTabOrigen(params.getTipoCarga());
            itemLote.setFechaTransaccion(Utilitarios.personalizarFecha(record.getfApertura(), "ddMMyyyy"));
            itemLote.setTipoOperacion(params.getTipoOperacion());


            Calendar cal = Calendar.getInstance();
            int periodoActual = cal.get(Calendar.MONTH) + 1;
            int mesApertura = record.getfApertura().getMonth() + 1;

            if ((mesApertura < periodoActual) && (record.getTipoOper().equals("V") || record.getTipoOper().equals("R"))) {

                itemLote.setImporteTran(record.getMontFinal());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                itemLote.setGlosa("VENCIMIENTO DEP PLAZO " + record.getEntidad() + " " + Utilitarios.personalizarFecha(record.getfVcto(), "MMMyyyy"));
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);


                itemLote.setImporteTran(record.getPrincipal().multiply(BigDecimal.valueOf(-1)));
                itemLote.setRefTransaccion("DEP " + record.getPrincipal().toString().substring(0, 4));
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getIntMesanterAcum().multiply(BigDecimal.valueOf(-1)));
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getIntMes().multiply(BigDecimal.valueOf(-1)));
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 3);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if ((mesApertura == periodoActual) && (record.getTipoOper().equals("V") || record.getTipoOper().equals("R"))) {
                itemLote.setImporteTran(record.getMontFinal());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                //itemLote.setTipoOperacion("DPFV");
                itemLote.setGlosa("VENCIMIENTO DEP PLAZO " + record.getEntidad() + " " + Utilitarios.personalizarFecha(record.getfVcto(), "MMMyyyy"));
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getPrincipal().multiply(BigDecimal.valueOf(-1)));
                itemLote.setRefTransaccion("DEP " + record.getPrincipal().toString().substring(0, 4));
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);


                itemLote.setImporteTran(record.getIntMes().multiply(BigDecimal.valueOf(-1)));
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 3);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if (record.getTipoOper().equals("A")) {
                itemLote.setGlosa("APERTURA DEP PLAZO " + record.getEntidad() + " " + Utilitarios.personalizarFecha(record.getfVcto(), "MMMyyyy"));

                itemLote.setImporteTran(record.getPrincipal());
                itemLote.setRefTransaccion("DEP " + record.getPrincipal().toString().substring(0, 4));
                //itemLote.setTipoOperacion(params.getTipoOperacion());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);


                itemLote.setImporteTran(record.getPrincipal().multiply(BigDecimal.valueOf(-1)));
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if (this.asientoNoCuadra(asiento)) {
                GeneraAsientoError asientoError = new GeneraAsientoError();
                asientoError.setFecCarga(record.getFecRegistro());
                asientoError.setNombreArchivo(record.getNomArchivo());
                asientoError.setNumLinea(record.getNumRegistro());
                resultDpf.getAsientosNoGenerado().add(asientoError);

                BofCargaDiDpf d = new BofCargaDiDpf();
                d.setCodCardpf(record.getCodCardpf());
                d.setEstEnvio(SateliteConstants.BOF_EST_ASIENTO_ENVIADO_ERROR);
                dpfDao.updateByPrimaryKeySelective(d);

            } else {
                for (BofLoteAsientos l : asiento) {
                    this.insertarItemLote(l);
                }
            }
        }
        return resultDpf;
    }

    private GeneraAsientoResult generarAsientosVarios(BofParamsGeneracionAsientos params) {
        List<BofCargaDiVarios> loteVarios = new ArrayList<>();
        List<BofLoteAsientos> asiento = null;
        GeneraAsientoResult resultVarios = new GeneraAsientoResult();
        loteVarios = varDato.obtenerLoteVarios(params);
        DinamicaContableModel dinamicaContable;
        for (BofCargaDiVarios record : loteVarios) {
            asiento = new ArrayList<>();
            BofLoteAsientos itemLote = new BofLoteAsientos();
            itemLote.setIdCabLote(record.getCodCardvar());
            itemLote.setPeriodo(params.getPeriodoCarga());
            itemLote.setUsuRegistro(params.getUsuarioGenera());
            itemLote.setTipoDiario(params.getTipoDiario());
            itemLote.setTabOrigen(params.getTipoCarga());
            itemLote.setTipoOperacion(params.getTipoOperacion());

            if ((record.getfNegociacion().equals(record.getfLiquidacion())) && record.getOperacion().equals("C")) {
                itemLote.setFechaTransaccion(Utilitarios.personalizarFecha(record.getfLiquidacion(), "ddMMyyyy"));
                itemLote.setImporteTran(record.getNominal());
                itemLote.setRefTransaccion("COMPRA " + record.getEmisor());
                itemLote.setGlosa("COMPRA " + record.getEmisor() + itemLote.getImporteTran().toString());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());

                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getNominal().negate());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if ((record.getfLiquidacion().after(record.getfNegociacion())) && record.getOperacion().equals("C")) {

                itemLote.setFechaTransaccion(Utilitarios.personalizarFecha(record.getfNegociacion(), "ddMMyyyy"));
                itemLote.setImporteTran(record.getMontovpComis());
                itemLote.setRefTransaccion("COMPRA BONO " + record.getNemotecnico());
                itemLote.setGlosa("COMPRA BONO " + record.getEmisor() + ' ' + record.getNemotecnico());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getMontovpComis().negate());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setFechaTransaccion(Utilitarios.personalizarFecha(record.getfLiquidacion(), "ddMMyyyy"));
                itemLote.setIdCabLote("P" + record.getCodCardvar());
                itemLote.setImporteTran(record.getMontovpComis());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getMontovpComis().negate());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }

            if ((record.getOperacion().equals("V") || record.getOperacion().equals("R")) && record.getTipInstru().equals("FFMM")) {
                itemLote.setFechaTransaccion(Utilitarios.personalizarFecha(record.getfNegociacion(), "ddMMyyyy"));
                itemLote.setImporteTran(record.getMontovpComis());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                itemLote.setGlosa("VENTA FFMM " + record.getEmisor() + ' ' + itemLote.getImporteTran().toString());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getNominal().negate());
                itemLote.setRefTransaccion("VENTA FFMM");
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getIntMesanterAcum().negate());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 3);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if ((record.getOperacion().equals("V") || record.getOperacion().equals("R")) && !record.getTipInstru().equals("FFMM")) {
                itemLote.setFechaTransaccion(Utilitarios.personalizarFecha(record.getfNegociacion(), "ddMMyyyy"));

                itemLote.setImporteTran(record.getMontovpComis());
                itemLote.setRefTransaccion(record.getOperBancaria().toBigInteger().toString());
                itemLote.setGlosa("PAGO VTA - " + record.getEmisor() + " " + record.getNemotecnico());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 1);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setRefTransaccion("PAGO VTA - " + record.getNemotecnico());
                itemLote.setImporteTran(record.getGananVenta().negate());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 2);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getGananNoAcum().negate());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 3);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getIntMesanterAcum().negate());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 4);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);

                itemLote.setImporteTran(record.getNominal().negate());
                dinamicaContable = this.getCuentaContable(record.getTipInstru(), params.getTipoOperacion(), 5);
                itemLote.setDebitoCredito(dinamicaContable.getCreditoDebito());
                itemLote.setCtaContable(dinamicaContable.getNumeroCuenta());
                itemLote.setNomCtaContable(dinamicaContable.getDescripCuenta());
                if (itemLote.getImporteTran().compareTo(BigDecimal.ZERO) != 0)
                    asiento.add(itemLote.Clone());
                //this.insertarItemLote(itemLote);
            }
            if (this.asientoNoCuadra(asiento)) {
                GeneraAsientoError asientoError = new GeneraAsientoError();
                asientoError.setFecCarga(record.getFecRegistro());
                asientoError.setNombreArchivo(record.getNomArchivo());
                asientoError.setNumLinea(record.getNumRegistro());
                resultVarios.getAsientosNoGenerado().add(asientoError);

                BofCargaDiVarios v = new BofCargaDiVarios();
                v.setCodCardvar(record.getCodCardvar());
                v.setEstEnvio(SateliteConstants.BOF_EST_ASIENTO_ENVIADO_ERROR);
                varDato.updateByPrimaryKeySelective(v);

            } else {
                for (BofLoteAsientos l : asiento) {
                    this.insertarItemLote(l);
                }
            }
        }
        return resultVarios;
    }

    private HashMap<String, String> getAsientoDefaultValues() {
        if (datosCuenta == null) {
            datosCuenta = new HashMap<>();
            try {
                List<Parametro> datosAsiento = parametroService.buscar(Constantes.COD_VALOR_DATOSASIENTO, Constantes.TIP_PARAM_DETALLE);
                for (Parametro p : datosAsiento) {
                    if (p.getNumOrden() == 1) datosCuenta.put("MONEDA", p.getNomValor());
                    if (p.getNumOrden() == 2) datosCuenta.put("CCOSTO", p.getNomValor());
                    if (p.getNumOrden() == 3) datosCuenta.put("SOCPRD", p.getNomValor());
                    if (p.getNumOrden() == 4) datosCuenta.put("CANAL", p.getNomValor());
                    if (p.getNumOrden() == 5) datosCuenta.put("TASABASE", p.getNomValor());
                    if (p.getNumOrden() == 6) datosCuenta.put("PROVEEDOR", p.getNomValor());
                    if (p.getNumOrden() == 7) datosCuenta.put("RUCDNI", p.getNomValor());
                    if (p.getNumOrden() == 8) datosCuenta.put("POLCLI", p.getNomValor());
                    if (p.getNumOrden() == 9) datosCuenta.put("SUNAT", p.getNomValor());
                    if (p.getNumOrden() == 10) datosCuenta.put("MPAGO", p.getNomValor());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return datosCuenta;
    }

    private void insertarItemLote(BofLoteAsientos l) {
        HashMap<String, String> datosAsiento = this.getAsientoDefaultValues();
        l.setMoneda(datosAsiento.get("MONEDA"));
        l.setCentroCosto(datosAsiento.get("CCOSTO"));
        l.setSocioProd(datosAsiento.get("SOCPRD"));
        l.setCanal(datosAsiento.get("CANAL"));
        l.setTasaBase(new BigDecimal(datosAsiento.get("TASABASE")));
        l.setProveedorEmpleado(datosAsiento.get("PROVEEDOR"));
        l.setRucDni(datosAsiento.get("RUCDNI"));
        l.setPolizaCliente(datosAsiento.get("POLCLI"));
        l.setComprobanteSunat(datosAsiento.get("SUNAT"));
        l.setMedioPago(datosAsiento.get("MPAGO"));
        l.setEstEnvio(0);
        loteDao.insert(l);
    }

    private boolean asientoNoCuadra(List<BofLoteAsientos> asiento) {
        BigDecimal sumaMontos = BigDecimal.ZERO;
        for (BofLoteAsientos linea : asiento)
            sumaMontos = sumaMontos.add(linea.getImporteTran());
        return sumaMontos.compareTo(BigDecimal.ZERO) != 0;
    }

    public void cancelaGeneracion(BofParamsGeneracionAsientos params) {
        List<BofLoteAsientos> asientosGenerados = new ArrayList<>();
        asientosGenerados = loteDao.generarAsientos(params);
        for (BofLoteAsientos linea : asientosGenerados) {
            linea.setEstEnvio(SateliteConstants.BOF_EST_ASIENTO_NO_ENVIADO);
            loteDao.updateByPrimaryKey(linea);
        }
    }


}
