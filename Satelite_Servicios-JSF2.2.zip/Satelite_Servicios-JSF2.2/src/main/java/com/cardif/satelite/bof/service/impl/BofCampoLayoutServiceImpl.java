package com.cardif.satelite.bof.service.impl;

import java.io.InputStream;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.OldExcelFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.bof.bean.BofCargaDiDpf;
import com.cardif.satelite.bof.bean.BofCargaDiVarios;
import com.cardif.satelite.bof.bean.BofCargaMensual;
import com.cardif.satelite.bof.bean.BofCargasLayout;
import com.cardif.satelite.bof.dao.BofCargasLayoutMapper;
import com.cardif.satelite.bof.service.BofCargaDpfExcelHandler;
import com.cardif.satelite.bof.service.BofCargaMensualExcelHandler;
import com.cardif.satelite.bof.service.BofCargaVariosExcelHandler;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;

@Service("bofCampoLayoutServiceImpl")
public class BofCampoLayoutServiceImpl implements com.cardif.satelite.bof.service.BofCampoLayoutService {

	@Autowired
	private BofCargasLayoutMapper bofCargasLayoutMapper;

	private static final Logger logger = Logger.getLogger(BofCampoLayoutServiceImpl.class);

	@Override
	public List<BofCargasLayout> listarPorNombreTabla(String nombreTabla) {
		List<BofCargasLayout> listaReturn = null;
		listaReturn = bofCargasLayoutMapper.listarPorNombreTabla(nombreTabla);
		return listaReturn;
	}

	@Override
	public String validarCamposLayout(UploadedFile archivoExcel, String nombreLayout, String nombreArchivo)
			throws Exception {
		String respuesta = null;
		try {
			boolean xlsx = nombreArchivo.substring(nombreArchivo.lastIndexOf(".xls") + 1, nombreArchivo.length())
					.equalsIgnoreCase("XLSX");
			List<BofCargasLayout> listaCamposLayout = listarPorNombreTabla(nombreLayout);
			BofCargaMensualExcelHandler xlsxHandler = new BofCargaMensualExcelHandler(listaCamposLayout);
			if (xlsx) {
				respuesta = leerXlsx(archivoExcel, nombreLayout, xlsxHandler);				
				int contFilas = xlsxHandler.getContFilas();
				if (contFilas < 2) {
					return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
				}
				List<BofCargaMensual> listaCargaMen = xlsxHandler.getListaCargaMensual();
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(Constantes.KEY_LIST_MENSUAL_XLSX , listaCargaMen);
				return respuesta;
			} else {
				return "ERROR EXTENSION EXCEL";
			}
		} catch (OldExcelFormatException e) {
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ANTIGUO_FORMATO_EXCEL);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public String validarCamposLayoutDpf(UploadedFile archivoExcel, String nombreLayout, String nombreArchivo)
			throws Exception {
		String respuesta = null;
		try {
			boolean xlsx = nombreArchivo.substring(nombreArchivo.lastIndexOf(".xls") + 1, nombreArchivo.length())
					.equalsIgnoreCase("XLSX");
			List<BofCargasLayout> listaCamposLayout = listarPorNombreTabla(nombreLayout);
			BofCargaDpfExcelHandler xlsxHandler = new BofCargaDpfExcelHandler(listaCamposLayout);
			if (xlsx) {
				respuesta = leerXlsx(archivoExcel, nombreLayout, xlsxHandler);				
				int contFilas = xlsxHandler.getContFilas();
				if (contFilas < 2) {
					return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
				}
				List<BofCargaDiDpf> listaCargaDpf = xlsxHandler.getListaCargaDpf();
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(Constantes.KEY_LIST_DPF_XLSX , listaCargaDpf);
				return respuesta;
			} else {
				return "ERROR EXTENSION EXCEL";
			}
		} catch (OldExcelFormatException e) {
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ANTIGUO_FORMATO_EXCEL);
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public String validarCamposLayoutVarios(UploadedFile archivoExcel, String nombreLayout, String nombreArchivo)
			throws Exception {
		String respuesta = null;
		try {
			boolean xlsx = nombreArchivo.substring(nombreArchivo.lastIndexOf(".xls") + 1, nombreArchivo.length())
					.equalsIgnoreCase("XLSX");
			List<BofCargasLayout> listaCamposLayout = listarPorNombreTabla(nombreLayout);
			BofCargaVariosExcelHandler xlsxHandler = new BofCargaVariosExcelHandler(listaCamposLayout);
			if (xlsx) {
				respuesta = leerXlsx(archivoExcel, nombreLayout, xlsxHandler);				
				int contFilas = xlsxHandler.getContFilas();
				if (contFilas < 2) {
					return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
				}
				List<BofCargaDiVarios> listaCargaVar = xlsxHandler.getListaCargaVarios();
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(Constantes.KEY_LIST_VARIOS_XLSX , listaCargaVar);
				return respuesta;
			} else {
				return "ERROR EXTENSION EXCEL";
			}
		} catch (OldExcelFormatException e) {
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ANTIGUO_FORMATO_EXCEL);
		} catch (Exception e) {
			throw e;
		}
	}

	private String leerXlsx(UploadedFile excelFile, String nombreLayout, SheetContentsHandler xlsxHandler)
			throws Exception {
		InputStream stream = null;
		try {
			OPCPackage container;
			container = OPCPackage.open(excelFile.getInputStream());
			ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(container);
			XSSFReader xssfReader = new XSSFReader(container);
			StylesTable styles = xssfReader.getStylesTable();
			stream = xssfReader.getSheet("rId1");
			String resultado = this.procesarXlsx(styles, strings, stream, nombreLayout, xlsxHandler);
			return resultado;
		} catch (Exception e) {
			throw e;
		} finally {
			if (stream != null) {
				stream.close();
			}
		}
	}

	private String procesarXlsx(StylesTable styles, ReadOnlySharedStringsTable strings, InputStream sheetInputStream,
			String nombreLayout, SheetContentsHandler xlsxHandler) {
		InputSource sheetSource = new InputSource(sheetInputStream);
		SAXParserFactory saxFactory = SAXParserFactory.newInstance();
		try {
			SAXParser saxParser = saxFactory.newSAXParser();
			XMLReader sheetParser = saxParser.getXMLReader();
			// List<BofCargasLayout> listaCamposLayout = listarPorNombreTabla(nombreLayout);
			// BofCargaMensualExcelHandler xlsxHandler = new
			// BofCargaMensualExcelHandler(listaCamposLayout);
			ContentHandler handler = new XSSFSheetXMLHandler(styles, strings, xlsxHandler, false);
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return e.getStackTrace().toString();
		}
	}

}
