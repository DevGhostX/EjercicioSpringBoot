package com.cardif.satelite.bof.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.bof.bean.BofCargaMensual;
import com.cardif.satelite.bof.dao.BofCargaMensualMapper;
import com.cardif.satelite.bof.service.BofCargaMensualService;


@Service("bofCargaMensualServiceImpl")
public class BofCargaMensualServiceImpl implements BofCargaMensualService {

    public static final Logger log = Logger.getLogger(BofCargaMensualServiceImpl.class);

    @Autowired
    BofCargaMensualMapper dao;

    @Override
    public void InsertarCargaMensual(List<BofCargaMensual> listaCargaMensual, String periodo) {
        // TODO Auto-generated method stub
        try {
            for (BofCargaMensual record : listaCargaMensual) {
                record.setPerCarga(periodo);
                record.setCodCargam(this.GetNewMenId(periodo));
                dao.insert(record);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }


    }

    @Override
    public List<BofCargaMensual> ListarCargaMensual(String codigoCarga) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> listarPeriodos() {
        List<String> periodosReturn = new ArrayList<String>();
        String period = "0";
        Calendar calendar = Calendar.getInstance();
        Integer year = calendar.get(Calendar.YEAR);
        Integer lastYear = year - 1;
        Integer currentMonth = calendar.get(Calendar.MONTH);
        periodosReturn.add("012" + lastYear.toString());

        for (int i = 1; i <= currentMonth + 1; i = i + 1) {
            period = "0" + (i > 9 ? String.valueOf(i) : "0" + String.valueOf(i)) + year.toString();
            periodosReturn.add(period);
        }

        return periodosReturn;
    }

    private String GetNewMenId(String periodo) {
        String valueReturn = "";
        String countPart = dao.countAll(periodo);
        valueReturn = periodo + countPart;
        return valueReturn;
    }

}
