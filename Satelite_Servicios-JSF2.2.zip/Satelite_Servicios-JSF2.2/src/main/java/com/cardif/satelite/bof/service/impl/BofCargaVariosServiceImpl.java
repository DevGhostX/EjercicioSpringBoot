package com.cardif.satelite.bof.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.bof.bean.BofCargaDiVarios;
import com.cardif.satelite.bof.dao.BofCargaDiVariosMapper;
import com.cardif.satelite.bof.service.BofCargaVariosService;

@Service("bofCargaVariosServiceImpl")
public class BofCargaVariosServiceImpl implements BofCargaVariosService {
	
	public static final Logger log = Logger.getLogger(BofCargaVariosServiceImpl.class);

	@Autowired
	private BofCargaDiVariosMapper bofCargaDiVariosMapper;
	
	@Override
	public void InsertarCargaVarios(List<BofCargaDiVarios> listaVarios, String periodo) {
		try {
			for (BofCargaDiVarios record : listaVarios) {
				record.setPerCarga(periodo);
				record.setCodCardvar(this.GetNewVarId(periodo));
				bofCargaDiVariosMapper.insert(record);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	@Override
	public List<BofCargaDiVarios> listarCargaVarios(String codigoCargaVarios) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> listarPeriodos() {
		List<String> periodosReturn = new ArrayList<String>();
		String period = "0";
		Calendar calendar = Calendar.getInstance();
		Integer year = calendar.get(Calendar.YEAR);
		Integer lastYear = year -1;
		Integer currentMonth = calendar.get(Calendar.MONTH);
		periodosReturn.add("012" + lastYear.toString());

		for(int i = 1; i<= currentMonth+1; i= i+1){
			period = "0" + (i>9? String.valueOf(i): "0" + String.valueOf(i)) + year.toString();
			periodosReturn.add(period);
		}

		return periodosReturn;
	}

	private String GetNewVarId(String periodoCarga){
		String valueReturn = "";
		String countPart = bofCargaDiVariosMapper.countAll(periodoCarga);
		valueReturn = periodoCarga + countPart;
		return valueReturn;
	}
}
