package com.cardif.satelite.bof.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.bof.bean.BofConfiguracion;
import com.cardif.satelite.bof.dao.BofConfiguracionMapper;
import com.cardif.satelite.bof.service.BofConfiguracionService;


@Service("BofConfiguracionService")
public class BofConfiguracionServiceImpl implements BofConfiguracionService {
	
	public static final Logger log = Logger.getLogger(BofConfiguracionServiceImpl.class);
	
	@Autowired
	BofConfiguracionMapper bofMapper;

	@Override
	public List<BofConfiguracion> listarConfiguracion(int codigoTabla) throws SyncconException {
		// TODO Auto-generated method stub
		List<BofConfiguracion> listaReturn;
		listaReturn = bofMapper.listarTablaConfiguracion(codigoTabla);
		return listaReturn;
	}

	@Override
	public BofConfiguracion getConfiguracion(int codigoConfiguracion) throws SyncconException {
		BofConfiguracion config = null;
		config = bofMapper.obtenerConfiguracion(codigoConfiguracion);
		return null;
	}

	@Override
	public int crearBofConfiguracion(BofConfiguracion configuracion) throws SyncconException {
		int result = bofMapper.insertarBofConfiguracion(configuracion);
		return result;
	}

	@Override
	public int actualizarBofConfiguracion(BofConfiguracion configuracion) throws SyncconException {
		int result = bofMapper.actualizarBofConfiguracion(configuracion);
		return result;
	}

	@Override
	public int eliminarBofConfiguracion(BofConfiguracion configuracion) throws SyncconException {
		int result = bofMapper.eliminarBofConfiguracion(configuracion);
		return result;
	}




}
