package com.cardif.satelite.bof.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.bof.bean.BofDinamicaContable;
import com.cardif.satelite.bof.dao.BofDinamicaContableMapper;
import com.cardif.satelite.bof.model.ConsultaDinamicaModel;
import com.cardif.satelite.bof.model.DinamicaContableModel;
import com.cardif.satelite.bof.service.BofDinamicaContableService;

@Service("bofDinamicaContableServiceImpl")
public class BofDinamicaContableServiceImpl implements BofDinamicaContableService {
	public static final Logger log = Logger.getLogger(BofDinamicaContableServiceImpl.class);

	@Autowired
	BofDinamicaContableMapper dinamicaDao;

	@Override
	public List<DinamicaContableModel> listarDinamicaContable(ConsultaDinamicaModel params) {
		List<DinamicaContableModel> listaReturn;
		try {

			listaReturn = dinamicaDao.selectAll(params);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
		return listaReturn;
	}

	@Override
	public int RegistrarDinamicaContable(BofDinamicaContable dinamica) {
		int recordsAfected = 0;
		try {
			recordsAfected = dinamicaDao.insert(dinamica);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
		return recordsAfected;
	}

	@Override
	public int ActualizaDinamicaContable(BofDinamicaContable dinamica) {
		int recordsAfected = 0;
		try {
			recordsAfected = dinamicaDao.updateByPrimaryKey(dinamica);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
		return recordsAfected;
	}

	@Override
	public int InactivaDinamicaContable(int codDinamica) {
		int recordsAfected = 0;
		try {
			recordsAfected = dinamicaDao.deleteByPrimaryKey(codDinamica);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
		return recordsAfected;
	}

	@Override
	public BofDinamicaContable obtenerPorId(int codDinamica) {
		BofDinamicaContable record = null;
		try {
			record = dinamicaDao.selectByPrimaryKey(codDinamica);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
		return record;
	}

}
