package com.cardif.satelite.bof.service.impl;

import com.cardif.satelite.bof.bean.BofLoteAsientos;
import com.cardif.satelite.bof.bean.BofParamsReporte;
import com.cardif.satelite.bof.service.BofSunSystemService;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.Utilitarios;
import com.cardif.sunsystems.mapeo.ingresoSun.SSC;
import com.cardif.sunsystems.services.SunComponenteService;

import com.cardif.sunsystems.util.ConstantesSun;
import com.cardif.sunsystems.util.Utilidades;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BofSunSystemServiceImpl implements BofSunSystemService {
    public static final Logger log = Logger.getLogger(BofSunSystemServiceImpl.class);

    @Override
    public List<BofLoteAsientos> registrarAsiento(List<BofLoteAsientos> bofDetLoteAsientos) throws Exception {
        SunComponenteService service = new SunComponenteService();
        boolean envioError = false;

        try {
            String requestXml = generarRequestEnvioAsientoXml(bofDetLoteAsientos);
            log.info("Inicio enviando Asientos a Sunsystem");
            log.info("SunSystemsController - El Payload para enviar a SUN es : " + requestXml);
            String responseXml = service.ejecutaConsulta(ConstantesSun.SSC_ComponenteJournal, ConstantesSun.SSC_MetodoLoadAndPost, requestXml);
            List<com.cardif.sunsystems.mapeo.salidaSun.SSC.Payload.Ledger.Line> responseList = parseResponseEnvioAsiento(responseXml);
            for (com.cardif.sunsystems.mapeo.salidaSun.SSC.Payload.Ledger.Line l : responseList) {
                if (l.getStatus().equals("fail")) {
                    envioError = true;
                    break;
                }
            }
            //for(BofLoteAsientos itemLote: bofDetLoteAsientos){
            //    itemLote.setNumeroDiario(String.valueOf(responseList.get(0).getJournalNumber()));
            //    itemLote.setEstEnvio(envioError? SateliteConstants.BOF_EST_ASIENTO_ENVIADO_ERROR: SateliteConstants.BOF_EST_ASIENTO_ENVIADO);
            //}
            int xCont = 0;
            for (com.cardif.sunsystems.mapeo.salidaSun.SSC.Payload.Ledger.Line l : responseList) {
                bofDetLoteAsientos.get(xCont).setLineNumber(String.valueOf(l.getJournalLineNumber()));
                bofDetLoteAsientos.get(xCont).setNumeroDiario(String.valueOf(l.getJournalNumber()));
                bofDetLoteAsientos.get(xCont).setEstEnvio(envioError ? SateliteConstants.BOF_EST_ASIENTO_ENVIADO_ERROR : SateliteConstants.BOF_EST_ASIENTO_ENVIADO);
                if (l.getStatus().equals("fail")) {
                    if (l.getMessages() != null)
                        for (com.cardif.sunsystems.mapeo.salidaSun.SSC.Payload.Ledger.Line.Messages.Message message : l.getMessages().getMessage()) {
                            if (message.getLevel().equals("error")) {
                                bofDetLoteAsientos.get(xCont).setGlosaEnvio(message.getUserText());
                            }
                        }
                }
                xCont = xCont + 1;
            }
            log.info("Fin enviando Asientos a Sunsystem");
            return bofDetLoteAsientos;
        } catch (Exception e) {
            log.error(e.getStackTrace(), e);
            return null;
        }
    }

    @Override
    public List<BofLoteAsientos> consultarAsientosReporte(BofParamsReporte params) {
        List<BofLoteAsientos> listaReturn = new ArrayList<>();
        BofLoteAsientos la = null;
        try {
            SunComponenteService service = new SunComponenteService();
            String requestXml = generaRequestReporte(params);
            String responseXml = service.ejecutaConsulta(ConstantesSun.SSC_ComponenteJournal, ConstantesSun.SSC_MetodoQuery, requestXml);
            List<com.cardif.sunsystems.mapeo.journal.SSC.Payload.Ledger.Line> asientos = parseResponseReporte(responseXml);
            for (com.cardif.sunsystems.mapeo.journal.SSC.Payload.Ledger.Line line : asientos) {
                la = mapToBean(line);
                listaReturn.add(la);
            }
            Collections.sort(listaReturn);
        } catch (Exception e) {
            log.error(e.getStackTrace(), e);
            return listaReturn;
        }
        return listaReturn;
    }

    private String generarRequestEnvioAsientoXml(List<BofLoteAsientos> bofDetLoteAsientos) throws Exception {
        JAXBContext jaxbContext = JAXBContext.newInstance(com.cardif.sunsystems.mapeo.ingresoSun.ObjectFactory.class);

        Marshaller marshaller = jaxbContext.createMarshaller();
        SSC jaxbElement = new SSC();
        SSC.MethodContext metodocontexto = new com.cardif.sunsystems.mapeo.ingresoSun.SSC.MethodContext();

        SSC.MethodContext.LedgerPostingParameters posting = new SSC.MethodContext.LedgerPostingParameters();

        posting.setPostingType(ConstantesSun.SSC_postingtype_contabilizar_sinerrores);
        posting.setReportingAccount(ConstantesSun.CTA_ReportingAccount);
        metodocontexto.setLedgerPostingParameters(posting);
        jaxbElement.setMethodContext(metodocontexto);

        SSC.User usuariows = new SSC.User();
        usuariows.setName(ConstantesSun.AUTH_USR_SUN_LOGIN);

        jaxbElement.setUser(usuariows);
        SSC.SunSystemsContext contexto = new SSC.SunSystemsContext();
        contexto.setBudgetCode(ConstantesSun.SSC_BudgetCode);
        contexto.setBusinessUnit(ConstantesSun.SSC_BusinessUnit_E01);
        jaxbElement.setSunSystemsContext(contexto);

        jaxbElement.setPayload(new SSC.Payload());
        jaxbElement.getPayload().setLedger(new SSC.Payload.Ledger());
        List<SSC.Payload.Ledger.Line> lineasAsiento = new ArrayList<SSC.Payload.Ledger.Line>();
        SSC.Payload.Ledger.Line linea = null;
        SSC.Payload.Ledger.Line.DetailLad detailLad = null;

        for (BofLoteAsientos lineaAsiento : bofDetLoteAsientos) {
            SSC.Payload.Ledger.Line lineaAsientoWs = this.mapToService(lineaAsiento);
            lineasAsiento.add(lineaAsientoWs);
        }
        jaxbElement.getPayload().getLedger().getLine().addAll(lineasAsiento);
        Writer writer = new StringWriter();
        marshaller.marshal(jaxbElement, writer);
        return writer.toString();
    }

    private String generaRequestReporte(BofParamsReporte params) {
        String requestXml = "";
        Utilidades utiles = new Utilidades();

        try {
            Document doc = utiles.loadXMLFromResource("/com/cardif/sunsystems/plantillas/journalBofHistorico.xml");
            NodeList items = doc.getElementsByTagName("Item");
            boolean periodoRemoved = false;

            items.item(0).getAttributes().getNamedItem("value").setNodeValue(params.getTipodiario());

            Node nodePeriodo = items.item(1);
            if (params.getPerIni().equals("") || params.getPerFin().equals("")) {
                nodePeriodo.getParentNode().removeChild(nodePeriodo);
                periodoRemoved = true;
            } else {
                items.item(1).getAttributes().getNamedItem("minvalue").setNodeValue(params.getPerIni());
                items.item(1).getAttributes().getNamedItem("maxvalue").setNodeValue(params.getPerFin());
            }

            Node nodeFechas = items.item(periodoRemoved ? 1 : 2);
            if (params.getFecInicio() == null || params.getFecFin() == null) {
                nodeFechas.getParentNode().removeChild(nodeFechas);
            } else {
                items.item(periodoRemoved ? 1 : 2).getAttributes().getNamedItem("minvalue").setNodeValue(Utilitarios.personalizarFecha(params.getFecInicio(), "ddMMyyyy"));
                items.item(periodoRemoved ? 1 : 2).getAttributes().getNamedItem("maxvalue").setNodeValue(Utilitarios.personalizarFecha(params.getFecFin(), "ddMMyyyy"));
            }
            requestXml = utiles.documenttoString(doc);
        } catch (Exception e) {
            log.error(e.getStackTrace(), e);
            return "";
        }
        return requestXml;
    }

    private List<com.cardif.sunsystems.mapeo.salidaSun.SSC.Payload.Ledger.Line> parseResponseEnvioAsiento(String responseXml) throws Exception {
        List<com.cardif.sunsystems.mapeo.salidaSun.SSC.Payload.Ledger.Line> response = null;
        JAXBContext jaxbContext = JAXBContext.newInstance(com.cardif.sunsystems.mapeo.salidaSun.ObjectFactory.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        StringReader reader = new StringReader(responseXml);
        log.info(reader.ready());
        Object obj = unmarshaller.unmarshal(reader);
        com.cardif.sunsystems.mapeo.salidaSun.SSC bufferResponse = (com.cardif.sunsystems.mapeo.salidaSun.SSC) obj;
        response = bufferResponse.getPayload().getLedger().getLine();
        return response;
    }

    private List<com.cardif.sunsystems.mapeo.journal.SSC.Payload.Ledger.Line> parseResponseReporte(String responseXml) throws Exception {
        JAXBContext jaxbContext = JAXBContext.newInstance(com.cardif.sunsystems.mapeo.journal.ObjectFactory.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        if (responseXml.indexOf("<Line>") == -1) return new ArrayList<>();
        StringReader reader = new StringReader(responseXml);
        com.cardif.sunsystems.mapeo.journal.SSC expenseObj = (com.cardif.sunsystems.mapeo.journal.SSC) unmarshaller.unmarshal(reader);
        com.cardif.sunsystems.mapeo.journal.SSC.Payload.Ledger superlinea = expenseObj.getPayload().getLedger();
        List<com.cardif.sunsystems.mapeo.journal.SSC.Payload.Ledger.Line> lineas = superlinea.getLine();
        return lineas;
    }

    private SSC.Payload.Ledger.Line mapToService(BofLoteAsientos lineaAsiento) {

        SSC.Payload.Ledger.Line l = new SSC.Payload.Ledger.Line();
        l.setAccountCode(lineaAsiento.getCtaContable());
        l.setAccountingPeriod(lineaAsiento.getPeriodo());
        l.setAnalysisCode1(lineaAsiento.getCentroCosto());
        l.setAnalysisCode2(lineaAsiento.getSocioProd());
        l.setAnalysisCode3(lineaAsiento.getCanal());
        l.setAnalysisCode4(lineaAsiento.getProveedorEmpleado());
        l.setAnalysisCode5(lineaAsiento.getRucDni());
        l.setAnalysisCode6(lineaAsiento.getPolizaCliente());
        l.setAnalysisCode7("");
        l.setAnalysisCode8("");
        l.setAnalysisCode9(lineaAsiento.getComprobanteSunat());
        l.setAnalysisCode10(lineaAsiento.getMedioPago());//MEDIO DE PAGO
        l.setCurrencyCode(lineaAsiento.getMoneda());
        l.setDebitCredit(lineaAsiento.getDebitoCredito());
        l.setDescription(lineaAsiento.getGlosa());
        l.setDueDate("");//NO SE SABE QUE ENVIAR
        l.setJournalType(lineaAsiento.getTipoDiario());
        //l.setTransactionAmount("0");
        l.setTransactionAmount(lineaAsiento.getImporteTran().toString());
        l.setBaseAmount(lineaAsiento.getImporteTran().toString());//warning
        l.setTransactionDate(lineaAsiento.getFechaTransaccion());
        l.setTransactionReference(lineaAsiento.getRefTransaccion());
        return l;
    }

    private BofLoteAsientos mapToBean(com.cardif.sunsystems.mapeo.journal.SSC.Payload.Ledger.Line line) {
        log.info(line);
        BofLoteAsientos la = new BofLoteAsientos();
        la.setPeriodo(String.valueOf(line.getAccountingPeriod()));
        la.setTipoDiario(line.getJournalLineNumber());
        la.setTipoDiario(line.getJournalType());
        la.setNumeroDiario(String.valueOf(line.getJournalNumber()));
        la.voidSetFormatFechaTransaccion(line.getTransactionDate());//FECHA TRX
        la.setCtaContable(line.getAccountCode());
        la.setNomCtaContable(line.getAccounts().getDescription());
        la.setRefTransaccion(line.getTransactionReference());
        la.setGlosa(line.getDescription());
        la.setImporteTran(new BigDecimal(line.getBaseAmount()));//ERROR FORMATO
        la.setDebitoCredito(line.getDebitCredit());
        la.setUsuRegistro(line.getOriginator());
        return la;
    }
}
