package com.cardif.satelite.configuracion.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.CanalProducto;
import com.cardif.satelite.model.ParametroAutomat;

public interface CanalProductoMapper {
	final String SELECT_BY_ESTADO = "SELECT ID, " + "NOMBRE_CANAL,  " + "ESTADO " + "FROM CANAL_PRODUCTO "
			+ "WHERE ESTADO = #{estado,jdbcType=NUMERIC} " + "AND ID != " + Constantes.ID_CANAL_DIGITAL
			+ "ORDER BY NOMBRE_CANAL ASC";

	final String SELECT_LISTA_CANALES_PRODUCTO = "SELECT ID,  NOMBRE_CANAL,  ESTADO FROM CANAL_PRODUCTO WHERE ID in (#{Producto,jdbcType=VARCHAR})";

	final String SELECT_CANAL = " SELECT ID,  NOMBRE_CANAL,  ESTADO FROM CANAL_PRODUCTO WHERE ID not in ( "
			+ Constantes.ID_CANAL_CLIENTES_ESPECIALES + " ) ";

	final String SELECT_TIPO_TRAMA = "SELECT COD_PARAM, COD_VALOR, NOMBRE_VALOR, NUM_ORDEN FROM PARAMETRO_AUTOMAT WHERE COD_PARAM = '"
			+ Constantes.COD_PARAM_TIPO_TRAMA + "' ORDER BY NUM_ORDEN ASC";

	final String SELECT_BY_COD_SOCIO = "SELECT DISTINCT CAP.ID,CAP.NOMBRE_CANAL,CAP.ESTADO,CAP.CANAL_MASTER FROM CANAL_PRODUCTO CAP WHERE ID IN( "
			+ "SELECT PRO.ID_CANAL FROM PRODUCTO PRO INNER JOIN (SELECT S.ID AS ID_SOCIO,S.NOMBRE_SOCIO FROM SOCIO S WHERE S.ESTADO = NVL(#{estadoSocio,jdbcType=NUMERIC}, S.ESTADO) )  "
			+ " TBL_SOCIO  ON TBL_SOCIO.ID_SOCIO = PRO.ID_SOCIO WHERE 	TBL_SOCIO.ID_SOCIO =NVL(#{codSocio,jdbcType=NUMERIC}, TBL_SOCIO.ID_SOCIO) "
			// + " AND PRO.MOD_SUSCRIPCION =
			// NVL(#{modSuscripcionOpcion,jdbcType=NUMERIC},
			// PRO.MOD_SUSCRIPCION)"
			+ " AND PRO.ESTADO = NVL(#{estadoProducto,jdbcType=NUMERIC}, PRO.ESTADO)) "
			+ " AND CAP.ESTADO= NVL(#{estadoCanal,jdbcType=NUMERIC}, CAP.ESTADO) " + " ORDER BY NOMBRE_CANAL ASC ";

	final String SELECT_SOCIOBYCANALMASTER = "SELECT DISTINCT CAP.ID,CAP.NOMBRE_CANAL,CAP.ESTADO,CAP.CANAL_MASTER FROM CANAL_PRODUCTO CAP WHERE ID IN( "
			+ "SELECT PRO.ID_CANAL FROM PRODUCTO PRO INNER JOIN (SELECT S.ID AS ID_SOCIO,S.NOMBRE_SOCIO FROM SOCIO S WHERE S.ESTADO = "
			+ Constantes.PRODUCTO_ESTADO_ACTIVO + ")"
			+ " TBL_SOCIO  ON TBL_SOCIO.ID_SOCIO = PRO.ID_SOCIO WHERE 	TBL_SOCIO.ID_SOCIO =NVL(#{socio,jdbcType=NUMERIC}, TBL_SOCIO.ID_SOCIO)) "
			+ " ORDER BY NOMBRE_CANAL ASC";

	/*
	 * final String SELECT_SOCIOBYCANAL
	 * ="SELECT DISTINCT CAP.ID,CAP.NOMBRE_CANAL,CAP.ESTADO,CAP.CANAL_MASTER FROM CANAL_PRODUCTO CAP WHERE nombre_canal not in('DIGITAL') and ID IN( "
	 * +
	 * "SELECT PRO.ID_CANAL FROM PRODUCTO PRO INNER JOIN (SELECT S.ID AS ID_SOCIO,S.NOMBRE_SOCIO FROM SOCIO S WHERE S.ESTADO = "
	 * + Constantes.PRODUCTO_ESTADO_ACTIVO +")" +
	 * " TBL_SOCIO  ON TBL_SOCIO.ID_SOCIO = PRO.ID_SOCIO WHERE 	TBL_SOCIO.ID_SOCIO =NVL(#{socio,jdbcType=NUMERIC}, TBL_SOCIO.ID_SOCIO)) "
	 * + " ORDER BY NOMBRE_CANAL ASC";
	 */
	final String SELECT_SOCIO_CANAL = "SELECT CP.ID , CP.NOMBRE_CANAL,CP.ESTADO,CP.CANAL_MASTER" + " FROM PRODUCTO PD"
			+ " INNER JOIN CANAL_PRODUCTO CP ON PD.ID_CANAL = CP.ID" + " WHERE PD.ESTADO = 1"
			+ " AND PD.MOD_SUSCRIPCION = 1" + " AND PD.TRAMA_DIARIA = 1" + " AND CP.CANAL_MASTER NOT IN ('DIGITAL')"
			+ " AND PD.ID_SOCIO = #{socio,jdbcType=NUMERIC}"
			+ " GROUP BY CP.ID, CP.NOMBRE_CANAL,CP.ESTADO,CP.CANAL_MASTER";

	final String SELECT_SOCIO_CANAL_MENSUAL = "SELECT CP.ID , CP.NOMBRE_CANAL,CP.ESTADO,CP.CANAL_MASTER"
			+ " FROM PRODUCTO PD" + " INNER JOIN CANAL_PRODUCTO CP ON PD.ID_CANAL = CP.ID" + " WHERE PD.ESTADO = 1"
			+ " AND PD.MOD_SUSCRIPCION = 1" + " AND PD.TRAMA_MENSUAL = 1" + " AND CP.CANAL_MASTER NOT IN ('DIGITAL')"
			+ " AND PD.ID_SOCIO = #{socio,jdbcType=NUMERIC}"
			+ " GROUP BY CP.ID, CP.NOMBRE_CANAL,CP.ESTADO,CP.CANAL_MASTER";

	public CanalProducto selectByPrimaryKey(Long id);

	@Select(SELECT_BY_ESTADO)
	@ResultMap("BaseResultMap")
	public List<CanalProducto> selectByEstado(int estado);

	@Select(SELECT_LISTA_CANALES_PRODUCTO)
	@ResultMap("BaseResultMap")
	public List<CanalProducto> selectListaCanalesProducto(@Param("Producto") String Producto);

	// public List<CanalProducto> selectByPrimaryKey(Long idProducto);

	@Select(SELECT_CANAL)
	@ResultMap("BaseResultMap")
	public List<CanalProducto> selectAll();

	@Select(SELECT_TIPO_TRAMA)
	@ResultMap("BaseResultTrama")
	public List<ParametroAutomat> selectTipoTrama();

	@Select(SELECT_BY_COD_SOCIO)
	@ResultMap("BaseResultMap")
	public List<CanalProducto> selectByCodSocio(@Param("modSuscripcionOpcion") Integer modSuscripcionOpcion,
			@Param("estadoSocio") Integer estadoSocio, @Param("estadoProducto") Integer estadoProducto,
			@Param("estadoCanal") Integer estadoCanal, @Param("codSocio") Long codSocio);

	@Select(SELECT_SOCIO_CANAL)
	@ResultMap("BaseResultMap")
	public List<CanalProducto> listarCanalSocio(@Param("socio") String socio);

	@Select(SELECT_SOCIO_CANAL_MENSUAL)
	@ResultMap("BaseResultMap")
	public List<CanalProducto> listarCanalSocioMensual(@Param("socio") String socio);

	@Select(SELECT_SOCIOBYCANALMASTER)
	@ResultMap("BaseResultMap")
	public List<CanalProducto> listarCanalSocioMaster(@Param("socio") String socio);

} // CanalProductoMapper
