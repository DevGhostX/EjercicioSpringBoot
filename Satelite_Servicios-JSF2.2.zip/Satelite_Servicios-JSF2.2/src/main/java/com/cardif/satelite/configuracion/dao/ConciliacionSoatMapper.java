package com.cardif.satelite.configuracion.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.ConciliacionSoat;

public interface ConciliacionSoatMapper {

	public int insertSelective(ConciliacionSoat record);

	public int insert(ConciliacionSoat record);

	final String UPDATE_ESTADO_CONCILIACION_CERRADA = "UPDATE CONCILIACION_SOAT SET ESTADO = "
			+ Constantes.COD_CONCILIACION_CERRADA_5 + "  WHERE ID_CONCI_SOAT = #{idConciSoat} ";

	@Select(UPDATE_ESTADO_CONCILIACION_CERRADA)
	public void updateEstadoConciliacionCerrada(@Param("idConciSoat") Long idConciSoat);

	public void updateCancelarConciTramaDiariavsMensual(@Param("estadoConciSoat") int estadoConciSoat,
			@Param("idConciSoat") Long idConciSoat);
}
