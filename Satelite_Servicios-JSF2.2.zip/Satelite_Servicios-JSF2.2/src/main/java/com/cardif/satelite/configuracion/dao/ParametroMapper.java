package com.cardif.satelite.configuracion.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.model.ParametroExample;
import com.cardif.satelite.model.ParametroKey;

public interface ParametroMapper {

	final String SELECT_PARAM = "SELECT * FROM PARAMETRO WHERE COD_PARAM = #{codParam} AND TIP_PARAM = #{tipParam} ORDER BY NOM_VALOR";

	@Select(SELECT_PARAM)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> selectParametro(@Param("codParam") String codParam, @Param("tipParam") String tipParam);

	/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
	/******* {Carlos Chayguaque} - {25/09/2020} ********/
	final String SELECT_PARAM_VALOR = "SELECT * FROM PARAMETRO WHERE COD_PARAM = #{codParam} AND TIP_PARAM = #{tipParam} AND COD_VALOR=#{codValor} ORDER BY NOM_VALOR";

	@Select(SELECT_PARAM_VALOR)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> selectParametroValor(@Param("codParam") String codParam, @Param("tipParam") String tipParam, @Param("codValor") String codValor);
	
	final String SELECT_PARAM_VALOR_DISCTINT = "SELECT DISTINCT COD_VALOR FROM PARAMETRO WHERE COD_PARAM = #{codParam} AND TIP_PARAM = #{tipParam}";

	@Select(SELECT_PARAM_VALOR_DISCTINT)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> selectDistinctParametro(@Param("codParam") String codParam, @Param("tipParam") String tipParam);
	/*** Fin {Automatización Contabilidad} - {Sprint 1} **/

	final String SELECT_PARAMETRO = "SELECT * FROM PARAMETRO WHERE COD_PARAM = #{codParam} AND TIP_PARAM = #{tipParam} AND COD_VALOR=#{codValor}";

	@Select(SELECT_PARAMETRO)
	@ResultMap(value = "BaseResultMap")
	Parametro obtenerParametro(@Param("codParam") String codParam, @Param("tipParam") String tipParam,
			@Param("codValor") String codValor);

	final String SELECT_COD_PARAMETRO = "SELECT * FROM PARAMETRO WHERE COD_PARAM = #{codParam} AND TIP_PARAM = #{tipParam} AND NOM_VALOR=#{nomValor}";

	@Select(SELECT_COD_PARAMETRO)
	@ResultMap(value = "BaseResultMap")
	Parametro obtenerCodParametro(@Param("codParam") String codParam, @Param("tipParam") String tipParam,
			@Param("nomValor") String nomValor);

	final String SELECT_DESCRIPTION_SOCIO = "SELECT NOM_VALOR FROM PARAMETRO WHERE COD_VALOR = #{codSocio,JDBCTYPE=VARCHAR} AND COD_PARAM = #{codParam,JDBCTYPE=VARCHAR} AND TIP_PARAM = #{tipParam,JDBCTYPE=VARCHAR}";

	@Select(SELECT_DESCRIPTION_SOCIO)
	String consultarDescripcion(@Param("codSocio") String codSocio, @Param("codParam") String codParam,
			@Param("tipParam") String tipParam);

	final String GET_BANCOS = "SELECT * FROM PARAMETRO WHERE cod_param=039 AND nom_valor like '%Cheque%'";

	@Select(GET_BANCOS)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> getBancos();

	final String GET_BANCOS_SATELITE = "SELECT * FROM PARAMETRO WHERE cod_param= #{codParam,JDBCTYPE=VARCHAR} AND TIP_PARAM =  #{TipParam,JDBCTYPE=VARCHAR}";

	@Select(GET_BANCOS_SATELITE)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> getParamGenerales(@Param("codParam") String codParam, @Param("TipParam") String TipParam);

	final String SELECT_CHEQUES_ESTADO_IMPRES = "SELECT * FROM PARAMETRO WHERE cod_param=068 AND tip_param='D' AND cod_valor in ('I','E')";

	@Select(SELECT_CHEQUES_ESTADO_IMPRES)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> getChequesEstadoImpresion();

	final String SELECT_FIRMANTES = "SELECT * FROM PARAMETRO WHERE cod_param=057 AND num_orden is not null";

	@Select(SELECT_FIRMANTES)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> getFirmantes();

	final String SELECT_MEDIOS_PAGO = "SELECT * FROM PARAMETRO where cod_param=#{cod_param} and tip_param=#{tip_param} and cod_valor not in ('8')";

	@Select(SELECT_MEDIOS_PAGO)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> selectMediosPago(@Param("cod_param") String codParam, @Param("tip_param") String tipParam);

	final String SELECT_BANCOS = "SELECT NOM_VALOR FROM PARAMETRO WHERE cod_param=039 AND nom_valor like '%Cheque%' or NOM_VALOR IN ('"
			+ Constantes.ELECTRONICO_SINIESTRO + "', '" + Constantes.MDP_MEDIO_PAGO_ELECTR_DEV_PRIM
			+ "') ORDER BY NOM_VALOR;";

	@Select(SELECT_BANCOS)
	List<String> selectBancos();

	final String SELECT_PAGOS_MASIVOS = "SELECT * FROM PARAMETRO WHERE COD_PARAM = #{codParam} AND TIP_PARAM = #{tipParam} "
			+ "AND COD_VALOR IN ('1','3','4','5')";

	@Select(SELECT_PAGOS_MASIVOS)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> selectPagosMasivos(@Param("codParam") String codParam, @Param("tipParam") String tipParam);

	final String SELECT_CUENTAS_BANCARIAS_BY_BANCO = "SELECT BAN.COD_VALOR, BAN.NOM_VALOR FROM PARAMETRO CTA INNER JOIN PARAMETRO BAN ON (BAN.COD_PARAM = #{codParamBancos} AND CTA.COD_PARAM = #{codParamCuentas} AND CTA.NOM_VALOR = BAN.COD_VALOR) WHERE CTA.COD_VALOR = #{codBanco} ";

	@Select(SELECT_CUENTAS_BANCARIAS_BY_BANCO)
	@ResultMap(value = "BaseResultMap")
	List<Parametro> selectCuentasBancariasByBanco(@Param("codBanco") String codBanco,
			@Param("codParamBancos") String codParamBancos, @Param("codParamCuentas") String codParamCuentas);

	/* MODULO PAGOS FASE 2 */
	final String SELECT_PARAMETRO_BY_NOM_VALOR = "SELECT * FROM PARAMETRO WHERE COD_PARAM = #{codParam} AND TIP_PARAM = #{tipParam} AND NOM_VALOR = #{nomValor}";

	@Select(SELECT_PARAMETRO_BY_NOM_VALOR)
	@ResultMap(value = "BaseResultMap")
	Parametro obtenerParametroByNomValor(@Param("codParam") String codParam, @Param("tipParam") String tipParam,
			@Param("nomValor") String nomValor);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int countByExample(ParametroExample example);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int deleteByExample(ParametroExample example);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int deleteByPrimaryKey(ParametroKey key);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int insert(Parametro record);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int insertSelective(Parametro record);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	List<Parametro> selectByExample(ParametroExample example);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	Parametro selectByPrimaryKey(ParametroKey key);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int updateByExampleSelective(@Param("record") Parametro record, @Param("example") ParametroExample example);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int updateByExample(@Param("record") Parametro record, @Param("example") ParametroExample example);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int updateByPrimaryKeySelective(Parametro record);

	/**
	 * This method was generated by MyBatis Generator. This method corresponds
	 * to the database table dbo.PARAMETRO
	 *
	 * @mbggenerated Mon Dec 10 19:35:17 COT 2012
	 */
	int updateByPrimaryKey(Parametro record);
}
