package com.cardif.satelite.configuracion.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.model.Producto;
import com.cardif.satelite.moduloimpresion.bean.ConsultaProductoSocio;
import com.cardif.satelite.suscripcion.bean.SocioProductoBean;
import com.cardif.satelite.suscripcion.bean.TipoArchivoBean;

public interface ProductoMapper {
	final String SELECT_PRODUCTOS_BY_ESTADO = "SELECT ID, ID_SOCIO, NOMBRE_PRODUCTO, TRAMA_DIARIA, TRAMA_MENSUAL, TIPO_ARCHIVO, MOD_SUSCRIPCION, MOD_IMPRESION, ESTADO , SEPARADOR "
			+ "FROM PRODUCTO WHERE ESTADO=#{estadoProducto,jdbcType=NUMERIC} ORDER BY NOMBRE_PRODUCTO ASC";

	final String LISTA_PRODUCTO_BY_IDSOCIO = "SELECT ID, ID_SOCIO, NOMBRE_PRODUCTO, TRAMA_DIARIA, TRAMA_MENSUAL, TIPO_ARCHIVO, MOD_SUSCRIPCION, MOD_IMPRESION, ESTADO, SEPARADOR,"
			+ "  (SELECT NOMBRE_CANAL FROM CANAL_PRODUCTO WHERE ID = ID_CANAL) AS NOMBRE_CANAL, ID_CANAL, TIPO_TRAMA FROM PRODUCTO WHERE ID_SOCIO = #{idsocio,jdbcType=NUMERIC} "
			+ " AND  ( UPPER(NOMBRE_PRODUCTO) LIKE UPPER( '%' || #{producto,jdbcType=VARCHAR} || '%'))  ORDER BY ID DESC ";

	final String SELECT_SOCIOyPRODUCTO = "SELECT ID_SOCIO,NOMBRE_SOCIO,p.ID,NOMBRE_PRODUCTO,TRAMA_DIARIA,TRAMA_MENSUAL,TIPO_ARCHIVO ,SEPARADOR FROM SOCIO s "
			+ "inner join PRODUCTO p on(s.ID = p.ID_SOCIO) WHERE P.ID_CANAL = (NVL(#{idcanal,jdbcType=NUMERIC}, P.ID_CANAL))";

	final String SELECT_SOCIOyPRODUCTO_DIARIAS = "SELECT DISTINCT p.ID_SOCIO,s.NOMBRE_SOCIO,p.ID,p.NOMBRE_PRODUCTO,P.TRAMA_DIARIA,P.TRAMA_MENSUAL,P.TIPO_ARCHIVO ,P.SEPARADOR FROM SOCIO s "
			+ "inner join PRODUCTO p on(s.ID = p.ID_SOCIO) inner join DETALLE_TRAMA_LAYOUT l on (p.id= l.id_producto) WHERE P.ID_CANAL = #{idcanal,jdbcType=NUMERIC} AND P.ID  = #{idsocio,jdbcType=NUMERIC} AND p.TRAMA_DIARIA = "
			+ Constantes.PRODUCTO_MOD_TRAMA_DIARIA_SI + " AND p.estado = " + Constantes.PRODUCTO_ESTADO_ACTIVO;

	final String SELECT_SOCIOyPRODUCTO_MENSUAL = "SELECT DISTINCT ID_SOCIO,NOMBRE_SOCIO,p.ID,NOMBRE_PRODUCTO,TRAMA_DIARIA,TRAMA_MENSUAL,TIPO_ARCHIVO ,SEPARADOR FROM SOCIO s "
			+ "inner join PRODUCTO p on(s.ID = p.ID_SOCIO) inner join DETALLE_TRAMA_LAYOUT l on (p.id= l.id_producto) WHERE P.ID_CANAL = NVL(#{idcanal,jdbcType=NUMERIC}, P.ID_CANAL) AND P.ID  = NVL(#{idsocio,jdbcType=NUMERIC}, P.ID)  AND p.TRAMA_MENSUAL ="
			+ Constantes.PRODUCTO_MOD_TRAMA_MENSUAL_SI + " AND p.estado = " + Constantes.PRODUCTO_ESTADO_ACTIVO;

	final String SELECT_FOR_MOD_IMPRESION = "SELECT PRO.ID, PRO.ID_SOCIO, PRO.NOMBRE_PRODUCTO, SOC.NOMBRE_SOCIO, PRO.TRAMA_DIARIA, PRO.TRAMA_MENSUAL, PRO.TIPO_ARCHIVO, PRO.MOD_SUSCRIPCION, PRO.MOD_IMPRESION, PRO.ESTADO "
			+ "FROM PRODUCTO PRO LEFT JOIN SOCIO SOC ON PRO.ID_SOCIO = SOC.ID WHERE PRO.MOD_IMPRESION=#{opcionModImpresion,jdbcType=NUMERIC} AND PRO.ESTADO="
			+ Constantes.PRODUCTO_ESTADO_ACTIVO + " ORDER BY SOC.NOMBRE_SOCIO, PRO.NOMBRE_PRODUCTO ASC";

	final String SELECT_TIPO_ARCHIVOS = "SELECT DISTINCT TIPO_ARCHIVO FROM PRODUCTO WHERE TIPO_ARCHIVO<>'"
			+ Constantes.PRODUCTO_TIPO_ARCHIVO_BD + "' ORDER BY TIPO_ARCHIVO ASC";

	final String SELECT_BY_MODSUSCRIPCION_ESTADO_CANAL = "SELECT PRO.ID, PRO.ID_SOCIO, PRO.NOMBRE_PRODUCTO, SOC.NOMBRE_SOCIO, PRO.TRAMA_DIARIA, PRO.TRAMA_MENSUAL, PRO.TIPO_ARCHIVO, PRO.MOD_SUSCRIPCION, PRO.MOD_IMPRESION, PRO.ESTADO "
			+ "FROM PRODUCTO PRO LEFT JOIN SOCIO SOC ON PRO.ID_SOCIO = SOC.ID	LEFT JOIN CANAL_PRODUCTO CAN ON PRO.ID_CANAL = CAN.ID "
			+ "WHERE (PRO.MOD_SUSCRIPCION = NVL(#{modSuscripcion,jdbcType=NUMERIC}, PRO.MOD_SUSCRIPCION)) AND (PRO.ID_CANAL = NVL(#{idCanal,jdbcType=NUMERIC}, PRO.ID_CANAL)) "
			+ "AND (PRO.ESTADO = NVL(#{estado,jdbcType=NUMERIC}, PRO.ESTADO)) ORDER BY SOC.NOMBRE_SOCIO, PRO.NOMBRE_PRODUCTO ASC";

	final String SELECT_BY_MODIMPRESION_ESTADO_CANAL = "SELECT PRO.ID, PRO.ID_SOCIO, PRO.NOMBRE_PRODUCTO, SOC.NOMBRE_SOCIO, PRO.TRAMA_DIARIA, PRO.TRAMA_MENSUAL, PRO.TIPO_ARCHIVO, PRO.MOD_SUSCRIPCION, PRO.MOD_IMPRESION, PRO.ESTADO "
			+ "FROM PRODUCTO PRO LEFT JOIN SOCIO SOC ON PRO.ID_SOCIO = SOC.ID	LEFT JOIN CANAL_PRODUCTO CAN ON PRO.ID_CANAL = CAN.ID "
			+ "WHERE (PRO.MOD_IMPRESION = NVL(#{modImpresion,jdbcType=NUMERIC}, PRO.MOD_IMPRESION)) AND (PRO.ID_CANAL = NVL(#{idCanal,jdbcType=NUMERIC}, PRO.ID_CANAL)) "
			+ "AND (PRO.ESTADO = NVL(#{estado,jdbcType=NUMERIC}, PRO.ESTADO)) ORDER BY SOC.NOMBRE_SOCIO, PRO.NOMBRE_PRODUCTO ASC";

	final String SELECT_PRODUCTO_BY_ID = "SELECT ID, ID_SOCIO, NOMBRE_PRODUCTO,TRAMA_DIARIA, TRAMA_MENSUAL,  TIPO_ARCHIVO,  MOD_SUSCRIPCION,  MOD_IMPRESION,  ESTADO,  ID_CANAL,  SEPARADOR,  FECHA_CREACION, FECHA_MODIFICACION,  USUARIO_CREACION, USUARIO_MODIFICACION, INDICADOR_REGVENTA, TIPO_TRAMA FROM PRODUCTO  WHERE ID = #{producto}";

	final String SELECT_BY_PK_DETALLE_TRAMA_DIARIA = "SELECT PRO.ID, PRO.ID_SOCIO, UPPER(PRO.NOMBRE_PRODUCTO) AS NOMBRE_PRODUCTO, UPPER(SOC.NOMBRE_SOCIO) AS NOMBRE_SOCIO, "
			+ "PRO.TRAMA_DIARIA, PRO.TRAMA_MENSUAL, PRO.TIPO_ARCHIVO, PRO.MOD_SUSCRIPCION, PRO.MOD_IMPRESION, PRO.ESTADO "
			+ "FROM PRODUCTO PRO LEFT JOIN SOCIO SOC ON PRO.ID_SOCIO = SOC.ID LEFT JOIN TRAMA_DIARIA TD ON PRO.ID = TD.PRODUCTO LEFT JOIN DETALLE_TRAMA_DIARIA DTD ON TD.SEC_ARCHIVO = DTD.SEC_ARCHIVO "
			+ "WHERE DTD.ID = #{pkDetalleTramaDiaria, jdbcType=NUMERIC} AND (ROWNUM = 1) ORDER BY PRO.ID ASC";


	final String SELECT_BY_MODIMPRESION_CANAL = " SELECT PRO.ID, PRO.ID_SOCIO, PRO.NOMBRE_PRODUCTO, SOC.NOMBRE_SOCIO, PRO.TRAMA_DIARIA, PRO.TRAMA_MENSUAL, "
			+ " PRO.TIPO_ARCHIVO, PRO.MOD_SUSCRIPCION, PRO.MOD_IMPRESION, PRO.ESTADO " + " FROM PRODUCTO PRO "
			+ " LEFT JOIN SOCIO SOC ON PRO.ID_SOCIO = SOC.ID "
			+ " LEFT JOIN CANAL_PRODUCTO CAN ON PRO.ID_CANAL = CAN.ID "
			+ " WHERE (PRO.MOD_IMPRESION = NVL(#{modImpresion,jdbcType=NUMERIC}, PRO.MOD_IMPRESION)) AND "
			+ " PRO.ESTADO=" + Constantes.PRODUCTO_ESTADO_ACTIVO
			+ " ORDER BY SOC.NOMBRE_SOCIO, PRO.NOMBRE_PRODUCTO ASC ";
	// Nuevo
	final String SELECT_BY_MODIMPRESION_SOCIO = " SELECT SOC.ID AS ID_SOCIO, SOC.NOMBRE_SOCIO, SOC.RUC_SOCIO, SOC.ESTADO "
			+ " FROM USER_SOAT_AUTOMATIZACION.SOCIO SOC "
			+ " INNER JOIN (SELECT ID_SOCIO FROM USER_SOAT_AUTOMATIZACION.PRODUCTO PDTO WHERE PDTO.ESTADO = "
			+ Constantes.PRODUCTO_ESTADO_ACTIVO
			+ " AND PDTO.MOD_IMPRESION = #{modImpresion,jdbcType=NUMERIC}  GROUP BY ID_SOCIO ) PRDTO ON SOC.ID = PRDTO.ID_SOCIO "
			+ " WHERE SOC.ESTADO = " + Constantes.PRODUCTO_ESTADO_ACTIVO + " ORDER BY SOC.NOMBRE_SOCIO ASC ";

	final String SELECT_FOR_ESTADO_NUEVO_REG_VENTA = "SELECT PRO.ID, PRO.ID_SOCIO, PRO.NOMBRE_PRODUCTO, SOC.NOMBRE_SOCIO, PRO.TRAMA_DIARIA, PRO.TRAMA_MENSUAL, PRO.TIPO_ARCHIVO, PRO.MOD_SUSCRIPCION, PRO.MOD_IMPRESION, PRO.ESTADO "
			+ "FROM PRODUCTO PRO LEFT JOIN SOCIO SOC ON PRO.ID_SOCIO = SOC.ID WHERE (PRO.ESTADO = #{estado,jdbcType=VARCHAR}) AND (SOC.ID = #{idSocio,jdbcType=VARCHAR}) ORDER BY SOC.NOMBRE_SOCIO, PRO.NOMBRE_PRODUCTO ASC";

	final String SELECT_FOR_ESTADO = " SELECT SOC.ID AS ID_SOCIO, " + " SOC.NOMBRE_SOCIO AS NOMBRE_SOCIO "
			+ " FROM SOCIO SOC " + " WHERE ESTADO=#{estado,jdbcType=NUMERIC} ORDER BY 2 ";

	final String SELECT_VALIDA_OBLIGACION_REG_FECHA_VENTA_BY_PRODUCTO = "SELECT ID, INDICADOR_REGVENTA, NOMBRE_PRODUCTO FROM PRODUCTO "
			+ "WHERE ID = #{idProducto,jdbcType=NUMERIC} ";

	final String SELECT_ARCHIVO_PRODUCTO_URL = "SELECT ruta_reporte FROM trama_diaria WHERE sec_archivo = #{idtrama,jdbcType=NUMERIC}";

	final String SELECT_ARCHIVO_PRODUCTO_URL_MASTER = "SELECT ruta_reporte FROM TRAMA_MASTER WHERE ID_MASTER = #{idtrama,jdbcType=NUMERIC}";

	final String SELECT_SOCIO_TRAMA = "SELECT ID, UPPER(NOMBRE_PRODUCTO) as NOMBRE_PRODUCTO, TRAMA_DIARIA, TRAMA_MENSUAL FROM producto where estado = "
			+ Constantes.PRODUCTO_ESTADO_ACTIVO
			+ " and id_canal = #{canal,jdbcType=NUMERIC} and id_socio = #{codSocio,jdbcType=NUMERIC}  order by nombre_producto asc";

	final String LISTA_CAMPOS_PRODUCTO_BY_ID_SOCIO = "SELECT ID, NOMBRE_PRODUCTO, TRAMA_DIARIA, TRAMA_MENSUAL FROM PRODUCTO WHERE ID_SOCIO = #{idSocio,jdbcType=NUMERIC} ";

	final String SELECT_PRODUCTO_VALIDACION_CONCILIACION = " SELECT PROD.ID, PROD.TRAMA_DIARIA, PROD.TRAMA_MENSUAL, ID_CANAL, ID_SOCIO, NOMBRE_PRODUCTO "
			+ " FROM PRODUCTO PROD WHERE ID_SOCIO = #{idSocio,jdbcType=NUMERIC} ORDER BY ID ";

	final String SELECT_PRODUCTO_CARDIF_SERVICIOS = " SELECT ID FROM PRODUCTO WHERE ID_SOCIO = #{idSocio,jdbcType=NUMERIC} AND ESTADO = "
			+ Constantes.PRODUCTO_ESTADO_ACTIVO + " AND UPPER(NOMBRE_PRODUCTO) = #{nombre_producto,jdbcType=VARCHAR}";

	public Producto selectByPrimaryKey(Long id);

	public int deleteByPrimaryKey(Long id);

	public int insert(Producto record);

	public int insertSelective(Producto record);

	public int updateByPrimaryKeySelective(Producto record);

	public int updateByPrimaryKey(Producto record);

	@Select(SELECT_PRODUCTOS_BY_ESTADO)
	@ResultMap("BaseResultMap")
	public List<Producto> selectProductosByEstado(@Param("estadoProducto") Integer estadoProducto);

	@Select(SELECT_FOR_MOD_IMPRESION)
	@ResultMap("ConsultaProductoSocioResultMap")
	public List<ConsultaProductoSocio> selectForModImpresion(@Param("opcionModImpresion") Integer opcionModImpresion);

	@Select(SELECT_TIPO_ARCHIVOS)
	@ResultMap("TipoArchivoResultMap")
	public List<TipoArchivoBean> selectTipoArchivos();

	@Select(SELECT_BY_MODSUSCRIPCION_ESTADO_CANAL)
	@ResultMap("ConsultaProductoSocioResultMap")
	public List<ConsultaProductoSocio> selectByModSuscripcionAndEstadoAndCanal(
			@Param("modSuscripcion") Integer modSuscripcion, @Param("idCanal") Long idCanal,
			@Param("estado") Integer estado);

	@Select(SELECT_BY_MODIMPRESION_ESTADO_CANAL)
	@ResultMap("ConsultaProductoSocioResultMap")
	public List<ConsultaProductoSocio> selectByModImpresionAndEstadoAndCanal(
			@Param("modImpresion") Integer modImpresion, @Param("idCanal") Long idCanal,
			@Param("estado") Integer estado);

	@Select(SELECT_SOCIOyPRODUCTO)
	@ResultMap(value = "JoinResultMap")
	public List<SocioProductoBean> listaSocioProducto(@Param("idcanal") Integer idcanal);

	@Select(SELECT_SOCIOyPRODUCTO_DIARIAS)
	@ResultMap(value = "JoinResultMap")
	public List<SocioProductoBean> listaSocioProductoDiarias(@Param("idcanal") String idcanal,
			@Param("idsocio") String idsocio);

	@Select(SELECT_SOCIOyPRODUCTO_MENSUAL)
	@ResultMap(value = "JoinResultMap")
	public List<SocioProductoBean> listaSocioProductoMensuales(@Param("idcanal") String idcanal,
			@Param("idsocio") String idsocio);

	@Select(SELECT_PRODUCTO_BY_ID)
	@ResultMap(value = "BaseResultMap")
	public Producto selectProductoByID(@Param("producto") int producto);

	@Select(LISTA_PRODUCTO_BY_IDSOCIO)
	@ResultMap(value = "BaseResultMap")
	public List<Producto> listaProductoByIdsocio(@Param("idsocio") Integer idsocio, @Param("producto") String producto);

	@Select(SELECT_PRODUCTO_CARDIF_SERVICIOS)
	@ResultMap(value = "ProductoCardifServicios")
	public Producto selectProductoCardifServicios(@Param("idSocio") Integer idsocio,
			@Param("nombre_producto") String nombre_producto);

	@Select(LISTA_CAMPOS_PRODUCTO_BY_ID_SOCIO)
	@ResultMap(value = "BaseResultMap")
	public List<Producto> listaCamposConfProductoByIdsocio(@Param("idSocio") Long idSocio);

	@Select(SELECT_BY_PK_DETALLE_TRAMA_DIARIA)
	@ResultMap("ConsultaProductoSocioResultMap")
	public ConsultaProductoSocio selectByPkDetalleTramaDiaria(@Param("pkDetalleTramaDiaria") Long pkDetalleTramaDiaria);

	@Select(SELECT_BY_MODIMPRESION_CANAL)
	@ResultMap("ConsultaProductoSocioResultMap")
	public List<ConsultaProductoSocio> selectForModImpresionAndCanal(@Param("modImpresion") Integer modImpresion,
			@Param("nombreCanal") String nombreCanal);

	// Nuevo
	@Select(SELECT_BY_MODIMPRESION_SOCIO)
	@ResultMap("ConsultaProductoSocioResultMap")
	public List<ConsultaProductoSocio> buscarSocioPorModImpresion(@Param("modImpresion") Integer modImpresion);

	@Select(SELECT_FOR_ESTADO_NUEVO_REG_VENTA)
	@ResultMap("ConsultaProductoSocioResultMap")
	public List<ConsultaProductoSocio> selectForEstadoNuevoRegVenta(@Param("estado") Integer estado,
			@Param("idSocio") Long idSocio);

	@Select(SELECT_FOR_ESTADO)
	@ResultMap("ConsultaProductoSocioResultMap")
	public List<ConsultaProductoSocio> selectForEstado(@Param("estado") Integer estado);

	@Select(SELECT_VALIDA_OBLIGACION_REG_FECHA_VENTA_BY_PRODUCTO)
	@ResultMap("ConsultaProductoSocioResultMap")
	public ConsultaProductoSocio selectIndicadorRegFechaVentaByProducto(@Param("idProducto") Long idProducto);

	@Select(SELECT_ARCHIVO_PRODUCTO_URL)
	public String selectArchivoUrl(@Param("idtrama") long codProducto);

	@Select(SELECT_ARCHIVO_PRODUCTO_URL_MASTER)
	public String selectArchivoUrlMaster(@Param("idtrama") long codProducto);

	@Select(SELECT_SOCIO_TRAMA)
	@ResultMap("BaseResultMap")
	public List<Producto> SelectbySocioCanal(@Param("canal") String canal, @Param("codSocio") Integer codSocio);

	@Select(SELECT_PRODUCTO_VALIDACION_CONCILIACION)
	@ResultMap("BaseResultMap")
	public List<Producto> selectBySocioProductoValidacionConciliacion(@Param("idSocio") Long idSocio);

} // ProductoMapper
