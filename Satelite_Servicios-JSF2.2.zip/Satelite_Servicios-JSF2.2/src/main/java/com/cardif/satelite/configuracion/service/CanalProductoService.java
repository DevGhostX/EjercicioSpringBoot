package com.cardif.satelite.configuracion.service;

import java.util.List;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.model.CanalProducto;
import com.cardif.satelite.model.Socio;

public interface CanalProductoService {

	public abstract List<CanalProducto> buscarPorEstado(int estado) throws SyncconException;

	public abstract List<CanalProducto> buscarPorCodSocio(Integer modSuscripcionOpcion, Long codSocio)
			throws SyncconException;

	public abstract List<Socio> buscarPorSocio(int productoEstadoActivo) throws SyncconException;

	public abstract List<CanalProducto> buscarCanalSocio(String Socio) throws SyncconException;

	public abstract List<CanalProducto> buscarCanalSocioMensual(String Socio) throws SyncconException;

	public List<CanalProducto> buscarCanalSocioMaster(String socio) throws SyncconException;

} // CanalProductoService
