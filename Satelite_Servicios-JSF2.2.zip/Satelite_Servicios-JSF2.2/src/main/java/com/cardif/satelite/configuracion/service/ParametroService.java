package com.cardif.satelite.configuracion.service;

import java.util.List;

import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.model.Parametro;

/**
 * @author 2ariasju
 * 
 */
public interface ParametroService {

	List<Parametro> selectMediosPago(String codParam, String tipParam);

	public List<Parametro> buscar(String codParam, String tipParam) throws SyncconException;

	public Parametro obtener(String codParam, String tipParam, String codValor) throws SyncconException;

	public Parametro obtenerCodValor(String codParam, String tipParam, String nomValor) throws SyncconException;

	public String obtenerDescripcion(String codSocio, String codParam, String tipParam) throws SyncconException;

	public List<Parametro> selectCuentasBancariasByBanco(String codBanco);

	public Parametro obtenerByNomValor(String codParam, String tipParam, String nomValor) throws SyncconException;

	/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
	/******* {Carlos Chayguaque} - {25/09/2020} ********/
	public List<Parametro> buscarValor(String codParam, String tipParam, String codValor) throws SyncconException;
	
	public List<Parametro> buscarTipoDiario(String codParam, String tipParam);
	/*** Fin {Automatización Contabilidad} - {Sprint 1} **/

}
