package com.cardif.satelite.constantes;

import java.math.BigDecimal;

public interface Constantes {

	// Constantes Satelite
	public static final String TIP_PARAM_CABECERA = "C";
	public static final String TIP_PARAM_DETALLE = "D";

	public static final String COD_PARAM_COMPANIA = "001";
	public static final String COD_PARAM_TIPOS_LIBROS = "002";
	public static final String COD_PARAM_VIA_COBRO = "003";
	public static final String COD_PARAM_TIPO_PROCESO = "004";
	public static final String COD_PARAM_TIPOS_COMPROBANTE = "005";
	public static final String COD_PARAM_TIPOS_DOCUMENTO = "006";
	public static final String COD_PARAM_TIPO_VENTA = "007";
	public static final String COD_PARAM_TIPO_REPORTE = "008";
	public static final String COD_PARAM_ESTADO_VENTA = "009";
	public static final String COD_PARAM_TIPO_SISTEMA = "010";
	public static final String COD_PARAM_SOCIO = "011";
	public static final String COD_PARAM_SOCIO_TLMK = "012";
	public static final String COD_PARAM_MONEDA = "013";
	public static final String COD_PARAM_INDICADOR_IGV = "014";
	public static final String COD_PARAM_SOCIO_SOAT = "025";
	public static final String COD_PARAM_CANAL_VENTA_SOAT = "032";
	public static final String COD_PARAM_E_COMPROBANTE = "033";
	public static final String COD_PARAM_TIPO_SISTEMA_CC = "034";
	public static final String COD_PARAM_PROPIEDADES_SATELITE = "063";
	
	/** Inicio {Automatización de Tesoreria} – {Sprint 1} - {PSS} - {d79986} * ***/
	/******* {Carlos Chayguaque} – {25/09/2020} ********/
	public static final String COD_PARAM_TIPOPAGO_OTROS = "144";
	public static final String COD_PARAM_TIPO_DIARIO_ASIENTO_LIBRE = "150";

	/*** Fin {Automatización de Tesoreria} – {Sprint 1} **/

	

	public static final Integer OPC_NIVEL_CERO = 0;
	public static final Integer OPC_NIVEL_UNO = 1;
	public static final Integer OPC_NIVEL_DOS = 2;

	public static final String FECHA_DEFAULT = "01/01/0001";
	public static final String MONTO_DEFAULT = "0.00";
	public static final String TIP_CAMBIO_DEFAULT = "0.000";
	public static final String CANTIDAD_DEFAULT = "0";
	public static final String TIP_COMP_DEFAULT = "00";
	public static final String TEXTO_DEFAULT = "";// "-"

	public static final String PREFIJO_ARCHIVO = "LE";
	public static final String RUC_CARDIF_SEGUROS = "20513328819";
	public static final String RUC_CARDIF_SERVICIOS = "20512830316";

	public static final String COD_REG_COMPRAS = "080100";
	public static final String COD_REG_VENTAS = "140100";
	public static final String COD_LIBRO_DIARIO = "050100";
	public static final String COD_LIBRO_MAYOR = "060100";

	public static final String COD_MONEDA_SOLES = "1";
	public static final String COD_MONEDA_DOLAR = "2";

	public static final String COD_CARDIF_SEGUROS = "1";
	public static final String COD_CARDIF_SERVICIOS = "2";

	public static final String REG_COMPRAS = "1";
	public static final String REG_VENTAS = "2";
	public static final String LIBRO_MAYOR = "3";
	public static final String LIBRO_DIARIO = "4";

	// Nombre de JOBs COBRANZA
	public static final String COBRANZA_CS_JOB_ENVIO = "JOB_ENVIO_CS";
	public static final String COBRANZA_CS_JOB_RESPUESTA = "JOB_RESPUESTA_CS";
	public static final String COBRANZA_VISA_JOB_ENVIO = "JOB_ENVIO_VISA";
	public static final String COBRANZA_VISA_JOB_RESPUESTA = "JOB_RESPUESTA_VISA";
	public static final String COBRANZA_MC_JOB_ENVIO = "JOB_ENVIO_MC";
	public static final String COBRANZA_MC_JOB_RESPUESTA = "JOB_RESPUESTA_MC";
	public static final String COBRANZA_IB_JOB_ENVIO = "JOB_ENVIO_IB";
	public static final String COBRANZA_IB_JOB_RESPUESTA = "JOB_RESPUESTA_IB";

	// Nombre de JOBs de SUSCRIPCION
	public static final String SUSCRIPCION_CARG_REG_VENTAS = "JOB_CARG_REG_VENTAS";
	public static final String SUSCRIPCION_LISTA_RAZON_SOCIAL = "036";

	// Nombre de JOBs de ACTUARIAL
	public static final String REPORTE_CALCULO_RESERVAS_ACSELE = "JOB_CAL_RESERVAS_ACSELE";
	public static final String REPORTE_CALCULO_RESERVAS_SEGYA = "JOB_CAL_RESERVAS_SEGYA";

	// Nombre de JOBs de Telemarketing
	public static final String TLMK_JOB_BASE_IB = "JOB_TLMK_IB";
	public static final String TLMK_JOB_BASE_SB = "JOB_TLMK_SB";
	public static final String TLMK_JOB_BASE_BC = "JOB_TLMK_BC";
	public static final String TLMK_JOB_BASE_RP = "JOB_TLMK_RP";
	public static final String TLMK_JOB_VIGILANCE = "JOB_TLMK_VIGILANCE";

	public static final String ESTADO_REGISTRADO = "REGISTRADO";
	public static final String ESTADO_ERROR = "ERROR";

	// ACTUALIZAR CODIGOS
	public static final Long SOCIO_ID_SB = 9L;
	public static final Long SOCIO_ID_RP = 3L;
	public static final Long SOCIO_ID_BC = 2L;
	public static final Long SOCIO_ID_IB = 19L;

	public static final String CONTABILIDAD_JOB_REG_VENTAS = "JOB_REG_VENTAS_SEGUROS";
	public static final String SUSCRIPCION_JOB_MIG_REG_VENTAS = "JOB_MIG_REG_VENTAS";

	// NOMBRES DE JOBS DE SINIESTROS
	public static final String COD_PARAM_LISTA_GENERO = "015";
	public static final String COD_PARAM_LISTA_EJECUTIVOS = "016";
	public static final String COD_PARAM_LISTA_RAMOS = "017";
	public static final String COD_PARAM_LISTA_COBERTURA = "018";
	public static final String COD_PARAM_LISTA_ESTADOS = "019";
	public static final String COD_PARAM_LISTA_RECHAZOS_AGRUPADOS = "020";
	public static final String COD_PARAM_LISTA_ESTADO_LEGAJO = "021";
	public static final String COD_PARAM_LISTA_RECHAZADOS = "022";
	public static final String COD_PARAM_LISTA_RESUMEN = "023";
	public static final String COD_PARAM_LISTA_SEGUROS = "024";
	public static final String COD_PARAM_SOCIOS_SINI = "026";
	public static final String COD_PARAM_TIPOS_DOCUMENTO_SINI = "027";
	public static final String COD_PARAM_LISTA_MONEDA = "028";
	public static final String COD_PARAM_LISTA_GENEROS_SINI = "029";
	public static final String COD_PARAM_LISTA_PARENTESCO_SINI = "030";
	public static final String COD_PARAM_LISTA_MOTIVOS_NO_ENTREGA = "031";
	public static final String COD_PARAM_LISTA_TIPO_REF_CAFAE = "035";
	public static final String COD_PARAM_SOCIOS_PLACAS = "083";

	/* INICIO SYNCCON JPALOMINO 28/10/2014 */
	// Modulo de Pagos (Prefijo MDP)
	public static final String MDP_TIPO_MARCADOR_PAGOS = "037";
	public static final String MDP_TIPO_PAGOS = "038";
	public static final String MDP_MEDIO_PAGOS = "039";

	public static final String MDP_CTAS_BANCO = "040";

	public static final String MDP_DIF_CAMBIO_WIN_PEN = "041";
	public static final String MDP_DIF_CAMBIO_LOSE_PEN = "042";
	public static final String MDP_DIF_CAMBIO_WIN_EUR = "043";
	public static final String MDP_DIF_CAMBIO_LOSE_EUR = "044";

	public static final String MDP_PAG_VARIOS_CTA_PROPINA = "045";
	public static final String MDP_PAG_VARIOS_T_DIARIO_PAGO = "046";

	public static final String MDP_CTA_GASTO_DETRAC_TRANS_COMISION = "047";
	public static final String MDP_PAG_DETRACCIONES_IMP_COMISION = "048";
	public static final String MDP_CENT_COST_DETRAC_TRANS_COMISION = "049";
	public static final String MDP_PAG_DETRACCIONES_T_DIARIO_PAGO = "050";
	public static final String MDP_PAG_DETRACCIONES_CTA_COMISION = "047";
	public static final String MDP_PAG_DETRACCIONES_CEN_COSTO = "049";

	public static final String MDP_PAG_RETENCION_CTA_PEN = "051";
	public static final String MDP_PAG_RETENCION_IMP = "052";
	public static final String MDP_PAG_RETENCION_MONTO_MIN = "053";
	public static final String MDP_PAG_RETENCION_CTA_PROPINA = "054";
	public static final String MDP_PAG_RETENCION_T_DIARIO_PAGO = "055";
	public static final String MDP_PAG_RETENCION_CTA_USD = "056";
	/* FIN SYNCCON JPALOMINO 28/10/2014 */

	/* INICIO SYNCCON JARIASS 19/01/2015 */
	public static final String MDP_DIF_CAMBIO_WIN_USD = "058";
	public static final String MDP_DIF_CAMBIO_LOSE_USD = "059";
	public static final String MDP_DIF_CAMBIO_WIN_EUR_USD = "060";
	public static final String MDP_DIF_CAMBIO_LOSE_EUR_USD = "061";
	public static final String MDP_PAG_SINIESTROS_T_DIARIO_PAGO = "062";
	public static final String MDP_PAG_COMIS_T_DIARIO_PAGO = "065";
	public static final String MDP_CTA_GASTO_ITF = "066";
	public static final String MDP_TRANSF_COMIS_PROV_EMPL = "067";
	public static final String MDP_ESTADOS = "068";
	public static final String MDP_MONEDAS = "069";
	public static final String MDP_DOC_PROVEEDOR = "070";
	public static final String MDP_PAG_TRASNF_T_DIARIO_PAGO = "071";
	public static final String MDP_RUTA_TRAMA = "072";
	/* FIN SYNCCON JARIASS 19/01/2015 */

	public static final String MDP_AUTH_SUNSYSTEMS_TOKEN = "TOKEN";
	public static final String MDP_DEV_BENEF_TOKEN = "DEVBENEF";

	/* INICIO SYNCCON JARIASS 15/04/2015 */
	public static final String COD_PARAM_MED_PAGO_SOAT = "079";
	public static final String COD_PARAM_CATEGORIA_SOAT = "080";
	public static final String COD_PARAM_USO_SOAT = "081";
	public static final String COD_PARAM_PRODUCTO_SOAT = "082";

	public static final String COD_SOCIO_SOAT_CENCOSUD = "01";
	public static final String COD_SOCIO_SOAT_COMPARA_BIEN = "02";
	public static final String COD_SOCIO_SOAT_DIRECTO = "03";
	public static final String COD_SOCIO_SOAT_FALABELLA = "04";
	public static final String COD_SOCIO_SOAT_RIPLEY = "05";
	public static final String COD_SOCIO_SOAT_RPP = "06";
	public static final String COD_SOCIO_SOAT_SUCURSAL = "07";
	/* INICIO SYNCCON JARIASS 15/04/2015 */

	public static final int PLAZO_DIAS_HABILES_SUNAT = 7;
	public static final String COD_PARAM_ESTADO_CERTIFICADO = "088";
	public static final int PLAZO_FECHA_SUNAT_OK = 1;
	public static final int PLAZO_FECHA_SUNAT_NO_OK = 0;

	/*
	 * Codigos de respuesta de PPL
	 */
	public static final int RESPUESTA_PPL_VALIDADO = 0;
	public static final int RESPUESTA_PPL_RECHAZADO = -1;

	public static final String COD_PARAM_SUNAT_DATOS = "089";
	public static final String USU_SUNAT_SEGUROS_RUC = "SEGUROS_RUC";
	public static final String USU_SUNAT_SEGUROS_USUARIO = "SEGUROS_USUARIO";
	public static final String USU_SUNAT_SEGUROS_CLAVE = "SEGUROS_CLAVE";
	public static final String USU_SUNAT_SERVICIOS_RUC = "SERVICIOS_RUC";
	public static final String USU_SUNAT_SERVICIOS_USUARIO = "SERVICIOS_USUARIO";
	public static final String USU_SUNAT_SERVICIOS_CLAVE = "SERVICIOS_CLAVE";

	public static final String SINI_TIPO_DOC_CE_DESCRIPCION = "CARNET DE EXTRANJERIA";
	public static final String SINI_TIPO_DOC_DNI_DESCRIPCION = "DNI";
	public static final String SINI_TIPO_DOC_PASAPORTE_DESCRIPCION = "PASAPORTE";

	// ****** INICIO AUTOMATIZACION SOAT *****
	public static final String COD_DOC_VALORADO_PRIVADO = "01";
	public static final String COD_DOC_VALORADO_PUBLICO = "02";

	public static final String PRODUCTO_TIPO_ARCHIVO_EXCEL = "EXCEL";
	public static final String PRODUCTO_TIPO_ARCHIVO_TXT = "TXT";
	public static final String PRODUCTO_TIPO_ARCHIVO_BD = "BD";
	public static final String MOD_IMPRESION_ESTADO_IMPRESO = "IMPRESO";
	public static final String MOD_IMPRESION_ESTADO_IMPRESA_DIG = "IMPRESA";
	public static final String MOD_IMPRESION_ESTADO_EN_ESPERA = "EN_ESPERA";
	public static final String MOD_IMPRESION_ESTADO_PENDIENTE = "PENDIENTE";
	public static final String MOD_IMPRESION_ESTADO_REIMPRESO = "REIMPRESO";

	public static final int COD_NUM_DOC_VALORADO_DISPONIBLE = 0;
	public static final int COD_NUM_DOC_VALORADO_USADO = 1;

	public static final int COD_NUM_DOC_VALORADO_EST_ACTIVO = 0;
	public static final int COD_NUM_DOC_VALORADO_EST_ANULADO = 1;

	public static final String MOD_IMP_VALIDACION_CERTIFICADO = "> Validación de Certificado";
	public static final String MOD_IMP_CONFIRMACION_IMPRESION = "> Confirmación de impresión";
	public static final String MOD_SUSC_VER_DETALLE = "> Ver Detalle";

	// Cambio de valores por cambio de flag en base de datos
	// public static final int PRODUCTO_ESTADO_ACTIVO = 0;
	// public static final int PRODUCTO_ESTADO_INACTIVO = 1;
	public static final int PRODUCTO_ESTADO_ACTIVO = 1;
	public static final int PRODUCTO_ESTADO_INACTIVO = 0;

	public static final int SOCIO_ESTADO_ACTIVO = 1;
	public static final int SOCIO_ESTADO_INACTIVO = 0;

	public static final int PRODUCTO_MOD_IMPRESION_SI = 1;
	public static final int PRODUCTO_MOD_IMPRESION_NO = 0;
	public static final int PRODUCTO_MOD_SUSCRIPCION_SI = 1;
	public static final int PRODUCTO_MOD_SUSCRIPCION_NO = 0;

	public static final int PRODUCTO_MOD_TRAMA_DIARIA_SI = 1;
	public static final int PRODUCTO_MOD_TRAMA_DIARIA_NO = 0;
	public static final int PRODUCTO_MOD_TRAMA_MENSUAL_SI = 1;
	public static final int PRODUCTO_MOD_TRAMA_MENSUAL_NO = 1;

	// public static final int COD_NUM_DOC_VALORADO_NO_USADO = 0; //Para el
	// Reemplazar del step 3 de modulo impresion

	// ---------------------------------------------------------------------------------
	public static final String COD_PARAM_ESTADO_LOTE_IMPRESION = "000001";
	public static final String COD_PARAM_RANGO_HORARIO = "000002";
	public static final String COD_PARAM_MOTIVO_REIMPRESION = "000003";
	public static final String COD_PARAM_TIPO_DOCUMENTO_ID = "000004";
	public static final String COD_PARAM_SEXO = "000005";
	public static final String COD_PARAM_MOTIVO_ANULACION = "000006";
	public static final String COD_PARAM_SOCIOS_MULTISOCIO = "000007";
	public static final String COD_PARAM_CATEGORIA_CLASE = "000008";
	public static final String COD_PARAM_CODIGO_CIA_SEGUROS = "000014";
	public static final String COD_PARAM_CODIGO_CIA_SEGUROS_VALOR = "COD_CIA";
	public static final String COD_PARAM_APESEG_COUNT = "000015";
	public static final String COD_PARAM_APESEG_COUNT_VALOR = "APESEG_COUNT";
	public static final String COD_PARAM_RUTA_APESEG = "000016";
	public static final String COD_PARAM_RUTA_APESEG_VALOR = "RUTA_ARCHIVO_APESEG";
	public static final String COD_PARAM_SBS_TIPO_ANEXO = "000017";
	public static final String COD_PARAM_SBS_ANIO = "000018";
	public static final String COD_PARAM_RUTA_SBS = "000019";
	public static final String COD_PARAM_RUTA_SBS_VALOR = "RUTA_ARCHIVO_SBS";
	public static final String COD_PARAM_FLB_TIPO_TRAMA = "000020";
	public static final String COD_PARAM_NRO_ULT_PERIODOS = "000021";
	public static final String COD_PARAM_NRO_ULT_PERIODOS_VALOR = "NRO_ULT_PERIODOS";
	public static final String COD_PARAM_DOC_IDENTIDAD_SUNAT = "000022";
	public static final String COD_PARAM_RUTA_SUNAT = "000023";
	public static final String COD_PARAM_RUTA_SUNAT_VALOR = "RUTA_ARCHIVO_SUNAT";
	public static final String COD_PARAM_IGV_IMPUESTO = "000024";
	public static final String COD_PARAM_IGV_IMPUESTO_VALOR = "IGV_IMPUESTO";
	public static final String COD_PARAM_PRODUCTO_SERIE = "000025";
	public static final String COD_PARAM_PRODUCTO_SERIE_ALTA = "ALTA";
	public static final String COD_PARAM_PRODUCTO_SERIE_BAJA = "BAJA";
	public static final String COD_PARAM_TIP_DOC_REG_VTA = "000026";
	public static final String COD_PARAM_TIPO_FORMATO_FECHA = "000029";

	public static final String REIMPRESION_SIN_MODIF_DATOS = "01";
	public static final String REIMPRESION_CON_MODIF_DATOS = "02";

	public static final String COD_CATEGORIA_CLASE_MOTO = "MOTO";
	public static final String COD_CATEGORIA_CLASE_AUTOMOVIL = "AUTOMOVIL";

	public static final String BTN_ARMAR_LOTE_SELECT_TODOS = "Seleccionar Todos";
	public static final String BTN_ARMAR_LOTE_DESELECT_TODOS = "Deseleccionar Todos";

	public static final String NUM_LOTE_FORMAT = "0000000000";

	/*
	 * Opciones de confirmacion de impresion
	 */
	public static final String MOD_IMP_IMPRESO_CORRECTAMENTE_SI = "SI";
	public static final String MOD_IMP_IMPRESO_CORRECTAMENTE_NO = "NO";
	public static final String MOD_IMP_IMPRESO_CORRECTAMENTE_REEMPLAZAR = "REEMPLAZAR";

	/*
	 * Validacion del certificado diferenciandola por color
	 */
	public static final String MOD_IMP_CERT_VALIDAR_BACKGROUND_COLOR_OK = "background-color: #D9EDF7;";
	public static final String MOD_IMP_CERT_VALIDAR_BACKGROUND_COLOR_FAIED = "background-color: #F2DEDE;";
	public static final String MOD_IMP_CERT_VALIDAR_BACKGROUND_COLOR_CLEAN = "background-color: white;";

	public static final int CANAL_PROD_ESTADO_ACTIVO = 0;
	public static final int CANAL_PROD_ESTADO_INACTIVO = 1;

	public static final String PRODUCTO_MOD_SUSCRIPCION = "SUSCRIPCION";
	public static final String PRODUCTO_MOD_IMPRESION = "IMPRESION";

	public static final int DET_TRAMA_DIA_MOTIVO_REIMPRESION = 1;
	public static final int DET_TRAMA_DIA_MOTIVO_ANULACION = 2;
	public static final String USU_AUTO_ANULA_POLIZA_FIN_VIGENCIA = "AUTOMATICO";
	public static final String USU_JOB_ANULA_POLIZA = "JOB";

	/* FLAGS ESTADOS REPORTE APESEG */
	public static final String ANU_APESEG_ERROR_EMISION = "1";
	public static final String ANU_APESEG_FIN_VIGENCIA = "2";

	public static final String POLIZA_ESTADO_VIGENTE = "VIGENTE";
	public static final String POLIZA_ESTADO_ANULADO = "ANULADO";

	/* Canal de venta SOAT Digital */
	public static final String SOAT_CANAL_DIGITAL = "DIGITAL";

	public static final int ID_CANAL_DIGITAL = 1;
	public static final int ID_CANAL_CLIENTES_ESPECIALES = 4;

	/*
	 * Nombre de los PRODUCTOS DIGITALES
	 * 
	 * SCS_DIGITAL BCS_DIGITAL CPB_DIGITAL DTO_DIGITAL FLB_DIGITAL RPY_DIGITAL
	 * 
	 * 
	 */
	public static final String PRODUCTO_NOMBRE_FALABELLA = "FLB_DIGITAL";
	public static final String PRODUCTO_NOMBRE_RIPLEY = "RPY_DIGITAL";
	public static final String PRODUCTO_NOMBRE_CENCOSUD = "BCS_DIGITAL";
	public static final String PRODUCTO_NOMBRE_COMPARA_BIEN = "CPB_DIGITAL";
	public static final String PRODUCTO_NOMBRE_DIRECTO = "DTO_DIGITAL";
	public static final String PRODUCTO_NOMBRE_SUCURSAL = "SCS_DIGITAL";

	public static final String CANAL_PROD_NOMBRE_DIGITAL = "DIGITAL";
	public static final String POLIZA_ESTADO_ANULADA = "ANULADA";
	public static final Integer COD_NUM_DOC_VALORADO_ACTIVO = null;
	public static final Integer COD_NUM_DOC_VALORADO_ANULADO = null;

	public static final String TIP_PERS_NATURAL = "N";
	public static final String TIP_PERS_JURIDICA = "J";

	public static final String TIP_DOC_DNI = "1";
	public static final String TIP_DOC_CE = "4";
	public static final String TIP_DOC_RUC = "6";
	public static final String TIP_DOC_RUC_REG_VTA = "06";
	public static final String TIP_DOC_CE_REG_VTA = "03";
	public static final String TIP_DOC_DNI_REG_VTA = "01";

	/* Necesario para APESEG */
	public static final String PAIS_PLACA_PERU = "0001";
	public static final String PAIS_PLACA_EXT = "9999";

	public static final String APESEG_REPORTADO_NO = "NO";
	public static final String APESEG_REPORTADO_SI = "SI";
	public static final String APESEG_MODIFICADO_MO = "MO";

	/* TIPO OPERACION DE REPORTE APESEG */
	public static final String APESEG_TIPO_OPERACION_NUEVO = "01";
	public static final String APESEG_TIPO_OPERACION_MODIFICADO = "02";
	public static final String APESEG_TIPO_OPERACION_ANULADO = "03";

	public static final String SBS_TIPO_ANEXO_PROD_PRIMAS = "01";
	public static final String SBS_TIPO_ANEXO_ANUL_PRIMAS = "03";
	public static final String SBS_TIPO_ANEXO_CONTRATO_SOAT = "05";

	public static final String SBS_DET_REPORTE_ESTADO_PROD = "PRODUCCION";
	public static final String SBS_DET_REPORTE_ESTADO_ANUL = "ANULACION";

	public static final String SBS_REPORTADO_SI = "SI";
	public static final String SBS_REPORTADO_NO = "NO";

	public static final String SBS_ESTADO_REPORTADO_PROD = "PRODUCCION";
	public static final String SBS_ESTADO_REPORTADO_ANUL = "ANULACION";
	public static final String SBS_ESTADO_REPORTADO_PEND = "PENDIENTE";

	public static final String FLB_TRAMA_DESPACHO = "TD";
	public static final String FLB_TRAMA_ANULACION = "TA";

	public static final String FLB_MOTIVO_DESPACHO = "619";
	public static final String FLB_MOTIVO_ANULACION = "782";

	public static final String REP_SUNAT_COD_AAA = "001";
	public static final String REP_SUNAT_PERIODO_ANUAL = "00";
	public static final String REP_SUNAT_ESTADO_INICIAL = "GENERADO";

	public static final String REP_REGISTRO_VENTA_TIPO_ALTA = "13";
	public static final String REP_REGISTRO_VENTA_TIPO_BAJA = "87";
	public static final String REP_REGISTRO_VENTA_IND_REG_VTA_ACTIVO = "1";
	public static final String REP_REGISTRO_VENTA_IND_REG_VTA_INACTIVO = "0";

	public static final String DESC_REP_REGISTRO_VENTA_TIPO_ALTA = "ALTA";
	public static final String DESC_REP_REGISTRO_VENTA_TIPO_BAJA = "BAJA";

	public static final String TIPO_CAMBIO_REG_VTA = "1";

	public static final String REP_REG_VENTA_COD_TIPO_SERIE_VIGENTE = "067";
	public static final String REP_REG_VENTA_COD_TIPO_SERIE_ANULADO = "167";

	public static final String NRO_CORRELATIVO_DEFAULT = "999";

	/* HC 22/06/2017 Nuevo Parametro */
	public static final String COD_PARAM_CORRELATIVO_SOCIO_CANAL = "000033";
	public static final String COD_PARAM_TIPO_TRAMA = "000034";

	public static final String SOC_GRUPO_COMERCIO_ACTIVO = "1";
	public static final String SOC_GRUPO_COMERCIO_INACTIVO = "0";

	public static final String ESTADO_REPORTE_SBS_PENDIENTE = "PENDIENTE";
	public static final String ESTADO_REPORTE_SBS_CONFIRMADO = "CONFIRMADO";

	public static final String SUSCRIPCION_JOB_MARCA_MODELO = "JOB_SOAT_MarcaModelo";

	public static final String COD_CIA_SEGUROS = "021";

	public static final int COD_PRODUCTO_FLB_DIGITAL = 5;

	public static final String SUSCRIPCION_JOB_CARGA_MASTER = "JOB_SOAT_Carga_Master";
	public static final String SUSCRIPCION_JOB_CARGA_DIARIA = "JOB_SOAT_Trama_Diaria";
	public static final String SUSCRIPCION_JOB_CARGA_MENSUAL = "JOB_SOAT_Trama_Mensual";
	public static final String SUSCRIPCION_JOB_CARGA_CONCILIACION_TRAMA = "JOB_SOAT_Conciliacion_Trama";
	public static final String SUSCRIPCION_JOB_CARGA_CONCILIACION = "JOB_SOAT_Conciliacion";

	public static final String DIGITOS_RUC_PERSONA_NATURAL = "10";
	public static final String DIGITOS_RUC_PERSONA_JURIDICAS = "20";

	public static final String INDICADOR_REGVENTA_OBLIGATORIO_POR_PRODUCTO = "1";
	public static final String INDICADOR_REGVENTA_NO_OBLIGATORIO_POR_PRODUCTO = "0";

	public static final String SUSCRIPCION_RUTA_SERVIDOR_SSIS = "000030";
	public static final String SUSCRIPCION_RUTA_SERVIDOR_SSIS_DIARIA = "TRAMA_DIARIA\\";
	public static final String SUSCRIPCION_RUTA_SERVIDOR_SSIS_MENSUAL = "TRAMA_MENSUAL\\";
	public static final String SUSCRIPCION_RUTA_SERVIDOR_SSIS_MASTER = "TRAMA_MASTER\\";
	public static final String SUSCRIPCION_RUTA_SERVIDOR_SSIS_CONCILIACION = "CONCILIACION_SOAT\\ReporteLiquidacion\\";
	public static final String SUSCRIPCION_RUTA_SERVIDOR_SSIS_CONCILIACION_SOAT = "CONCILIACION_SOAT\\ReporteLiquidacion\\";

	public static final String REPORTE_SBS_PRODUCCION_PRIMAS = "01";

	public static final String INDEX_INICIAL_GRILLA = "1";

	public static final String MENSAJE_VALIDACION_CAMPOS_VACIOS = "No se permiten campos vacios.";
	public static final String MENSAJE_VALIDACION_CONF_SOCIO_CANAL_REPETIDO = "El tipo de canal ya existe.";
	public static final String MENSAJE_VALIDACION_NOMBRE_SOCIO_CANAL_REPETIDO = "El nombre del canal ya existe.";
	public static final Object MOD_IMPRESION_ESTADO_ANULADO = "ANULADO";

	// Reporte de Conciliación SOAT
	public static final int ESTADO_REPORTE_CONCILIACION_SOAT_ACTIVO = 1;
	public static final String PROCESO_REPORTE_CONCILIACION_SOAT_DIARIA_MENSUAL = "DIARIA_MENSUAL";
	public static final String PROCESO_REPORTE_CONCILIACION_SOAT_MENSUAL_MASTER = "MENSUAL_MASTER";
	public static final int FLAG_EJECUCION_REPORTE_CONCILIACION_SOAT = 0;
	public static final String MSJ_VAL_CONCILIACION_CERRADA = "Conciliación Cerrada, ya no se podrá conciliar para este periodo.";

	// Mensajes de validacion de fecha
	public static final String MSJ_VAL_FECHA_YYYYDD_FORMATO_INCORRECTO = "La fecha no cumple con el formato.";
	public static final String MSJ_VAL_FECHA_YYYYDD_RANGO_INCORRECTO = "La fecha ingresada es incorrecta.";

	// Cantidad de Tipos de canal
	public static final int CANTIDAD_TIPOS_CANAL_POR_SOCIO = 3;

	// SAS ONCO TIPO DOCUMENTO
	public static final String COD_SASONCO_TIPO_DOCUMENTO_DNI = "1-1";
	public static final String COD_SASONCO_TIPO_DOCUMENTO_PASPORTE = "7-2";
	public static final String COD_SASONCO_TIPO_DOCUMENTO_CE = "4-4";
	public static final String COD_SASONCO_TIPO_DOCUMENTO_RUC = "6-5";
	public static final String COD_SASONCO_TIPO_DOCUMENTO_OTROS = "9-6";

	// ESTADOS DE LA TABLA CONCILIACION_SOAT (CONCILIACION DIARIA VS MENSUAL |
	// CONCILIACION SOAT)
	public static final String COD_CONCILIACION_PENDIENTE_1 = "1";
	public static final String COD_CONCILIACION_INICIA_PROCESO_2 = "2";
	public final int COD_CONCILIACION_RECHAZADO_COD = 2;
	public static final String COD_CONCILIACION_CON_OBSERVACIONES_3 = "3";
	public static final String COD_CONCILIACION_CORRECTO_4 = "4";
	public static final String COD_CONCILIACION_CERRADA_5 = "5";

	public static final String DESC_CONCILIACION_PENDIENTE_1 = "PENDIENTE";
	public static final String DESC_CONCILIACION_INICIA_PROCESO_2 = "RECHAZADO";
	public static final String DESC_CONCILIACION_CON_OBSERVACIONES_3 = "TERMINADO CON OBSERVACIONES";
	public static final String DESC_CONCILIACION_CORRECTO_4 = "FINALIZADO CORRECTO";
	public static final String DESC_CONCILIACION_CERRADA_5 = "CONCILIACION CERRADA";

	// MENSAJE CUANDO DE INTENTA ELIMINAR UNA TRAMA QUE SE ENCUENTRA CONCILIADA
	public static final String MSJ_NO_ANULACION_TRAMA_CONCILIADA_DM = "No se puede eliminar la trama, se encuentra conciliada.";

	// ESTADO QUE DEFINE LA CONCILIACION DE TRAMA DIARIA VS TRAMA MENSUAL
	public static final String ESTADO_CONCILIADO_TRAMA_DM = "CONCILIADO";

	// ESTADOS DE LAS TABLAS TRAMA_DIARIA (PARA TRAMA DIARIA Y TRAMA MENSUAL)
	/*
	 * 
	 * ESTADO 0 = PENDIENTE -- NACE ESTADO 1 = INICIA CARGA TRAMA -- INICIA
	 * PROCESO PAQUETE ESTADO 2 = CARGADO -- REGISTRADO EN TABLA TEMPORAL ESTADO
	 * 3 = REGISTRADO -- REGISTRADO EN TABLA PRINCIPAL ESTADO 6 = OBSERVADO --
	 * REGISTRADO EN TABLA PRINCIPAL CON OBSERVACIONES ESTADO 4 = ANULADO --
	 * ANULADO POR APLICATIVO (ELIMINAR TRAMA) ESTADO 5 = RECHAZADO -- RECHAZADO
	 * POR ERRORES, ARCHIVO NO EXISTE
	 */

	public static final int COD_ESTADO_TRAMA_PENDIENTE_0 = 0;
	public static final String DESC_ESTADO_TRAMA_PENDIENTE_0 = "PENDIENTE";

	public static final int COD_ESTADO_TRAMA_INICIA_CARGA_1 = 1;
	public static final String DESC_ESTADO_TRAMA_INICIA_CARGA_1 = "INICIA CARGA";

	public static final int COD_ESTADO_TRAMA_CARGADO_2 = 2;
	public static final String DESC_ESTADO_TRAMA_CARGADO_2 = "CARGADO";

	public static final int COD_ESTADO_TRAMA_REGISTRADO_3 = 3;
	public static final String DESC_ESTADO_TRAMA_REGISTRADO_3 = "REGISTRADO";

	public static final int COD_ESTADO_TRAMA_ANULADO_4 = 4;
	public static final String DESC_ESTADO_TRAMA_ANULADO_4 = "ANULADO";

	public static final int COD_ESTADO_TRAMA_RECHAZADO_5 = 5;
	public static final String DESC_ESTADO_TRAMA_RECHAZADO_5 = "RECHAZADO";

	public static final int COD_ESTADO_TRAMA_OBSERVADO_6 = 6;
	public static final String DESC_ESTADO_TRAMA_OBSERVADO_6 = "OBSERVADO";

	public static final String MSJ_NO_DATOS_BUSQUEDA_VENTA = "No se encontraron datos para la búsqueda.";

	// HORA POR DEFECTO PARA LAS POLIZAS
	public static final String HORA_DEFAULT_POSTVENTA_POLIZAS = "12:00:00";

	// PosVenta Mensajes de validacion para postventa
	public static final String MSJ_VAL_NINGUN_DATO_MODIFICADO = "No se ha modificado ningun dato.";

	// Datos del vehiculo
	public static final String MSJ_VAL_POSTVENTA_PLACA = "Ingresar campo obligatorio Placa.";
	public static final String MSJ_VAL_POSTVENTA_NUM_ASIENTOS = "Ingresar campo obligatorio Número de Asientos.";
	public static final String MSJ_VAL_POSTVENTA_ANIO_FAB = "Ingresar campo obligatorio Año de Fabricación.";
	public static final String MSJ_VAL_POSTVENTA_CATEGORIA_CLASE = "Ingresar campo obligatorio Categoría / Clase.";
	public static final String MSJ_VAL_POSTVENTA_USO_VEHICULO = "Ingresar campo obligatorio Uso de Vehículo.";
	public static final String MSJ_VAL_POSTVENTA_MARCA_VEHICULO = "Ingresar campo obligatorio Marca de Vehículo.";
	public static final String MSJ_VAL_POSTVENTA_MODELO_VEHICULO = "Ingresar campo obligatorio Modelo de Vehículo.";

	// Datos del Propietario
	public static final String MSJ_VAL_POSTVENTA_TIP_DOC = "Ingresar campo obligatorio Tipo de Documento.";
	public static final String MSJ_VAL_POSTVENTA_NUM_DOC = "Ingresar campo obligatorio Número de Documento.";
	public static final String MSJ_VAL_POSTVENTA_FEC_NAC = "Ingresar campo obligatorio Fecha de Nacimiento.";
	public static final String MSJ_VAL_POSTVENTA_SEXO = "Ingresar campo obligatorio Sexo.";
	public static final String MSJ_VAL_POSTVENTA_APE_PAT = "Ingresar campo obligatorio Apellido Paterno.";
	public static final String MSJ_VAL_POSTVENTA_APE_MAT = "Ingresar campo obligatorio Apellido Materno.";
	public static final String MSJ_VAL_POSTVENTA_NOMBRES = "Ingresar campo obligatorio Nombres.";

	// Datos de la Poliza
	public static final String MSJ_VAL_POSTVENTA_PRIMA_BRUTA = "Ingresar campo obligatorio Prima Bruta.";
	public static final String MSJ_VAL_POSTVENTA_INI_VIGENCIA = "Ingresar campo obligatorio Inicio de Vigencia.";
	public static final String MSJ_VAL_POSTVENTA_FIN_VIGENCIA = "Ingresar campo obligatorio Fin de Vigencia.";
	public static final String MSJ_VAL_POSTVENTA_FEC_VENTA = "Ingresar campo obligatorio Fecha de Venta.";

	// PARAMETROS DE SISTEMA
	public static final String PARAM_SIS_CATEGORIA_CARDIF_SERVICIOS = "CARDIF_SERVICIOS";
	public static final Integer PARAM_SIS_CATEGORIA_COD_CARDIF_SERVICIOS = 2;
	public static final Integer COD_PRODUCTO_EMP_SERVICIOS = 26;
	public static final String DESC_PRODUCTO_EMP_SERVICIOS = "EMP SERVICIOS";

	public static final Long ID_SOCIO_FALABELLA = 1L;

	// Mensaje Exito
	public static final String MSJ_FILE_UPLOAD_EXITO = "Se cargó el archivo correctamente.";

	// 20171030 - Parametros Tipo Trama
	public static final String COD_VALOR_TIPO_TRAMA_ALTAS = "01";
	public static final String COD_VALOR_TIPO_TRAMA_BAJAS = "02";
	public static final String COD_VALOR_TIPO_TRAMA_AMBOS = "03";

	// 20171121 - Origen de registro para CORRELATIVOS_VENTAS
	public static final String ORIGEN_NUEVA_VENTA = "NV";
	public static final String ORIGEN_TRAMA_DIARIA = "TD";
	// ****** FIN AUTOMATIZACION SOAT *****

	public static final String TIPO_SEGURO = "01";

	public static final String TIPO_REASEGURO = "03";

	public static final String TIPO_CUENTA = "04";

	public static final String TIPO_MOVIMIENTO = "05";

	public static final String TIPO_ESTADO = "06";

	public static final String TIPO_CONTRATO = "07";

	public static final String DETALLE_CUENTA = "08";

	public static final String TIPO_PROCESO = "09";

	public static final String LISTA_PAISES = "22";

	public static final String TIPO_PROCESO_ELIMINADO = "0904";

	public static final String TIPO_ESTADO_ACTIVO = "0601";

	public static final String TIPO_ESTADO_INACTIVO = "0602";

	public static final String RUTA_SQL = "1602";

	public static final String RUTA_EXCEL_DESTINO = "1605";

	public static final String PROCESADO = "0901";

	public static final String NOPROCESADO = "0902";

	public static final String PROCESADO_ERROR = "0903";

	public static final String INACTIVADO = "0904";

	public static final String MSJ_ACTIVO = "El parámetro se activará y por lo tanto,será ";
	public static final String MSJ_ACTIVO2 = "incluido en los reportes.¿Desea continuar?";

	public static final String MSJ_INACTIVO = "El parámetro se desactivará y por lo tanto,no será";
	public static final String MSJ_INACTIVO2 = "incluido en los reportes.¿Desea continuar?";

	public static final String PROCESO_PENDIENTE = "P";
	public static final String PROCESO_SOLICITUD = "S";
	public static final String PROCESO_COMPLETADO = "C";
	public static final String JOB_EJECUTAR_ARCHIVO = "JOB_SBS_PROCESA_ARCHIVOS";

	public static final int COD_ESTADO_ACTIVO = 1;
	public static final int COD_ESTADO_INACTIVO = 0;

	public static final String RAMO_CATEGORIA = "RAMO";
	public static final String SINI_MANUAL = "SINIMANUAL";

	public static final String DESCRIPCION_MONEDA_SOLES = "SOLES";

	/*
	 * MODULO DE SINIESTROS - PAGO POR VENTANILLA
	 * 
	 */

	// ------Beneficiarios.

	public static final String SINIESTRO_ASEG_PERSONA_NATURAL_PNA = "PNA";
	public static final String SINIESTRO_ASEG_SOCIO_SOC = "SOC";

	public static final String SINIESTRO_BENEFICIARIO_ASEGURADO_ASE = "ASE";
	public static final String SINIESTRO_BENEFICIARIO_OTROS_OTR = "OTR";

	public static final String SINI_BENEF_LINK_VER_DETALLE_GRILLA = "Ver Detalle";

	public static final String COD_ESTADO_SINI_APROBADO = "2";

	public static final String SINI_BENEF_ESTADO_PENDIENTE = "01";
	public static final String SINI_BENEF_ESTADO_PROVISIONADO = "02";
	public static final String SINI_BENEF_ESTADO_PENDIENTE_PAGO = "03";
	public static final String SINI_BENEF_ESTADO_PROCESADO = "04";
	public static final String SINI_BENEF_ESTADO_COBRADO = "05";

	public static BigDecimal CIEN_PORCIENTO_BENEF = new BigDecimal("100");

	public static final int PRESICION_DECIMAL_BENEF = 2;

	// ------Carga Trama Siniestro Ventanilla.

	public static String SINI_TIPO_TRAMA_CONFIRMACION = "0"; // 0: Confirmación
	// 1: Cobro

	public static String SINI_TIPO_TRAMA_COBRO = "1";

	// Tipos documento para los archivos (tramas) del BBVA
	public static String CARNE_DIPLOMATICO_D = "D";
	public static String LIBRETA_MILITAR_M = "M";
	public static String CARNE_EXTRANJERIA_E = "E";
	public static String PASAPORTE_P = "P";
	public static String RUC_R = "R";
	public static String LIBRETA_ELECTORAL_AND_DNI_L = "L";
	public static String SIN_DOCUMENTOS_S = "S";
	public static final String COD_PARAM_CUENTAS_ACEPTADAS = "094";
	public static final String TRAMA_GENERADA_BBVA = "2";
	public static final String MASIVO_PAGOS_SINIESTROS = "PAGOS SINIESTROS";
	public static final String COD_PARAM_LISTA_TIPO_TRAMA_GENERADA = "095";
	public static final String SINIESTRO_SOLES = "SNPEN";
	public static final String SINIESTRO_DOLAR = "SNUSD";

	// datos para envio de correo
	public static final String USER_NAME_MAIL = "pe-alerts@cardif.com.pe";
	public static final String SMTP_HOST_MAIL = "smtp-app.cardifnet.com";
	public static final String SMTP_PORT_MAIL = "25";
	public static final String SMTP_STARTTLS_MAIL = "true";
	public static final String SMTP_AUTH_FALSE_MAIL = "false";
	public static final long MAXIMO_5_MEGAS = 5242880;
	public static final String COD_PARAM_SIZE_MAX_ADJUNTOS = "096";

	public static final String COD_VALOR_PARENTESCO_TITULAR = "1";

	public static final String FORMATO_FECHA_DDMMYYYY = "ddMMyyyy";

	public static final String COD_VALOR_ELECTRONICO_SINIESTRO_BBVA = "10";
	public static final String COD_VALOR_ELECTRONICO_DEVOLUCION_PRIMA = "11";

	public static final String ELECTRONICO_SINIESTRO = "ELECTR SINIEST";

	public static final String COD_PARAM_ESTADO_BENEFICIARIO = "098";

	public static final String COD_PARAM_TIPO_MONEDA = "099";

	public static final String COD_PARAM_SINIESTRO_MANUAL = "100";

	public static final String COD_PARAM_CORREO_ENVIO_LOTES = "101";

	public static final String COD_PARAM_RAMOS_SINIESTROS = "102";

	public static final String FLAG_SINIESTRO_ASEGURADO_SOCIO_SI = "S";

	public static final String FLAG_SINIESTRO_ASEGURADO_SOCIO_NO = "N";

	public static final String ESTADO_SINIESTRO_ESTADO_APROBADO = "2";

	public static final String CORREO_FIRMANTE_SINIESTRO_ELECTRONICO = "097";

	public static final String DOCUMENTOS_IDENTIDAD_BBVA = "093";
	public static final String COD_PARAM_NOMENCLATURA_BBVA = "103";
	public static final String COD_VALOR_NOMENCLATURA_BBVA_SN = "3";
	public static final String COD_VALOR_DEV_PRIM_BBVA_SN = "5";

	public static final String PERFIL_AMER_ROLE_SAC = "AMER_ROLE_SAC";
	public static final String PERFIL_AMER_ROLE_SAC_JEFE = "AMER_ROLE_SAC_JEFE";

	/* Trama Util BBVA */
	public static final String CODIGO_REGISTRO_3110 = "3110";
	public static final String CODIGO_REGISTRO_3120 = "3120";
	public static final String CODIGO_REGISTRO_3130 = "3130";
	public static final String CODIGO_REGISTRO_3210 = "3210";
	public static final String CODIGO_REGISTRO_3220 = "3220";
	public static final String CODIGO_REGISTRO_3230 = "3230";
	public static final String CODIGO_REGISTRO_3910 = "3910";
	public static final String CODIGO_BANCO_DB = "200";
	public static final String TIPO_DOCUMENTO_ORDENANTE = "R";
	public static final String PARAMETRO_089 = "089";
	public static final String PARAMETRO_036 = "036";
	public static final String PARAMETRO_001 = "001";
	public static final String PARAMETRO_086 = "086";
	public static final String VALIDACION_PERTENENCIA = "1";
	public static final String INDICADOR_DEVOLUCION = "0";
	public static final String CODIGO_DEVOLUCION = "0000";
	public static final String ORDEN_DE_PAGO = "0011";
	public static final String CUENTA_ORDEN_DE_PAGO = "00000000000000000000";
	public static final String FORMA_ORDEN_DE_PAGO = "O";
	public static final String TIPO_CUENTA_ORDEN_DE_PAGO = "00";
	public static final int REGISTROS_DEFAULT = 4;
	public static final int NUMERO_CORRIDAS = 3;
	/* MODULO PAGOS FASE 2 - INICIO */

	/* Trama Util SBK */
	public static final String CODIGO_BANCO_SBK = "200";
	public static final String CODIGO_FORMA_PAGO_SBK_DEFAULT = "1";
	public static final String CODIGO_PARAMETRO_BANCO_SBK_XX1 = "138";
	public static final String VALOR_PARAMETRO_BANCO_SBK_XX1 = "1";
	
	// PARAMETROS
	public static final String COD_PARAM_CUENTAS_BANCOS = "040";
	public static final String COD_PARAM_MONEDA_TESORERIA = "069";
	public static final String COD_PARAM_BANCOS_TESORERIA = "111";
	public static final String COD_PARAM_ESTADOS_CHEQUE_TESORERIA = "112";
	public static final String COD_PARAM_TIPO_DIARIOS_TESORERIA = "113";
	public static final String COD_PARAM_PARAMETROS_GENERALES_TESORERIA = "114";
	public static final String COD_PARAM_CUENTA_CONTABLE_BANCO_TESORERIA = "115";
	public static final String COD_PARAM_REVERSION_GIRADOS_NO_COBRADOS = "116";
	public static final String COD_PARAM_ESTADOS_BENEFICIARIO = "117";
	public static final String COD_PARAM_CONFIG_CABECERAS_LAYOUT = "118";
	public static final String COD_PARAM_CONFIG_FILAS_INI_LAYOUT = "119";
	public static final String COD_PARAM_MAX_DIAS_VIGENCIA_CHEQUE = "MAXDIASVIGENCIACHEQUE";
	public static final String COD_PARAM_BANCOS_PAGOS_DEV_PRIMA_BENEF = "121";
	public static final String NOMVALOR_BANCOS_PAGOS_DEV_PRIMA_BENEF = "BANCOS";
	// ESTADOS CHEQUES
	public static final String CHEQUE_ESTADO_ANULADO = "0";
	public static final String CHEQUE_ESTADO_ANULADO_DESC = "ANULADO";
	public static final String CHEQUE_ESTADO_DISPONIBLE = "1";
	public static final String CHEQUE_ESTADO_DISPONIBLE_DESC = "DISPONIBLE";
	public static final String CHEQUE_ESTADO_RESERVADO = "2";
	public static final String CHEQUE_ESTADO_RESERVADO_DESC = "RESERVADO";
	public static final String CHEQUE_ESTADO_PENDIENTE_COBRO = "3";
	public static final String CHEQUE_ESTADO_PENDIENTE_COBRO_DESC = "PENDIENTE DE COBRO";
	public static final String CHEQUE_ESTADO_REVERSADO = "4";
	public static final String CHEQUE_ESTADO_REVERSADO_DESC = "REVERSADO";
	public static final String CHEQUE_ESTADO_COBRADO = "5";
	public static final String CHEQUE_ESTADO_COBRADO_DESC = "COBRADO";

	// TIPOS DE DIARIO
	public static final String TIPO_DIARIO_CHNOC = "CHNOC";
	public static final String TIPO_DIARIO_CHANU = "CHANU";
	public static final String TIPO_DIARIO_PGOSI = "PGOSI";
	public static final String TIPO_DIARIO_VPAY1 = "VPAY1";
	public static final String TIPO_DIARIO_VPAY2 = "VPAY2";
	public static final String TIPO_DIARIO_VPAY3 = "VPAY3";
	public static final String TIPO_DIARIO_VPAY4 = "VPAY4";
	public static final String TIPO_DIARIO_VPAY5 = "VPAY5";

	// ID LAYOUT PAGO CHEQUES
	public static final String ID_TABLA_LAYOUT_PAGO_CHEQUES = "1";

	// MONEDAS
	public static final String MONEDA_SOLES_SIMBOLO = "PEN";
	public static final String MONEDA_DOLAR_SIMBOLO = "USD";

	// TIPOS DE PAGO
	public static final String TIPO_PAGO_ITF = "ITF";
	public static final String TIPO_PAGO_COMISION_BANCARIA = "COMISION_BANCARIA";
	public static final String TIPO_PAGO_COMISION_SOCIO = "COMISION_SOCIO";
	public static final String TIPO_PAGO_RECAUDACION = "RECAUDACION";

	// PARAMETROS PARA CUENTAS DE GASTO
	public static final String CUENTA_GASTO_ITF = "066";
	public static final String CUENTA_GASTO_COMISION_BANCARIA = "047";
	public static final String CUENTA_GASTO_COMISION_SOCIO = "047";
	public static final String CUENTA_GASTO_RECAUDACION = "047";

	// MEDIOS DE PAGO
	public static final String MEDIO_PAGO_CHEQUE_IBK = "CHEQUE IBK";
	public static final String MEDIO_PAGO_CHEQUE_SBK = "CHEQUE SBK";
	public static final String MEDIO_PAGO_CHEQUE_BBVA = "CHEQUE BBVA";
	public static final String MEDIO_PAGO_CHEQUE_BN = "CHEQUE BN";

	// BANCOS
	public static final String BANCO_ID_BANBIF = "BB";
	public static final String BANCO_ID_BANCO_NACION = "BN";
	public static final String BANCO_ID_BBVA = "BC";
	public static final String BANCO_ID_CREDISCOTIA = "CS";
	public static final String BANCO_ID_GNB = "GN";
	public static final String BANCO_ID_INTERBANK = "IB";
	public static final String BANCO_ID_SCOTIABANK = "SB";

	// CUENTAS
	public static final String CUENTA_CONTABLE_10 = "10";
	public static final String CUENTA_CONTABLE_20 = "20";
	public static final String CUENTA_CONTABLE_23 = "23";
	public static final String CUENTA_CONTABLE_26 = "26";

	// RAMOS
	public static final String RAMO_ROBO_ASALTO = "41";
	public static final String RAMO_MULTISEGUROS = "57";
	public static final String RAMO_MISCELANEOS = "59";
	public static final String RAMO_ACCIDENTES_PERSONALES = "61";
	public static final String RAMO_ONCOLOGICO_ASIST_MEDICA = "64";
	public static final String RAMO_SOAT = "66";
	public static final String RAMO_VIDA_INDIV_LARGO_PLAZO = "71";
	public static final String RAMO_VIDA_GRUPO_FAMILIAR = "72";
	public static final String RAMO_DESGRAVAMEN = "74";
	public static final String RAMO_VIDA_INDIV_CORTO_PLAZO = "80";

	// ANALISIS CODE SUN
	public static final String ANALYSIS_CODE_10_CHEQUE = "007";

	// DEVOLUCIÓN DE PRIMAS
	public static final String ID_TABLA_LAYOUT_DEVOLUCION_PRIMA = "2";
	public static final String ID_TIPO_DIARIO_DEV_PRIMA = "DVPRI";
	public static final String CTA_CONTABLE_DEV_PRIMA = "20190924";
	public static final String COD_TIPO_DOC_DNI = "2";
	public static final String COD_TIPO_DOC_CARNET_EXT = "1";
	public static final String COD_TIPO_DOC_PASAPORTE = "3";
	public static final String COD_TIPO_MONEDA_SOLES = "2";
	public static final String COD_TIPO_MONEDA_DOL = "1";
	public static final String MDP_COD_MARCADOR_DEV_BENEF_SELECTED = "5";
	public static final String MDP_COD_MARCADOR_ELECTR_DEV_PRI_SELECTED = "11";
	public static final String MDP_MEDIO_PAGO_ELECTR_DEV_PRIM = "ELECTR DEV PRI";
	public static final String MDP_MEDIO_PAGO_CHEQUE_SCOTIABANK = "CHEQUE SBK";
	public static final String MDP_MEDIO_PAGO_CHEQUE_BBVA = "CHEQUE BBVA";
	public static final String MDP_TIPO_PAGO_MASIVO = "MASIVO";
	public static final String MDP_TIPO_PAGO_INDIVIDUAL = "INDIVIDUAL";
	public static final String MDP_CTA_CONTABLE_DEV_PRI = "20190924";
	public static final String MDP_CTA_CONTABLE_DEV_PRI_USD = "20290924";
	public static final String MDP_COD_ESTADO_PAGADO = "2";
	public static final int MDP_COD_TIPO_MOV_COMISION = 1;
	public static final int MDP_COD_TIPO_MOV_ITF = 2;
	public static final int MDP_COD_TIPO_MOV_SOCIO = 4;
	public static final int MDP_COD_TIPO_MOV_RECAUDO = 3;
	public static final int MDP_COD_TIPO_MOV_AJUSTES = 5;
	public static final String MDP_SIGNO_POSITIVO = "POSITIVO";
	public static final String MDP_SIGNO_NEGATIVO = "NEGATIVO";
	public static final String MDP_COD_BANCO_NACION = "BN";
	public static final String MDP_COD_BANCO_GNB = "GN";

	// ESTADOS BENEF DEVOL PRIMA
	public static final String ESTADO_PENDIENTE_BENEF_DEV_PRIM = "1";
	public static final String ESTADO_PENDIENTE_DESC_BENEF_DEV_PRIM = "PENDIENTE";

	public static final String CUENTAS_CONTABLES_RECAUDOS_COMISIONES_ITF = "131";
	public static final String CUENTA_CONTABLE_COMISION_BANCARIA_SOLES = "BAN_S";
	public static final String CUENTA_CONTABLE_COMISION_BANCARIA_DOLARES = "BAN_D";
	public static final String CUENTA_CONTABLE_COMISION_SOCIO_SOLES = "SOC_S";
	public static final String CUENTA_CONTABLE_COMISION_SOCIO_DOLARES = "SOC_D";
	public static final String CUENTA_CONTABLE_RECAUDOS_SOLES = "REC_S";
	public static final String CUENTA_CONTABLE_RECAUDOS_DOLARES = "REC_D";
	public static final String CUENTA_CONTABLE_ITF_SOLES = "ITF_S";
	public static final String CUENTA_CONTABLE_ITF_DOLARES = "ITF_D";
	public static final String CUENTA_CONTABLE_AJUSTES_SOLES = "AJU_S";

	public static final String PORCENTAJE_RETENCION = "127";

	/* MODULO PAGOS FASE 2 - FIN */

	/* T073265 EmbargosTelematicos INICIO */

	/* EMBARGO TELEMATICOS */
	public static final String COD_PARAM_ESTADOS_PROPUESTA_PAGO = "125";
	public static final String COD_PARAM_UIT_PROPUESTA_PAGO = "126";
	public static final String COD_PARAM_PORCENTAJE_RETENCION = "127";
	public static final String COD_PARAM_FILTRO_PROVEEDOR = "128";
	public static final String COD_PARAM_ESTADOS_PROVEEDOR = "129";
	public static final String COD_PARAM_PLAZO_DIAS_LIBERAR_SUNAT = "130";
	public static final String COD_PARAM_CANT_REG_POR_PAGINAS = "132";
	public static final String COD_PREFIJO_EMBARGO = "133";

	/* ESTADOS DE PROVEEDOR */
	public static final String EST_SIN_ESTADO = "0";
	public static final String EST_NO_ENVIADO_A_SUNAT = "1";
	public static final String EST_NO_RETENIDO = "2";
	public static final String EST_RETENIDO_POR_SUNAT = "3";
	public static final String EST_LIBERADO = "4";
	public static final String EST_PAGADO = "5";
	public static final String EST_ENVIADO_A_SUNAT = "6";

	/* ESTADO PROPUESTA DE PAGOS */
	public static final String EST_SIN_ESTADO_PROP = "0";
	public static final String EST_ABIERTO = "1";
	public static final String EST_EN_PROCESO = "2";
	public static final String EST_CERRADO = "3";

	/* T073265 EmbargosTelematicos FIN */

	public static final String MARCADOR_D = "D";
	public static final String MARCADOR_C = "C";

	/** MODULO REASEGUROS-COASEGUROS - INICIO */

	// PARAMETROS
	public static final String COD_PARAM_ANIO_INICIAL = "18";
	public static final String COD_PARAM_ESTADOS_PERIODO_OPERATIVO = "19";
	public static final String COD_PARAM_VALIDAR_PERIODO_ABIERTO_SUN = "20";
	public static final String COD_PARAM_VALIDAR_PERIODO_CUENTA_10 = "CUENTA_10";
	public static final String COD_PARAM_VALIDAR_PERIODO_CUENTA_26 = "CUENTA_26";
	public static final String COD_PARAM_TRIMESTRES = "14";
	public static final String COD_PARAM_TIPOS_CONTRATO = "07";
	public static final String COD_PARAM_ANIOS = "13";
	public static final String COD_PARAM_TIPO_CUENTA = "04";
	public static final String COD_PARAM_MONEDAS = "02";
	public static final String COD_PARAM_TIPO_DIARIO = "23";
	public static final String COD_PARAM_ESTADO_DINAMICA = "24";
	public static final String COD_PARAM_COD_SOCIO_PRODUCTO = "25";
	public static final String COD_PARAM_MARCADOR_DINAMICA = "26";
	public static final String COD_PARAM_MESES = "27";
	public static final String COD_PARAM_ESTADOS_ASIENTO = "28";
	public static final String COD_PARAM_ANIOS_ATRAS = "29";
	public static final String COD_PARAM_AUTHORITY_MANT_ANTICUAMIENTO = "32";

	// TIPOS DE REPORTE
	public static final String COD_PARAM_MODELO_1_DETALLE = "1001";
	public static final String COD_PARAM_MODELO_1_RESUMEN = "1002";
	public static final String COD_PARAM_MODELO_2_RESUMEN = "1003";
	public static final String COD_PARAM_ANEXO_2A = "1004";
	public static final String COD_PARAM_ANEXO_2B = "1005";
	public static final String COD_PARAM_ANEXO_18A = "3101";
	public static final String COD_PARAM_ANEXO_18F = "3103";
	public static final String COD_PARAM_ANEXO_18G = "3104";
	public static final String COD_PARAM_ANEXO_18H = "3105";
	public static final String COD_PARAM_ANEXO_18J = "3106";
	public static final String COD_PARAM_ANEXO_18E = "3102";
	public static final String COD_PARAM_PAIS_PERU = "2201";

	// ACCIONES PARA PERIODOS OPERATIVOS
	public static final String ACCION_ABRIR = "Abrir";
	public static final String ACCION_CERRAR = "Cerrar";
	public static final String ACCION_REABRIR = "Reabrir";

	// ESTADOS PERIODOS OPERATIVOS
	public static final String COD_ESTADO_BASE = "PEBAS";
	public static final String COD_ESTADO_ABIERTO = "PEABI";
	public static final String COD_ESTADO_CERRADO = "PECER";
	public static final String COD_ESTADO_REABIERTO = "PEREA";
	public static final String ESTADO_PERIODO_ABIERTO = "Abierto";
	public static final String ESTADO_PERIODO_REABIERTO = "ReAbierto";
	public static final String ESTADO_PERIODO_CERRADO = "Cerrado";

	// CONSTANTES
	public static final String METODO_VALIDA_PERIODO_ABIERTO_SUN = "VALIDAR_PERIODO_ABIERTO_SUN";
	public static final Integer FLAG_CERRAR_PERIODO_ANT = 1;
	public static final Integer FLAG_NO_CERRAR_PERIODO_ANT = 0;
	public static final Integer FLAG_ABRIR_PERIODO_POST = 1;
	public static final Integer FLAG_NO_ABRIR_PERIODO_POST = 0;

	// ESTADOS REPORTE
	public static final String COD_PARAM_ESTADO_PROCESADO_OK = "1501";
	public static final String COD_PARAM_ESTADO_PROCESADO_ERROR = "1502";
	public static final String COD_PARAM_ESTADO_PROCESADO_NO_PROCESADO = "1503";

	// TIPOS DE SEGURO
	public static final String COD_PARAM_TIPO_SEGURO_COASEGURO = "0101";
	public static final String COD_PARAM_TIPO_SEGURO_REASEGURO = "0102";
	public static final String TIPO_SEGURO_REASEGURO = "REASEGURO";
	public static final String TIPO_SEGURO_COASEGURO = "COASEGURO";
	public static final String TIPO_SEGURO_REASEGURO_ABREV = "REA";
	public static final String TIPO_SEGURO_COASEGURO_ABREV = "COA";

	// TITULOS
	public static final String TITULO_LOG_ERROR_MODELO_1_DETALLE = "LOG DE ERRORES: MODELO 1 - DETALLE";
	public static final String TITULO_LOG_ERROR_MODELO_1_RESUMEN = "LOG DE ERRORES: MODELO 1 - RESUMEN";
	public static final String TITULO_LOG_ERROR_MODELO_2_RESUMEN = "LOG DE ERRORES: MODELO 2 - RESUMEN";
	public static final String TITULO_MODELO_1 = "MODELO N° 1";
	public static final String TITULO_MODELO_1_RESUMEN = "MODELO N° 1 - RESUMEN";
	public static final String TITULO_MODELO_2_RESUMEN = "MODELO N° 2 - RESUMEN";
	public static final String TITULO_REPORTE_MODELO_UNO_SBS = "ReporteModeloUnoSBS";
	public static final String TITULO_REPORTE_MODELO_UNO_RESUMEN_SBS = "ReporteModeloUnoResumenSBS";
	public static final String TITULO_REPORTE_MODELO_DOS_RESUMEN_SBS = "ReporteModeloDosResumenSBS";

	// TRIMESTRES
	public static final String PRIMER_TRIMESTRE = "1401";
	public static final String SEGUNDO_TRIMESTRE = "1402";
	public static final String TERCER_TRIMESTRE = "1403";
	public static final String CUARTO_TRIMESTRE = "1404";

	// MONEDAS
	public static final String MONEDA_PEN = "PEN";
	public static final String MONEDA_USD = "USD";

	// MARCADORES
	public static final String MARCADOR_CARGO = "C";
	public static final String MARCADOR_ABONO = "A";
	// public static final String MARCADOR_D = "D";
	// public static final String MARCADOR_C = "C";
	public static final String COD_NO_APLICA = "NA";

	// LAYOUT TXT SUCAVE
	public static final String ANEXO2B_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO2B_COLUMNAID_COD_SBS = "10";
	public static final String ANEXO2B_COLUMNAID_CUENTAS_COBRAR_REACOA = "20";
	public static final String ANEXO2B_COLUMNAID_SEIS_MESES_ANT = "30";
	public static final String ANEXO2B_COLUMNAID_DOCE_MESES_ANT = "40";
	public static final String ANEXO2B_COLUMNAID_TOTAL = "50";

	public static final String ANEXO2A_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO2A_COLUMNAID_COD_SBS = "10";
	public static final String ANEXO2A_COLUMNAID_EMP_CLASIFICADORA = "30";
	public static final String ANEXO2A_COLUMNAID_CALIFICACION = "40";
	public static final String ANEXO2A_COLUMNAID_PRIMAS_PAGAR = "50";
	public static final String ANEXO2A_COLUMNAID_PRIMAS_COBRAR = "60";
	public static final String ANEXO2A_COLUMNAID_SINI_COBRAR = "70";
	public static final String ANEXO2A_COLUMNAID_SINI_PAGAR = "80";
	public static final String ANEXO2A_COLUMNAID_CUENTAS_COBRAR = "90";
	public static final String ANEXO2A_COLUMNAID_CUENTAS_PAGAR = "100";
	public static final String ANEXO2A_COLUMNAID_DESC_COMI = "110";
	public static final String ANEXO2A_COLUMNAID_SALDO_DEUDOR = "120";
	public static final String ANEXO2A_COLUMNAID_SALDO_ACREEDOR = "130";
	/* ANEXO 18A */
	public static final String ANEXO18A_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO18A_COLUMNAID_COD_REASEGURADOR = "20";
	public static final String ANEXO18A_COLUMNAID_COD_EMPRESA_CLASIFICADORA = "30";
	public static final String ANEXO18A_COLUMNAID_CLASIFICACION = "40";
	public static final String ANEXO18A_COLUMNAID_FECHA_CLASIF_RIESGO = "45";
	public static final String ANEXO18A_COLUMNAID_COD_REGISTRO_EMPRESA_CORREDORA_REA = "50";
	public static final String ANEXO18A_COLUMNAID_TIPO_CONTRATO = "65";
	public static final String ANEXO18A_COLUMNAID_RIESGO = "70";
	public static final String ANEXO18A_COLUMNAID_FECHA_INI_VIGENCIA = "90";
	public static final String ANEXO18A_COLUMNAID_FECHA_FIN_VIGENCIA = "95";
	public static final String ANEXO18A_COLUMNAID_PRIMAS_CEDIDAS_BRUTAS = "100";
	public static final String ANEXO18A_COLUMNAID_PRIMAS_CEDIDAS_NETAS = "105";

	/* ANEXO 18F */
	public static final String ANEXO18F_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO18F_COLUMNAID_COD_RAMO = "10";
	public static final String ANEXO18F_COLUMNAID_PRIMA_CEDIDA = "30";
	public static final String ANEXO18F_COLUMNAID_SINI_REAACEPTADO = "40";
	public static final String ANEXO18F_COLUMNAID_COMI_REAACEPTADO = "50";
	public static final String ANEXO18F_COLUMNAID_PRIMA_REAACEPTADO = "70";
	public static final String ANEXO18F_COLUMNAID_SINI_REACEDIDO = "80";
	public static final String ANEXO18F_COLUMNAID_COMI_PRICEDIDAS = "90";
	public static final String ANEXO18F_COLUMNAID_SALDO = "100";

	/* ANEXO 18G */
	public static final String ANEXO18G_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO18G_COLUMNAID_CODIGO = "20";
	public static final String ANEXO18G_COLUMNAID_RIESGO = "60";
	public static final String ANEXO18G_COLUMNAID_INI_VIGENCIA = "70";
	public static final String ANEXO18G_COLUMNAID_FIN_VIGENCIA = "80";
	public static final String ANEXO18G_COLUMNAID_TIPO_CONTRATO = "90";
	public static final String ANEXO18G_COLUMNAID_LIMITE_COBERTURA = "100";
	public static final String ANEXO18G_COLUMNAID_PARTICIPACION_CONTRATO = "115";
	public static final String ANEXO18G_COLUMNAID_PRIMA_REA_RECIBIDA = "120";

	/* ANEXO 18H */
	public static final String ANEXO18H_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO18H_COLUMNAID_COD_EMPRESA = "10";
	public static final String ANEXO18H_COLUMNAID_RIESGO = "30";
	public static final String ANEXO18H_COLUMNAID_NOM_ASEGURADO = "40";
	public static final String ANEXO18H_COLUMNAID_NUM_SINIESTRO = "50";
	public static final String ANEXO18H_COLUMNAID_FEC_OCURRENCIA = "60";
	public static final String ANEXO18H_COLUMNAID_LUGAR_OCURRENCIA = "70";
	public static final String ANEXO18H_COLUMNAID_IMPORTE_SINI_PAGAR = "100";
	public static final String ANEXO18H_COLUMNAID_IMPORTE_RETENCION = "110";
	public static final String ANEXO18H_COLUMNAID_IMPORTE_CESION = "120";

	/* ANEXO 18J */
	public static final String ANEXO18J_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO18J_COLUMNAID_COD_PAIS = "10";
	public static final String ANEXO18J_COLUMNAID_PRIMAS_CEDIDAS = "30";
	public static final String ANEXO18J_COLUMNAID_SINI_PRIMAS_REA_ACEPTADOS = "40";
	public static final String ANEXO18J_COLUMNAID_COMI_PRIMAS_REA_ACEPTADOS = "50";
	public static final String ANEXO18J_COLUMNAID_PRIMAS_REA_ACEPTADO = "70";
	public static final String ANEXO18J_COLUMNAID_SINI_PRIMAS_CEDIDAS_REA_CEDIDOS = "80";
	public static final String ANEXO18J_COLUMNAID_COMI_PRIMAS_CEDIDAS = "90";
	public static final String ANEXO18J_COLUMNAID_SALDO_I_E = "100";

	/* ANEXO 18E */
	public static final String ANEXO18E_COLUMNAID_COD_FILA = "0";
	public static final String ANEXO18E_COLUMNAID_COD_REASEGURADOR = "10";
	public static final String ANEXO18E_COLUMNAID_EMP_CLASIF = "11";
	public static final String ANEXO18E_COLUMNAID_CLASIF_RIESGO = "13";
	public static final String ANEXO18E_COLUMNAID_FECHA_CLASIF_RIESGO = "15";
	public static final String ANEXO18E_COLUMNAID_RIESGO = "40";
	public static final String ANEXO18E_COLUMNAID_NOMBRE_ASEGURADO = "50";
	public static final String ANEXO18E_COLUMNAID_NUM_SINIESTRO = "55";
	public static final String ANEXO18E_COLUMNAID_FEC_OCURRENCIA = "60";
	public static final String ANEXO18E_COLUMNAID_IMPORTE_SINI_PAGAR = "65";
	public static final String ANEXO18E_COLUMNAID_MERCADO_LOCAL = "80";
	public static final String ANEXO18E_COLUMNAID_MERCADO_EXTERIOR = "90";
	public static final String ANEXO18E_COLUMNAID_TOTAL = "100";

	public static final String INACTIVO = "0";
	public static final String ACTIVO = "1";

	public static final String COD_IGV = "30";

	public static final String COD_PARAM_REPORTE_ANEXO_SBS = "31";

	public static final String COD_ANEXO_18A = "3101";
	public static final String COD_ANEXO_18E = "3102";
	public static final String COD_ANEXO_18F = "3103";
	public static final String COD_ANEXO_18G = "3104";
	public static final String COD_ANEXO_18H = "3105";
	public static final String COD_ANEXO_18J = "3106";

	public static final String COD_PARAM_GRUPO_TIPO_REPORTE = "10";
	public static final String FORMATO_FECHA_CABECERA_ANEXOS = "AAAAMMDD";

	public static final String ESTADO_ASIENTO_GENERADO = "ASGEN";
	public static final String ESTADO_ASIENTO_NO_GENERADO = "ASNGE";
	public static final String ESTADO_ASIENTO_REVERSADO = "ASREV";

	public static final String TIPO_REASEGURO_CEDIDO = "CED";
	public static final String TIPO_REASEGURO_RECIBIDO = "REC";

	public static final String TIPO_OPERACION_SINIESTRO = "SIN";
	public static final String TIPO_OPERACION_PRIMA = "PRI";
	public static final String TIPO_OPERACION_RESERVAS = "RES";
	public static final String TIPO_OPERACION_ESTIMACION = "EST";

	public static final String TIPO_DIARIO_SINPL = "SINPL";
	public static final String TIPO_DIARIO_CREMI = "CREMI";
	public static final String TIPO_DIARIO_PRSIN = "PRSIN";

	public static final String COD_SBS_CARDIF = "03183";

	public static final String COD_PARAM_CUENTAS_ANEXO_18_E = "33";
	public static final String COD_VALOR_OTROS_SINIESTROS_100 = "100";
	public static final String COD_VALOR_OTRAS_PROVISIONES_200 = "200";
	public static final String COD_VALOR_TOTALES_CUENTA_26_300 = "300";
	public static final String COD_VALOR_SINIESTROS_COBRAR_CONTRATOS_REASEGURO_400 = "400";

	public static final String COD_PARAM_CUENTAS_ANEXO_18_H = "34";
	public static final String COD_VALOR_SINIESTROS_LIQUIDADOS_PENDIENTES_PAGO_100 = "100";
	public static final String COD_PARAMETRO_RAMO_RIESGO = "17";
	public static final String COD_ANEXO_TXT_2A = "01";
	public static final String COD_ANEXO_TXT_2B = "02";
	/** MODULO REASEGUROS-COASEGUROS - FIN */

	/** CPE - INICIO **/
	public static final String VALOR_DEFECTO_CBX = "-1";

	public static final String COD_PARAM_CPE_ESTADO_PROCESO = "001";
	public static final String COD_PARAM_CPE_ORIGEN_DATOS = "002";
	public static final String COD_PARAM_CPE_TIPO_MONEDA = "003";
	public static final String COD_PARAM_CPE_TIPO_COMPROBANTES = "004";
	public static final String COD_PARAM_CPE_ESTADO_VENTA = "005";
	public static final String COD_PARAM_CPE_TIPO_DOCUMENTO = "006";
	public static final String COD_PARAM_CPE_TIPO_PRODUCTO = "007";
	public static final String COD_PARAM_CPE_EMPRESA = "008";
	public static final String COD_PARAM_CPE_CARDIF_SEGUROS = "009";
	public static final String COD_PARAM_CPE_CARDIF_SERVICIOS = "010";
	public static final String COD_PARAM_CPE_ESTADO_CFG = "011";
	public static final String COD_PARAM_CPE_SIS_GENERAL_CFG = "013";
	/* 012 */
	/* 013 */
	public static final String COD_PARAM_CPE_EMPRESA_CON_DETRACCION = "014";
	public static final String COD_PARAM_CPE_TIPO_COMPROBANTE_REF = "015";
	public static final String COD_PARAM_CPE_ESCONTRAMA_SPLT = "016";
	public static final String COD_PARAM_CPE_LOTE_CE = "017";
	public static final String COD_PARAM_CPE_PREFIJO_CE = "018";
	public static final String COD_PARAM_CPE_FLG_SW_PROD_TEST = "019";
	public static final String COD_PARAM_ESCON_SW_PRD = "020";
	public static final String COD_PARAM_ESCON_SW_TST = "021";
	public static final String COD_PARAM_CONTA_AUTH = "022";
	public static final String COD_PARAM_FLG_SSIS_CE = "023";
	public static final String COD_PARAM_MOTIVO_REF_NC = "025";
	public static final String COD_PARAM_MOTIVO_REF_ND = "026";

	public static final String COD_PARAM_TIPO_REPORTES = "031";
	public static final String COD_PARAM_CORRELATIVO_PLE_SERVICIOS = "032";
	public static final String COD_PARAM_CORRELATIVO_PLE_SEGUROS = "037";
	public static final String COD_PARAM_DETRACCION_SERVICIOS = "038";
	public static final String COD_PARAM_NUM_MAXIMO_ONLINE = "035";
	public static final String COD_PARAM_TIPO_PROCESO_POR_EMPRESA = "039";
	public static final String COD_PARAM_DETRACCION_ESCON = "040";
	public static final String COD_PARAM_ACCESO_SUNSYSTEMS = "042";

	public static final String COD_PARAM_SUNAT_TIPO_TRIBUTO = "005";
	public static final String COD_PARAM_SUNAT_TIPO_AFECTACION = "007";
	public static final String COD_VALOR_DESCRIP_TIPO_AFECTACION_GRAV = "Gravado";
	public static final String COD_VALOR_DESCRIP_TIPO_AFECTACION_INAF = "Inafecto";
	public static final String COD_VALOR_DESCRIP_TIPO_AFECTACION_EXON = "Exonerado";

	public static final String COD_PARAM_ESQUEMA = "041";
	public static final String COD_VALOR_ESQUEMA_SEGUROS = "ESQUEMA_SEGUROS";
	
	public static final String COD_PARAM_CORRELATIVO_LOTE = "034";
	public static final String COD_VALOR_CORRELATIVO_LOTE = "CORRELATIVO_LOTE";

	public static final String COD_PARAM_CPE_RUTA_ARCHIVOCARGA_ARC_CARGA = "ARC_CARGA";
	public static final String COD_PARAM_CPE_RUTA_TRAMAESCON_ESCON_IN = "ESCON_IN";
	public static final String COD_PARAM_CPE_RUTA_TRAMAESCON_ESCON_OUT = "ESCON_OUT";
	public static final String COD_PARAM_CPE_ESCONTRAMA_SPLT_ESCONTRAMA_SPLT = "ESCONTRAMA_SPLT";
	public static final String COD_PARAM_CPE_LOTE_CE_PRF_LT = "PRF_LT";
	public static final String COD_PARAM_CPE_LOTE_CE_PRF_PROC = "PRF_PROC";
	public static final String COD_PARAM_CPE_LOTE_CE_PRF_TP_MAS = "PRF_TP_MAS";
	public static final String COD_PARAM_CPE_LOTE_CE_PRF_TP_ONL = "PRF_TP_ONL";
	public static final String COD_PARAM_CPE_PREFIJO_CE_FAC_ELEC = "FAC_ELEC";
	public static final String COD_PARAM_CPE_PREFIJO_CE_BOL_ELEC = "BOL_ELEC";
	public static final String COD_PARAM_CPE_PREFIJO_CE_NCF_ELEC = "NCF_ELEC";
	public static final String COD_PARAM_CPE_PREFIJO_CE_NCB_ELEC = "NCB_ELEC";
	public static final String COD_PARAM_CPE_PREFIJO_CE_NDF_ELEC = "NDF_ELEC";
	public static final String COD_PARAM_CPE_PREFIJO_CE_NDB_ELEC = "NDB_ELEC";
	public static final String COD_PARAM_CPE_FLG_SW_PROD_TEST_FLG_SW_PROD_TEST = "FLG_SW_PROD_TEST";
	public static final String COD_PARAM_ESCON_SW_PRD_URL_SW_PRD = "URL_SW_2_1_PRD";
	public static final String COD_PARAM_ESCON_SW_TST_URL_SW_TST = "URL_SW_2_1_TST";
	public static final String COD_PARAM_CONTA_AUTH_CONTA_AUTH = "CONTA_AUTH";
	public static final String COD_VALOR_ESTADO_PROCESO_PENDIENTE = "1";
	public static final String COD_VALOR_ESTADO_PROCESO_PROCESADO = "2";
	public static final String COD_VALOR_ESTADO_PROCESO_PROCESADO_ERRORES = "3";
	public static final String COD_VALOR_SIS_GENERAL_RUTA_CARGA = "RUTA_ARCHIVOCARGA";
	public static final String COD_VALOR_EN_PROCESO = "0";
	public static final String COD_VALOR_COMPLETADA = "1";
	public static final String COD_VALOR_CANCELADA = "2";

	public static final String COD_VALOR_USU_SW_PRD_SEG = "USU_SW_PRD_SEG";
	public static final String COD_VALOR_PASS_SW_PRD_SEG = "PASS_SW_PRD_SEG";
	public static final String COD_VALOR_USU_SW_PRD_SERV = "USU_SW_PRD_SERV";
	public static final String COD_VALOR_PASS_SW_PRD_SERV = "PASS_SW_PRD_SERV";
	public static final String COD_VALOR_USU_SW_TST_SEG = "USU_SW_TST_SEG";
	public static final String COD_VALOR_PASS_SW_TST_SEG = "PASS_SW_TST_SEG";
	public static final String COD_VALOR_USU_SW_TST_SERV = "USU_SW_TST_SERV";
	public static final String COD_VALOR_PASS_SW_TST_SERV = "PASS_SW_TST_SERV";

	public static final String CPE_CODIGO_PROD = "1";
	public static final String CPE_CODIGO_TEST = "0";

	public static final String FLG_COMPLETADO_NO = "0";
	public static final String FLG_COMPLETADO_SI = "1";
	public static final String FLG_DETRACCION_NO = "0";
	public static final String FLG_DETRACCION_SI = "1";
	public static final String LABEL_ALL_CBX = "Todos";
	public static final String COD_VALOR_TIPO_COMPROBANTE_FACTURA = "01";
	public static final String COD_VALOR_TIPO_COMPROBANTE_BOLETA = "03";
	public static final String COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO = "07";
	public static final String COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO = "08";

	public static final String COD_VALOR_TIPO_COMPROBANTE_REF_FACTURA = "F";
	public static final String COD_VALOR_TIPO_COMPROBANTE_REF_BOLETA = "B";

	public static final String ID_CARGA_COMPROBANTES_MANUAL = "0";
	public static final String ID_LAYOUT_ARCHIVO = "1";
	public static final String ID_FIRST_SHEET_XLSX = "rId1";
	public static final String KEY_LIST_VENTA_XLSX = "LIST_VENTA_XLSX";
	public static final String ID_TIPO_CARGA_ONLINE = "0";
	public static final String ID_TIPO_CARGA_BACKGROUND = "1";

	public static final String COD_ORIGEN_ARCHIVO = "0";
	public static final String COD_ORIGEN_UPLOAD = "1";
	public static final String COD_ORIGEN_PIMS = "2";
	public static final String COD_ORIGEN_MANUAL = "9";

	public static final String COD_EMPRESA_CARDIF_SEGUROS = "1";
	public static final String COD_EMPRESA_CARDIF_SERVICIOS = "2";

	public static final String COD_TIPO_PRODUCTO_INDIVIDUAL = "1";
	public static final String COD_TIPO_PRODUCTO_COLECTIVO = "2";
	public static final String COD_TIPO_PRODUCTO_ADMINISTRATIVO = "3";

	public static final String COD_ESTADO_VENTA_PENDIENTE = "1";
	public static final String COD_ESTADO_VENTA_ENVIADO = "2";
	public static final String COD_ESTADO_VENTA_VALIDADO = "3";
	public static final String COD_ESTADO_VENTA_RECHAZADO = "4";
	public static final String COD_ESTADO_VENTA_ERROR_ENVIO = "5";
	public static final String COD_ESTADO_VENTA_ANULADO = "6";

	public static final String COD_SCON_RESPONSE_OK = "0";
	public static final String COD_SCON_RESPONSE_ANULADO = "2108";
	public static final String COD_SCON_RESPONSE_ERROR_ENVIO = "-0011";
	public static final String COD_SCON_RESPONSE_MAYOR_7_DIAS_EMISION = "2108";

	public static final String COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC = "00";
	public static final String NOM_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC = "Doc. Tri. No Dom. Sin Ruc";
	public static final String COD_VALOR_TIPO_DOC_CLIENTE_DNI = "01";
	public static final String NOM_TIPO_DOC_CLIENTE_DNI = "DNI";
	public static final String COD_VALOR_TIPO_DOC_CLIENTE_CARNET_EXTRANJERIA = "04";
	public static final String NOM_TIPO_DOC_CLIENTE_CARNET_EXTRANJERIA = "Carnet Extranjería";
	public static final String COD_VALOR_TIPO_DOC_CLIENTE_RUC = "06";
	public static final String NOM_TIPO_DOC_CLIENTE_RUC = "RUC";
	public static final String COD_VALOR_TIPO_DOC_CLIENTE_PASAPORTE = "07";
	public static final String NOM_TIPO_DOC_CLIENTE_PASAPORTE = "Pasaporte";
	public static final String TIPO_PROCESO_CE_ONLINE = "0";
	public static final String TIPO_PROCESO_CE_MASIVO = "1";
	/**TIP_PER0100_FASE02 INICIO 2019/11/25 - 15:11 - Se agregar constante de proceso ONLINE RESUMEN.*/
	public static final String TIPO_PROCESO_CE_ONLINE_RESUMEN = "2";
	/**TIP_PER0100_FASE02 FIN 2019/11/25 - 15:11 - Se agregar constante de proceso ONLINE RESUMEN. */
	public static final String CPE_PREFIJO_BOLETA = "B";
	public static final String CPE_PREFIJO_FACTURA = "F";
	public static final String COD_VALOR_TIPO_REPORTE_COMPROBANTES_ELECTRÓNICOS = "1";
	public static final String COD_VALOR_TIPO_REPORTE_REGISTRO_DE_VENTAS = "2";
	public static final String COD_VALOR_TIPO_REPORTE_PLE_REGISTRO_DE_VENTAS = "3";

	public static final String COD_VALOR_EMPRESA_DIR = "DIR";
	public static final String COD_VALOR_EMPRESA_ID_TIP_DOC = "ID_TIP_DOC";
	public static final String COD_VALOR_EMPRESA_MAIL = "MAIL";
	public static final String COD_VALOR_EMPRESA_RAS_SOC = "RAS_SOC";
	public static final String COD_VALOR_EMPRESA_RUC = "RUC";
	public static final String COD_VALOR_EMPRESA_TEL = "TEL";
	public static final String COD_VALOR_EMPRESA_UBIGEO = "UBIGEO";
	public static final String COD_VALOR_EMPRESA_WEB = "WEB";

	public static final String COD_VALOR_GENERAL_IGV = "IGV";

	public static final String COD_VALOR_TIPO_AFECTACION_FACT_EXPORT = "40";
	public static final String COD_VALOR_TIPO_AFECTACION_BASE_IMPONIBLE = "10";
	public static final String COD_VALOR_TIPO_AFECTACION_IMP_EXONERADO = "20";
	public static final String COD_VALOR_TIPO_AFECTACION_INAFECTO = "30";
	public static final String COD_VALOR_TIPO_AFECTACION_VAL_GRATUITAS = "21";

	public static final String COD_VALOR_CONCEPTO_TRIB_EXPORTACIONES = "1000";
	public static final String COD_VALOR_CONCEPTO_TRIB_GRAVADAS = "1001";
	public static final String COD_VALOR_CONCEPTO_TRIB_INAFECTAS = "1002";
	public static final String COD_VALOR_CONCEPTO_TRIB_EXONERADAS = "1003";
	public static final String COD_VALOR_CONCEPTO_TRIB_GRATUITAS = "1004";
	public static final String COD_VALOR_CONCEPTO_TRIB_SUB_TOTAL = "1005";
	public static final String COD_VALOR_CONCEPTO_TRIB_PERCEPCIONES = "2001";
	public static final String COD_VALOR_CONCEPTO_TRIB_RETENCIONES = "2002";
	public static final String COD_VALOR_CONCEPTO_TRIB_DETRACCIONES = "2003";
	public static final String COD_VALOR_CONCEPTO_TRIB_BONIFICACIONES = "2004";
	public static final String COD_VALOR_CONCEPTO_TRIB_TOTAL_DESCUENTOS = "2005";

	public static final String COD_VALOR_TIPO_OPERACION_VENTA_SIN_DETRACCION = "0101";
	public static final String COD_VALOR_TIPO_OPERACION_VENTA_CON_DETRACCION = "1001";
	public static final String COD_VALOR_TIPO_OPERACION_VENTA_NO_DOMICILIADO = "0401";

	public static final String COD_VALOR_TIPO_TRIBUTO_IGV = "1000";
	public static final String COD_VALOR_TIPO_TRIBUTO_EXPORTACION = "9995";
	public static final String COD_VALOR_TIPO_TRIBUTO_GRATUITO = "9996";
	public static final String COD_VALOR_TIPO_TRIBUTO_EXONERADO = "9997";
	public static final String COD_VALOR_TIPO_TRIBUTO_INAFECTO = "9998";

	public static final String TOTAL_ANTICIPO_CPE = "100";
	public static final String CODIGO_LEYENDA_CPE = "1000";
	public static final String CODIGO_LEYENDA_GRATUITAS_CPE = "1002";
	public static final String CODIGO_LEYENDA_DETRACCION_CPE = "2006";
	public static final String MONEDA_PERU_ACTUAL = "Soles";
	public static final String COD_NUMBER_OF_INTERNATIONAL_UNITS = "NIU";

	public static final String CPE_JOB_NAME_PACKAGE_TXT = "JOB_SAT_CPE_GeneraTxtEscon";
	public static final String CPE_JOB_NAME_SEGUROS_PACKAGE_TXT = "JOB_SAT_CPE_SEGUROS_GeneraTxtEscon";
	public static final String CPE_CODIGO_TIPO_PROCESO_MASIVO = "M";
	public static final String CPE_CODIGO_TIPO_PROCESO_ONLINE = "O";
	/**TIP_PER0100_FASE02 INICIO 2019/11/26 - 11:38 - Se agregar constante de proceso ONLINE RESUMEN.*/
	public static final String CPE_CODIGO_TIPO_PROCESO_ONLINE_RESUMEN = "R";
	public static final String CPE_FLG_PROCESAR_ONLINE_RESUMEN = "1";
	/**TIP_PER0100_FASE02 FIN 2019/11/26 - 11:38 - Se agregar constante de proceso ONLINE RESUMEN. */
	public static final String CPE_FLG_PROCESAR_MASIVO = "1";
	public static final String COD_VALOR_PACKAGE_TXT_FLG = "FLG_SSIS_GENERATXT_ESCON";
	public static final String FLG_SSIS_GENERATXT_ESCON_GENERAR = "0";
	public static final String FLG_SSIS_GENERATXT_ESCON_OCUPADO = "1";
	
	/**TIP_PER0100_FASE02 INICIO-FIN 2019/11/26 - 18:27 - Se agregar constante de proceso ONLINE RESUMEN GENERAR RESUMEN PAQUETE.*/
	public static final String COD_VALOR_PACKAGE_RESUMEN_FLG = "FLG_SSIS_GENERARESU_ESCON";
	public static final String FLG_SSIS_GENERARESUMEN_ESCON_GENERAR = "0";
	public static final String FLG_SSIS_GENERARESUMEN_ESCON_OCUPADO = "1";
	/**TIP_PER0100_FASE02 FIN 2019/11/26 - 18:27 - Se agregar constante de proceso ONLINE RESUMEN GENERAR RESUMEN PAQUETE.*/
	
	public static final String CPE_CODIGO_ASIG_SUNAT = "0000";
	public static final String CPE_MEDIA_TYPE_JSON = "application/json";

	public static final String ID_LAYOUT_ARCHIVO_ERROR = "4";

	public static final String CPE_JOB_NAME_PACKAGE_CARGAVENTA_BG = "JOB_SAT_CPE_CargaVenta_BG";
	public static final String COD_VALOR_PACKAGE_CARGAVENTA_FLG = "FLG_SSIS_CARGAVENTA_BG";
	public static final String FLG_SSIS_CARGAVENTA_ESCON_GENERAR = "0";
	public static final String FLG_SSIS_CARGAVENTA_ESCON_OCUPADO = "1";

	public static final String COD_VALOR_SISRUTA_SEGUROS = "SISRUTA_SEGUROS";
	public static final String COD_VALOR_SISRUTA_SERVICIO = "SISRUTA_SERVICIO";
	public static final String COD_VALOR_SISRUTARESP = "SISRUTARESP";

	public static final String CPE_DESCRIPCION_DUPLI_ARCHIVO = "Duplicado Archivo";
	public static final String CPE_DESCRIPCION_DUPLI_VENTA = "Duplicado";
	public static final String CPE_DESCRIPCION_VENTA_NUEVA = "Nuevo";
	public static final String CPE_FLG_AGRUPADO = "1";

	public static final String CPE_CODIGO_WS_STATUS_OK = "200";
	public static final String CPE_PARAM_COD_VALOR_RUC = "RUC";
	public static final String CPE_IDENTIFICADOR_LIBRO_REG_VENTAS_E_INGRESOS = "140100";
	public static final Integer CPE_LONGITUD_SERIE = 3;
	public static final String CPE_ND_PENALIDAD = "03";

	public static final String CPE_FORMATO_FECHA_STR = "YYYYMMDD";

	public static final String COD_VALOR_PROCESO_ONLINE_SEGUROS = "ONLINESGROS";
	public static final String COD_VALOR_PROCESO_MASIVO_SEGUROS = "MASIVOSGROS";
	public static final String COD_VALOR_PROCESO_ONLINE_SERVICIOS = "ONLINESRVCS";
	public static final String COD_VALOR_PROCESO_MASIVO_SERVICIOS = "MASIVOSRVCS";
	
	/**TIP_PER0100_FASE02 INICIO 2019/11/26 - 17:50 - Se agregar constante de tipo proceso ONLINE RESUMEN PARA LOS SISTEMAS SEGUROS Y SERVICIOS.*/
	public static final String COD_VALOR_PROCESO_RESUMEN_SEGUROS = "RESUMENSGROS";
	public static final String COD_VALOR_PROCESO_RESUMEN_SERVICIOS = "RESUMENSRVCS";
	/**TIP_PER0100_FASE02 FIN 2019/11/26 - 17:50 - Se agregar constante de tipo proceso ONLINE RESUMEN PARA LOS SISTEMAS SEGUROS Y SERVICIOS. */
	
	public static final String COD_VALOR_MSJE_DETRACCION_ESCON = "Operación sujeta a detracción";	
	public static final String COD_VALOR_MSJE_GRATUITAS_ESCON = "TRANSFERENCIA GRATUITA DE UN BIEN Y/O SERVICIO PRESTADO GRATUITAMENTE";

	
	
	/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 12:55 - Se agrega tipo de motivo SUNAT otros con código 10 */
	public static final String COD_MOTIVO_SUNAT_OTROS = "10";
	/*TIP_PER0100_CC09_13 FIN */
	
	/**TIP_PER0100_CC15 INICIO 2019/06/20 - 18:30 - Se agrega tipo de comprobante autorizado */
	public static final String COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO = "13";
	/**TIP_PER0100_CC15 FIN */
	/** CPE - FIN **/
	
	/**TIP_PER0100_FASE02 INICIO 2019/12/09 - 11:25 - Se agregar constante para el nombre del job de resumen de comprobante.*/
	public static final String CPE_JOB_NAME_SAT_CPE_SERVICIOS_RESUMEN = "JOB_SAT_CPE_SERVICIOS_RESUMEN";
	/**TIP_PER0100_FASE02 FIN 2019/12/09 - 11:25 - Se agregar constante para el nombre del job de resumen de comprobante. */
	
	/* Constantes de menu y accion - Auditoria */
	public static final int CPE_AUDITORIA_OPCION_ACCION_N = 1;
	public static final int CPE_AUDITORIA_OPCION_ACCION_U = 2;
	public static final int CPE_AUDITORIA_OPCION_ACCION_D = 3;
	public static final int CPE_AUDITORIA_OPCION_ACCION_O = 4;
	public static final String CPE_AUDITORIA_MENU_MANT_SINIESTRO = "Mantenimiento Siniestros";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GEN_PLANILLA = "Generar Planilla";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GEN_PLANILLA_PROCESO = "UPDATE SINI_SINIESTRO";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GENPLANTANALISIS = "Generar Plantilla Analisis";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GENPLANTLIQUID = "Generar Plantilla Liquidacion";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GENPLANT_PROCESO = "EXPORTACION PLANTILLA";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GUARDA_NUEVO = "Guardar - Nuevo";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GUARDA_NUEVO_PROCESO = "INSERT SINI_SINIESTRO - INSERT SINI_POLIZA - INSERT SINI_DATOS_CAFAE - INSERT SINI_ROBO - INSERT SINI_RENTA_HOSP - INSERT SINI_DESGRAVAMEN - INSERT SINI_DESEMPLEO";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GUARDA_MODIFICA = "Guardar - Modificar";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_GUARDA_MODIFICA_PROCESO = "UPDATE SINI_SINIESTRO - UPDATE SINI_POLIZA - UPDATE SINI_DATOS_CAFAE - UPDATE SINI_ROBO - UPDATE SINI_RENTA_HOSP - UPDATE SINI_DESGRAVAMEN - UPDATE SINI_DESEMPLEO";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_AGREGAR = "Agregar Beneficiario";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_AGREGAR_PROCESO = "INSERT SINI_BENEF";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_ELIMINAR = "Eliminar Beneficiario";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_ELIMINAR_PROCESO = "DELETE SINI_BENEF";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_MODIFICAR = "Modificar Beneficiario";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_MODIFICAR_PROCESO = "UPDATE SINI_BENEF";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_DIST_PART = "Distribuir Participacion Beneficiario";
	public static final String CPE_AUDITORIA_ACCION_MANT_SINIESTRO_BENEF_DIST_PART_PROCESO = "UPDATE SINI_BENEF";
	
	public static final String CPE_AUDITORIA_MENU_CARGA_SINIESTRO = "Carga Siniestros manuales con beneficiarios";
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_PROC_CARGA = "Procesar carga";
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_ELIM_SINIESTRO = "Eliminar Carga Siniestro";
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_PROC_CARGA_PROCESO = "INSERT SINI_MANUAL";
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_ELIM_SINIESTRO_PROCESO = "DELETE SINI_MANUAL";
	
	//INI 01-JUL-2020 PSS PERU (RCHAVEZ) 
	public static final String CPE_AUDITORIA_MENU_CARGA_SINIESTRO_CO = "Carga Siniestros Colombia con beneficiarios"; //MENU
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_CO_PROC_CARGA = "Procesar carga Siniestro Colombia"; //ACCION
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_CO_ELIM_SINIESTRO = "Eliminar Siniestro Colombia"; //ACION
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_CO_EXPO_SINIESTRO = "Exportar Siniestros Colombia"; //ACCION
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_CO_PROC_CARGA_PROCESO = "INSERT SINI_CO_BENEF"; //PROCESO
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_CO_ELIM_SINIESTRO_PROCESO = "DELETE SINI_CO_BENEF"; //PROCESO
	public static final String CPE_AUDITORIA_ACCION_CARGA_SINIESTRO_CO_EXPO_SINIESTRO_PROCESO = "EXPORT SINI_CO_BENEF";  //PROCESO
	//FIN 01-JUL-2020 PSS PERU (RCHAVEZ) 
	
	public static final String CPE_AUDITORIA_MENU_CONSULTA_SINIESTRO = "Consulta Siniestros con beneficiarios";
	public static final String CPE_AUDITORIA_ACCION_CONSULTA_SINIESTRO_EXP_OPE_CONT = "Exportar para ope. contables";
	public static final String CPE_AUDITORIA_ACCION_CONSULTA_SINIESTRO_EXP_OPE_CONT_PROCESO = "UPDATE SINI_BENEF";
	//public static final String CPE_AUDITORIA_ACCION_CONSULTA_SINIESTRO_GEN_REPORTE = "Generar Reporte";
	
	public static final String CPE_AUDITORIA_MENU_CARGA_TRAMA_SINIESTRO = "Carga de tramas pagos siniestros por ventanilla";
	public static final String CPE_AUDITORIA_ACCION_CARGA_TRAMA_SINIESTRO_PROC_TRAMAS = "Procesar tramas";
	public static final String CPE_AUDITORIA_ACCION_CARGA_TRAMA_SINIESTRO_PROC_TRAMAS_PROCESO = "INSERT CARGA_TRAMA_EXTERNO - UPDATE SINI_BENEF - UPDATE SINI_MANUAL";
	public static final String CPE_AUDITORIA_ACCION_CARGA_TRAMA_SINIESTRO_PROC_TRAMAS_PROCESO_TOT = "INSERT CARGA_TRAMA_EXTERNO - UPDATE SINI_BENEF - UPDATE SINI_MANUAL - UPDATE M_BENEFICIARIO";
	public static final String CPE_AUDITORIA_ACCION_CARGA_TRAMA_SINIESTRO_PROC_TRAMAS_PROCESOMBCN = "CONFIRMADOS - UPDATE M_BENEFICIARIO";
	public static final String CPE_AUDITORIA_ACCION_CARGA_TRAMA_SINIESTRO_PROC_TRAMAS_PROCESOMBCB = "COBROS - UPDATE M_BENEFICIARIO";
	
	/* --------------------------------------- */
	
	/**INICIO BOF JTN */
	public static final String COD_VALOR_BOFCONF = "145";
	public static final String COD_VALOR_TIPOCARGA = "147";
	public static final String COD_VALOR_DATOSASIENTO = "146";
	
	public static final String KEY_LIST_MENSUAL_XLSX = "LIST_MENSUAL_XLSX";
	public static final String KEY_LIST_DPF_XLSX = "LIST_DPF_XLSX";
	public static final String KEY_LIST_VARIOS_XLSX = "LIST_VARIOS_XLSX";
	public static final String MSG_CARGA_OK = "CARGA DE ARCHIVO EXITOSA";

	public static final String TAB_CARGA_MENSUAL = "MOV";
	public static final String TAB_CARGA_DPF = "DPF";
	public static final String TAB_CARGA_VARIOS = "MV";
	/**FIN BOF JTN */

        /** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
	/******* {Carlos Chayguaque} - {25/09/2020} ********/
	public static final String CONTA_RESERVA_DIARIO_DEFAULT = "*";
	public static final String CONTA_RESERVA_COD_PARAM_SHEET = "143";
	public static final String CONTA_RESERVA_COL_CAB = "B";
	public static final String CONTA_RESERVA_COL_CAB_VAL = "C";
	public static final String KEY_LIST_RESERVAS_XLSX = "LIST_RESERVAS_XLSX";
	public static final String KEY_LIST_DATOSE_XLSX = "LIST_DATOSE_XLSX";
	public static final String KEY_LIST_DATOSR_XLSX = "LIST_DATOSR_XLSX";
	public static final String CONTA_TIPO_CARGA_RESERVA = "1"; //Carga de reservas
	public static final String CONTA_TIPO_CARGA_DATOS = "2"; //Carga de datos
	/*** Fin {Automatización Contabilidad} - {Sprint 1} **/

	// INI 13-AGO-2020 PSS PERU (RCHAVEZ) 
	public static final String COD_PARAM_CLAVE_ARCHIVO_SINI_CO = "142";
	// FIN 13-AGO-2020 PSS PERU (RCHAVEZ) 
}