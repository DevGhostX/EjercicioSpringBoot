package com.cardif.satelite.constantes;

public interface ErrorConstants {

	public static final String ERROR_SYNCCON = "ERROR SYNCCON: ";
	public static final String MSJ_ERROR_GENERAL = "Lo sentimos, ha ocurrido un error";
	public static final String MSJ_ERROR = "error";
	public static final String COD_ERROR_GENERAL = "10000";

	/* Errores Generales */
	public static final String COD_ERROR_LOGIN_INVALIDO = "10001";
	public static final String COD_ERROR_USUARIO_INHABILITADO = "10002";
	public static final String COD_ERROR_CONTRASENA_EQUIVOCADA = "10003";
	public static final String COD_ERROR_CONTRASENAS_DIFERENTES = "10004";
	public static final String COD_ERROR_SELECCION = "10005";
	public static final String COD_ERROR_CAMPOS_OBLIGATORIOS = "10006";
	public static final String COD_ERROR_AUTENTICACION = "10007";
	public static final String COD_ERROR_PERFIL = "10008";

	public static final String COD_ERROR_BASE_DATOS = "11000";

	public static final String COD_ERROR_BD_INSERTAR = "11001";
	public static final String COD_ERROR_BD_ACTUALIZAR = "11002";
	public static final String COD_ERROR_BD_ELIMINAR = "11003";
	public static final String COD_ERROR_BD_BUSCAR = "11004";
	public static final String COD_ERROR_BD_OBTENER = "11005";
	public static final String COD_ERROR_BD_INTEGRIDAD = "11006";

	public static final String COD_ERROR_CARGAR_EXCEL = "12001";
	public static final String COD_ERROR_TRANSFORMAR_EXCEL = "12001";
	public static final String COD_ERROR_JOB = "12006";
	public static final String COD_ERROR_ARCHIVO = "12007";
	public static final String COD_ERROR_PERIODO = "12008";
	public static final String COD_ERROR_ESTRUCTURA = "24030";

	public static final String COD_ERROR_EXCLUIDO = "12009";
	public static final String COD_ERROR_NO_PRIMA = "12010";
	public static final String COD_ERROR_PLACA = "12011";
	public static final String COD_ERROR_FEC_VIG_ANTERIOR = "12012";
	public static final String COD_ERROR_FEC_VIG_POSTERIOR = "12013";
	public static final String COD_ERROR_CARGA_NULO = "12014";
	public static final String COD_ERROR_FEC_VIG_FIN = "12015";
	public static final String COD_ERROR_FEC_CIERRE_INI = "12016";
	public static final String COD_ERROR_FEC_CIERRE_FIN = "12017";
	public static final String COD_ERROR_REPORTE_EJECUCION = "12018";
	public static final String COD_ERROR_RANGO_FEC = "12019";

	public static final String COD_ERROR_ELIMINAR_LISTA = "12020";
	public static final String COD_ERROR_FEC_VIG_FIN_EMPTY = "12021";
	public static final String COD_ERROR_CUOTAS = "12022";
	public static final String COD_ERROR_CANT_PROD = "12023";
	public static final String COD_ERROR_ARCHIVO_INPUT = "12024";
	public static final String COD_ERROR_ARCHIVO_FEEDBACK = "12025";
	public static final String COD_ERROR_CANT_CERO = "12026";
	public static final String COD_ERROR_LISTA_VACIA = "12027";
	public static final String COD_ERROR_RANGO_FECHAS = "12028";
	public static final String COD_ERROR_RANGO_FECHAS_CONTABLES = "12029";
	public static final String COD_ERROR_COMPROBANTE_FECHA_DESDE_HASTA = "12030";
	public static final String DATOS_GUARDADOS_CORRECTAMENTE = "12200";

	public static final String COD_ERROR_CONSUL_PLACA = "12100";
	public static final String COD_ERROR_CONSUL_PROPIETARIO = "12101";
	public static final String COD_ERROR_CONSUL_DNI = "12102";
	public static final String COD_ERROR_CONSUL_PLACA_EXISTE = "12103";
	public static final String COD_ERROR_VALIDA_EDAD = "12104";
	public static final String COD_ERROR_ACCESO_PROPIETARIO = "12105";
	public static final String COD_ERROR_ACCESO_VEHICULAR = "12106";

	public static final String COD_ERROR_PERIODO_CERRADO = "13001";
	public static final String COD_ERROR_PERIODO_NO_PROCESADO = "13002";
	public static final String COD_ERROR_PERIODO_PENDIENTE = "13003";
	public static final String COD_ERROR_PERIODO_COD_NOEXISTE = "13004";
	public static final String COD_ERROR_PERIODO_TIPO_ARCHIVO_TXT = "13005";
	public static final String COD_ERROR_PERIODO_TIPO_ARCHIVO_XLSX = "13006";
	public static final String COD_ERROR_PERIODO_CERRADO_NO_EXPORTAR = "13007";
	public static final String COD_ERROR_PERIODO_CERRADO_NO_PROCESAR = "13008";
	public static final String COD_ERROR_LEER_ARCHIVO_EXCEL = "13009";

	public static final String COD_ERROR_SUSCRIP_FECHA_DESDE_HASTA = "13010";
	public static final String COD_ERROR_SUSCRIP_LISTA_VACIA_AL_EXPORTAR = "13011";

	public static final String COD_ERROR_WS_ACSELE = "14000";
	public static final String COD_ERROR_DOCU_WS_ACSELE = "14001";
	public static final String COD_ERROR_POLIZA_WS_ACSELE = "14002";

	public static final String COD_ERROR_FEC_VALIDEZ = "15000";

	public static final String COD_ERROR_REGISTRO_NO_SELECCIONADO = "16000";
	public static final String COD_ERROR_BUSQUEDA_PENDIENTE = "16001";
	public static final String COD_ERROR_SINIESTROS_NO_SELECCIONADOS = "16002";
	public static final String COD_ERROR_SINIESTROS_FECHA_APROBO_RECHAZA = "16003";
	public static final String COD_ERROR_SINIESTROS_FECHA_NOTIFICACION_SOCIO = "16004";
	public static final String COD_ERROR_SINIESTROS_FECHA_NOTIFICACION_SOCIO_CON_FECHA_INI_VIGENCIA = "16005";
	public static final String COD_ERROR_SINIESTROS_FECHA_NOTIFICACION_SOCIO_CON_FECHA_ACTUAL = "16006";
	public static final String COD_ERROR_SINIESTROS_NRO_PLANILLAS = "16007";
	public static final String COD_ERROR_SINIESTROS_NRO_PLANILLAS_CERO = "16027";

	public static final String COD_ERROR_SINIESTROS_AL_MENOS_UNA_COBERTURA_CAFAE = "16008";
	public static final String COD_ERROR_SINIESTROS_FECHA_OCURRENCIA_CON_FECHA_ACTUAL = "16009";
	public static final String COD_ERROR_SINIESTROS_FECHA_NOTIFICACION_CARDIF_CON_FECHA_ACTUAL = "16010";
	public static final String COD_ERROR_SINIESTROS_FECHA_ULT_DOCUMEN_CARDIF_CON_FECHA_ACTUAL = "16011";
	public static final String COD_ERROR_SINIESTROS_FECHA_INICIO_VIGENCIA_CON_FECHA_ACTUAL = "16012";
	public static final String COD_ERROR_SINIESTROS_FECHA_NACIMIENTO_CON_FECHA_ACTUAL = "16013";
	public static final String COD_ERROR_SINIESTROS_FECHA_FIN_VIGENCIA_CON_FECHA_ACTUAL = "16014";
	public static final String COD_ERROR_SINIESTROS_FECHA_ULT_DOCUM_CARDIF_Y_NOT_CON_FECHA_ACTUAL = "16015";
	public static final String COD_ERROR_SINIESTROS_FECHA_EMI_Y_FECHA_APROBACION = "16016";
	public static final String COD_ERROR_SINIESTROS_FECHA_ENTRE_Y_FECHA_EMI_CHECE = "16017";
	public static final String COD_ERROR_SINIESTROS_FECHA_EMI_CHEQUE_FECHA_ACTUAL = "16018";
	public static final String COD_ERROR_SINIESTROS_FECHA_APROB_RECHA_Y_FECHA_INICIO_VIGENCIA = "16019";
	public static final String COD_ERROR_SINIESTROS_FECHA_ENTRE_Y_FECHA_ACTUAL = "16020";
	public static final String COD_ERROR_SINIESTROS_FECHA_PROBACION_RECHA_Y_FECHA_ACTUAL = "16021";
	public static final String COD_ERROR_SINIESTROS_ESTADO_APROBADO_REQUIERE_LLENAR_PAGOS = "16022";
	public static final String COD_ERROR_SINIESTROS_FECHA_OCURRENCIA_CON_FECHA_NOTIFICACION_CARDIF = "16023";
	public static final String COD_ERROR_SINIESTROS_FECHA_FIN_VIGENCIA_CON_FECHA_INI_VIGENCIA = "16024";
	public static final String COD_ERROR_SINIESTROS_FECHA_NACIMIENTO_CON_FECHA_OCURRENCIA = "16025";
	public static final String COD_ERROR_SINIESTROS_FECHA_PROBACION_RECHA_Y_FECHA_ULTIMA_DOCUMENT_CARDIF = "16026";
	public static final String COD_ERROR_SINIESTROS_FECHA_ULT_DOCUMEN_SOCIO_CON_FECHA_ACTUAL = "16028";
	public static final String COD_ERROR_SINIESTROS_FECHA_ULT_DOC_SOCIO_Y_NOT_CON_FECHA_ULT_DOC_CARDIF = "16029";
	public static final String COD_ERROR_SINIESTROS_FECHA_NOT_SOCIO_Y_NOT_CON_FECHA_NOT_CARDIF = "16030";
	public static final String COD_ERROR_SINIESTROS_FECHA_PROBACION_RECHA_Y_FECHA_NOTIF_CARDIF = "16031";

	public static final String COD_ERROR_PERIODO_INVALIDO = "17000";
	public static final String COD_ERROR_NO_MASTER = "17001";
	public static final String COD_ERROR_FORMATO_INCORRECTO = "17002";
	public static final String COD_ERROR_SINIESTROS_CON_NRO_PLANILLA = "17003";
	public static final String COD_ERROR_SINIESTROS_NO_APROBADOS = "17004";
	public static final String COD_ERROR_NO_COINCIDEN_SOCIOS = "17005";
	public static final String COD_ERROR_NO_COINCIDEN_POLIZAS = "17006";
	public static final String COD_ERROR_NO_COINCIDEN_PRODUCTOS = "17007";
	public static final String COD_ERROR_PERIODO_VACIO = "17008";
	public static final String COD_ERROR_NO_MENSUAL = "17009";
	public static final String COD_ERROR_NO_DIARIA = "17010";

	public static final String COD_ERROR_FEC_NO_INGRESADA = "18000";
	public static final String COD_ERROR_SOCIO_MASTER = "18001";

	public static final String COD_ERROR_FILA_NO_SELECCIONADA = "19000";
	public static final String COD_ERROR_RANGO_INVALIDO = "19001";

	public static final String COD_ERROR_REG_VEHICULAR_SERIE_FORMAT = "19100";

	public static final String COD_ERROR_GEN_COMPROBANTE_NO_CHECK = "24001";
	public static final String COD_ERROR_LISTA_TRAMA_REVERSION_VACIA = "24002";
	public static final String COD_ERROR_PLAZO_MAXIMO_SUNAT = "24003";
	public static final String COD_ERROR_EXPORTAR_CERT_RETENCION = "24004";
	public static final String COD_ERROR_SUNSYSTEMS_LEDGERTRANSACTION_UPDATE = "24005";
	public static final String COD_ERROR_LISTA_CERT_RETENCION_VACIA = "24006";
	public static final String COD_ERROR_UND_NEGOCIO_NO_EXISTE = "24007";
	public static final String COD_ERROR_TRAMA_RETENCION_ERROR = "24008";

	public static final String COD_ERROR_CAMPOS_OBLIGATORIOS_PROVEEDOR_PERIODO = "24085";

	// PRIMER PASE
	public static final String COD_ERROR_ARMAR_LOTE_FECHA_COMPRA_DESDE = "20001";
	public static final String COD_ERROR_ARMAR_LOTE_FECHA_COMPRA_HASTA = "20002";
	public static final String COD_ERROR_ARMAR_LOTE_SOCIO_NULO = "20003";
	public static final String COD_ERROR_ARMAR_LOTE_NO_CHECK_SELECT = "20004";
	public static final String COD_ERROR_ARMAR_LOTE_ACT_POLIZA_IMP = "20005";
	public static final String COD_ERROR_ARMAR_LOTE_ACT_DOC_VALORADO = "20006";
	public static final String COD_ERROR_ARMAR_LOTE_DET_LOTE_IMPRESION = "20007";
	public static final String COD_ERROR_ARMAR_LOTE_FORMATO_CERTIFICADOS = "20008";
	public static final String COD_ERROR_ARMAR_LOTE_IMP_NULA = "20009";
	public static final String COD_ERROR_ARMAR_LOTE_CONF_IMPRESION_POLIZA = "20010";
	public static final String COD_ERROR_ARMAR_LOTE_ACTUA_LOTE_IMPRESION = "20011";
	public static final String COD_ERROR_ARMAR_LOTE_NRO_CERTIFICADO_VACIO = "20012";
	public static final String COD_ERROR_ARMAR_LOTE_DUPLICIDAD_CERTIFICADOS = "20013";
	public static final String COD_ERROR_ARMAR_LOTE_NRO_CERT_NO_DISPONIBLE = "20014";
	public static final String COD_ERROR_ARMAR_LOTE_VALIDAR_FILTRO_MINIMO = "20015";

	public static final String COD_ERROR_CONF_CERTIFICADO_PUB_LISTA_NULA = "20101";
	public static final String COD_ERROR_CONF_CERTIFICADO_PRI_LISTA_NULA = "20102";
	public static final String COD_ERROR_CONF_CERTIFICADO_PUB_ELIM_NULA = "20103";
	public static final String COD_ERROR_CONF_CERTIFICADO_PRI_ELIM_NULA = "20104";

	public static final String COD_ERROR_REP_POLIZAS_SOAT_BUSQUEDA_PENDIENTE = "21001";

	public static final String COD_ERROR_REP_APESEG_BUSQUEDA_PENDIENTE = "22001";

	public static final String COD_ERROR_LOTE_IMPRESION_PK_VACIO = "22010";
	public static final String COD_ERROR_DESCARGAR_PDF_VACIO = "22011";

	public static final String COD_ERROR_POST_VENTA_SOAT_FORMATO_CERT = "22100";
	public static final String COD_ERROR_POST_VENTA_SOAT_CERT_NO_DISPONIBLE = "22101";
	public static final String COD_ERROR_POST_VENTA_SOAT_REASIGNAR_CERT = "22102";

	public static final String COD_ERROR_ALTA_DE_REIMPRESION = "22103";
	public static final String COD_ERROR_CONFIRMAR_CERT_POST_VENTA = "22104";
	public static final String COD_ERROR_POST_VENTA_ACTUALIZAR_VACIOS = "22105";
	public static final String COD_ERROR_GENERAR_PDF_POLIZA = "22106";
	public static final String COD_ERROR_NUEVA_MARCA_MODELO = "22107";

	public static final String COD_ERROR_MARCA_VEHICULO_EXISTE = "22108";
	public static final String COD_ERROR_MODELO_VEHICULO_EXISTE = "22109";
	public static final String COD_ERROR_SBS_ANEXO_EXISTE = "22111";

	public static final String COD_ERROR_CORRELATIVO_APESEG = "20110";

	public static final String COD_ERROR_REP_FALABELLA_ITEMS_VACIO = "22112";
	public static final String COD_ERROR_REP_FALABELLA_TIPO_TRAMA = "22113";

	public static final String COD_ERROR_REPORTE_RV_FILA_NULA = "24009";

	public static final String COD_ERROR_REP_SBS_ES_11A = "24010";
	public static final String COD_ERROR_REP_SBS_ES_11A_SIN_FILAS = "24011";
	public static final String COD_ERROR_REP_SBS_ES_11C = "24012";
	public static final String COD_ERROR_REP_SBS_ES_11C_SIN_FILAS = "24013";
	public static final String COD_ERROR_REP_SBS_S_18 = "24016";
	public static final String COD_ERROR_REP_SBS_S_18_SIN_FILAS = "24017";

	public static final String COD_ERROR_REP_SBS_TIP_ANEXO_INDEFINIDO = "24014";
	public static final String COD_ERROR_REP_SBS_REGISTRAR = "24015";
	public static final String COD_ERROR_DET_MASTER_PRECIOS_NULO = "24018";

	public static final String COD_INFO_MENSAJE_CARACTERES_ESPECIALES = "24019";
	public static final String COD_INFO_MENSAJE_VALIDACION_CERTIFIVCADO = "24020";
	public static final String COD_VALIDACION_ARMAR_LOTE = "24021";
	public static final String COD_INFO_MENSAJE_ERROR_WEBSERVICE = "24022";
	public static final String COD_ERROR_POST_VENTA_VALIDACION_SAS = "24023";
	public static final String COD_ERROR_POST_VENTA_SOAT_NULL = "24024";

	public static final String COD_INFO_ELIMINAR_TRAMAS = "24025";
	public static final String COD_SOCIODIGITAL_ERROR_UPDATE = "24026";
	public static final String COD_INFO_MENSAJE_VALIDACION_NROPOLIZA_UPD = "24027";// add
	// db
	public static final String COD_INFO_MENSAJE_VALIDACION_NROPOLIZA_EDIT = "24029";
	public static final String COD_ERROR_VALIDACION_FORMATO_EXCEL = "24028";

	public static final String COD_ERROR_PROCESAR_ARCHIVO = "12002";

	// 20171030 - Mensaje Seleccion de socio con tipo de venta
	public static final String COD_ERROR_VALIDACION_SOCIO_TIPO_VENTA = "24060";

	// 20171124 - Mensaje fecha emision menor a filtro fecha emision (hasta)
	public static final String COD_ERROR_VALIDACION_FECHA_EMISION_HASTA = "24070";

	public static final String COD_ERROR_RUTA_TRAMAS_NO_EXISTE = "24031";

	/* Inicio - 20170925 - Distribuir participación de Beneficiarios */
	public static final String COD_ERROR_SUMA_TOTAL_PART_IGUAL_CIEN = "24032";
	public static final String COD_ERROR_TOTAL_MONTOS_IGUAL_IMP_PAGOS = "24033";
	public static final String COD_ERROR_OK_VALORES_PARTICIPACION_ACTUALIZADOS = "24034";

	/*********************************************/
	/** DESARROLLO PROYECTO VIGILANCE */
	// Mensajes carga archivo excel
	public static final String COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL = "24035";
	public static final String COD_ERROR_MAL_ESTRUCTURA_CAB_EXCEL = "24036";
	public static final String COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL = "24037";
	public static final String COD_ERROR_ANTIGUO_FORMATO_EXCEL = "24038";
	public static final String COD_ERROR_ERR_CARGA_EXCEL = "24039";
	// Mensajes carga blacklist o flash
	public static final String COD_ERROR_MSJ_PROCESO_CARGA_EXITOSA = "24040";
	public static final String COD_ERROR_NO_REGISTROS_GRILLA = "24041";
	public static final String COD_ERROR_ERR_NOMBRE_GENERADO = "24042";
	public static final String COD_ERROR_SELEC_TIPO_CARGA = "24043";
	public static final String COD_ERROR_SELEC_MES_CARGA = "24044";
	public static final String COD_ERROR_INGRESAR_ANIO_CARGA = "24045";
	public static final String COD_ERROR_CARG_ARCH = "24046";
	public static final String COD_ERROR_ANIO_MAYOR_ACTUAL = "24047";
	public static final String COD_ERROR_ANIO_MENOR = "24048";
	public static final String COD_ERROR_ARCHIVO_RECHAZADO = "24049";
	// Mensajes registro de procesos
	public static final String COD_ERROR_SELEC_TIPO_PROCESO = "24050";
	public static final String COD_ERROR_SELEC_ANIO = "24051";
	public static final String COD_ERROR_SELEC_BLACK_LIST = "24052";
	public static final String COD_ERROR_SELEC_FLASH = "24053";
	public static final String COD_ERROR_SELEC_BLACK_O_FLASH = "24054";
	public static final String COD_ERROR_CARG_ARCH_VENTAS = "24055";
	public static final String COD_ERROR_SELECT_ORIGEN = "24056";
	public static final String COD_ERROR_ELIM_ARCH_VENTAS = "24057";
	public static final String COD_ERROR_AGREG_PROCESO = "24058";
	public static final String COD_ERROR_MSJ_REGISTRO_PROCESOS_EXITOSO = "24059";
	/*********************************************/

	/** MODULO PAGOS FASE 2 - INICIO */
	public static final String COD_ERROR_SELECT_BANCO = "24061";
	public static final String COD_ERROR_SELECT_CTA_BANCARIA = "24062";
	public static final String COD_ERROR_INGRESAR_CORRELATIVOS_DESDE = "24063";
	public static final String COD_ERROR_INGRESAR_CORRELATIVOS_HASTA = "24064";
	public static final String COD_ERROR_OK_REGISTRO_CORRELATIVO = "24065";
	public static final String COD_ERROR_INGRESAR_CORR_MAYOR_MENOR = "24066";
	public static final String COD_ERROR_CRUCE_CORRELATIVOS = "24067";
	public static final String COD_ERROR_FEC_REG_FINAL_MENOR_INICIAL = "24068";
	public static final String COD_ERROR_FEC_MOD_FINAL_MENOR_INICIAL = "24069";
	public static final String COD_ERROR_SELECT_ESTADOS_PERMITIDOS = "24071";
	public static final String COD_ERROR_SELECT_UN_SOLO_ESTADO = "24072";
	public static final String COD_ERROR_SELECT_CHEQUES = "24073";
	public static final String COD_ERROR_FORMATO_PERIODO = "24074";
	public static final String COD_ERROR_INGRESAR_ARCHIVO_PERIODO = "24075";
	public static final String COD_ERROR_CARGAR_CHEQUES = "24076";
	public static final String COD_ERROR_VALIDAR_PAGO_CHEQUES = "24077";
	public static final String COD_ERROR_ACEPTAR_PAGO_CHEQUES = "24078";
	public static final String COD_ERROR_OK_PAGO_CHEQUES = "24079";
	public static final String COD_ERROR_VALIDA_OBLIG_BUSQ = "24085";
	public static final String COD_ERROR_TIPO_PAGO = "24086";
	public static final String COD_ERROR_MARCADOR = "24087";
	public static final String COD_ERROR_MEDIO_PAGO = "24088";
	public static final String COD_ERROR_MEDIO_PAGO_DEV_PRIM = "24089";
	public static final String COD_ERROR_CTA_BANCARIA_DEV_PRIM = "24090";
	public static final String COD_ERROR_INDIVIDUAL_MULTIPLE = "24100";
	public static final String COD_ERROR_ELECTR_DEV_PRI_NO_MASIVO = "24101";
	public static final String COD_ERROR_CHQ_REVERS_TIPO_DIARIO = "24102";
	public static final String COD_ERROR_OK_PROCESO_EXITOSO = "24092";
	public static final String COD_ERROR_CHQ_REVERS_CTA_CBLE_NULO = "24108";
	/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
	/******* {Carlos Chayguaque} - {25/09/2020} ********/
	public static final String COD_ERROR_VALIDA_OBLIG_BUSQ_REVERSA = "24300";
	public static final String COD_ERROR_VALIDA_OBLIG_BUSQ_CUENTA = "24301";
	/*** Fin {Automatización Contabilidad} - {Sprint 1} **/

	// RECAUDOS COMISIONES ITF
	public static final String COD_ERROR_CARGAR_LAYOUT = "24080";
	public static final String COD_ERROR_CONFIG_LAYOUT = "24081";
	public static final String COD_ERROR_DV_DUPLICADO = "24082";
	public static final String COD_ERROR_CHEQUES_DISPONIBLES_INSUFICIENTES = "24083";
	public static final String COD_ERROR_CHEQUES_INSUFICIENTES_MSJCORTO = "24098";
	public static final String COD_ERROR_VALIDAR_PROCESAR_ASIENTOS = "24103";

	// MODULO PAGOS
	public static final String COD_ERROR_SELECT_MEDIO_PAGO_CTA_BANCO = "24084";
	public static final String COD_ERROR_GENERAR_LOTE = "24142";
	public static final String COD_ERROR_FALTA_ACTUALIZAR_ULTIMO_NUM_DIARIO = "24189";

	/** MODULO PAGOS FASE 2 - FIN */

	// Mensajes Propuesta Pago - Sistema Embargo Telematicos SUNAT
	public static final String COD_ERROR_PROVEEDOR_NO_CUMPLE_REGLA_NEGOCIO = "24155";
	public static final String COD_INFO_REG_SATISFACTORIO_PROPUESTA_PAGO = "24156";
	public static final String COD_INFO_ELIMINACION_REG = "24157";
	public static final String COD_INFO_ACTUALIZA_REG = "24158";
	public static final String COD_ERROR_FECHA_DESDE = "24159";
	public static final String COD_ERROR_FECHA_HASTA = "24160";
	public static final String COD_ERROR_ELIMINA = "24162";

	/** MODULO REASEGUROS-COASEGUROS - INICIO */
	public static final String COD_ERROR_PERIOD_ANT_EST_BASE = "24091";
	public static final String COD_ERROR_OK_PROCESO_PERIODO = "24092";
	public static final String COD_ERROR_PERIODO_NO_ABIERTO_SUN = "24093";
	public static final String COD_ERROR_CERRAR_PERIODO_ANT = "24094";
	public static final String COD_ERROR_CARGAS_SIN_ASIENTOS = "24095";
	public static final String COD_ERROR_APERTURAR_SGTE_PERIODO = "24096";
	public static final String COD_ERROR_INGRESO_MOTIVO = "24097";
	public static final String COD_ERROR_PROCESO_NO_POSIBLE = "24099";

	public static final String COD_ERROR_VALIDAR_PROCESAR_ASIENTOS_REACOA = "24103";
	public static final String COD_ERROR_SELECT_PERIODO_ANIO_TRIMESTRE = "24104";
	public static final String COD_ERROR_PERIODO_NO_ABIERTO = "24105";
	public static final String COD_ERROR_OK_MONTOS_REGISTRADOS = "24106";
	public static final String COD_ERROR_MONTOS_FORMATO_INCORRECTO = "24107";
	public static final String COD_ERROR_MONTOS_NO_REGISTRADOS = "24109";
	public static final String COD_ERROR_NO_EXISTEN_RESULTADOS = "24110";
	public static final String COD_ERROR_EXISTEN_CUENTAS_INGRESADAS = "24111";
	public static final String COD_ERROR_EXISTE_DEPENDENCIA_OTRA_DINAMICA = "24112";
	public static final String COD_ERROR_EXISTE_IGV_DINAMICA = "24113";
	public static final String COD_ERROR_EXISTE_DESCUENTO_DINAMICA = "24114";
	public static final String COD_ERROR_DEBE_INGRESAR_CUENTA = "24115";
	public static final String COD_ERROR_CUENTA_SOLO_NUMERICO = "24116";
	public static final String COD_ERROR_CUENTA_INICIA_NUMEROS = "24117";
	public static final String COD_ERROR_DEBE_INGRESAR_DESCRIPCION_CUENTA = "24118";
	public static final String COD_ERROR_DEBE_SELECCIONAR_MARCADOR = "24119";
	public static final String COD_ERROR_CUENTA_INGRESADA_EXISTE = "24120";
	public static final String COD_ERROR_DEBE_INGRESAR_CUENTA_VALIDA = "24121";
	public static final String COD_ERROR_CUENTA_NO_CORRESPONDE_MONEDA = "24122";
	public static final String COD_ERROR_CUENTA_IGV_EXISTE = "24123";
	public static final String COD_ERROR_CUENTA_DESCUENTO_EXISTE = "24124";
	public static final String COD_ERROR_DEBE_SELECCIONAR_TIPO_SEGURO = "24125";
	public static final String COD_ERROR_DEBE_SELECCIONAR_SOCIO = "24126";
	public static final String COD_ERROR_DEBE_SELECCIONAR_DETALLE_CUENTA = "24127";
	public static final String COD_ERROR_DEBE_SELECCIONAR_TIPO_MOVIMIENTO = "24128";
	public static final String COD_ERROR_DEBE_SELECCIONAR_EMPRESA = "24129";
	public static final String COD_ERROR_DEBE_SELECCIONAR_PRODUCTO = "24130";
	public static final String COD_ERROR_DEBE_INGRESAR_RIESGO = "24131";
	public static final String COD_ERROR_DEBE_SELECCIONAR_REASEGURO = "24132";
	public static final String COD_ERROR_DEBE_INGRESAR_NOMBRE_DINAMICA = "24133";
	public static final String COD_ERROR_DEBE_SELECCIONAR_MONEDA = "24134";
	public static final String COD_ERROR_DEBE_SELECCIONAR_SI_AFECTO_IGV = "24135";
	public static final String COD_ERROR_DEBE_SELECCIONAR_SI_AFECTO_DESCUENTO = "24136";
	public static final String COD_ERROR_DEBE_SELECCIONAR_TIPO_DIARIO = "24137";
	public static final String COD_ERROR_DEBE_SELECCIONAR_CODIGO_SOCIO_PRODUCTO = "24138";
	public static final String COD_ERROR_DEBE_SELECCIONAR_CANAL = "24139";
	public static final String COD_ERROR_DEBE_INGRESAR_CENTRO_COSTO = "24140";
	public static final String COD_ERROR_DEBE_SELECCIONAR_ESTADO_DINAMICA = "24141";

	public static final String COD_ERROR_DEBE_EXISTIR_CUENTA_CARGO_ABONO = "24143";
	public static final String COD_ERROR_DEBE_EXISTIR_CUENTA_IGV = "24144";
	public static final String COD_ERROR_DEBE_EXISTIR_CUENTA_DESCUENTO = "24145";
	public static final String COD_ERROR_NOMBRE_DINAMICA_UNICO = "24146";
	public static final String COD_ERROR_EXISTE_DINAMICA_CONTABLE = "24147";
	public static final String COD_ERROR_DEBE_INGRESAR_CUENTAS = "24148";
	public static final String COD_ERROR_SELECT_PERIODO_ANIO_MES = "24149";
	public static final String COD_ERROR_DEBE_SELECCIONAR_DEPENDENCIA = "24150";
	public static final String COD_ERROR_DEBE_SELECCIONAR_DINAMICA_PADRE = "24151";
	public static final String COD_OK_DINAMICA_REGISTRO_EXITOSO = "24152";
	public static final String COD_ERROR_ESTADO_PERIODO_ABIERTO_REABIERTO = "24153";
	public static final String COD_OK_PARAMETRO_OPERACIONES_EXITOSO = "24154";

	public static final String COD_ERROR_CUENTA_CARGO_EXISTE = "24161";
	public static final String COD_ERROR_DEBE_SELECCIONAR_TIPO_CONTRATO = "24163";
	public static final String COD_ERROR_DEBE_SELECCIONAR_ESTADO = "24164";
	public static final String COD_ERROR_DEBE_SELECCIONAR_EMPRESA_CLASIFICADORA = "24165";
	public static final String COD_ERROR_DEBE_SELECCIONAR_CLASIFICACION_RIESGO = "24166";
	public static final String COD_ERROR_DEBE_INGRESAR_FECHA_CLASIF_RIESGO = "24167";
	public static final String COD_ERROR_DEBE_INGRESAR_NUMERO_CONTRATO = "24168";
	public static final String COD_ERROR_DEBE_INGRESAR_FECHA_INICIO_VIGENCIA = "24169";
	public static final String COD_ERROR_DEBE_INGRESAR_FECHA_TERMINO_VIGENCIA = "24170";
	public static final String COD_ERROR_DEBE_INGRESAR_POLIZA = "24171";
	public static final String COD_ERROR_DEBE_INGRESAR_MONEDA_LIMITE_COBERTURA = "24172";
	public static final String COD_ERROR_DEBE_INGRESAR_LIMITE_COBERTURA = "24173";
	public static final String COD_ERROR_DEBE_INGRESAR_PARTICIPACION_CONTRATO = "24174";
	public static final String COD_ERROR_DEBE_INGRESAR_CESION_CUOTA_PARTE = "24175";
	public static final String COD_ERROR_DEBE_INGRESAR_CESION_EXCEDENTE = "24176";
	public static final String COD_ERROR_DEBE_INGRESAR_SUMA_ASEGURADA = "24177";
	public static final String COD_ERROR_VALIDACION_CAMPOS_CESION_PORCENTAJE = "24178";
	public static final String COD_ERROR_VALIDACION_FECHAS_VIGENCIA = "24179";
	public static final String COD_ERROR_FALTA_CONF_PARAMETROS = "24180";
	public static final String COD_ERROR_NO_EXISTE_INFORMACION_PARA_ANIOYTRIMESTRE_SELECCIONADO = "24181";
	public static final String COD_ERROR_SIN_PERMISOS = "24182";
	public static final String COD_ERROR_OK_ENTICUAMIENTO = "24183";
	public static final String COD_ERROR_MONTO_TRANSACCION_ASIENTO = "24184";
	public static final String COD_ERROR_PARAMETRO_OPERACION_EXISTE = "24185";
	public static final String COD_ERROR_MONTOS_ANTICUAMIENTO_NO_CARGADO_PERIODO_OPERATIVO = "24186";
	public static final String COD_ERROR_ELIMINAR_ARCHIVO_PROCESADO = "24187";
	public static final String COD_ERROR_DINAMICA_CONTABLE_INACTIVA = "24188";
	public static final String COD_ERROR_PARTICIPACION_CONTRATO_NO_VALIDO = "24190";
	/** MODULO REASEGUROS-COASEGUROS - FIN */
	
	/** Módulo CPE **/
	public static final String COD_ERROR_ELIMINAR_PROCESO_PREGUNTA = "24201";
	public static final String COD_ERROR_ELIMINAR_PROCESO_CONFIRMACION = "24202";
	public static final String COD_ERROR_MANT_SOCIO_PRODUCTO_BUSQUEDA = "24203";
	public static final String COD_ERROR_MANT_SOCIO_PRODUCTO_PREGUNTA_ELIMINAR = "24204";
	public static final String COD_ERROR_MANT_SOCIO_PRODUCTO_ELIMINAR = "24205";
	public static final String COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS = "24206";
	public static final String COD_ERROR_MANT_SOCIO_PRODUCTO_CONF_EXISTENTE = "24207";
	public static final String COD_ERROR_MANT_SOCIO_PRODUCTO_INSERTAR = "24208";
	public static final String COD_ERROR_MANT_SERIE_CORRELATIVO_NUM_ASIGNADO = "24209";
	public static final String COD_ERROR_MANT_SERIE_CORRELATIVO_CONFIRMAR_INSERTAR = "24210";
	public static final String COD_ERROR_MANT_SERIE_CORRELATIVO_INSERTAR = "24211";
	public static final String COD_ERROR_MANT_PARAM_GENER_REVISAR_VALORES = "24212";
	public static final String COD_ERROR_MANT_PARAM_GENER_CORREO_INVALIDO = "24213";
	public static final String COD_ERROR_MANT_PARAM_GENER_INSERTAR = "24214";
	public static final String COD_ERROR_MANT_SOCIO_PRODUCTO_ACTUALIZAR = "24215";
	public static final String COD_ERROR_CARGA_DEBE_SELECCIONAR_ORIGEN = "24216";
	public static final String COD_ERROR_CARGA_REGISTRADO_SATISFACTORIAMENTO = "24217";
	public static final String COD_ERROR_CARGA_CAMPOS_OBLIGATORIOS = "24218";
	public static final String COD_ERROR_REGISTRO_COMPLETADO_COMPROBANTE_MANUAL = "24223";
	public static final String COD_ERROR_INFO_REGISTRADA_EXITO = "24224";
	public static final String COD_ERROR_VENTA_NO_PENDIENTE = "24226";
	public static final String COD_ERROR_VENTA_SIN_CONF_SOCIO_PRODUCTO = "24227";
	public static final String COD_ERROR_USUARIO_NO_REGISTRA = "24228";
	public static final String COD_ERROR_REGISTRO_EXISTOSO_PROCESO = "24229";
	public static final String COD_ERROR_NO_ELIMINAR_PROCESO = "24230";
	public static final String COD_ERROR_MSJ_MAXIMO_ONLINE = "24235";
	public static final String COD_ERROR_MSJ_PROCESO_MASIVO = "24236";
	public static final String COD_ERROR_MSJ_NO_EXISTEN_REGISTROS_POR_PROCESAR = "24237";
	public static final String COD_ERROR_MSJ_FACTURA_SIN_RUC = "24238";
	public static final String COD_ERROR_MSJ_FALTA_SELECCIONAR_EMPRESA_SOCIO_PRODUCTO_TIPOCOMP = "24239";
	public static final String COD_ERROR_MSJ_NO_EXISTE_CONFIGURACION_SOCIO_PRODUCTO = "24240";
	public static final String COD_ERROR_MSJ_NO_ELIMINAR_SERIE_CORRELATIVO_TIENE_COMPROBANTES_EMITIDOS = "24241";
	public static final String COD_ERROR_MSJ_NO_ELIMINA_VENTA = "24242";
	public static final String COD_ERROR_FORMATO_CORREO_INCORRECTO = "24243";
	public static final String COD_ERROR_NUM_DOC_INCORRECTO = "24244";
	public static final String COD_ERROR_VENTA_SIN_SERIE_CORRELATIVO = "24245";
	public static final String COD_ERROR_MSJ_NCND_REFERENCIA = "24246";
	public static final String COD_ERROR_MSJ_NOMBRE_PROCESO_LARGO = "24247";
	public static final String COD_ERROR_MSJ_LONGITUD_INCORRECTA_NUM_DOC = "24248";
	public static final String COD_ERROR_MSJ_NO_EXISTE_RUTA_CARGA_ARCHIVOS = "24249";
	public static final String COD_ERROR_MSJ_NO_EXISTE_RUTA_TRAMA_SEGUROS = "24250";
	public static final String COD_ERROR_MSJ_NO_EXISTE_RUTA_TRAMA_SERVICIO = "24251";
	public static final String COD_ERROR_MSJ_NO_EXISTE_RUTA_TRAMA_RESPUESTA = "24252";
	public static final String COD_ERROR_MSJ_NO_EXISTE_CONEXION_ESCON= "24253";
	public static final String COD_ERROR_MSJ_PRODUCTO_SUNAT= "24254";
	public static final String COD_ERROR_MSJ_LONGITUD_SERIE = "24255";
	public static final String COD_ERROR_MSJ_NO_ELIMINAR_SOCIO_PRODUCTO_TIENE_COMPROBANTES_EMITIDOS = "24256";
	public static final String COD_ERROR_MSJ_NCND_CONCEPTO = "24257";
	public static final String COD_ERROR_MSJ_MONTOS_VALIDADOS = "24258";
	public static final String COD_ERROR_MSJ_NCND_REFERENCIA_NULL = "24259";
	public static final String COD_ERROR_MSJ_VENTA_MISMA_EMPRESA = "24260";
	public static final String COD_ERROR_MSJ_NO_DOM_COMPROBANTE = "24261";
	public static final String COD_ERROR_MSJ_NO_DOM_INAFECTO_IGV = "24262";
	public static final String COD_ERROR_MSJ_NO_DOM_AFECTO_IGV = "24263";
	public static final String COD_ERROR_MSJ_TRANSF_GRATUITAS = "24264";
	public static final String COD_ERROR_MSJ_TRANSF_GRATUITAS_TOTAL = "24265";
	public static final String COD_ERROR_MSJ_TRANSF_GRATUITAS_TIPO_AFECTACION = "24266";
	public static final String COD_ERROR_MSJ_TRANSF_GRATUITAS_TIPO_AFECT_EXISTE = "24267";
	public static final String COD_ERROR_MSJ_ND_TIPOCOMPROBANTE = "24268";
	public static final String COD_ERROR_MSJ_ND_PENALIDAD_INAFECTO = "24269";
	public static final String COD_ERROR_MSJ_CONFIG_SIN_AFECTOIGV = "24270";
	public static final String COD_ERROR_MSJ_CONFIG_CON_AFECTOIGV = "24271";
	public static final String COD_ERROR_MSJ_NO_DOM_NO_APLICA_BOLETA = "24272";
	/*TIP_PER0100_CC09_13 INICIO 2019/05/15 - 14:53 - Se agrega mensajes de error de validaciones del Layout*/
	public static final String COD_ERROR_MSJ_LONGITUD_CAMPO_MAXIMA_SUPERADA = "24273";
	public static final String COD_ERROR_MSJ_CAMPOS_DEPENDIENTES = "24274";
	public static final String COD_ERROR_MSJ_VALORES_PERMITIDOS_DEL_CAMPO = "24275";
	public static final String COD_ERROR_MSJ_VALOR_CAMPO_NUMERICO_NO_VALIDO = "24276";
	public static final String COD_ERROR_MSJ_CAMPOS_DEPENDIENTES_NO_GUARDAN_RELACION = "24277";
	public static final String COD_ERROR_MSJ_RANGO_VALORES_PERMITIDOS_DEL_CAMPO = "24278";
	public static final String COD_ERROR_MSJ_COD_EMPRESA_NO_APLICA_DETRACCION = "24279";
	/*TIP_PER0100_CC09_13 FIN*/
	
	/**TIP_PER0100_CC14 INICIO 2019/06/17 - 16:15 - Se agrega mensajes de error de validaciones para mantenimiento de Detalle Item de Comprobante*/
	public static final String COD_ERROR_MSJ_CONCEPTO_ITEM_DETALLE_OBLIGATORIO = "24280";
	public static final String COD_ERROR_MSJ_MINIMA_CANTIDAD_Y_SOLO_ENTEROS = "24281";
	public static final String COD_ERROR_MSJ_VALOR_VENTA_DETALLE_NO_MENOR_IGUAL_A_CERO = "24282";
	public static final String COD_ERROR_MSJ_SUMA_VALORES_PRECIO_VENTA_SUPERA_VALOR_VENTA_TOTAL = "24283";
	public static final String COD_ERROR_MSJ_PROBLEMAS_AL_REGISTRAR_LOS_ITEM_DE_DETALLE_DE_COMPROBANTE = "24284";
	public static final String COD_ERROR_MSJ_PROCESO_DE_REGISTROS_ITEM_DE_DETALLE_DE_COMPROBANTE_EXITOSO = "24285";
	public static final String COD_ERROR_MSJ_SUMA_VALORES_PRECIO_VENTA_NO_COINCIDE_VALOR_VENTA_TOTAL = "24286";
	public static final String COD_ERROR_MSJ_NO_SE_HAN_INGRESADO_ITEMS_ASOCIADOS_A_LA_VENTA="24287";
	public static final String COD_ERROR_NO_SE_ENCONTRARON_DATOS_EN_DATAMART="24291";
	public static final String COD_ERROR_LOS_REQUISITOS_MINIMOS_PARA_DATAMART_SON_POLIZA_IDPIMS_Y_NUMDOC="24292";
	public static final String COD_ERROR_NO_EXISTEN_REGISTROS_EN_LISTA_ERRORES="24293";
	/**TIP_PER0100_CC14 FIN*/
	
	/**TIP_PER0100_CC15 INICIO 2019/06/20 - 18:44 - Se agrega mensaje por no existir configuración con prefijo F de aquellos documentos cuyo codReferencia sea 13*/
												 /**Se agrega mensaje de error en caso datos de comprobantes de referencia se ingresen nulos o vacios.*/
												 /**Se agrega mensaje de validación en caso se envíe un número correlativo de referencia menor igual a cero*/
	public static final String COD_ERROR_MSJ_NO_EXISTE_CONF_SOCIO_PRODUCTO_COD_REFERENC_13_PREFIJ_F="24288";
	public static final String COD_ERROR_MSJ_CAMPOS_COMPROBANTES_REFERENCIA_OBLIGATORIOS="24289";
	public static final String COD_ERROR_MSJ_CAMPO_CORRELATIVO_REF_NO_PUEDE_SER_MENOR_IGUAL_CERO="24290";
	/**TIP_PER0100_CC15 INICIO*/
	/** Módulo CPE **/
	
	public static final String COD_ERROR_SERVICIO_AUTENTIFICACION_NO_DISPONIBLE = "24294";
	public static final String COD_ERROR_MSJ_PROCESO_RESUMEN_ENVIADO = "24295";/**TIP_PER0100_FASE02 INICIO-FIN 2019/11/26 - 18:40 - Se agregar Código de mensaje de proceso de resumen enviado .*/

/** Inicio {Automatización de Tesoreria} – {Sprint 1} - {PSS} - {d79986} * ***/
/******* {Carlos Chayguaque} – {25/09/2020} ********/
	public static final String COD_ERROR_FECHA_PERIODO = "24302"; //RCHAVEZ 05-SET-2020
	public static final String COD_ERROR_FECHA_TRANSACCION = "24303"; //RCHAVEZ 05-SET-2020
	public static final String COD_ERROR_TIPO_ASIENTO_PAGO = "24304"; //RCHAVEZ 05-SET-2020
/*** Fin {Automatización de Tesoreria} – {Sprint 1} **/

}