/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class AsientoActuarialBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// GENERAL
	private Long id;
	private String numCtaBanco;
	private String nameCtaBanco;
	private String fecha;
	private String fechaOperacion;
	private String descripcion;
	private String codMovimiento;
	private double importePositivo;
	private double importeNegativo;
	private String referencia;
	private String tipoDiario;
	private Integer numDiario;
	private String cuentaContable;
	private String numRef;
	private String usuarioReg;
	private String fechaRegistra;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumCtaBanco() {
		return numCtaBanco;
	}

	public void setNumCtaBanco(String numCtaBanco) {
		this.numCtaBanco = numCtaBanco;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getFechaOperacion() {
		return fechaOperacion;
	}

	public void setFechaOperacion(String fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCodMovimiento() {
		return codMovimiento;
	}

	public void setCodMovimiento(String codMovimiento) {
		this.codMovimiento = codMovimiento;
	}

	public double getImportePositivo() {
		return importePositivo;
	}

	public void setImportePositivo(double importePositivo) {
		this.importePositivo = importePositivo;
	}

	public double getImporteNegativo() {
		return importeNegativo;
	}

	public void setImporteNegativo(double importeNegativo) {
		this.importeNegativo = importeNegativo;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getTipoDiario() {
		return tipoDiario;
	}

	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}

	public Integer getNumDiario() {
		return numDiario;
	}

	public void setNumDiario(Integer numDiario) {
		this.numDiario = numDiario;
	}

	public String getCuentaContable() {
		return cuentaContable;
	}

	public void setCuentaContable(String cuentaContable) {
		this.cuentaContable = cuentaContable;
	}

	public String getNumRef() {
		return numRef;
	}

	public void setNumRef(String numRef) {
		this.numRef = numRef;
	}

	public String getUsuarioReg() {
		return usuarioReg;
	}

	public void setUsuarioReg(String usuarioReg) {
		this.usuarioReg = usuarioReg;
	}

	public String getFechaRegistra() {
		return fechaRegistra;
	}

	public void setFechaRegistra(String fechaRegistra) {
		this.fechaRegistra = fechaRegistra;
	}

	public String getNameCtaBanco() {
		return nameCtaBanco;
	}

	public void setNameCtaBanco(String nameCtaBanco) {
		this.nameCtaBanco = nameCtaBanco;
	}

	@Override
	public String toString() {
		return "AsientoActuarialBean [id=" + id + ", numCtaBanco=" + numCtaBanco + ", nameCtaBanco=" + nameCtaBanco
				+ ", fecha=" + fecha + ", fechaOperacion=" + fechaOperacion + ", descripcion=" + descripcion
				+ ", codMovimiento=" + codMovimiento + ", importePositivo=" + importePositivo + ", importeNegativo="
				+ importeNegativo + ", referencia=" + referencia + ", tipoDiario=" + tipoDiario + ", numDiario="
				+ numDiario + ", cuentaContable=" + cuentaContable + ", numRef=" + numRef + ", usuarioReg=" + usuarioReg
				+ ", fechaRegistra=" + fechaRegistra + "]";
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/