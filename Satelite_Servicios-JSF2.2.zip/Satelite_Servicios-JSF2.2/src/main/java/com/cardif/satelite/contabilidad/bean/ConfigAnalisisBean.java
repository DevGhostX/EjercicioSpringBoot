/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.util.Date;

public class ConfigAnalisisBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String paramAnalisis;
	private String paramDescripcion;
	private String usuarioRegistra;
	private Date fechaRegistra;
	private String usuarioModifica;
	private Date fechaModifica;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getParamAnalisis() {
		return paramAnalisis;
	}
	public void setParamAnalisis(String paramAnalisis) {
		this.paramAnalisis = paramAnalisis;
	}
	public String getParamDescripcion() {
		return paramDescripcion;
	}
	public void setParamDescripcion(String paramDescripcion) {
		this.paramDescripcion = paramDescripcion;
	}
	public String getUsuarioRegistra() {
		return usuarioRegistra;
	}
	public void setUsuarioRegistra(String usuarioRegistra) {
		this.usuarioRegistra = usuarioRegistra;
	}
	public Date getFechaRegistra() {
		return fechaRegistra;
	}
	public void setFechaRegistra(Date fechaRegistra) {
		this.fechaRegistra = fechaRegistra;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public Date getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
	@Override
	public String toString() {
		return "ConfigAnalisisBean [id=" + id + ", paramAnalisis=" + paramAnalisis + ", paramDescripcion="
				+ paramDescripcion + ", usuarioRegistra=" + usuarioRegistra + ", fechaRegistra=" + fechaRegistra
				+ ", usuarioModifica=" + usuarioModifica + ", fechaModifica=" + fechaModifica + "]";
	}
	
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/