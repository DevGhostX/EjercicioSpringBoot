/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.util.Date;

public class ConfigCuentaContableBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String cuentaContable;
	private String tipoAnalisis;
	private Integer idProducto;
	private String codProducto;
	private String descProducto;
	private String moneda;
	private String minCuenta;
	private String maxCuenta;
	private Integer idAnalisis;
	private String codAnalisis;
	private String descAnalisis;
	private String usuarioRegistra;
	private Date fechaRegistra;
	private String usuarioModifica;
	private Date fechaModifica;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCuentaContable() {
		return cuentaContable;
	}
	public void setCuentaContable(String cuentaContable) {
		this.cuentaContable = cuentaContable;
	}
	public String getTipoAnalisis() {
		return tipoAnalisis;
	}
	public void setTipoAnalisis(String tipoAnalisis) {
		this.tipoAnalisis = tipoAnalisis;
	}
	public String getUsuarioRegistra() {
		return usuarioRegistra;
	}
	public void setUsuarioRegistra(String usuarioRegistra) {
		this.usuarioRegistra = usuarioRegistra;
	}
	public Date getFechaRegistra() {
		return fechaRegistra;
	}
	public void setFechaRegistra(Date fechaRegistra) {
		this.fechaRegistra = fechaRegistra;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public Date getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
	public Integer getIdProducto() {
		return idProducto;
	}
	public void setIdProducto(Integer idProducto) {
		this.idProducto = idProducto;
	}
	public String getCodProducto() {
		return codProducto;
	}
	public void setCodProducto(String codProducto) {
		this.codProducto = codProducto;
	}
	public String getDescProducto() {
		return descProducto;
	}
	public void setDescProducto(String descProducto) {
		this.descProducto = descProducto;
	}
	public Integer getIdAnalisis() {
		return idAnalisis;
	}
	public void setIdAnalisis(Integer idAnalisis) {
		this.idAnalisis = idAnalisis;
	}
	public String getCodAnalisis() {
		return codAnalisis;
	}
	public void setCodAnalisis(String codAnalisis) {
		this.codAnalisis = codAnalisis;
	}
	public String getDescAnalisis() {
		return descAnalisis;
	}
	public void setDescAnalisis(String descAnalisis) {
		this.descAnalisis = descAnalisis;
	}
	
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getMinCuenta() {
		return minCuenta;
	}
	public void setMinCuenta(String minCuenta) {
		this.minCuenta = minCuenta;
	}
	public String getMaxCuenta() {
		return maxCuenta;
	}
	public void setMaxCuenta(String maxCuenta) {
		this.maxCuenta = maxCuenta;
	}
	
	@Override
	public String toString() {
		return "ConfigCuentaContableBean [id=" + id + ", cuentaContable=" + cuentaContable + ", tipoAnalisis="
				+ tipoAnalisis + ", idProducto=" + idProducto + ", codProducto=" + codProducto + ", descProducto="
				+ descProducto + ", moneda=" + moneda + ", minCuenta=" + minCuenta + ", maxCuenta=" + maxCuenta
				+ ", idAnalisis=" + idAnalisis + ", codAnalisis=" + codAnalisis + ", descAnalisis=" + descAnalisis
				+ ", usuarioRegistra=" + usuarioRegistra + ", fechaRegistra=" + fechaRegistra + ", usuarioModifica="
				+ usuarioModifica + ", fechaModifica=" + fechaModifica + "]";
	}
	
	/*@Override
	public String toString() {
		return "ConfigCuentaContableBean [id=" + id + ", cuentaContable=" + cuentaContable + ", tipoAnalisis="
				+ tipoAnalisis + ", idProducto=" + idProducto + ", idAnalisis=" + idAnalisis + ", usuarioRegistra="
				+ usuarioRegistra + ", fechaRegistra=" + fechaRegistra + ", usuarioModifica=" + usuarioModifica
				+ ", fechaModifica=" + fechaModifica + "]";
	}*/

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/