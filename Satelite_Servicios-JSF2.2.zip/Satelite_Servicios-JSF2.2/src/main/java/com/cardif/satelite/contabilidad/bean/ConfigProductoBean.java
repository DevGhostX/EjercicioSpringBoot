/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.util.Date;

public class ConfigProductoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String prodCodigo;
	private String prodDescripcion;
	private String prodMoneda;
	private String prodCodEquivalente;
	private String usuarioRegistra;
	private Date fechaRegistra;
	private String usuarioModifica;
	private Date fechaModifica;
	
	public String getProdCodigo() {
		return prodCodigo;
	}
	public void setProdCodigo(String prodCodigo) {
		this.prodCodigo = prodCodigo;
	}
	public String getProdDescripcion() {
		return prodDescripcion;
	}
	public void setProdDescripcion(String prodDescripcion) {
		this.prodDescripcion = prodDescripcion;
	}
	public String getProdMoneda() {
		return prodMoneda;
	}
	public void setProdMoneda(String prodMoneda) {
		this.prodMoneda = prodMoneda;
	}
	public String getProdCodEquivalente() {
		return prodCodEquivalente;
	}
	public void setProdCodEquivalente(String prodCodEquivalente) {
		this.prodCodEquivalente = prodCodEquivalente;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsuarioRegistra() {
		return usuarioRegistra;
	}
	public void setUsuarioRegistra(String usuarioRegistra) {
		this.usuarioRegistra = usuarioRegistra;
	}
	public Date getFechaRegistra() {
		return fechaRegistra;
	}
	public void setFechaRegistra(Date fechaRegistra) {
		this.fechaRegistra = fechaRegistra;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public Date getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
	@Override
	public String toString() {
		return "ConfigProductoBean [id=" + id + ", prodCodigo=" + prodCodigo + ", prodDescripcion=" + prodDescripcion
				+ ", prodMoneda=" + prodMoneda + ", prodCodEquivalente=" + prodCodEquivalente + ", usuarioRegistra="
				+ usuarioRegistra + ", fechaRegistra=" + fechaRegistra + ", usuarioModifica=" + usuarioModifica
				+ ", fechaModifica=" + fechaModifica + "]";
	}
		
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/