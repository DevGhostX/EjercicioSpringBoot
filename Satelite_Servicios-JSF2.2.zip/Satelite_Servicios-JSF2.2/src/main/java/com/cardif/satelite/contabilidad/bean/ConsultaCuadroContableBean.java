/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.util.Date;

public class ConsultaCuadroContableBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer idConsulta;
	private Integer idProceso;
	private String tipoDiario;
	private String numDiario;
	private String cuentaContable;
	private String referencia;
	private String descripcion;
	private String marcadorDc;
	private String moneda;
	private double importeSoles;
	private double importeTrans;
	private String usuario;
	private Date fechaCreacion;
	
	public Integer getIdConsulta() {
		return idConsulta;
	}
	public void setIdConsulta(Integer idConsulta) {
		this.idConsulta = idConsulta;
	}
	public Integer getIdProceso() {
		return idProceso;
	}
	public void setIdProceso(Integer idProceso) {
		this.idProceso = idProceso;
	}
	public String getTipoDiario() {
		return tipoDiario;
	}
	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}
	public String getNumDiario() {
		return numDiario;
	}
	public void setNumDiario(String numDiario) {
		this.numDiario = numDiario;
	}
	public String getCuentaContable() {
		return cuentaContable;
	}
	public void setCuentaContable(String cuentaContable) {
		this.cuentaContable = cuentaContable;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getMarcadorDc() {
		return marcadorDc;
	}
	public void setMarcadorDc(String marcadorDc) {
		this.marcadorDc = marcadorDc;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public double getImporteSoles() {
		return importeSoles;
	}
	public void setImporteSoles(double importeSoles) {
		this.importeSoles = importeSoles;
	}
	public double getImporteTrans() {
		return importeTrans;
	}
	public void setImporteTrans(double importeTrans) {
		this.importeTrans = importeTrans;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	
	@Override
	public String toString() {
		return "ConsultaCuadroContableBean [idConsulta=" + idConsulta + ", idProceso=" + idProceso + ", tipoDiario="
				+ tipoDiario + ", numDiario=" + numDiario + ", cuentaContable=" + cuentaContable + ", referencia="
				+ referencia + ", descripcion=" + descripcion + ", marcadorDc=" + marcadorDc + ", moneda=" + moneda
				+ ", importeSoles=" + importeSoles + ", importeTrans=" + importeTrans + ", usuario="
				+ usuario + ", fechaCreacion=" + fechaCreacion + "]";
	}
	
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/