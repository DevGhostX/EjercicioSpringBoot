/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;

public class CuadroContableBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer idProceso;
	private String codProducto;
	private String codAnalisis;
	private String cuentaContable;
	private String descripcion;
	private String moneda;
	private double impTransaccion;
	private double impBase;
	private double impEstimaciones;
	private double impReservas;
	private double impTotales;
	private double impDiferencias;
	
	public Integer getIdProceso() {
		return idProceso;
	}
	public void setIdProceso(Integer idProceso) {
		this.idProceso = idProceso;
	}
	public String getCodProducto() {
		return codProducto;
	}
	public void setCodProducto(String codProducto) {
		this.codProducto = codProducto;
	}
	public String getCuentaContable() {
		return cuentaContable;
	}
	public void setCuentaContable(String cuentaContable) {
		this.cuentaContable = cuentaContable;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public double getImpTransaccion() {
		return impTransaccion;
	}
	public void setImpTransaccion(double impTransaccion) {
		this.impTransaccion = impTransaccion;
	}
	public double getImpBase() {
		return impBase;
	}
	public void setImpBase(double impBase) {
		this.impBase = impBase;
	}
	public double getImpEstimaciones() {
		return impEstimaciones;
	}
	public void setImpEstimaciones(double impEstimaciones) {
		this.impEstimaciones = impEstimaciones;
	}
	public double getImpReservas() {
		return impReservas;
	}
	public void setImpReservas(double impReservas) {
		this.impReservas = impReservas;
	}
	public double getImpTotales() {
		return impTotales;
	}
	public void setImpTotales(double impTotales) {
		this.impTotales = impTotales;
	}
	public double getImpDiferencias() {
		return impDiferencias;
	}
	public void setImpDiferencias(double impDiferencias) {
		this.impDiferencias = impDiferencias;
	}
	public String getCodAnalisis() {
		return codAnalisis;
	}
	public void setCodAnalisis(String codAnalisis) {
		this.codAnalisis = codAnalisis;
	}
	@Override
	public String toString() {
		return "CuadroContableBean [idProceso=" + idProceso + ", codProducto=" + codProducto + ", codAnalisis="
				+ codAnalisis + ", cuentaContable=" + cuentaContable + ", descripcion=" + descripcion + ", moneda="
				+ moneda + ", impTransaccion=" + impTransaccion + ", impBase=" + impBase + ", impEstimaciones="
				+ impEstimaciones + ", impReservas=" + impReservas + ", impTotales=" + impTotales + ", impDiferencias="
				+ impDiferencias + "]";
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/