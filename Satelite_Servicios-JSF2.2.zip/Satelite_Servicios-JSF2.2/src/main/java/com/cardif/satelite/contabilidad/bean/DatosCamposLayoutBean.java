/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.util.Date;

public class DatosCamposLayoutBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer idCarga;
	private Integer idProceso;
	private String codProducto;
	private String moneda;
	private String socio;
	private String nomProducto;
	private String codResumen;
	private double rrc;
	private double ingresosDiferidos;
	private double rmat;
	private double pendientes;
	private double ibnr;
	private double comDiferidos;
	private double def;
	private double pendientesCedidos;
	private double ibnrCedidos;
	private double rrcCedidos;
	private double rmatCedidos;
	private double gasDir;
	private double gasInDir;
	private double defCobrar;
	private String tipoCarga;
	private Date fechaCarga;
	private String usuario;
	
	public Integer getIdCarga() {
		return idCarga;
	}
	public void setIdCarga(Integer idCarga) {
		this.idCarga = idCarga;
	}
	public String getTipoCarga() {
		return tipoCarga;
	}
	public void setTipoCarga(String tipoCarga) {
		this.tipoCarga = tipoCarga;
	}
	public Date getFechaCarga() {
		return fechaCarga;
	}
	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getCodProducto() {
		return codProducto;
	}
	public void setCodProducto(String codProducto) {
		this.codProducto = codProducto;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getSocio() {
		return socio;
	}
	public void setSocio(String socio) {
		this.socio = socio;
	}
	public String getNomProducto() {
		return nomProducto;
	}
	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}
	public String getCodResumen() {
		return codResumen;
	}
	public void setCodResumen(String codResumen) {
		this.codResumen = codResumen;
	}
	public double getRrc() {
		return rrc;
	}
	public void setRrc(double rrc) {
		this.rrc = rrc;
	}
	public double getIngresosDiferidos() {
		return ingresosDiferidos;
	}
	public void setIngresosDiferidos(double ingresosDiferidos) {
		this.ingresosDiferidos = ingresosDiferidos;
	}
	public double getRmat() {
		return rmat;
	}
	public void setRmat(double rmat) {
		this.rmat = rmat;
	}
	public double getPendientes() {
		return pendientes;
	}
	public void setPendientes(double pendientes) {
		this.pendientes = pendientes;
	}
	public double getIbnr() {
		return ibnr;
	}
	public void setIbnr(double ibnr) {
		this.ibnr = ibnr;
	}
	public double getComDiferidos() {
		return comDiferidos;
	}
	public void setComDiferidos(double comDiferidos) {
		this.comDiferidos = comDiferidos;
	}
	public double getDef() {
		return def;
	}
	public void setDef(double def) {
		this.def = def;
	}
	public double getPendientesCedidos() {
		return pendientesCedidos;
	}
	public void setPendientesCedidos(double pendientesCedidos) {
		this.pendientesCedidos = pendientesCedidos;
	}
	public double getIbnrCedidos() {
		return ibnrCedidos;
	}
	public void setIbnrCedidos(double ibnrCedidos) {
		this.ibnrCedidos = ibnrCedidos;
	}
	public double getRrcCedidos() {
		return rrcCedidos;
	}
	public void setRrcCedidos(double rrcCedidos) {
		this.rrcCedidos = rrcCedidos;
	}
	public double getRmatCedidos() {
		return rmatCedidos;
	}
	public void setRmatCedidos(double rmatCedidos) {
		this.rmatCedidos = rmatCedidos;
	}
	public double getGasDir() {
		return gasDir;
	}
	public void setGasDir(double gasDir) {
		this.gasDir = gasDir;
	}
	public double getGasInDir() {
		return gasInDir;
	}
	public void setGasInDir(double gasInDir) {
		this.gasInDir = gasInDir;
	}
	public double getDefCobrar() {
		return defCobrar;
	}
	public void setDefCobrar(double defCobrar) {
		this.defCobrar = defCobrar;
	}
	public Integer getIdProceso() {
		return idProceso;
	}
	public void setIdProceso(Integer idProceso) {
		this.idProceso = idProceso;
	}
	
	@Override
	public String toString() {
		return "DatosCamposLayoutBean [idCarga=" + idCarga + ", idProceso=" + idProceso + ", codProducto=" + codProducto
				+ ", moneda=" + moneda + ", socio=" + socio + ", nomProducto=" + nomProducto + ", codResumen="
				+ codResumen + ", rrc=" + rrc + ", ingresosDiferidos=" + ingresosDiferidos + ", rmat=" + rmat
				+ ", pendientes=" + pendientes + ", ibnr=" + ibnr + ", comDiferidos=" + comDiferidos + ", def=" + def
				+ ", pendientesCedidos=" + pendientesCedidos + ", ibnrCedidos=" + ibnrCedidos + ", rrcCedidos="
				+ rrcCedidos + ", rmatCedidos=" + rmatCedidos + ", gasDir=" + gasDir + ", gasInDir=" + gasInDir
				+ ", defCobrar=" + defCobrar + ", tipoCarga=" + tipoCarga + ", fechaCarga=" + fechaCarga + ", usuario="
				+ usuario + "]";
	}
	
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/