/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.util.Date;

public class ProcesoCuadroContableBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer idProceso;
	private String nombreProceso;
	private String periodo;
	private String usuarioRegistro;
	private Date fechaCreacion;
	private String tipoCarga;
	private String estado;
	
	public Integer getIdProceso() {
		return idProceso;
	}
	public void setIdProceso(Integer idProceso) {
		this.idProceso = idProceso;
	}
	public String getNombreProceso() {
		return nombreProceso;
	}
	public void setNombreProceso(String nombreProceso) {
		this.nombreProceso = nombreProceso;
	}
	public String getUsuarioRegistro() {
		return usuarioRegistro;
	}
	public void setUsuarioRegistro(String usuarioRegistro) {
		this.usuarioRegistro = usuarioRegistro;
	}
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public String getPeriodo() {
		return periodo;
	}
	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}
	public String getTipoCarga() {
		return tipoCarga;
	}
	public void setTipoCarga(String tipoCarga) {
		this.tipoCarga = tipoCarga;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	@Override
	public String toString() {
		return "ProcesoCuadroContableBean [idProceso=" + idProceso + ", nombreProceso=" + nombreProceso + ", periodo="
				+ periodo + ", usuarioRegistro=" + usuarioRegistro + ", fechaCreacion=" + fechaCreacion + ", tipoCarga="
				+ tipoCarga + ", estado=" + estado + "]";
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/