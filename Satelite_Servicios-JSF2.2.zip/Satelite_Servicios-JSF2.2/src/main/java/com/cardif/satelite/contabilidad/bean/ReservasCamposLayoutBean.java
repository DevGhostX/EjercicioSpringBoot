/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ReservasCamposLayoutBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer idCarga;
	private String periodoContable;
	private Date fechaTransaccion;
	private String tipoDiario;
	private String nombreHoja;
	private String codigoCuenta;
	private String nombreCuenta;
	private double importeTransaccion;
	private double importeTransaccionN;
	private String codigoMoneda;
	private String refTransaccion;
	private String descripcion;
	private String centroCosto;
	private String socioProducto;
	private String canal;
	private String proveedorEmpleado;
	private String documentoCliente;
	private String polizaCliente;
	private String inversiones;
	private String nroSiniestro;
	private String tipoCdpSunat;
	private String medioPago;
	private String indicadorActivo;
	private String codigoActivo;
	private String tasaBase;
	private String nroRetDet;
	private String layout;
	private Date fechaCarga;
	private String usuario;
	
	public String getPeriodoContable() {
		return periodoContable;
	}
	public void setPeriodoContable(String periodoContable) {
		this.periodoContable = periodoContable;
	}
	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}
	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}
	public String getTipoDiario() {
		return tipoDiario;
	}
	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}
	public String getCodigoCuenta() {
		return codigoCuenta;
	}
	public void setCodigoCuenta(String codigoCuenta) {
		this.codigoCuenta = codigoCuenta;
	}
	public String getNombreCuenta() {
		return nombreCuenta;
	}
	public void setNombreCuenta(String nombreCuenta) {
		this.nombreCuenta = nombreCuenta;
	}
	public double getImporteTransaccion() {
		return importeTransaccion;
	}
	public void setImporteTransaccion(double importeTransaccion) {
		this.importeTransaccion = importeTransaccion;
	}
	public String getCodigoMoneda() {
		return codigoMoneda;
	}
	public void setCodigoMoneda(String codigoMoneda) {
		this.codigoMoneda = codigoMoneda;
	}
	public String getRefTransaccion() {
		return refTransaccion;
	}
	public void setRefTransaccion(String refTransaccion) {
		this.refTransaccion = refTransaccion;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getCentroCosto() {
		return centroCosto;
	}
	public void setCentroCosto(String centroCosto) {
		this.centroCosto = centroCosto;
	}
	public String getSocioProducto() {
		return socioProducto;
	}
	public void setSocioProducto(String socioProducto) {
		this.socioProducto = socioProducto;
	}
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}
	public String getProveedorEmpleado() {
		return proveedorEmpleado;
	}
	public void setProveedorEmpleado(String proveedorEmpleado) {
		this.proveedorEmpleado = proveedorEmpleado;
	}
	public String getDocumentoCliente() {
		return documentoCliente;
	}
	public void setDocumentoCliente(String documentoCliente) {
		this.documentoCliente = documentoCliente;
	}
	public String getPolizaCliente() {
		return polizaCliente;
	}
	public void setPolizaCliente(String polizaCliente) {
		this.polizaCliente = polizaCliente;
	}
	public String getInversiones() {
		return inversiones;
	}
	public void setInversiones(String inversiones) {
		this.inversiones = inversiones;
	}
	public String getNroSiniestro() {
		return nroSiniestro;
	}
	public void setNroSiniestro(String nroSiniestro) {
		this.nroSiniestro = nroSiniestro;
	}
	public String getTipoCdpSunat() {
		return tipoCdpSunat;
	}
	public void setTipoCdpSunat(String tipoCdpSunat) {
		this.tipoCdpSunat = tipoCdpSunat;
	}
	public String getMedioPago() {
		return medioPago;
	}
	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}
	public String getIndicadorActivo() {
		return indicadorActivo;
	}
	public void setIndicadorActivo(String indicadorActivo) {
		this.indicadorActivo = indicadorActivo;
	}
	public String getCodigoActivo() {
		return codigoActivo;
	}
	public void setCodigoActivo(String codigoActivo) {
		this.codigoActivo = codigoActivo;
	}
	public String getTasaBase() {
		return tasaBase;
	}
	public void setTasaBase(String tasaBase) {
		this.tasaBase = tasaBase;
	}
	public String getNroRetDet() {
		return nroRetDet;
	}
	public void setNroRetDet(String nroRetDet) {
		this.nroRetDet = nroRetDet;
	}
	public String getLayout() {
		return layout;
	}
	public void setLayout(String layout) {
		this.layout = layout;
	}
	public Date getFechaCarga() {
		return fechaCarga;
	}
	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	public String getNombreHoja() {
		return nombreHoja;
	}
	public void setNombreHoja(String nombreHoja) {
		this.nombreHoja = nombreHoja;
	}
	
	public Integer getIdCarga() {
		return idCarga;
	}
	public void setIdCarga(Integer idCarga) {
		this.idCarga = idCarga;
	}
	
	public double getImporteTransaccionN() {
		return importeTransaccionN;
	}
	public void setImporteTransaccionN(double importeTransaccionN) {
		this.importeTransaccionN = importeTransaccionN;
	}
	@Override
	public String toString() {
		return "ReservasCamposLayoutBean [idCarga=" + idCarga + ", periodoContable=" + periodoContable
				+ ", fechaTransaccion=" + fechaTransaccion + ", tipoDiario=" + tipoDiario + ", nombreHoja=" + nombreHoja
				+ ", codigoCuenta=" + codigoCuenta + ", nombreCuenta=" + nombreCuenta + ", importeTransaccion="
				+ importeTransaccion + ", importeTransaccionN=" + importeTransaccionN + ", codigoMoneda=" + codigoMoneda
				+ ", refTransaccion=" + refTransaccion + ", descripcion=" + descripcion + ", centroCosto=" + centroCosto
				+ ", socioProducto=" + socioProducto + ", canal=" + canal + ", proveedorEmpleado=" + proveedorEmpleado
				+ ", documentoCliente=" + documentoCliente + ", polizaCliente=" + polizaCliente + ", inversiones="
				+ inversiones + ", nroSiniestro=" + nroSiniestro + ", tipoCdpSunat=" + tipoCdpSunat + ", medioPago="
				+ medioPago + ", indicadorActivo=" + indicadorActivo + ", codigoActivo=" + codigoActivo + ", tasaBase="
				+ tasaBase + ", nroRetDet=" + nroRetDet + ", layout=" + layout + ", fechaCarga=" + fechaCarga
				+ ", usuario=" + usuario + "]";
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/