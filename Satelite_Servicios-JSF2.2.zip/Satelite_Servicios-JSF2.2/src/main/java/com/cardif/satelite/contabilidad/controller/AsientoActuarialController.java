/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.controller;

import java.io.File;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.xml.ws.soap.SOAPFaultException;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.model.UploadedFile;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;
import com.cardif.satelite.tesoreria.bean.ResultadoErroresContable;
import com.cardif.satelite.tesoreria.service.ProcesoPagos;
import com.cardif.satelite.contabilidad.service.AsientosActuarialService;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;
import com.cardif.sunsystems.bean.AsientoContableBean;
import com.cardif.sunsystems.controller.SunsystemsController;
import com.cardif.sunsystems.util.ConstantesSun;
import com.cardif.sunsystems.util.Utilidades;

@Controller("asientoActuarialController")
@Scope("session")
public class AsientoActuarialController implements Serializable {
	
	private static final long serialVersionUID = -8323560799344065774L;

	public static final Logger LOGGER = Logger.getLogger(AsientoActuarialController.class);
	
	@Autowired(required = true)
	private ParametroService parametroService;
	
	@Autowired(required = true)
	private ProcesoPagos procesoPagos;
	
	@Autowired
	private AsientosActuarialService asientosActuarialService;
	
	private List<ReservasCamposLayoutBean> listaAsientos;
	private List<AsientoContableBean> resultadoContable;
	private List<ResultadoErroresContable> resultadoErroresContable;
	private List<ResultadoErroresContable> resultadoCorrectosContable;
	private List<ResultadoErroresContable> listaCorrectosAsientoContable;
	private boolean pasoValidaciones;
	private String outText = "";
	private boolean success = false;
	private String tipoDiario;
	private List<SelectItem> tiposDiarioItems;
	
	private UploadedFile archivoR;
	private String nombreArchivoR;
	private String mensajeValidacionUploadFileR;
	private String idFileUploadComponentR;
	
	private File archivoD;
	private String nombreArchivoD;
	private String mensajeValidacionUploadFileD;
	private String idFileUploadComponentD;
	
	private SunsystemsController controlSun = SunsystemsController.getInstance();
	
	private String valEuroSoles;
	private String valDolarSoles;
	private String valEuroDolares;

	private SimpleDateFormat fm = null;
	private SimpleDateFormat fmPeriodo = null;
	private SimpleDateFormat fmSUN = null;
	
	private String codMoneda;
	private String desMoneda;
	private String tipoMedioPago = "";
	private int sumaLineaAsientosErrores = 0;
	private int contAsientosContablesGenerados = 0;
	private int contVacios = -1;
	private int sumaLineaAsientos = 0;
	private String tipoPago;
	
	Utilidades utiles = null;
	
	private AsientoContableBean asientoSeleccionado;
	private boolean disabledCarga;
	private boolean disabledTipoDiario;
	private boolean disabledProceso;
	private boolean disabledLimpiar;
	private boolean disabledSun;
	private List<Parametro> listaMoneda;
	
	private int totalRegistrosFiltro;
	private String totalImporteHaber;
	private String totalImporteDebe;
	private String periodoCarga;
	
	@PostConstruct
	public String inicio() {
		try {
			disabledCarga = true;
			disabledProceso = true;
			disabledSun = true;
			disabledLimpiar = true;
			tipoDiario = "*";
			listaAsientos = new ArrayList<ReservasCamposLayoutBean>();
			resultadoContable = new ArrayList<AsientoContableBean>();
			asientoSeleccionado = new AsientoContableBean();
			listaMoneda = parametroService.buscar(Constantes.COD_PARAM_MONEDA, Constantes.TIP_PARAM_DETALLE);
			
			tiposDiarioItems = new ArrayList<SelectItem>();
			tiposDiarioItems.add(new SelectItem("*", "Seleccionar Tipo Diario..."));
			tiposDiarioItems = obtenerTiposDiario();
			
			if (resultadoContable != null) {
				resultadoContable.clear();
			}
			
			periodoCarga = null;
			fmSUN = new SimpleDateFormat(ConstantesSun.UTL_FORMATO_FECHA_SUNSYSTEMS);
			fm = new SimpleDateFormat("dd/MM/yyyy");
			fmPeriodo = new SimpleDateFormat("MMyyyy");
			actualizarTiposCambio(new Date()); // Obtener tipos de cambio de SUN
			
			deshabilitarObjetos(false, true, true, true, true);
			//
		} catch (SyncconException e) {
			LOGGER.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			LOGGER.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			LOGGER.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			LOGGER.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		return null;
	}
	
	public void deshabilitarObjetos(boolean disabledCarga, boolean disabledProceso, boolean disabledSun, boolean disabledTipoDiario, boolean disabledLimpiar) {
		this.disabledCarga = disabledCarga;
		this.disabledProceso = disabledProceso;
		this.disabledSun = disabledSun;
		this.disabledTipoDiario = disabledTipoDiario;
		this.disabledLimpiar = disabledLimpiar;
	}
	
	public void editarAsiento() {
		try {
			BigDecimal tipoCambioDolSol;
			BigDecimal importeDol;
			List<AsientoContableBean> resultadoContableTmp = new ArrayList<AsientoContableBean>();
			for(AsientoContableBean asiento:resultadoContable) {
				if(asiento.getIdAsiento() == asientoSeleccionado.getIdAsiento()) {
					asiento.setGlosa(asientoSeleccionado.getGlosa());
					asiento.setReferencia(asientoSeleccionado.getReferencia());
					asiento.setImporteSoles(asientoSeleccionado.getImporteSoles());
					if (!(valDolarSoles.isEmpty())) {
						tipoCambioDolSol = new BigDecimal(valDolarSoles);
						if(tipoCambioDolSol.doubleValue()==0) importeDol = new BigDecimal(0);
						else importeDol = Utilidades.redondear(2, asientoSeleccionado.getImporteSoles().divide(tipoCambioDolSol, RoundingMode.HALF_UP));
					} else {
						importeDol = new BigDecimal(0);
					}
					asiento.setImporteTransaccion(importeDol);
					asiento.setSocioProducto(asientoSeleccionado.getSocioProducto());
					if (Math.signum(asientoSeleccionado.getImporteSoles().doubleValue()) > 0) {
						asiento.setMarcadorDC(Constantes.MARCADOR_D);
					} else {
						asiento.setMarcadorDC(Constantes.MARCADOR_C);
					}
					asiento.setImporteTransaccion(asientoSeleccionado.getImporteTransaccion());
					resultadoContableTmp.add(asiento);
				}else {
					resultadoContableTmp.add(asiento);
				}
			}
			resultadoContable = resultadoContableTmp;
			asientosActuarialService.actualizarAsiento(asientoSeleccionado);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private List<SelectItem> obtenerTiposDiario() throws Exception {
		List<Parametro> tiposDiario = parametroService.buscarTipoDiario(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE);
		if (tiposDiario != null && tiposDiario.size() > 0) {
			for (Parametro p : tiposDiario) {
				tiposDiarioItems.add(new SelectItem(p.getCodValor(), p.getCodValor()));
			}
		}
		return tiposDiarioItems;
	}
	
	public String validarLayoutReserva(FileUploadEvent event) {
		String respuesta = null;
		try {
			
			//System.out.println("tipoDiario: "+tipoDiario);
			// Validar layout
			mensajeValidacionUploadFileR = "";
			//archivoR = event.getUploadItem().getFile();
			archivoR = event.getUploadedFile();
			//nombreArchivoR = event.getUploadItem().getFileName();
			nombreArchivoR = archivoR.getName();
			
			List<Parametro> parametro = parametroService.buscar(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE);
			//if(!tipoDiario.equals(Constantes.CONTA_RESERVA_DIARIO_DEFAULT))  parametro = parametroService.buscarValor(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE, tipoDiario);
			//System.out.println("cantidad de hojas: "+parametro.size());
			
			for(Parametro prm:parametro) {
				mensajeValidacionUploadFileR = asientosActuarialService.validarReservasCamposLayout(archivoR, nombreArchivoR, prm);
				if (mensajeValidacionUploadFileR != null) {
					clearUploadR();
					FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, mensajeValidacionUploadFileR, null);
					return null;
				} else {
					mensajeValidacionUploadFileR = null;
				}
			}
			deshabilitarObjetos(false,false,true,false,false);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			mensajeValidacionUploadFileR = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_CARGA_EXCEL);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
			clearUploadR();
		}
		return respuesta;
	}
	
	public String clearUploadR() {
		String respuesta = null;
		try {
			if (archivoR != null) {
				//if (archivoR.exists()) {
					archivoR.delete();
				//}
				archivoR = null;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	/** Mostrar mensaje de validacion al completar la carga del layout */
	public String mostrarMensajeUploadFileR() {
		String respuesta = null;
		try {
			if (mensajeValidacionUploadFileR != null) {
				clearUploadR();
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO, mensajeValidacionUploadFileR);
				mensajeValidacionUploadFileR = null;
				idFileUploadComponentR = "uploaderR";
			} else {
				idFileUploadComponentR = "txtHidden";
				deshabilitarObjetos(false,false,true,false,false);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	/** Limpia los valores del formulario */
	public void limpiarFormularioTotal() {
		if(periodoCarga!=null) {
			ReservasCamposLayoutBean reserva = new ReservasCamposLayoutBean();
			reserva.setPeriodoContable(periodoCarga);
			asientosActuarialService.borrarReservas(reserva);
		}
		limpiarFormularioR();
	}
	
	public String volverProcesar() {
		String respuesta = null;
		try {
			// Inicializar variables
			tipoDiario = "*";
			if (resultadoContable != null) {
				resultadoContable.clear();
			}
			totalRegistrosFiltro = 0;
			totalImporteHaber = "";
			totalImporteDebe = "";
			deshabilitarObjetos(false,false,true,false,false);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String limpiarFormularioR() {
		String respuesta = null;
		try {
			// Inicializar variables
			archivoR = null;
			tipoDiario = "*";
			if (resultadoContable != null) {
				resultadoContable.clear();
			}
			totalRegistrosFiltro = 0;
			totalImporteHaber = "";
			totalImporteDebe = "";
			if(periodoCarga!=null) periodoCarga = null;
			deshabilitarObjetos(false,true,true,true,true);

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	/** Validar formulario */
	private void validarFormularioR() throws SyncconException {

		// Validar que se haya cargado archivo
		if (archivoR == null) {
			throw new SyncconException(ErrorConstants.COD_ERROR_CARGAR_LAYOUT, FacesMessage.SEVERITY_INFO);
		}
	}
	
	/** Genera los asientos para el envio a SUN */
	public String generaAsientoActuarial() {
		String respuesta = null;
		try {
			// Validar formulario
			validarFormularioR();
			
			if(tipoDiario.equals("*")) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Seleccionar un Tipo Diario");
			}else {
				// Leer archivo layout
				List<ReservasCamposLayoutBean> listaIni = new ArrayList<ReservasCamposLayoutBean>();
				List<ReservasCamposLayoutBean> listaFin = new ArrayList<ReservasCamposLayoutBean>();
				List<Parametro> parametro = parametroService.buscar(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE);
				if(!tipoDiario.equals(Constantes.CONTA_RESERVA_DIARIO_DEFAULT))  parametro = parametroService.buscarValor(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE, tipoDiario);
				//System.out.println("cantidad de hojas: "+parametro.size());
				
				resultadoContable = new ArrayList<AsientoContableBean>();
				
				/* valida tipo diario y periodo*/
				/*periodoCarga = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(Constantes.KEY_LIST_RESERVAS_XLSX+"_"+String.valueOf(parametro.get(0).getNumOrden())).toString();
				ReservasCamposLayoutBean reserva = new ReservasCamposLayoutBean();
				reserva.setTipoDiario(tipoDiario);
				reserva.setPeriodoContable(periodoCarga);
				if(asientosActuarialService.validarExisteCargaReserva(reserva)>0) {
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "El tipo Diario: "+tipoDiario+", ya fue registrado para el periodo: "+periodoCarga);
				}else {*/
				
					for(Parametro prm:parametro) {
						//lista = asientosActuarialService.leerReservasLayout(archivoR, nombreArchivoR, prm);
						listaIni = FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
								.get(Constantes.KEY_LIST_RESERVAS_XLSX+"_"+String.valueOf(prm.getNumOrden())) == null ? asientosActuarialService.leerReservasLayout(archivoR, nombreArchivoR, prm) 
										: (List<ReservasCamposLayoutBean>) FacesContext.getCurrentInstance()
											.getExternalContext().getSessionMap().get(Constantes.KEY_LIST_RESERVAS_XLSX+"_"+String.valueOf(prm.getNumOrden()));
						
						if(listaIni!=null) {
							if(listaIni.size()>0) {
								listaFin = asientosActuarialService.insertarReservas(listaIni); // registra carga de reservas en BD
							}
						}
						
						// Generar asientos contables
						if (mensajeValidacionUploadFileR == null) {
							if(listaFin.size()>0) generarAsientos(listaFin);
							//System.out.println("genero asientos "+prm.getNomValor());
						} else {
							FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
							FacesContext.getCurrentInstance().addMessage(null, facesMsg);
						}
					}
					obtenerImportesFiltro();
					deshabilitarObjetos(true, true, false, true, false);
					// Limpiar formulario
					// limpiarFormularioR();
				}
			//}
		} catch (SyncconException ex) {
			ex.printStackTrace();
			LOGGER.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	private void generarAsientos(List<ReservasCamposLayoutBean> lista) throws Exception {

		try {
			if (lista != null && lista.size() > 0) {
				//AsientoContableBean bean;
				//resultadoContable = new ArrayList<AsientoContableBean>();

				for (ReservasCamposLayoutBean reserva : lista) {
					ArrayList<AsientoContableBean> asiento = new ArrayList<AsientoContableBean>();
					asiento = setearAsiento(reserva);
					resultadoContable.addAll(asiento);
				}
				//System.out.println("resultadoContable.size : " + resultadoContable.size());
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	public String obtieneCincoUltDigCtaCte(String cuentaBancaria) {
		String respuesta = "";
		respuesta = cuentaBancaria.substring(cuentaBancaria.length() - 5);
		return respuesta;
	}
	
	private ArrayList<AsientoContableBean> setearAsiento(ReservasCamposLayoutBean reservasCamposLayoutBean)
			throws Exception {
		
		//Logica de seteo de asientos
		//System.out.println("setea asientos.....");
		
		String codCtaBancaria = reservasCamposLayoutBean.getCodigoCuenta();
		
		ArrayList<AsientoContableBean> asiento = new ArrayList<AsientoContableBean>();
		AsientoContableBean beanAsiento = new AsientoContableBean();
		// DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
		// String fechaStr; = dateFormat.format(fecha);
		BigDecimal importeTransxx = new BigDecimal(0);
		BigDecimal importeTrans = new BigDecimal(0);
		BigDecimal importeDol;
		BigDecimal importeEur;
		BigDecimal importeBase = new BigDecimal(0);
		BigDecimal tipoCambioDolSol;
		BigDecimal tipoCambioEurSol;
		BigDecimal tipoCambioEurDol;
		String codMovimiento;
		//int codTipoMov = tesoBancoCamposLayoutBean.getCodTipoMov();
		String cta47Itf = "";
		String cta47Comision = "";
		String cta47Socio = "";
		String cta47Recaudo = "";
		String cta47Ajustes = "";
		String[] listFecha;
		String fechaOperStr = "";
		String fec = "";
		String cuatroUltDigCtaCte = "";

		DateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
		fec = formato.format(reservasCamposLayoutBean.getFechaTransaccion());
		fechaOperStr = fec.substring(8, 10) + fec.substring(5, 7) + fec.substring(0, 4);

		//System.out.println("fechaOperStr: " + fechaOperStr);
		Date fecha = Utilitarios.convertStringToDate(fechaOperStr, ConstantesSun.UTL_FORMATO_FECHA_SUNSYSTEMS);

		//importeTransxx = new BigDecimal(reservasCamposLayoutBean.getImporteTransaccion()).setScale(2,BigDecimal.ROUND_HALF_UP);
		//System.out.println("*** importeTrans xxxx: " + importeTransxx);
		importeTrans = Utilidades.redondear(2,new BigDecimal(reservasCamposLayoutBean.getImporteTransaccion())); 
		//System.out.println("*** importeTrans: " + importeTrans);

		//System.out.println(desMoneda + " importeSoles: " + importeSoles.toString());
		//System.out.println(desMoneda + " valDolarSoles: " + valDolarSoles);
		
		if (!(valDolarSoles.isEmpty())) {
			tipoCambioDolSol = new BigDecimal(valDolarSoles);
			if(tipoCambioDolSol.doubleValue()==0) importeDol = new BigDecimal(0);
			else importeDol = Utilidades.redondear(2, importeTrans.multiply(tipoCambioDolSol));
		} else {
			importeDol = new BigDecimal(0);
		}

		/*if (!(valEuroSoles.isEmpty())) {
			tipoCambioEurSol = new BigDecimal(valEuroSoles);
			if(tipoCambioEurSol.doubleValue()==0) importeEur = new BigDecimal(0);
			else importeEur = Utilidades.redondear(2, importeSoles.divide(tipoCambioEurSol, RoundingMode.HALF_UP));
		} else {
			importeEur = new BigDecimal(0);
		}*/
		if(reservasCamposLayoutBean.getCodigoMoneda().equalsIgnoreCase("USD")) {
			importeBase = importeDol;
		}else {
			importeBase = importeTrans;
		}
		
		beanAsiento.setLayout(reservasCamposLayoutBean.getLayout());
		beanAsiento.setNombreLibro("A");
		//beanAsiento.setMarcador(ConstantesSun.SSC_AllocationMarker_P);
		beanAsiento.setCuentaContable(codCtaBancaria);
		beanAsiento.setFecha(fecha);
		//bean10.setPeriodo("0".concat(fechaOperStr.substring(2)));
		String[] fechaOper = reservasCamposLayoutBean.getPeriodoContable().split("/");
		beanAsiento.setPeriodo(fechaOper[0].concat(fechaOper[1]));
		cuatroUltDigCtaCte = obtieneCincoUltDigCtaCte(codCtaBancaria);
		//beanAsiento.setGlosa(cuatroUltDigCtaCte.concat("-").concat(reservasCamposLayoutBean.getDescripcion()));
		beanAsiento.setGlosa(reservasCamposLayoutBean.getDescripcion());
		beanAsiento.setMoneda(reservasCamposLayoutBean.getCodigoMoneda());
		//System.out.println("beanAsiento importeSoles: " + importeSoles);

		beanAsiento.setImporteSoles(importeBase);
		beanAsiento.setRefImpSoles(importeBase.toString());
		beanAsiento.setRefImpTrans(importeTrans.toString());
		beanAsiento.setImporteTransaccion(importeTrans);

		if (Math.signum(importeTrans.doubleValue()) > 0) {
			beanAsiento.setMarcadorDC(Constantes.MARCADOR_D);
		} else {
			beanAsiento.setMarcadorDC(Constantes.MARCADOR_C);
		}

		//bean10.setTipoPago(ConstantesSun.PAGOS_RECAU_COM_ITF); //consultar
		beanAsiento.setTipoMedioPago(reservasCamposLayoutBean.getMedioPago());
		beanAsiento.setTipoDiario(reservasCamposLayoutBean.getTipoDiario());
		beanAsiento.setReferencia(reservasCamposLayoutBean.getRefTransaccion());
		beanAsiento.setDescripcion(reservasCamposLayoutBean.getDescripcion());
		beanAsiento.setTipoComprobanteSunat(reservasCamposLayoutBean.getTipoCdpSunat());
		beanAsiento.setCentroCosto(reservasCamposLayoutBean.getCentroCosto());
		beanAsiento.setPolizaCliente(reservasCamposLayoutBean.getPolizaCliente());
		beanAsiento.setCanal(reservasCamposLayoutBean.getCanal());
		beanAsiento.setProveedorEmpleado(reservasCamposLayoutBean.getProveedorEmpleado());
		beanAsiento.setNroSiniestro(reservasCamposLayoutBean.getNroSiniestro());
		beanAsiento.setInversiones(reservasCamposLayoutBean.getInversiones());		
		beanAsiento.setSocioProducto(reservasCamposLayoutBean.getSocioProducto());
		beanAsiento.setRucDniCliente(reservasCamposLayoutBean.getDocumentoCliente());
		beanAsiento.setNombreHoja(reservasCamposLayoutBean.getNombreHoja());
		beanAsiento.setIdAsiento(reservasCamposLayoutBean.getIdCarga());
		beanAsiento.setNombreCuenta(reservasCamposLayoutBean.getNombreCuenta());
		
		asiento.add(beanAsiento);
		
		return asiento;
	}
	
	public String enviarAsientoSun() {
		String respuesta = null;

		try {
			if (resultadoContable == null || resultadoContable.size() == 0) {
				pasoValidaciones = false;
				throw new SyncconException(ErrorConstants.COD_ERROR_VALIDAR_PROCESAR_ASIENTOS,
						FacesMessage.SEVERITY_INFO);
			}
			
			List<Integer> listDiario;
			List<String> resultado = new ArrayList<String>();
			String result;
			int numDiario = 0;
			int numLineaDiario = 0;
			HashMap<Integer, Object> resultadosValidacion = new HashMap<Integer, Object>();
			String retorno = null;
			HashMap<Integer, String> listaErrores = new HashMap<Integer, String>();
			HashMap<Integer, Integer> listaAsientosCorrectos = new HashMap<Integer, Integer>();
			resultadoErroresContable = new ArrayList<ResultadoErroresContable>();
			resultadoCorrectosContable = new ArrayList<ResultadoErroresContable>();
			
			List<AsientoContableBean> listaAsiento = new ArrayList<AsientoContableBean>();
			int i = 0;
			utiles = new Utilidades();

			// resultado =
			// controlSun.envioSunPagos(listaAsiento.get(0).getMoneda(),
			// resultadoContable, tipoPago, tipoMedioPago);
			// listaAsiento = (ArrayList<AsientoContableBean>)
			// utiles.seteaDiarioAsientoContable(resultado,resultadoContable);
			
			/*int tam = Constantes.CONTA_TAMANIO_ENVIO_SUN;
			int num = resultadoContable.size()-tam;
			if(num<0) num = resultadoContable.size();
			else num = tam;
			int x = 0;*/
			for (AsientoContableBean a : resultadoContable) {

				/*if (a.getCuentaContable().trim().substring(0, 2).equals("10")) {
					tipoMedioPago = a.getTipoMedioPago();
					tipoPago = a.getTipoPago();
				}*/
				
				//numLineaDiario = 0;
				//numDiario = 0;

				listaAsiento.add(a);
				i++;
				/*x++;
				//if (Utilitarios.esPar(i)) {
				if(i==num) {
					// for(AsientoContableBean asiento:listaAsiento){
					result = controlSun.envioSunContabilidad(listaAsiento.get(0).getMoneda(), listaAsiento);
					listDiario = utiles.seteaDiarioAsientoContable(result);
					resultado.add(result);
					if (listDiario.size() > 0) {
						numLineaDiario = listDiario.get(0);
						numDiario = listDiario.get(1);
					}
					// }
					if (numDiario != 0) {
						int j = 0;
						while(j<num) {
							resultadoContable.get((x-num)+j).setDiario(numDiario);
							j++;
						}
						//resultadoContable.get(i - 2).setDiario(numDiario);
						//resultadoContable.get(i - 1).setDiario(numDiario);
					}
					// se genera una nueva lista para el sgte par de cuentas
					listaAsiento = new ArrayList<AsientoContableBean>();
					i = 0;
					num = resultadoContable.size() - x;
					if(num<tam) num = resultadoContable.size() - x;
					else num = tam;
				}*/
				//}
			}
			
			/* Enviar WS SUN */
			result = controlSun.envioSunContabilidad(listaAsiento.get(0).getMoneda(), listaAsiento);
			//System.out.println("result: "+result);
			listDiario = utiles.seteaDiarioAsientoContable(result);
			resultado.add(result);
			if (listDiario.size() > 0) {
				for(int j=0; j<resultadoContable.size(); j++) {
					numLineaDiario = listDiario.get(0);
					numDiario = listDiario.get(1);
					//resultado.add(result);
					if (numDiario != 0) {
						resultadoContable.get(j).setDiario(numDiario);
					}
				}
			}
			/* **** */

			sumaLineaAsientosErrores = 0;
			for (i = 0; i < resultado.size(); i++) {
				if (i == 0) {
					contAsientosContablesGenerados = 0;
				}
				listaErrores = procesoPagos.procesarResultadoSun(resultado.get(i));
				if (listaErrores.size() > 0) {
					resultadoErroresContable.addAll(procesarHashMapErroresSun(listaErrores, "ERRORES PROCESO SUN"));
					resultadoErroresContable.add(new ResultadoErroresContable());
				} else {
					listaAsientosCorrectos = procesoPagos.procesarResultadoSunExitoso(resultado.get(i));
					resultadoCorrectosContable.addAll(procesarHashMapCorrectosPago(listaAsientosCorrectos));
					resultadoCorrectosContable.add(new ResultadoErroresContable());
					// Actualizo el estado, cheque, banco, cuentaBanco,
					// cuentaContable

					LOGGER.info("listaAsientosCorrectos: "+listaAsientosCorrectos);
					// desabActualizarM = false;
				}
			}

			for (i = 0; i < resultadoContable.size(); i++) {
				AsientoContableBean item = resultadoContable.get(i);
				if (item == null || item.getCuentaContable() == null) {
					resultadoContable.remove(i);
				}
			}

			listaCorrectosAsientoContable = resultadoCorrectosContable;

			for (i = 0; i < listaCorrectosAsientoContable.size(); i++) {
				ResultadoErroresContable item = listaCorrectosAsientoContable.get(i);
				if (item == null || item.getDiario() == null) {
					listaCorrectosAsientoContable.remove(i);
				}
			}

			if (resultadoErroresContable.size() > 0) {
				success = false;
				pasoValidaciones = true;
				FacesContext context = FacesContext.getCurrentInstance();
				context.getExternalContext().getSessionMap().remove(ConstantesSun.MDP_FEL_CORRELATIVO_GENERADO);
				return null;
			}

			if (resultadoCorrectosContable.size() > 0) {
				success = true;
				pasoValidaciones = true;
				asientosActuarialService.insertaContaAsientosActuarial(resultadoContable, resultadoCorrectosContable);
				volverProcesar();
			}

			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().getSessionMap().remove(ConstantesSun.MDP_FEL_CORRELATIVO_GENERADO);
			
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	private void enviarMensaje(String mensaje) {
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, mensaje, null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		facesMsg = null;
	}
	
	public String actualizarTiposCambio(Date fecha) {
		LOGGER.info("Actualizando Tipo Cambio");
		HashMap<String, BigDecimal> lista_val = null;
		try {
			lista_val = procesoPagos.traerTipoCambioActual(fmSUN.format(fecha));
			//System.out.println("actualizarTiposCambio - lista_val: " + lista_val);

			LOGGER.info("lista_val " + lista_val);

			if (lista_val instanceof HashMap) {
				//System.out.println("actualizarTiposCambio - codigo: " + lista_val.get("codigo"));
				if (lista_val.get("codigo").compareTo(new BigDecimal("9")) == 0) {
					LOGGER.info("Falla en tipos cambios");
					enviarMensaje("Falla en tipos de cambios");
				}

				LOGGER.info("codigo " + lista_val.get("codigo"));
				if (lista_val.get("codigo").compareTo(new BigDecimal("0")) == 0) {
					valEuroSoles = lista_val.get("eur-pen").toString();
					valDolarSoles = lista_val.get("usd-pen").toString();
					valEuroDolares = lista_val.get("eur-usd").toString();
				} else {
					valEuroSoles = "";
					valDolarSoles = "";
					valEuroDolares = "";
					LOGGER.info("Falla en tipos cambios");
					enviarMensaje("No hay tipos de cambio para esta fecha");
				}

			}
			// lista_val = null;
			return null;
		} catch (SOAPFaultException e) {
			LOGGER.error("ERROR SOAP: " + e.getMessage());
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"La autentificacion en SUN ha fallado", null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			return "error";
		} catch (Exception e) {
			LOGGER.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			LOGGER.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}

		return null;
	}
	
	private List<ResultadoErroresContable> procesarHashMapErroresSun(HashMap<Integer, String> listaErrores,
			String origen) {
		Iterator it = listaErrores.entrySet().iterator();
		List<ResultadoErroresContable> lista = new ArrayList<ResultadoErroresContable>();
		ResultadoErroresContable resul;
		Map.Entry e1;
		int iterador = 0;
		while (it.hasNext()) {
			e1 = (Map.Entry) it.next();
			resul = new ResultadoErroresContable();
			resul.setLineaAsientoError(e1.getKey() + "");

			String[] elementos = e1.getValue().toString().split(ConstantesSun.UTL_CHR_SEPARADOR);

			resul.setDiario(e1.getKey() + "");
			resul.setLineaDiario(elementos[0]);
			resul.setMensajeAsientoError(elementos[1]);
			resul.setProcedenciaError(origen);
			// resul.setLineaAsientoError(
			// resultadoContable.get(iterador + contVaciosErrores +
			// sumaLineaAsientosErrores).getCuentaContable());
			resul.setLineaAsientoError(resultadoContable.get(iterador + sumaLineaAsientosErrores).getCuentaContable());
			lista.add(resul);
			iterador++;
		}
		// contVaciosErrores++;
		sumaLineaAsientosErrores += listaErrores.size();
		return lista;
	}

	private List<ResultadoErroresContable> ProcesarHashMapCorrectos(HashMap<Integer, Integer> listaAsientosCorrectos) {
		ResultadoErroresContable resul;
		List<ResultadoErroresContable> lista = new ArrayList<ResultadoErroresContable>();
		for (Entry<Integer, Integer> e : listaAsientosCorrectos.entrySet()) {
			resul = new ResultadoErroresContable();
			resul.setDiario(e.getKey() + "");
			resul.setLineaDiario(e.getValue() + "");
			resul.setLineaAsientoError(resultadoContable.get(e.getKey() + contVacios + sumaLineaAsientos).getCuentaContable());
			LOGGER.info("[" + e.getKey() + "=" + e.getValue() + "]");
			lista.add(resul);
		}
		contVacios++;
		sumaLineaAsientos += listaAsientosCorrectos.size();
		return lista;
	}
	
	private List<ResultadoErroresContable> procesarHashMapCorrectosPago(
			HashMap<Integer, Integer> listaAsientosCorrectos) {
		ResultadoErroresContable resul;
		List<ResultadoErroresContable> lista = new ArrayList<ResultadoErroresContable>();
		for (Entry<Integer, Integer> e : listaAsientosCorrectos.entrySet()) {
			resul = new ResultadoErroresContable();
			resul.setDiario(e.getKey() + "");
			resul.setLineaDiario(e.getValue() + "");
			// int ind = e.getKey() + contVacios + sumaLineaAsientos;
			resul.setLineaAsientoError(resultadoContable.get(contAsientosContablesGenerados).getCuentaContable());
			LOGGER.info("[" + e.getKey() + "=" + e.getValue() + "]");
			lista.add(resul);
			contAsientosContablesGenerados++;
		}
		return lista;
	}
	
	private void obtenerImportesFiltro() {
		int cantidadTotal = 0;
		BigDecimal importeTotalHaber = new BigDecimal("0");
		BigDecimal importeTotalDebe = new BigDecimal("0");
		if (resultadoContable != null && resultadoContable.size() > 0) {
			for (AsientoContableBean asiento : resultadoContable) {
				cantidadTotal = cantidadTotal + 1;
				if(asiento.getMarcadorDC().equalsIgnoreCase("D")) importeTotalDebe = importeTotalDebe.add(asiento.getImporteSoles());
				else importeTotalHaber = importeTotalHaber.add(asiento.getImporteSoles());
			}
		}
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		DecimalFormat formateador = (DecimalFormat) nf;
		formateador.applyPattern("###,###.##");

		totalImporteHaber = formateador.format(importeTotalHaber) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalImporteDebe = formateador.format(importeTotalDebe) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		LOGGER.debug("totalImporteHaber: " + totalImporteHaber + " local" + Locale.US.toString());
		LOGGER.debug("totalImporteDebe: " + totalImporteDebe + " local" + Locale.US.toString());
		totalRegistrosFiltro = cantidadTotal;
	}
	
	public void cambioTipoDiario() {
		LOGGER.info("tipoDiario change: "+tipoDiario);
		/*if(!tipoDiario.equals("*")) deshabilitarObjetos(false,true,true);
		else deshabilitarObjetos(true,true,true);*/
	}

	public List<ReservasCamposLayoutBean> getListaAsientos() {
		return listaAsientos;
	}

	public void setListaAsientos(List<ReservasCamposLayoutBean> listaAsientos) {
		this.listaAsientos = listaAsientos;
	}

	public UploadedFile getArchivoR() {
		return archivoR;
	}

	public void setArchivoR(UploadedFile archivoR) {
		this.archivoR = archivoR;
	}

	public String getNombreArchivoR() {
		return nombreArchivoR;
	}

	public void setNombreArchivoR(String nombreArchivoR) {
		this.nombreArchivoR = nombreArchivoR;
	}

	public String getMensajeValidacionUploadFileR() {
		return mensajeValidacionUploadFileR;
	}

	public void setMensajeValidacionUploadFileR(String mensajeValidacionUploadFileR) {
		this.mensajeValidacionUploadFileR = mensajeValidacionUploadFileR;
	}

	public String getIdFileUploadComponentR() {
		return idFileUploadComponentR;
	}

	public void setIdFileUploadComponentR(String idFileUploadComponentR) {
		this.idFileUploadComponentR = idFileUploadComponentR;
	}

	public File getArchivoD() {
		return archivoD;
	}

	public void setArchivoD(File archivoD) {
		this.archivoD = archivoD;
	}

	public String getNombreArchivoD() {
		return nombreArchivoD;
	}

	public void setNombreArchivoD(String nombreArchivoD) {
		this.nombreArchivoD = nombreArchivoD;
	}

	public String getMensajeValidacionUploadFileD() {
		return mensajeValidacionUploadFileD;
	}

	public void setMensajeValidacionUploadFileD(String mensajeValidacionUploadFileD) {
		this.mensajeValidacionUploadFileD = mensajeValidacionUploadFileD;
	}

	public String getIdFileUploadComponentD() {
		return idFileUploadComponentD;
	}

	public void setIdFileUploadComponentD(String idFileUploadComponentD) {
		this.idFileUploadComponentD = idFileUploadComponentD;
	}

	public List<AsientoContableBean> getResultadoContable() {
		return resultadoContable;
	}

	public void setResultadoContable(List<AsientoContableBean> resultadoContable) {
		this.resultadoContable = resultadoContable;
	}
	
	public boolean isPasoValidaciones() {
		return pasoValidaciones;
	}

	public void setPasoValidaciones(boolean pasoValidaciones) {
		this.pasoValidaciones = pasoValidaciones;
	}
	
	public String getOutText() {
		return outText;
	}

	public void setOutText(String outText) {
		this.outText = outText;
	}
	
	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public List<ResultadoErroresContable> getResultadoErroresContable() {
		return resultadoErroresContable;
	}

	public void setResultadoErroresContable(List<ResultadoErroresContable> resultadoErroresContable) {
		this.resultadoErroresContable = resultadoErroresContable;
	}

	public List<ResultadoErroresContable> getResultadoCorrectosContable() {
		return resultadoCorrectosContable;
	}

	public void setResultadoCorrectosContable(List<ResultadoErroresContable> resultadoCorrectosContable) {
		this.resultadoCorrectosContable = resultadoCorrectosContable;
	}

	public List<ResultadoErroresContable> getListaCorrectosAsientoContable() {
		return listaCorrectosAsientoContable;
	}

	public void setListaCorrectosAsientoContable(List<ResultadoErroresContable> listaCorrectosAsientoContable) {
		this.listaCorrectosAsientoContable = listaCorrectosAsientoContable;
	}

	public String getTipoDiario() {
		return tipoDiario;
	}

	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}

	public List<SelectItem> getTiposDiarioItems() {
		return tiposDiarioItems;
	}

	public void setTiposDiarioItems(List<SelectItem> tiposDiarioItems) {
		this.tiposDiarioItems = tiposDiarioItems;
	}

	public SunsystemsController getControlSun() {
		return controlSun;
	}

	public void setControlSun(SunsystemsController controlSun) {
		this.controlSun = controlSun;
	}

	public String getValEuroSoles() {
		return valEuroSoles;
	}

	public void setValEuroSoles(String valEuroSoles) {
		this.valEuroSoles = valEuroSoles;
	}

	public String getValDolarSoles() {
		return valDolarSoles;
	}

	public void setValDolarSoles(String valDolarSoles) {
		this.valDolarSoles = valDolarSoles;
	}

	public String getValEuroDolares() {
		return valEuroDolares;
	}

	public void setValEuroDolares(String valEuroDolares) {
		this.valEuroDolares = valEuroDolares;
	}

	public SimpleDateFormat getFm() {
		return fm;
	}

	public void setFm(SimpleDateFormat fm) {
		this.fm = fm;
	}

	public SimpleDateFormat getFmPeriodo() {
		return fmPeriodo;
	}

	public void setFmPeriodo(SimpleDateFormat fmPeriodo) {
		this.fmPeriodo = fmPeriodo;
	}

	public SimpleDateFormat getFmSUN() {
		return fmSUN;
	}

	public void setFmSUN(SimpleDateFormat fmSUN) {
		this.fmSUN = fmSUN;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getDesMoneda() {
		return desMoneda;
	}

	public void setDesMoneda(String desMoneda) {
		this.desMoneda = desMoneda;
	}

	public String getTipoMedioPago() {
		return tipoMedioPago;
	}

	public void setTipoMedioPago(String tipoMedioPago) {
		this.tipoMedioPago = tipoMedioPago;
	}

	public int getSumaLineaAsientosErrores() {
		return sumaLineaAsientosErrores;
	}

	public void setSumaLineaAsientosErrores(int sumaLineaAsientosErrores) {
		this.sumaLineaAsientosErrores = sumaLineaAsientosErrores;
	}

	public int getContAsientosContablesGenerados() {
		return contAsientosContablesGenerados;
	}

	public void setContAsientosContablesGenerados(int contAsientosContablesGenerados) {
		this.contAsientosContablesGenerados = contAsientosContablesGenerados;
	}

	public String getTipoPago() {
		return tipoPago;
	}

	public void setTipoPago(String tipoPago) {
		this.tipoPago = tipoPago;
	}

	public AsientoContableBean getAsientoSeleccionado() {
		return asientoSeleccionado;
	}

	public void setAsientoSeleccionado(AsientoContableBean asientoSeleccionado) {
		this.asientoSeleccionado = asientoSeleccionado;
	}

	public boolean isDisabledCarga() {
		return disabledCarga;
	}

	public void setDisabledCarga(boolean disabledCarga) {
		this.disabledCarga = disabledCarga;
	}

	public boolean isDisabledSun() {
		return disabledSun;
	}

	public void setDisabledSun(boolean disabledSun) {
		this.disabledSun = disabledSun;
	}

	public List<Parametro> getListaMoneda() {
		return listaMoneda;
	}

	public void setListaMoneda(List<Parametro> listaMoneda) {
		this.listaMoneda = listaMoneda;
	}

	public boolean isDisabledProceso() {
		return disabledProceso;
	}

	public void setDisabledProceso(boolean disabledProceso) {
		this.disabledProceso = disabledProceso;
	}

	public boolean isDisabledTipoDiario() {
		return disabledTipoDiario;
	}

	public void setDisabledTipoDiario(boolean disabledTipoDiario) {
		this.disabledTipoDiario = disabledTipoDiario;
	}

	public int getTotalRegistrosFiltro() {
		return totalRegistrosFiltro;
	}

	public void setTotalRegistrosFiltro(int totalRegistrosFiltro) {
		this.totalRegistrosFiltro = totalRegistrosFiltro;
	}

	public String getTotalImporteHaber() {
		return totalImporteHaber;
	}

	public void setTotalImporteHaber(String totalImporteHaber) {
		this.totalImporteHaber = totalImporteHaber;
	}

	public String getTotalImporteDebe() {
		return totalImporteDebe;
	}

	public void setTotalImporteDebe(String totalImporteDebe) {
		this.totalImporteDebe = totalImporteDebe;
	}

	public String getPeriodoCarga() {
		return periodoCarga;
	}

	public void setPeriodoCarga(String periodoCarga) {
		this.periodoCarga = periodoCarga;
	}

	public boolean isDisabledLimpiar() {
		return disabledLimpiar;
	}

	public void setDisabledLimpiar(boolean disabledLimpiar) {
		this.disabledLimpiar = disabledLimpiar;
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/