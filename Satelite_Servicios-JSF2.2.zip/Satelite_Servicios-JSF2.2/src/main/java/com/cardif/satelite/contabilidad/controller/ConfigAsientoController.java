/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.contabilidad.bean.ConfigAnalisisBean;
import com.cardif.satelite.contabilidad.bean.ConfigCuentaContableBean;
import com.cardif.satelite.contabilidad.bean.ConfigProductoBean;
import com.cardif.satelite.contabilidad.service.AsientosActuarialService;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.util.SateliteUtil;

@Controller("configAsientoController")
@Scope("session")
public class ConfigAsientoController {

	private static final long serialVersionUID = -8323560799344065774L;

	public static final Logger logger = Logger.getLogger(ConfigAsientoController.class);
	
	@Autowired
	private ParametroService parametroService;
	
	@Autowired
	private AsientosActuarialService asientosActuarialService;
	
	private ConfigProductoBean productoBean;
	private ConfigProductoBean selectProducto;
	private List<ConfigProductoBean> listaProductoBean;
	private List<ConfigProductoBean> itemsProductoBean;
	
	private ConfigAnalisisBean analisisBean;
	private ConfigAnalisisBean selectAnalisis;
	private List<ConfigAnalisisBean> listaAnalisisBean;
	private List<ConfigAnalisisBean> itemsAnalisisBean;
	
	private ConfigCuentaContableBean cuentaContableBean;
	private ConfigCuentaContableBean selectCuentaContable;
	private List<ConfigCuentaContableBean> listaCuentaContableBean;
	private List<SelectItem> listaMoneda;
	private List<SelectItem> listaCuentaProducto;
	private List<SelectItem> listaCuentaAnalisis;
	private String usuario;
	
	private final String TAB_DEFAULT = "tabProducto";
	private final String TAB_MANT_PARAM_DIARIO = "tabParamTipoDiario";
	private final String TAB_MANT_ANALISIS = "tabAnalisis";
	private final String TAB_MANT_CUENTAS = "tabCuentas";

	private String tabSeleccionado = TAB_DEFAULT;
	
	@PostConstruct
	public String inicio() {
		
		try {
			usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString();
			
			productoBean = new ConfigProductoBean();
			selectProducto = new ConfigProductoBean();
			analisisBean = new ConfigAnalisisBean();
			selectAnalisis = new ConfigAnalisisBean();
			cuentaContableBean = new ConfigCuentaContableBean();
			selectCuentaContable = new ConfigCuentaContableBean();
			
			listaProductoBean = new ArrayList<ConfigProductoBean>();
			listaAnalisisBean = new ArrayList<ConfigAnalisisBean>();
			listaCuentaContableBean = new ArrayList<ConfigCuentaContableBean>();
			
			itemsProductoBean = new ArrayList<ConfigProductoBean>();
			itemsAnalisisBean = new ArrayList<ConfigAnalisisBean>();
			
			listaMoneda = new ArrayList<SelectItem>();
			listaMoneda = obtenerMonedas();
			
			limpiarProducto();
			limpiarAnalisis();
			limpiarCuenta();
			
			listarProducto();
			listarAnalisis();
			listarCuenta();
			
			listaCuentaProducto = obtenerCuentaProducto();
			listaCuentaAnalisis = obtenerCuentaAnalisis();
		
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		
		return null;
	}
	
	public void activateTab(ActionEvent ae){
	    String componentId = ae.getComponent().getId();
	    System.out.println("componentId: "+componentId);
	}
	
	private List<SelectItem> obtenerMonedas() throws Exception {
		List<Parametro> monedas = parametroService.buscar(Constantes.COD_PARAM_MONEDA, Constantes.TIP_PARAM_DETALLE);
		if (monedas != null && monedas.size() > 0) {
			for (Parametro p : monedas) {
				listaMoneda.add(new SelectItem(p.getCodValor(), p.getCodValor()));
			}
		}
		return listaMoneda;
	}
	
	private List<SelectItem> obtenerCuentaProducto() throws Exception {
		listaCuentaProducto = new ArrayList<SelectItem>();
		if (itemsProductoBean != null && itemsProductoBean.size() > 0) {
			for (ConfigProductoBean p : itemsProductoBean) {
				listaCuentaProducto.add(new SelectItem(String.valueOf(p.getId()), p.getProdCodEquivalente()+" - "+p.getProdDescripcion()));
			}
		}
		return listaCuentaProducto;
	}
	
	private List<SelectItem> obtenerCuentaAnalisis() throws Exception {
		listaCuentaAnalisis = new ArrayList<SelectItem>();
		if (itemsAnalisisBean != null && itemsAnalisisBean.size() > 0) {
			for (ConfigAnalisisBean p : itemsAnalisisBean) {
				listaCuentaAnalisis.add(new SelectItem(String.valueOf(p.getId()), p.getParamAnalisis()+" - "+p.getParamDescripcion()));
			}
		}
		return listaCuentaAnalisis;
	}
	
	public void limpiarProducto() {
		productoBean.setProdCodigo("");
		productoBean.setProdDescripcion("");
		productoBean.setProdCodEquivalente("");
		productoBean.setProdMoneda("");
		productoBean.setId(0);
	}
	public void limpiarAnalisis() {
		analisisBean.setParamAnalisis("");
		analisisBean.setParamDescripcion("");
		analisisBean.setId(0);
	}
	public void limpiarCuenta() {
		cuentaContableBean.setCuentaContable("");
		cuentaContableBean.setTipoAnalisis("");
		cuentaContableBean.setId(0);
	}
	
	public String agregarProducto() {
		String respuesta = null;
		try {
			if(!validarProducto()) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar los campos obligatorios");
			}else {
				productoBean.setUsuarioRegistra(usuario);
				Integer id = asientosActuarialService.agregarConfigProducto(productoBean);
				productoBean.setId(id);
				limpiarProducto();
				listarProducto();
				obtenerCuentaProducto();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		return respuesta;
	}
	public String agregarAnalisis() {
		String respuesta = null;
		try {
			if(!validarAnalisis()) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar los campos obligatorios");
			}else {
				analisisBean.setUsuarioRegistra(usuario);
				Integer id = asientosActuarialService.agregarConfigAnalisis(analisisBean);
				analisisBean.setId(id);
				limpiarAnalisis();
				listarAnalisis();
				obtenerCuentaAnalisis();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		return respuesta;
	}
	public String agregarCuenta() {
		String respuesta = null;
		try {
			if(!validarCuenta()) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar los campos obligatorios");
			}else {
				cuentaContableBean.setUsuarioRegistra(usuario);
				Integer id = asientosActuarialService.agregarConfigCuenta(cuentaContableBean);
				cuentaContableBean.setId(id);
				limpiarCuenta();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		return respuesta;
	}
	
	public void mostrarProducto() {
		try {
			productoBean = asientosActuarialService.verConfigProducto(selectProducto);
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	public void mostrarAnalisis() {
		try {
			analisisBean = asientosActuarialService.verConfigAnalisis(selectAnalisis);
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	public void mostrarCuenta() {
		try {
			cuentaContableBean = asientosActuarialService.verConfigCuenta(selectCuentaContable);
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}

	public void editarProducto() {
		try {
			if(!validarProducto()) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar los campos obligatorios");
			}else {
				selectProducto.setUsuarioModifica(usuario);
				asientosActuarialService.editarConfigProducto(selectProducto);
				limpiarProducto();
				listarProducto();
				obtenerCuentaProducto();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	
	public void editarAnalisis() {
		try {
			if(!validarAnalisis()) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar los campos obligatorios");
			}else {
				selectAnalisis.setUsuarioModifica(usuario);
				asientosActuarialService.editarConfigAnalisis(selectAnalisis);
				limpiarAnalisis();
				listarAnalisis();
				obtenerCuentaAnalisis();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	
	public void editarCuenta() {
		try {
			if(!validarCuenta()) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar los campos obligatorios");
			}else {
				selectCuentaContable.setUsuarioModifica(usuario);
				asientosActuarialService.editarConfigCuenta(selectCuentaContable);
				limpiarCuenta();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	
	public void borrarProducto() {
		try {
			if(selectProducto!=null) {
				asientosActuarialService.borrarConfigProducto(selectProducto);
				listarProducto();
				obtenerCuentaProducto();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	public void borrarAnalisis() {
		try {
			if(selectAnalisis!=null) {
				asientosActuarialService.borrarConfigAnalisis(selectAnalisis);
				listarAnalisis();
				obtenerCuentaAnalisis();
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	public void borrarCuenta() {
		try {
			if(selectCuentaContable!=null) {
				asientosActuarialService.borrarConfigCuenta(selectCuentaContable);
				listarCuenta();
			}
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
	}
	
	public void listarProducto() {
		productoBean.setProdCodigo(null);
		productoBean.setProdDescripcion(null);
		productoBean.setProdMoneda(null);
		productoBean.setProdCodEquivalente(null);
		listaProductoBean = asientosActuarialService.listarConfigProducto(productoBean);
		itemsProductoBean = asientosActuarialService.itemsConfigProducto(productoBean);
	}
	public void listarAnalisis() {
		analisisBean.setParamAnalisis(null);
		analisisBean.setParamDescripcion(null);
		listaAnalisisBean = asientosActuarialService.listarConfigAnalisis(analisisBean);
		itemsAnalisisBean = asientosActuarialService.itemsConfigAnalisis(analisisBean);
	}
	public void listarCuenta() {
		cuentaContableBean.setTipoAnalisis(null);
		cuentaContableBean.setCuentaContable(null);
		cuentaContableBean.setIdProducto(null);
		cuentaContableBean.setIdAnalisis(null);
		listaCuentaContableBean = asientosActuarialService.listarConfigCuenta(cuentaContableBean);
	}
	
	public void buscarProducto() {
		ConfigProductoBean productoBusBean = new ConfigProductoBean();
		productoBusBean.setProdCodigo(productoBean.getProdCodigo()!=null?(!productoBean.getProdCodigo().equals("")?productoBean.getProdCodigo().trim():null):null);
		productoBusBean.setProdDescripcion(productoBean.getProdDescripcion()!=null?(!productoBean.getProdDescripcion().equals("")?productoBean.getProdDescripcion().trim():null):null);
		productoBusBean.setProdMoneda(productoBean.getProdMoneda()!=null?(!productoBean.getProdMoneda().equals("")?productoBean.getProdMoneda().trim():null):null);
		productoBusBean.setProdCodEquivalente(productoBean.getProdCodEquivalente()!=null?(!productoBean.getProdCodEquivalente().equals("")?productoBean.getProdCodEquivalente().trim():null):null);
		listaProductoBean = asientosActuarialService.listarConfigProducto(productoBusBean);
	}
	public void buscarAnalisis() {
		ConfigAnalisisBean analisisBusBean = new ConfigAnalisisBean();
		analisisBusBean.setParamAnalisis(analisisBean.getParamAnalisis()!=null?(!analisisBean.getParamAnalisis().equals("")?analisisBean.getParamAnalisis().trim():null):null);
		analisisBusBean.setParamDescripcion(analisisBean.getParamDescripcion()!=null?(!analisisBean.getParamDescripcion().equals("")?analisisBean.getParamDescripcion().trim():null):null);
		listaAnalisisBean = asientosActuarialService.listarConfigAnalisis(analisisBusBean);
	}
	public void buscarCuenta() {
		ConfigCuentaContableBean cuentaContableBusBean = new ConfigCuentaContableBean();
		cuentaContableBusBean.setTipoAnalisis(cuentaContableBean.getTipoAnalisis()!=null?(!cuentaContableBean.getTipoAnalisis().equals("")?cuentaContableBean.getTipoAnalisis().trim():null):null);
		cuentaContableBusBean.setCuentaContable(cuentaContableBean.getCuentaContable()!=null?(!cuentaContableBean.getCuentaContable().equals("")?cuentaContableBean.getCuentaContable().trim():null):null);
		if(cuentaContableBean.getIdAnalisis()!=0) cuentaContableBusBean.setIdAnalisis(cuentaContableBean.getIdAnalisis());
		if(cuentaContableBean.getIdProducto()!=0) cuentaContableBusBean.setIdProducto(cuentaContableBean.getIdProducto());
		listaCuentaContableBean = asientosActuarialService.listarConfigCuenta(cuentaContableBusBean);
	}
	
	public boolean validarProducto() {
		boolean valida = true;
		if(productoBean.getProdCodigo()==null) {
			valida = false; 
		}else {
			if(productoBean.getProdCodigo().equals("")) {
				valida = false;
			}
		}
		if(productoBean.getProdDescripcion()==null) {
			valida = false;
		}else {
			if(productoBean.getProdDescripcion().equals("")) {
				valida = false;
			}
		}
		if(productoBean.getProdMoneda()==null) { 
			valida = false;
		}else {
			if(productoBean.getProdMoneda().equals("")) { 
				valida = false;
			}
		}
		if(productoBean.getProdCodEquivalente()==null) {
			valida = false;
		}else {
			if(productoBean.getProdCodEquivalente().equals("")) {
				valida = false;
			}
		}
		return valida;
	}
	public boolean validarAnalisis() {
		boolean valida = true;
		if(analisisBean.getParamAnalisis()==null) {
			valida = false;
		}else {
			if(analisisBean.getParamAnalisis().equals("")) {
				valida = false;
			}
		}
		if(analisisBean.getParamDescripcion()==null) {
			valida = false;
		}else {
			if(analisisBean.getParamDescripcion().equals("")) {
				valida = false;
			}
		}
		return valida;
	}
	public boolean validarCuenta() {
		boolean valida = true;
		if(cuentaContableBean.getCuentaContable()==null) {
			valida = false;
		}else {
			if(cuentaContableBean.getCuentaContable().equals("")) {
				valida = false;
			}
		}
		if(cuentaContableBean.getTipoAnalisis()==null) {
			valida = false;
		}else {
			if(cuentaContableBean.getTipoAnalisis().equals("")) {
				valida = false;
			}
		}
		if(cuentaContableBean.getIdAnalisis()==null) {
			valida = false;
		}else {
			if(cuentaContableBean.getIdAnalisis()==0) {
				valida = false;
			}
		}
		if(cuentaContableBean.getIdProducto()==null) {
			valida = false;
		}else {
			if(cuentaContableBean.getIdProducto()==0) {
				valida = false;
			}
		}
		return valida;
	}
	
	public void cambioMoneda() {
		logger.info("moneda change ");
	}
	
	public void cancelar() {
		logger.info("Cancela borrar registro...");
	}
	
	public void cerrar() {
		logger.info("Cerrar Editar registro...");
	}
	
	public void cambioTipoAnalisis() {
		logger.info("cuenta tipo analisis ");
	}
	
	public void cambioCuentaProducto() {
		logger.info("cuenta producto ");
	}

	public ConfigProductoBean getProductoBean() {
		return productoBean;
	}

	public void setProductoBean(ConfigProductoBean productoBean) {
		this.productoBean = productoBean;
	}

	public ConfigAnalisisBean getAnalisisBean() {
		return analisisBean;
	}

	public void setAnalisisBean(ConfigAnalisisBean analisisBean) {
		this.analisisBean = analisisBean;
	}

	public ConfigCuentaContableBean getCuentaContableBean() {
		return cuentaContableBean;
	}

	public void setCuentaContableBean(ConfigCuentaContableBean cuentaContableBean) {
		this.cuentaContableBean = cuentaContableBean;
	}

	public List<ConfigProductoBean> getListaProductoBean() {
		return listaProductoBean;
	}

	public void setListaProductoBean(List<ConfigProductoBean> listaProductoBean) {
		this.listaProductoBean = listaProductoBean;
	}

	public List<ConfigAnalisisBean> getListaAnalisisBean() {
		return listaAnalisisBean;
	}

	public void setListaAnalisisBean(List<ConfigAnalisisBean> listaAnalisisBean) {
		this.listaAnalisisBean = listaAnalisisBean;
	}

	public List<ConfigCuentaContableBean> getListaCuentaContableBean() {
		return listaCuentaContableBean;
	}

	public void setListaCuentaContableBean(List<ConfigCuentaContableBean> listaCuentaContableBean) {
		this.listaCuentaContableBean = listaCuentaContableBean;
	}

	public ConfigProductoBean getSelectProducto() {
		return selectProducto;
	}

	public void setSelectProducto(ConfigProductoBean selectProducto) {
		this.selectProducto = selectProducto;
	}

	public ConfigAnalisisBean getSelectAnalisis() {
		return selectAnalisis;
	}

	public void setSelectAnalisis(ConfigAnalisisBean selectAnalisis) {
		this.selectAnalisis = selectAnalisis;
	}

	public ConfigCuentaContableBean getSelectCuentaContable() {
		return selectCuentaContable;
	}

	public void setSelectCuentaContable(ConfigCuentaContableBean selectCuentaContable) {
		this.selectCuentaContable = selectCuentaContable;
	}
	
	public List<SelectItem> getListaMoneda() {
		return listaMoneda;
	}

	public void setListaMoneda(List<SelectItem> listaMoneda) {
		this.listaMoneda = listaMoneda;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getTabSeleccionado() {
		return tabSeleccionado;
	}

	public void setTabSeleccionado(String tabSeleccionado) {
		this.tabSeleccionado = tabSeleccionado;
	}

	public List<SelectItem> getListaCuentaProducto() {
		return listaCuentaProducto;
	}

	public void setListaCuentaProducto(List<SelectItem> listaCuentaProducto) {
		this.listaCuentaProducto = listaCuentaProducto;
	}

	public List<SelectItem> getListaCuentaAnalisis() {
		return listaCuentaAnalisis;
	}

	public void setListaCuentaAnalisis(List<SelectItem> listaCuentaAnalisis) {
		this.listaCuentaAnalisis = listaCuentaAnalisis;
	}

	public String getTAB_DEFAULT() {
		return TAB_DEFAULT;
	}

	public String getTAB_MANT_PARAM_DIARIO() {
		return TAB_MANT_PARAM_DIARIO;
	}

	public String getTAB_MANT_ANALISIS() {
		return TAB_MANT_ANALISIS;
	}

	public String getTAB_MANT_CUENTAS() {
		return TAB_MANT_CUENTAS;
	}

	public List<ConfigProductoBean> getItemsProductoBean() {
		return itemsProductoBean;
	}

	public void setItemsProductoBean(List<ConfigProductoBean> itemsProductoBean) {
		this.itemsProductoBean = itemsProductoBean;
	}

	public List<ConfigAnalisisBean> getItemsAnalisisBean() {
		return itemsAnalisisBean;
	}

	public void setItemsAnalisisBean(List<ConfigAnalisisBean> itemsAnalisisBean) {
		this.itemsAnalisisBean = itemsAnalisisBean;
	}
	
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/