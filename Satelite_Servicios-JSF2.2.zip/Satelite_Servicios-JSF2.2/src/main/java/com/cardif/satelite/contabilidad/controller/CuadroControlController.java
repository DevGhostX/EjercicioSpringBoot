/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.controller;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
//import java.util.Optional;
import java.util.TreeSet;
//import java.util.stream.Collectors;
//import java.util.stream.Collectors.*;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.contabilidad.bean.ConfigAnalisisBean;
import com.cardif.satelite.contabilidad.bean.ConfigCuentaContableBean;
import com.cardif.satelite.contabilidad.bean.ConfigProductoBean;
import com.cardif.satelite.contabilidad.bean.ConsultaCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.CuadroContableBean;
import com.cardif.satelite.contabilidad.bean.DatosCamposLayoutBean;
import com.cardif.satelite.contabilidad.bean.ProcesoCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;
import com.cardif.satelite.contabilidad.service.AsientosActuarialService;
import com.cardif.satelite.cpe.service.UsuarioService;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.tesoreria.service.ProcesoPagos;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;
import com.cardif.sunsystems.bean.AsientoContableBean;
import com.cardif.sunsystems.controller.SunsystemsController;
import com.cardif.sunsystems.util.ConstantesSun;
import com.cardif.sunsystems.util.Utilidades;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.FontFactory;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.*;

@Controller("cuadroControlController")
@Scope("session")
public class CuadroControlController implements Serializable {

	private static final long serialVersionUID = -8323560799344065774L;

	public static final Logger logger = Logger.getLogger(CuadroControlController.class);

	@Autowired(required = true)
	private ParametroService parametroService;

	@Autowired(required = true)
	private UsuarioService usuarioService;

	@Autowired(required = true)
	private ProcesoPagos procesoPagos;
	
	/* Importación de datos*/
	private String tipoCarga; //Estimada = 1 / Real = 2
	private String mensajeValidacionUploadFileE;
	private String mensajeValidacionUploadFileR;
	private String idFileUploadComponentE;
	private String idFileUploadComponentR;
	
	private UploadedFile archivoE;
	private String nombreArchivoE;
	
	private UploadedFile archivoR;
	private String nombreArchivoR;
	
	private List<DatosCamposLayoutBean> resultadoCargaE;
	private List<DatosCamposLayoutBean> resultadoCargaR;
	
	private boolean disabledProcesoE;
	private boolean disabledProcesoR;
	
	private final String TAB_DEFAULT = "tabDatos";
	private final String TAB_CUADRO_SUN = "tabConsultaSun";
	private final String TAB_CUADRO_COMP = "tabCuentaComp";
	private final String TAB_CUADRO_CONTABLE = "tabCuadroContable";
	
	private String tabSeleccionado = TAB_DEFAULT;
	
	Utilidades utiles = null;
	private SunsystemsController controlSun = SunsystemsController.getInstance();
	
	/* Consulta de cuentas a SUN*/
	private String periodoMin;
	private String periodoMax;
	private String cuentaMin;
	private String cuentaMax;
	private List<SelectItem> tiposDiarioItems;
	
	private Collection<Integer> selection;
	private volatile List<AsientoContableBean> resultadoBusqueda;
	private List<List<AsientoContableBean>> splistaProcesos;
	
	private int totalRegistrosFiltro;
	private String totalImporteFiltro;
	private int totalRegistrosFiltroSeleccionados;
	private String totalImporteFiltroSeleccionados;
	private int sumaLineaAsientosErrores = 0;
	private int contAsientosContablesGenerados = 0;
	
	private boolean disabledBusqueda;
	private boolean disabledGrabar;
	private boolean disabledLimpiar;
	private boolean disabledVolver;
	
	private Integer idProcesoCabecera;
	
	private boolean validaExisteCuentaProceso;

	/* Reporte Cuadro Contable*/
	private List<ProcesoCuadroContableBean> listaProcesos;
	private ProcesoCuadroContableBean selectCuadro;
	private List<CuadroContableBean> listaContable;
	private List<ConfigAnalisisBean> listaAnalisisBean;
	private List<SelectItem> listaCuentaAnalisis;
	private String codAnalisis;
	private int totalRegistrosCuadro;
	private String totalImporteSoles;
	private String totalImporteTrans;
	private String totalImporteEstima;
	private String totalImporteReser;
	private String totalImporteTotal;
	private String totalImporteDif;
	private List<ConfigCuentaContableBean> cuentas;

	@Autowired
	private AsientosActuarialService asientosActuarialService;

	@PostConstruct
	public String inicio() {
		try {
			
			//Importación Detalle
			disabledProcesoE = false;
			disabledProcesoR = false;
			
			if (resultadoCargaE != null) {
				resultadoCargaE.clear();
			}
			if (resultadoCargaR != null) {
				resultadoCargaR.clear();
			}
			
			//Consulta Detalle
			periodoMin = "";
			periodoMax = "";
			
			cuentas = asientosActuarialService.obtenerCuentasConfig(new ConfigCuentaContableBean());
			
			cuentaMin = cuentas.get(0).getMinCuenta();
			cuentaMax = cuentas.get(0).getMaxCuenta();
			
			tiposDiarioItems = new ArrayList<SelectItem>();
			tiposDiarioItems.add(new SelectItem("*", "Todos los Tipo Diario"));
			tiposDiarioItems = obtenerTiposDiario();
			
			//validaExisteCuentaProceso = false;
			
			deshabilitarObjetosBus(false, true, false, true);
			
			resultadoBusqueda = new ArrayList<AsientoContableBean>();
			if (resultadoBusqueda != null) {
				resultadoBusqueda.clear();
			}
			
			//Reporte Cuadro Contable
			listaAnalisisBean = asientosActuarialService.itemsConfigAnalisis(new ConfigAnalisisBean());
			selectCuadro = new ProcesoCuadroContableBean();
			listaContable = new ArrayList<CuadroContableBean>();
			listaCuentaAnalisis = obtenerCuentaAnalisis();
			obtenerProcesos();
			
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		return null;
	}
	
	/* INICIO IMPORTACION DE DATOS */
	
	public void deshabilitarObjetosE(boolean disabledProcesoE) {
		this.disabledProcesoE = disabledProcesoE;
	}
	
	public void deshabilitarObjetosR(boolean disabledProcesoR) {
		this.disabledProcesoR = disabledProcesoR;
	}
	
	public void activateTab(ActionEvent ae){
	    String componentId = ae.getComponent().getId();
	    System.out.println("componentId: "+componentId);
	}
	
	public String validarLayoutE(FileUploadEvent event) {
		String respuesta = null;
		tipoCarga = "1";
		try {
			
			// Validar layout
			mensajeValidacionUploadFileE = "";
			archivoE = event.getUploadedFile();
			nombreArchivoE = archivoE.getName();
			
			mensajeValidacionUploadFileE = asientosActuarialService.validarDatosCamposLayout(archivoE, nombreArchivoE, tipoCarga);
			if (mensajeValidacionUploadFileE != null) {
				clearUploadE();
				FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, mensajeValidacionUploadFileE, null);
				return null;
			} else {
				mensajeValidacionUploadFileE = null;
			}

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			mensajeValidacionUploadFileE = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_CARGA_EXCEL);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
			clearUploadE();
		}
		return respuesta;
	}
	
	public String validarLayoutR(FileUploadEvent event) {
		String respuesta = null;
		tipoCarga = "2";
		try {
			
			// Validar layout
			mensajeValidacionUploadFileR = "";
			archivoR = event.getUploadedFile();
			nombreArchivoR = archivoR.getName();
			
			mensajeValidacionUploadFileR = asientosActuarialService.validarDatosCamposLayout(archivoR, nombreArchivoR, tipoCarga);
			if (mensajeValidacionUploadFileR != null) {
				clearUploadR();
				FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, mensajeValidacionUploadFileR, null);
				return null;
			} else {
				mensajeValidacionUploadFileR = null;
			}

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			mensajeValidacionUploadFileR = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_CARGA_EXCEL);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
			clearUploadR();
		}
		return respuesta;
	}
	
	public Integer grabarProcesoCabecera() {
		
		try {
			ProcesoCuadroContableBean beanProceso = new ProcesoCuadroContableBean();
			DateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
			String nombreProceso = "Reporte de Cuadro Contable - "+formato.format(new Date());
			beanProceso.setNombreProceso(nombreProceso);
			beanProceso.setUsuarioRegistro(FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString());
			idProcesoCabecera = asientosActuarialService.insertarProceso(beanProceso);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
		return idProcesoCabecera;
	}
	
	public String procesarDatosE() {
		String respuesta = null;
		try {
			// Validar formulario
			validarFormularioE();
			
			// Leer archivo layout
			List<DatosCamposLayoutBean> lista = new ArrayList<DatosCamposLayoutBean>();
			
			lista = (List<DatosCamposLayoutBean>) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(Constantes.KEY_LIST_DATOSE_XLSX);
			
			// Grabar cabecera del proceso de cuadro contable
			if(idProcesoCabecera==null) {
				idProcesoCabecera = grabarProcesoCabecera();
			}
			// ---------
			
			resultadoCargaE = asientosActuarialService.insertarDatos(lista, idProcesoCabecera); // registra carga de datos en BD
			
			if(resultadoCargaE.size()==0) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ocurrió un error Proceso de datos, consultar al administrador");
			}
			
			// Generar asientos contables
			if (mensajeValidacionUploadFileE != null) {
				FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					 null);
				FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			}
			deshabilitarObjetosE(true);
			obtenerProcesos();

		} catch (SyncconException ex) {
			ex.printStackTrace();
			logger.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String procesarDatosR() {
		String respuesta = null;
		try {
			// Validar formulario
			validarFormularioR();
			
			// Leer archivo layout
			List<DatosCamposLayoutBean> lista = new ArrayList<DatosCamposLayoutBean>();
			
			lista = (List<DatosCamposLayoutBean>) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(Constantes.KEY_LIST_DATOSR_XLSX);
			
			// Grabar cabecera del proceso de cuadro contable
			if(idProcesoCabecera==null) {
				idProcesoCabecera = grabarProcesoCabecera();
			}
			// ---------
			
			resultadoCargaR = asientosActuarialService.insertarDatos(lista, idProcesoCabecera); // registra carga de datos en BD
			
			if(resultadoCargaR.size()==0) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ocurrió un error Proceso de datos, consultar al administrador");
			}
			
			// Generar asientos contables
			if (mensajeValidacionUploadFileR != null) {
				FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					 null);
				FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			}
			deshabilitarObjetosR(true);
			obtenerProcesos();

		} catch (SyncconException ex) {
			ex.printStackTrace();
			logger.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	private void validarFormularioE() throws SyncconException {

		// Validar que se haya cargado archivo
		if (archivoE == null) {
			throw new SyncconException(ErrorConstants.COD_ERROR_CARGAR_LAYOUT, FacesMessage.SEVERITY_INFO);
		}
	}
	
	private void validarFormularioR() throws SyncconException {

		// Validar que se haya cargado archivo
		if (archivoR == null) {
			throw new SyncconException(ErrorConstants.COD_ERROR_CARGAR_LAYOUT, FacesMessage.SEVERITY_INFO);
		}
	}
	
	public String clearUploadR() {
		String respuesta = null;
		try {
			if (archivoR != null) {
				//if (archivoR.exists()) {
					archivoR.delete();
				//}
				archivoR = null;
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String clearUploadE() {
		String respuesta = null;
		try {
			if (archivoE != null) {
				//if (archivoR.exists()) {
					archivoE.delete();
				//}
				archivoE = null;
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String mostrarMensajeUploadFileE() {
		String respuesta = null;
		try {
			if (mensajeValidacionUploadFileE != null) {
				clearUploadE();
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO, mensajeValidacionUploadFileE);
				mensajeValidacionUploadFileE = null;
				idFileUploadComponentE = "uploaderE";
			} else {
				idFileUploadComponentE = "txtHiddenE";
			}

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String mostrarMensajeUploadFileR() {
		String respuesta = null;
		try {
			if (mensajeValidacionUploadFileR != null) {
				clearUploadR();
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO, mensajeValidacionUploadFileR);
				mensajeValidacionUploadFileR = null;
				idFileUploadComponentR = "uploaderR";
			} else {
				idFileUploadComponentR = "txtHiddenR";
			}

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	/** Limpia los valores del formulario */
	public String limpiarFormularioDatosE() {
		String respuesta = null;
		try {
					
			if(idProcesoCabecera!=null) {
				ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
				proceso.setIdProceso(idProcesoCabecera);
				
				proceso.setTipoCarga("1");
				asientosActuarialService.borraDatosxProceso(proceso);
				
				if(resultadoCargaE!=null && resultadoCargaR==null) {
					
					//Se resta los montos del balance
					asientosActuarialService.borrarImportesBalance(proceso);
					
					//Se borran las nuevas cuentas (importe  = 0)
					asientosActuarialService.borrarCuentasBalance(proceso);
					
					asientosActuarialService.borraConsultasxProceso(proceso);
					
					asientosActuarialService.borraProceso(proceso);
					idProcesoCabecera = null;
					limpiarFiltros();
				}
				limpiarFormularioE();
			}
			
			// Inicializar variables
			archivoE = null;
			if (resultadoCargaE != null) {
				resultadoCargaE.clear();
				resultadoCargaE = null;
			}
					
			deshabilitarObjetosE(false);
			obtenerProcesos();

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String limpiarFormularioDatosR() {
		String respuesta = null;
		try {
					
			if(idProcesoCabecera!=null) {
				ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
				proceso.setIdProceso(idProcesoCabecera);
				
				proceso.setTipoCarga("2");
				asientosActuarialService.borraDatosxProceso(proceso);
				
				if(resultadoCargaE==null && resultadoCargaR!=null) {
					//Se resta los montos del balance
					asientosActuarialService.borrarImportesBalance(proceso);
					
					//Se borran las nuevas cuentas (importe  = 0)
					asientosActuarialService.borrarCuentasBalance(proceso);
					
					asientosActuarialService.borraConsultasxProceso(proceso);
					
					asientosActuarialService.borraProceso(proceso);
					idProcesoCabecera = null;
					limpiarFiltros();
				}
				limpiarFormularioR();
			}
			
			// Inicializar variables		
			archivoR = null;
			if (resultadoCargaR != null) {
				resultadoCargaR.clear();
				resultadoCargaR = null;
			}
			
			deshabilitarObjetosR(false);
			obtenerProcesos();

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String limpiarFormularioE() {
		String respuesta = null;
		try {
			// Inicializar variables
			archivoE = null;
			if (resultadoCargaE != null) {
				resultadoCargaE.clear();
			}
			deshabilitarObjetosE(false);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String limpiarFormularioR() {
		String respuesta = null;
		try {
			// Inicializar variables
			archivoR = null;
			if (resultadoCargaR != null) {
				resultadoCargaR.clear();
			}
			deshabilitarObjetosR(false);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public void borrarProceso() {
		try {
			if(selectCuadro.getIdProceso()!=null) {
				ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
				proceso.setIdProceso(selectCuadro.getIdProceso());
				//logger.info("id proceso a borrar: "+selectCuadro.getIdProceso());
				
				//Se borran los datos
				proceso.setTipoCarga("1");
				asientosActuarialService.borraDatosxProceso(proceso);
				
				proceso.setTipoCarga("2");
				asientosActuarialService.borraDatosxProceso(proceso);
				
				//Se resta los montos del balance
				asientosActuarialService.borrarImportesBalance(proceso);
				
				//Se borran las nuevas cuentas (importe  = 0)
				asientosActuarialService.borrarCuentasBalance(proceso);
				
				//Se borra la busqueda en Sun
				asientosActuarialService.borraConsultasxProceso(proceso);
				
				//Se borra el proceso
				asientosActuarialService.borraProceso(proceso);
				
				obtenerProcesos();
				if(idProcesoCabecera==selectCuadro.getIdProceso() || periodoMin.equals(selectCuadro.getPeriodo())) {
					idProcesoCabecera = null;
					limpiarFiltros();
					limpiarFormularioE();
					limpiarFormularioR();
				}
				
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void cerrarProceso() {
		try {
			if(selectCuadro.getIdProceso()!=null) {
				ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
				proceso.setIdProceso(selectCuadro.getIdProceso());
				proceso.setPeriodo(selectCuadro.getPeriodo());
				//logger.info("id proceso a borrar: "+selectCuadro.getIdProceso());
				
				asientosActuarialService.cierreImportesFinal(proceso);
				
				asientosActuarialService.cierreProcesoFinal(proceso);
				
				asientosActuarialService.borrarConsultasxPeriodo(proceso);
				asientosActuarialService.borrarDatosxPeriodo(proceso);
				asientosActuarialService.borrarProcesoxPeriodo(proceso);
				
				obtenerProcesos();
				if(idProcesoCabecera==selectCuadro.getIdProceso() || selectCuadro.getPeriodo().equals(periodoMin)) {
					idProcesoCabecera = null;
					limpiarFiltros();
					limpiarFormularioE();
					limpiarFormularioR();
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void cancelarE() {
		logger.info("Cancela limpiar datos estimados...");
		deshabilitarObjetosE(true);
	}
	
	public void cancelarR() {
		logger.info("Cancela limpiar datos reales...");
		deshabilitarObjetosR(true);
	}
	
	public void cancelarProc() {
		logger.info("Cancela borrar proceso...");
	}
	
	public void mostrarPanelE() {
		logger.info("Mostrar panel de limpiar datos estimados...");
		//limpiarFormularioE();
	}
	
	public void mostrarPanelR() {
		logger.info("Mostrar panel de limpiar datos reales...");
		//limpiarFormularioR();
	}
	
	/* FIN IMPORTACION DE DATOS */
	
	/* INICIO BUSQUEDA DE CUENTAS EN SUN */
	public String consultarCuentas() {
		String msjError;
		//logger.info("Inicio");
		String respuesta = null;
		try {
			
			if (!validarObligatoriosBuscar()) {
				msjError = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_VALIDA_OBLIG_BUSQ_CUENTA);
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, msjError);
				respuesta = null;
			} else {
				ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
				proceso.setPeriodo(periodoMin);
				Integer countPer = asientosActuarialService.validarExistePeriodo(proceso);
				if(countPer>0) {
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "El periodo a consultar, ya fue procesado");
					deshabilitarObjetosBus(false, true, false, true);
					resultadoBusqueda = new ArrayList<AsientoContableBean>();
					respuesta = null;
				}else {
					String[] arrayTipoDiario = new String [tiposDiarioItems.size()];
					arrayTipoDiario = traerTiposDiario();
					/*if(!tipoDiario.equals("*")) {
						arrayTipoDiario = new String[1];
						arrayTipoDiario[0] = tipoDiario;
					}*/
					//logger.info("cuentaMin: "+cuentaMin);
					//logger.info("cuentaMax: "+cuentaMax);
					splistaProcesos = procesoPagos.consultarCuentasContabilidad(periodoMin, periodoMax, cuentaMin, cuentaMax, arrayTipoDiario);
					
					resultadoBusqueda = ProcesarSuperlista(splistaProcesos);
					if(resultadoBusqueda==null) resultadoBusqueda = new ArrayList<AsientoContableBean>();
	
					if (resultadoBusqueda.size() != 0) {
						
						/*if(idProcesoCabecera!=null) {
							ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
							proceso.setIdProceso(idProcesoCabecera);
							Integer count = asientosActuarialService.validarExisteCuentasProceso(proceso);
							if(count>0) {
								validaExisteCuentaProceso = true;
							}else {
								validaExisteCuentaProceso = false;
							}
						}*/
						deshabilitarObjetosBus(false, false, false, true);
					} else {
						deshabilitarObjetosBus(false, true, false, true);
					}
					
					obtenerImportesFiltro();
					
					if(resultadoBusqueda.size()==0) {
						SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "No existe información para la busqueda");
						respuesta = null;
					}
				}
			}
		} catch (Exception e) {
			logger.error("Hay un error");
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = "error";
		}
		//logger.info("Fin");

		return respuesta;
	}
	
	private List<AsientoContableBean> ProcesarSuperlista(List<List<AsientoContableBean>> splistaProcesos2) {
		List<AsientoContableBean> retorno = new ArrayList<AsientoContableBean>();

		for (int i = 0; i < splistaProcesos2.size(); i++) {
			List<AsientoContableBean> aa = splistaProcesos2.get(i);
			retorno.addAll(aa);
		}
		
		//agrupa por cuenta y suma los importes de soles y transaccion
		/*List<AsientoContableBean> transform = retorno.stream()
	               .collect(Collectors.groupingBy(foo -> foo.getCuentaContable()))
	               .entrySet().stream()
	               .map(e -> e.getValue().stream()
	                   .reduce((f1,f2) -> new AsientoContableBean(f1.getCuentaContable(),
	                		   f1.getImporteTransaccion().doubleValue() + f2.getImporteTransaccion().doubleValue(),
	                		   f1.getImporteSoles().doubleValue() + f2.getImporteSoles().doubleValue())))
	                   .map(f -> f.get())
	                   .collect(Collectors.toList());*/
		/*retorno.stream().collect(Collectors.groupingBy(foo -> foo.getCuentaContable(), Collectors.collectingAndThen(Collectors.reducing(
			     (a,b)-> new AsientoContableBean(a.getCuentaContable(), 
			    		 a.getImporteTransaccion().doubleValue()+b.getImporteTransaccion().doubleValue(), 
			    		 a.getImporteSoles().doubleValue()+b.getImporteSoles().doubleValue())),
			         Optional::get)))
			     .forEach((id,foo)->System.out.println(foo));*/

		
		//Ordenar por tipoDiario/numDiario/Referencia/Importe
		Collections.sort(retorno, new Comparator<AsientoContableBean>() {
			public int compare(AsientoContableBean a1, AsientoContableBean a2) {
				int comp;
				//retorno = a1.getTipoDiario().compareToIgnoreCase(a2.getTipoDiario());
				//if(retorno == 0)
					//retorno = String.valueOf(a1.getDiario()).compareTo(String.valueOf(a2.getDiario()));
				//if(retorno == 0)
				comp = a1.getCuentaContable().compareTo(a2.getCuentaContable());
				if(comp == 0)
					comp = a1.getDescripcion().compareToIgnoreCase(a2.getDescripcion());
				//if(comp == 0)
					//comp = Double.valueOf(Math.abs(a1.getImporteSoles().doubleValue())).compareTo(Double.valueOf(Math.abs(a2.getImporteSoles().doubleValue())));
				return comp;
			}
		});
		//--------
		
		//agrupar y sumar obsoleto pero eficiente...
		List<AsientoContableBean> retornoTmp = new ArrayList<AsientoContableBean>();
		String cuentaTmp = "";
		String descripcionTmp = "";
		String monedaTmp = "";
		String tipoDiarioTmp = "";
		String periodoTmp = "";
		int numDiarioTmp = 0;
		String referenciaTmp = "";
		String marcadorDcTmp = "";
		double impTrxTmp = 0;
		double impBaseTmp = 0;
		double sumImpTrxTmp = 0;
		double sumImpBaseTmp = 0;
		int i = 0;
		int tam = retorno.size();
		for(AsientoContableBean asiento:retorno) {
			AsientoContableBean asientoTmp = new AsientoContableBean();
			if(cuentaTmp.equals(asiento.getCuentaContable())) {
				sumImpTrxTmp = impTrxTmp + asiento.getImporteTransaccion().doubleValue();
				sumImpBaseTmp = impBaseTmp + asiento.getImporteSoles().doubleValue();
			}else {
				if(i>0) {
					asientoTmp.setImporteTransaccion(new BigDecimal(sumImpTrxTmp));
					asientoTmp.setImporteSoles(new BigDecimal(sumImpBaseTmp));
					asientoTmp.setCuentaContable(cuentaTmp);
					asientoTmp.setDescripcion(descripcionTmp);
					asientoTmp.setMoneda(monedaTmp);
					asientoTmp.setTipoDiario(tipoDiarioTmp);
					asientoTmp.setDiario(numDiarioTmp);
					asientoTmp.setReferencia(referenciaTmp);
					asientoTmp.setMarcadorDC(marcadorDcTmp);
					asientoTmp.setPeriodo(periodoTmp);
					//if(!retornoTmp.contains(asientoTmp))
						retornoTmp.add(asientoTmp);
				}
				sumImpTrxTmp = asiento.getImporteTransaccion().doubleValue();
				sumImpBaseTmp = asiento.getImporteSoles().doubleValue();
			}
			cuentaTmp = asiento.getCuentaContable();
			descripcionTmp = asiento.getDescripcion();
			monedaTmp = asiento.getMoneda();
			tipoDiarioTmp = asiento.getTipoDiario();
			numDiarioTmp = asiento.getDiario();
			referenciaTmp = asiento.getReferencia();
			marcadorDcTmp = asiento.getMarcadorDC();
			periodoTmp = asiento.getPeriodo();
			impTrxTmp = sumImpTrxTmp;
			impBaseTmp = sumImpBaseTmp;
			i++;
			if(i==tam) {
				asientoTmp = new AsientoContableBean();
				asientoTmp.setImporteTransaccion(new BigDecimal(sumImpTrxTmp));
				asientoTmp.setImporteSoles(new BigDecimal(sumImpBaseTmp));
				asientoTmp.setCuentaContable(cuentaTmp);
				//logger.info("description bus: "+descripcionTmp);
				asientoTmp.setDescripcion(descripcionTmp);
				asientoTmp.setMoneda(monedaTmp);
				asientoTmp.setTipoDiario(tipoDiarioTmp);
				asientoTmp.setDiario(numDiarioTmp);
				asientoTmp.setReferencia(referenciaTmp);
				asientoTmp.setMarcadorDC(marcadorDcTmp);
				asientoTmp.setPeriodo(periodoTmp);
				//if(!retornoTmp.contains(asientoTmp))
					retornoTmp.add(asientoTmp);
			}
		}
		//------
		
		//return retorno;
		return retornoTmp;
	}
	
	public boolean validarObligatoriosBuscar() {
		boolean resultValidar = false;

		//if ((periodoMin == null) || periodoMax == null) {
		if ((periodoMin == null)) {
			resultValidar = false;
		} else {
			//if ((periodoMin.trim().length()==0) || (periodoMax.trim().length()==0)) {
			if ((periodoMin.trim().length()==0)) {
				resultValidar = false;
			}else {
				/*if ((cuentaMin == null) || cuentaMax == null) {
					resultValidar = false;
				} else {
					if ((cuentaMin.trim().length()==0) || (cuentaMax.trim().length()==0)) {
						resultValidar = false;
					}else {
						resultValidar = true;
					}
				}*/
				resultValidar = true;
			}
		}
		
		return resultValidar;
	}
	
	private List<SelectItem> obtenerTiposDiario() throws Exception {
		List<Parametro> tiposDiario = parametroService.buscarTipoDiario(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE);
		if (tiposDiario != null && tiposDiario.size() > 0) {
			for (Parametro p : tiposDiario) {
				tiposDiarioItems.add(new SelectItem(p.getCodValor(), p.getCodValor()));
			}
		}
		return tiposDiarioItems;
	}
	
	private String[] traerTiposDiario() {
		List<Parametro> tiposDiario = parametroService.buscarTipoDiario(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE);
		String[] arrayTipoDiario = new String[tiposDiario.size()];
		if (tiposDiario != null && tiposDiario.size() > 0) {
			int i = 0;
			for (Parametro p : tiposDiario) {
				arrayTipoDiario[i] = p.getCodValor();
				i++;
			}
		}
		return arrayTipoDiario;
	}
	
	private void obtenerImportesFiltro() {
		int cantidadTotal = 0;
		BigDecimal importeTotaFiltro = new BigDecimal("0");
		if (resultadoBusqueda != null && resultadoBusqueda.size() > 0) {
			for (AsientoContableBean asiento : resultadoBusqueda) {
				cantidadTotal = cantidadTotal + 1;
				importeTotaFiltro = importeTotaFiltro.add(asiento.getImporteSoles());
			}
		}
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		DecimalFormat formateador = (DecimalFormat) nf;
		formateador.applyPattern("###,###.##");

		totalImporteFiltro = formateador.format(importeTotaFiltro) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		logger.debug("totalImporteFiltro: " + totalImporteFiltro + " local" + Locale.US.toString());
		totalRegistrosFiltro = cantidadTotal;
	}
	
	private void obtenerImportesFiltroSeleccionados() {
		int cantidadTotal = 0;
		BigDecimal importeTotaFiltro = new BigDecimal("0");
		if (resultadoBusqueda != null && resultadoBusqueda.size() > 0) {
			for (AsientoContableBean asiento : resultadoBusqueda) {
				if (asiento.isSeleccionado()) {
					cantidadTotal = cantidadTotal + 1;
					importeTotaFiltro = importeTotaFiltro.add(asiento.getImporteSoles());
				}
			}
		}
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		DecimalFormat formateador = (DecimalFormat) nf;
		formateador.applyPattern("###,###.##");
		totalImporteFiltroSeleccionados = formateador.format(importeTotaFiltro) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalRegistrosFiltroSeleccionados = cantidadTotal;
	}
	
	public String limpiarFiltros() {
		//logger.info("Inicio");
		String respuesta = null;
		try {

			if (selection != null) {
				selection.clear();
			}

			resultadoBusqueda = new ArrayList<AsientoContableBean>();
			periodoMin = ConstantesSun.UTL_CHR_VACIO;
			periodoMax = ConstantesSun.UTL_CHR_VACIO;
			//cuentaMin = ConstantesSun.UTL_CHR_VACIO;
			//cuentaMax = ConstantesSun.UTL_CHR_VACIO;
			totalRegistrosFiltro = 0;
			totalRegistrosFiltroSeleccionados = 0;
			totalImporteFiltro = "";
			
			if (resultadoBusqueda != null) {
				resultadoBusqueda.clear();
			}
			
			//validaExisteCuentaProceso = false;
			
			deshabilitarObjetosBus(false, true, false, true);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		//logger.info("Fin");
		return respuesta;
	}
	
	public void guardarBusqueda() {
		try {
			if(idProcesoCabecera!=null) {
				if(resultadoBusqueda!=null) {
					if(resultadoBusqueda.size()>0) {
						//Guarda la busqueda del periodo
						asientosActuarialService.guardarBusqueda(resultadoBusqueda, idProcesoCabecera);
						
						//Actualiza el periodo en el proceso
						ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
						proceso.setIdProceso(idProcesoCabecera);
						//String periodoSave = resultadoBusqueda.get(0).getPeriodo();
						String periodoSave = periodoMin;
						//System.out.println("periodoSave: "+periodoSave);
						if(periodoSave.length()<7) {
							if(periodoSave.length()==5) { 
								periodoSave = "00"+periodoSave;
							}else {
								if(periodoSave.length()==6) { 
									periodoSave = "0"+periodoSave;
								}
							}
						}
						proceso.setPeriodo(periodoSave);
						asientosActuarialService.actualizarPeriodoProceso(proceso);
						//--------
						
						//Actualiza importes en el balance
						asientosActuarialService.actualizarImportesBalance(proceso);
						//-------
						
						//validaExisteCuentaProceso = true;
						
						deshabilitarObjetosBus(true, true, true, false);
						
						obtenerProcesos();
						
						SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO, "Los Datos se grabaron correctamente");
					}else {
						SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "No existe información a grabar");
					}
				}else {
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "No existe información a grabar");
				}
			}else {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Se requiere previamente la importación de datos");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void volverBusqueda() {
		try {
			//deshabilitarObjetosBus(false, true, false, true);
			ProcesoCuadroContableBean proceso = new ProcesoCuadroContableBean();
			proceso.setIdProceso(idProcesoCabecera);
			
			//Se resta los montos del balance
			asientosActuarialService.borrarImportesBalance(proceso);
			
			//Se borran las nuevas cuentas (importe  = 0)
			asientosActuarialService.borrarCuentasBalance(proceso);
			
			asientosActuarialService.borraConsultasxProceso(proceso);
			limpiarFiltros();
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void deshabilitarObjetosBus(boolean disabledBusqueda, boolean disabledGrabar, boolean disabledLimpiar, boolean disabledVolver) {
		this.disabledBusqueda = disabledBusqueda;
		this.disabledGrabar = disabledGrabar;
		this.disabledLimpiar = disabledLimpiar;
		this.disabledVolver = disabledVolver;
	}
	/* FIN BUSQUEDA DE CUENTAS EN SUN */
	
	/* INICIO COMPARACION DE CUENTAS "mreservas" */
	
	/* FIN COMPARACION DE CUENTAS "mreservas" */
	
	/* INICIO REPORTTE DE CUADRO CONTROL */
	public void obtenerProcesos() {
		listaProcesos = asientosActuarialService.obtenerProcesosCC();
	}
	
	public void generarCuadroContable() {
		CuadroContableBean bean = null;
		listaContable = new ArrayList<CuadroContableBean>();
		//System.out.println("codAnalisis: "+codAnalisis);
		//System.out.println("selectCuadro.getIdProceso(): "+selectCuadro.getIdProceso());
		if(codAnalisis!=null) {
			if(!codAnalisis.equals("*")) {
				ConfigAnalisisBean beanAnalisis = new ConfigAnalisisBean();
				beanAnalisis.setParamAnalisis(codAnalisis);
				List<ConfigAnalisisBean> listaAnalisisBeanTmp = asientosActuarialService.listarConfigAnalisis(beanAnalisis);
			
				for(ConfigAnalisisBean prodBean:listaAnalisisBeanTmp) {
					bean = new CuadroContableBean();
					bean.setIdProceso(selectCuadro.getIdProceso());
					bean.setCodAnalisis(prodBean.getParamAnalisis());
					//String nameLista = "nameListaCuenta"+String.valueOf(Integer.valueOf(prodBean.getParamAnalisis()));
					//String nameAnalisis = "nameAnalisis"+String.valueOf(Integer.valueOf(prodBean.getParamAnalisis()));
					String nameLista = "nameListaCuenta";
					String nameAnalisis = "nameAnalisis";
					listaContable = asientosActuarialService.obtenerCuadroContable(bean);
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(nameLista, listaContable);
					FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(nameAnalisis, prodBean.getParamDescripcion());
					obtenerImportesCuadro();
				}
			}else {
				listaContable = new ArrayList<CuadroContableBean>();
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("nameListaCuenta", new ArrayList<CuadroContableBean>());
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("nameAnalisis", "");
			}
		}else {
			listaContable = new ArrayList<CuadroContableBean>();
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("nameListaCuenta", new ArrayList<CuadroContableBean>());
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("nameAnalisis", "");
		}
	}
	
	private List<SelectItem> obtenerCuentaAnalisis() throws Exception {
		listaCuentaAnalisis = new ArrayList<SelectItem>();
		listaCuentaAnalisis.add(new SelectItem("*", "Seleccionar..."));
		if (listaAnalisisBean != null && listaAnalisisBean.size() > 0) {
			for (ConfigAnalisisBean p : listaAnalisisBean) {
				listaCuentaAnalisis.add(new SelectItem(p.getParamAnalisis(),p.getParamDescripcion()));
			}
		}
		return listaCuentaAnalisis;
	}
	
	private void obtenerImportesCuadro() {
		int cantidadTotal = 0;
		BigDecimal importeTotalSoles = new BigDecimal("0");
		BigDecimal importeTotalTrans = new BigDecimal("0");
		BigDecimal importeTotalEstima = new BigDecimal("0");
		BigDecimal importeTotalReser = new BigDecimal("0");
		BigDecimal importeTotalTotal = new BigDecimal("0");
		BigDecimal importeTotalDif = new BigDecimal("0");
		if (listaContable != null && listaContable.size() > 0) {
			for (CuadroContableBean asiento : listaContable) {
				cantidadTotal = cantidadTotal + 1;
				importeTotalSoles = importeTotalSoles.add(new BigDecimal(asiento.getImpBase()));
				importeTotalTrans = importeTotalTrans.add(new BigDecimal(asiento.getImpTransaccion()));
				importeTotalEstima = importeTotalEstima.add(new BigDecimal(asiento.getImpEstimaciones()));
				importeTotalReser = importeTotalReser.add(new BigDecimal(asiento.getImpReservas()));
				importeTotalTotal = importeTotalTotal.add(new BigDecimal(asiento.getImpTotales()));
				importeTotalDif = importeTotalDif.add(new BigDecimal(asiento.getImpDiferencias()));
			}
		}
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		DecimalFormat formateador = (DecimalFormat) nf;
		formateador.applyPattern("###,###.##");

		totalImporteSoles = formateador.format(importeTotalSoles) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalImporteTrans = formateador.format(importeTotalTrans) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalImporteEstima = formateador.format(importeTotalEstima) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalImporteReser = formateador.format(importeTotalReser) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalImporteTotal = formateador.format(importeTotalTotal) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalImporteDif = formateador.format(importeTotalDif) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		/*logger.debug("totalImporteSoles: " + totalImporteSoles + " local" + Locale.US.toString());
		logger.debug("totalImporteTrans: " + totalImporteTrans + " local" + Locale.US.toString());
		logger.debug("totalImporteEstima: " + totalImporteEstima + " local" + Locale.US.toString());
		logger.debug("totalImporteReser: " + totalImporteReser + " local" + Locale.US.toString());
		logger.debug("totalImporteTotal: " + totalImporteTotal + " local" + Locale.US.toString());
		logger.debug("totalImporteDif: " + totalImporteDif + " local" + Locale.US.toString());*/
		totalRegistrosCuadro = cantidadTotal;
	}
	
	public void exportarTablaCuentaContableExcel(){
		
		SXSSFWorkbook book = new SXSSFWorkbook();
		Sheet sheet = null;
		
		try {
			
			/*if(listaContable.size()==0) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "No existen datos a exportar");
			}else {*/
				sheet = book.createSheet("CONTROL DE RESERVAS Y DIFERIDOS");
				sheet.setColumnWidth(0, 4000);
				sheet.setColumnWidth(1, 15000);
				sheet.setColumnWidth(2, 4000);
				sheet.setColumnWidth(3, 4000);
				sheet.setColumnWidth(4, 4000);
				sheet.setColumnWidth(5, 4000);
				sheet.setColumnWidth(6, 4000);
				sheet.setColumnWidth(7, 4000);
				sheet.setColumnWidth(8, 4000);
				
				// Estilos para cabecera del documento
				CellStyle headStyle = book.createCellStyle();
	
				Font headFont = book.createFont();
				headFont.setFontHeightInPoints((short) 9);
				headFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headFont.setColor(HSSFColor.BLACK.index);
	
				headStyle.setAlignment(CellStyle.ALIGN_CENTER);
				headStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
				headStyle.setBorderTop(CellStyle.BORDER_THIN);
				headStyle.setBorderLeft(CellStyle.BORDER_THIN);
				headStyle.setBorderRight(CellStyle.BORDER_THIN);
				headStyle.setBorderBottom(CellStyle.BORDER_THIN);
				headStyle.setFont(headFont);
				
				// Estilos para el cuerpo del documento
				CellStyle bodyStyle = book.createCellStyle();
	
				Font bodyFont = book.createFont();
				bodyFont.setFontHeightInPoints((short) 9);
				bodyFont.setColor(HSSFColor.BLACK.index);
	
				bodyStyle.setAlignment(CellStyle.ALIGN_CENTER);
				bodyStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
				bodyStyle.setBorderTop(CellStyle.BORDER_THIN);
				bodyStyle.setBorderLeft(CellStyle.BORDER_THIN);
				bodyStyle.setBorderRight(CellStyle.BORDER_THIN);
				bodyStyle.setBorderBottom(CellStyle.BORDER_THIN);
				bodyStyle.setFont(bodyFont);
				
				// Construyendo cuerpo
				int rowPosition = 0;
				int columnPosition = 0;
				int border = 1;
				
				Row row = sheet.createRow(rowPosition);
				
				Cell cell = row.createCell(columnPosition);
				RichTextString val = new XSSFRichTextString("CONTROL DE RESERVAS Y DIFERIDOS AL PERIODO "+selectCuadro.getPeriodo());
				cell.setCellValue(val);
				cell.setCellStyle(headStyle);
				int x = sheet.addMergedRegion(new CellRangeAddress(0,0,0,8));
				//Border para la combinación de celdas
				CellRangeAddress region = sheet.getMergedRegion(sheet instanceof XSSFSheet || sheet instanceof SXSSFSheet ? x - 1 : x);
				Workbook wb = sheet.getWorkbook();
		        RegionUtil.setBorderTop(border, region, sheet, wb);
		        RegionUtil.setBorderLeft(border, region, sheet, wb);
		        RegionUtil.setBorderBottom(border, region, sheet, wb);
		        RegionUtil.setBorderRight(border, region, sheet, wb);
				
				
				rowPosition++;
				row = sheet.createRow(rowPosition);
	
				cell = row.createCell(columnPosition);
				val = new XSSFRichTextString("");
				cell.setCellValue(val);
				x = sheet.addMergedRegion(new CellRangeAddress(rowPosition,rowPosition,0,8));
				//Border para la combinación de celdas
				region = sheet.getMergedRegion(sheet instanceof XSSFSheet || sheet instanceof SXSSFSheet ? x - 1 : x);
		        RegionUtil.setBorderTop(border, region, sheet, wb);
		        RegionUtil.setBorderLeft(border, region, sheet, wb);
		        RegionUtil.setBorderBottom(border, region, sheet, wb);
		        RegionUtil.setBorderRight(border, region, sheet, wb);
				
				List<CuadroContableBean> listaContableTmp = new ArrayList<CuadroContableBean>();
				for(ConfigAnalisisBean beanAnal:listaAnalisisBean) {
				
					rowPosition++;
					row = sheet.createRow(rowPosition);
					
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString(beanAnal.getParamDescripcion());
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					x = sheet.addMergedRegion(new CellRangeAddress(rowPosition,rowPosition,0,8));
					//Border para la combinación de celdas
					region = sheet.getMergedRegion(sheet instanceof XSSFSheet || sheet instanceof SXSSFSheet ? x - 1 : x);
			        RegionUtil.setBorderTop(border, region, sheet, wb);
			        RegionUtil.setBorderLeft(border, region, sheet, wb);
			        RegionUtil.setBorderBottom(border, region, sheet, wb);
			        RegionUtil.setBorderRight(border, region, sheet, wb);
					
					rowPosition++;
					row = sheet.createRow(rowPosition);
					
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("CONTABILIDAD");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition = 5;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("ACTUARIAL");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					x = sheet.addMergedRegion(new CellRangeAddress(rowPosition,rowPosition,0,4));
					//Border para la combinación de celdas
					region = sheet.getMergedRegion(sheet instanceof XSSFSheet || sheet instanceof SXSSFSheet ? x - 1 : x);
			        RegionUtil.setBorderTop(border, region, sheet, wb);
			        RegionUtil.setBorderLeft(border, region, sheet, wb);
			        RegionUtil.setBorderBottom(border, region, sheet, wb);
			        RegionUtil.setBorderRight(border, region, sheet, wb);
					x = sheet.addMergedRegion(new CellRangeAddress(rowPosition,rowPosition,5,8));
					//Border para la combinación de celdas
					region = sheet.getMergedRegion(sheet instanceof XSSFSheet || sheet instanceof SXSSFSheet ? x - 1 : x);
			        RegionUtil.setBorderTop(border, region, sheet, wb);
			        RegionUtil.setBorderLeft(border, region, sheet, wb);
			        RegionUtil.setBorderBottom(border, region, sheet, wb);
			        RegionUtil.setBorderRight(border, region, sheet, wb);
					
					//Empieza el detalle
					rowPosition++;
					columnPosition = 0;
					row = sheet.createRow(rowPosition);
		
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Cod. Cuenta");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
		
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Descripción");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Moneda");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Transacción");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Base");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Estimaciones");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Reservas");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Totales");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("Diferencias");
					cell.setCellValue(val);
					cell.setCellStyle(headStyle);
					
					// DATA
					CuadroContableBean beanCuadro = new CuadroContableBean();
					beanCuadro.setIdProceso(selectCuadro.getIdProceso());
					beanCuadro.setCodAnalisis(beanAnal.getParamAnalisis());
					listaContableTmp = asientosActuarialService.obtenerCuadroContable(beanCuadro);
					double sumaImpTr = 0;
					double sumaImpBa = 0;
					double sumaImpEs = 0;
					double sumaImpRe = 0;
					double sumaImpTo = 0;
					double sumaImpDi = 0;
					for (int i = 0; i < listaContableTmp.size(); i++) {
						//if(!listaContableTmp.get(i).getDescripcion().equals("")) {
						rowPosition++;
						row = sheet.createRow(rowPosition);
						for (int j = 0; j <= 8; j++) {
							cell = row.createCell(j);
							if (j == 0) {
								cell.setCellValue(listaContableTmp.get(i).getCuentaContable());
							} else if (j == 1) {
								cell.setCellValue(listaContableTmp.get(i).getDescripcion());
							} else if (j == 2) {
								cell.setCellValue(listaContableTmp.get(i).getMoneda());
							} else if (j == 3) {
								cell.setCellValue(Utilitarios.formateoMonto(listaContableTmp.get(i).getImpTransaccion()));
							} else if (j == 4) {
								cell.setCellValue(Utilitarios.formateoMonto(listaContableTmp.get(i).getImpBase()));
							} else if (j == 5) {
								cell.setCellValue(Utilitarios.formateoMonto(listaContableTmp.get(i).getImpEstimaciones()));
							} else if (j == 6) {
								cell.setCellValue(Utilitarios.formateoMonto(listaContableTmp.get(i).getImpReservas()));
							} else if (j == 7) {
								cell.setCellValue(Utilitarios.formateoMonto(listaContableTmp.get(i).getImpTotales()));
							} else if (j == 8) {
								cell.setCellValue(Utilitarios.formateoMonto(listaContableTmp.get(i).getImpDiferencias()));
							}
							cell.setCellStyle(bodyStyle);
						}
						sumaImpTr = sumaImpTr + listaContableTmp.get(i).getImpTransaccion();
						sumaImpBa = sumaImpBa + listaContableTmp.get(i).getImpBase();
						sumaImpEs = sumaImpEs + listaContableTmp.get(i).getImpEstimaciones();
						sumaImpRe = sumaImpRe + listaContableTmp.get(i).getImpReservas();
						sumaImpTo = sumaImpTo + listaContableTmp.get(i).getImpTotales();
						sumaImpDi = sumaImpDi + listaContableTmp.get(i).getImpDiferencias();
						//}
					}
					
					columnPosition = 0;
					rowPosition++;
					row = sheet.createRow(rowPosition);
		
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("");
					cell.setCellValue(val);
					//cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("");
					cell.setCellValue(val);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("TOTALES");
					cell.setCellValue(val);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					//val = new XSSFRichTextString();
					cell.setCellValue(Utilitarios.formateoMonto(sumaImpTr));
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					//val = new XSSFRichTextString();
					cell.setCellValue(Utilitarios.formateoMonto(sumaImpBa));
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					//val = new XSSFRichTextString();
					cell.setCellValue(Utilitarios.formateoMonto(sumaImpEs));
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					//val = new XSSFRichTextString();
					cell.setCellValue(Utilitarios.formateoMonto(sumaImpRe));
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					//val = new XSSFRichTextString();
					cell.setCellValue(Utilitarios.formateoMonto(sumaImpTo));
					cell.setCellStyle(headStyle);
					
					columnPosition++;
					cell = row.createCell(columnPosition);
					//val = new XSSFRichTextString();
					cell.setCellValue(Utilitarios.formateoMonto(sumaImpDi));
					cell.setCellStyle(headStyle);
					
					//Linea vacía
					columnPosition = 0;
					rowPosition++;
					row = sheet.createRow(rowPosition);
					cell = row.createCell(columnPosition);
					val = new XSSFRichTextString("");
					cell.setCellValue(val);
					
				}
				
				String fileName = "Cuadro_Contable_"+selectCuadro.getPeriodo()+".xlsx";
	
				HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
				response.addHeader("Content-Disposition", "attachment; filename=" + fileName);
				response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	
				OutputStream out = response.getOutputStream();
				book.write(out);
				out.close();
	
				FacesContext.getCurrentInstance().responseComplete();
			//}
		}catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		
	}
	
	public void exportarTablaCuentaContablePdf() {
		
		logger.info(".....Inicio de impresión de PDF.....");
		
		/*if(listaContable.size()==0) {
			SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "No existen datos a exportar");
		}else {*/
		
			try {
				//Document document = new Document();
				//document.setPageSize(PageSize.A4.rotate());
				Rectangle thispaper = PageSize.A4;
		        Document document = new Document(thispaper.rotate(), 36, 36, 36, 40);
		
				OutputStream ost = new FileOutputStream(System.getProperty("java.io.tmpdir") + "Cuadro_Contable_"+selectCuadro.getPeriodo()+".pdf");
		
				PdfWriter writer = PdfWriter.getInstance(document, ost);
				MyPageEvents events = new CuadroControlController(). new MyPageEvents();
				writer.setPageEvent(events);
		
				document.addAuthor("CARDIF");
				document.addCreationDate();
				document.addProducer();
				document.addCreator("Cardif");
				document.addTitle("Cuadro Contable");
				document.addKeywords("pdf, itext, Java, open source, http");
		
				com.lowagie.text.Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 10, com.lowagie.text.Font.NORMAL);
				com.lowagie.text.Font boldFont = FontFactory.getFont(FontFactory.HELVETICA, 10, com.lowagie.text.Font.BOLD);
				
				//Footer
				HeaderFooter footer =new HeaderFooter(new Phrase(""), false);
				footer.setAlignment(Element.ALIGN_CENTER);
				footer.setBorder(Rectangle.NO_BORDER);
		
				document.setFooter(footer);
				document.open();
				
				String titCab1 = "CONTABILIDAD";
				String titCab2 = "ACTUARIAL";
				String titCabDet1 = "Cod. Cuenta";
				String titCabDet2 = "Descripción";
				String titCabDet3 = "Moneda";
				String titCabDet4 = "Transacción";
				String titCabDet5 = "Base";
				String titCabDet6 = "Estimaciones";
				String titCabDet7 = "Reservas";
				String titCabDet8 = "Totales";
				String titCabDet9 = "Diferencias";
				
				Paragraph cab1 = new Paragraph(titCab1, boldFont);
				Paragraph cab2 = new Paragraph(titCab2, boldFont);
				Paragraph det1 = new Paragraph(titCabDet1, boldFont);
				Paragraph det2 = new Paragraph(titCabDet2, boldFont);
				Paragraph det3 = new Paragraph(titCabDet3, boldFont);
				Paragraph det4 = new Paragraph(titCabDet4, boldFont);
				Paragraph det5 = new Paragraph(titCabDet5, boldFont);
				Paragraph det6 = new Paragraph(titCabDet6, boldFont);
				Paragraph det7 = new Paragraph(titCabDet7, boldFont);
				Paragraph det8 = new Paragraph(titCabDet8, boldFont);
				Paragraph det9 = new Paragraph(titCabDet9, boldFont);
				
				String Page = "PAGE: " + (document.getPageNumber() + 1);
				
				/*Table table = new Table(1, 1);
				com.lowagie.text.Cell cell = new com.lowagie.text.Cell("CONTROL DE RESERVAS Y DIFERIDOS AL PERIODO "+selectCuadro.getPeriodo());
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setVerticalAlignment(Element.ALIGN_TOP);
				cell.setBorder(Rectangle.NO_BORDER);
				cell.setWidth("100%");
				table.addCell(cell);
				document.add(table);*/
				
				PdfPTable datatable = new PdfPTable(1);
				datatable.getDefaultCell().setPadding(3);
				int headerwidthsC[] = { 100 }; // percentage
				datatable.setWidths(headerwidthsC);
				datatable.setWidthPercentage(100); // percentage
				
				datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				datatable.getDefaultCell().setBorderWidth(0);
				datatable.getDefaultCell().setGrayFill(1.0f);
				
				datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				datatable.addCell("CONTROL DE RESERVAS Y DIFERIDOS AL PERIODO "+selectCuadro.getPeriodo());			
				datatable.getDefaultCell().setBorderWidth(0);
				
				document.add(datatable);
				
				List<CuadroContableBean> listaContableTmp = new ArrayList<CuadroContableBean>();
				for(ConfigAnalisisBean beanAnal:listaAnalisisBean) {
				
					datatable = new PdfPTable(1);
					datatable.getDefaultCell().setPadding(3);
					int headerwidths0[] = { 100 }; // percentage
					datatable.setWidths(headerwidths0);
					datatable.setWidthPercentage(100); // percentage
					
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setGrayFill(1.0f);
					
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					datatable.addCell(beanAnal.getParamDescripcion());			
					datatable.getDefaultCell().setBorderWidth(1);
					
					document.add(datatable);
					
					int NumColumns = 2;
					datatable = new PdfPTable(NumColumns);
					
					datatable.getDefaultCell().setPadding(3);
					int headerwidths1[] = { 60, 40 }; // percentage
					datatable.setWidths(headerwidths1);
					datatable.setWidthPercentage(100); // percentage
			
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setGrayFill(1.0f);
					
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					datatable.addCell(cab1);			
					datatable.getDefaultCell().setBorderWidth(1);
					
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					datatable.addCell(cab2);			
					datatable.getDefaultCell().setBorderWidth(1);
					
					//datatable.setHeaderRows(1);
					document.add(datatable);
					
					NumColumns = 9;
					datatable = new PdfPTable(NumColumns);
			
					datatable.getDefaultCell().setPadding(3);
					int headerwidths2[] = { 5, 30, 5, 10, 10, 10, 10, 10, 10 }; // percentage
					datatable.setWidths(headerwidths2);
					datatable.setWidthPercentage(100); // percentage
			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					datatable.getDefaultCell().setGrayFill(1.0f);
					
					datatable.addCell(det1);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det2);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det3);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det4);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det5);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det6);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det7);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det8);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.addCell(det9);			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					
					datatable.setHeaderRows(1);
					
					int i = 0;
					
					//DATA
					CuadroContableBean beanCuadro = new CuadroContableBean();
					beanCuadro.setIdProceso(selectCuadro.getIdProceso());
					beanCuadro.setCodAnalisis(beanAnal.getParamAnalisis());
					listaContableTmp = asientosActuarialService.obtenerCuadroContable(beanCuadro);
					BigDecimal sumaImpTr = new BigDecimal("0");
					BigDecimal sumaImpBa = new BigDecimal("0");
					BigDecimal sumaImpEs = new BigDecimal("0");
					BigDecimal sumaImpRe = new BigDecimal("0");
					BigDecimal sumaImpTo = new BigDecimal("0");
					BigDecimal sumaImpDi = new BigDecimal("0");
					for(CuadroContableBean bean:listaContableTmp) {
						i++;
						
						/*if(i % 18 == 0){
							//doc.add(datatable);						
							document.newPage();				
		
							// Detail
							NumColumns = 9;
							datatable = new PdfPTable(NumColumns);
		
							datatable.getDefaultCell().setPadding(3);
							int headerwidths3[] = { 13,30, 23, 25, 20,20,30}; // percentage
							datatable.setWidths(headerwidths3);
							datatable.setWidthPercentage(100); // percentage
		
							datatable.getDefaultCell().setBorderWidth(1);
							datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
							datatable.getDefaultCell().setGrayFill(0.9f);
							datatable.addCell(bean.getCuentaContable());
							datatable.addCell(bean.getDescripcion());
							datatable.addCell(bean.getMoneda());
							datatable.addCell(DIT4);
							datatable.addCell(DIT5);
							datatable.addCell(DIT6);
							datatable.addCell(DIT7);
							datatable.addCell(DIT7);
							datatable.addCell(DIT7);
							datatable.setHeaderRows(1); // this is the end of the table header
		
							datatable.getDefaultCell().setBorderWidth(1);
		
							document.add(datatable);			
						}*/
						
						if (i % 2 == 1) {
							datatable.getDefaultCell().setGrayFill(1.0f);
						} else {
							datatable.getDefaultCell().setGrayFill(0.9f);
						}
						
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
						datatable.addCell(new Paragraph(bean.getCuentaContable(), normalFont));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
						datatable.addCell(new Paragraph(bean.getDescripcion(), normalFont));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
						datatable.addCell(new Paragraph(bean.getMoneda(), normalFont));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
						datatable.addCell(String.valueOf(Utilitarios.formateoMonto(new BigDecimal(bean.getImpTransaccion()).setScale(2, RoundingMode.CEILING).doubleValue())));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
						datatable.addCell(String.valueOf(Utilitarios.formateoMonto(new BigDecimal(bean.getImpBase()).setScale(2, RoundingMode.CEILING).doubleValue())));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
						datatable.addCell(String.valueOf(Utilitarios.formateoMonto(new BigDecimal(bean.getImpEstimaciones()).setScale(2, RoundingMode.CEILING).doubleValue())));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
						datatable.addCell(String.valueOf(Utilitarios.formateoMonto(new BigDecimal(bean.getImpReservas()).setScale(2, RoundingMode.CEILING).doubleValue())));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
						datatable.addCell(String.valueOf(Utilitarios.formateoMonto(new BigDecimal(bean.getImpTotales()).setScale(2, RoundingMode.CEILING).doubleValue())));
						datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
						datatable.addCell(String.valueOf(Utilitarios.formateoMonto(new BigDecimal(bean.getImpDiferencias()).setScale(2, RoundingMode.CEILING).doubleValue())));
						
						/*if(i % 17 == 0){
							document.add(datatable);						
		
							// Detail
							NumColumns = 9;
							datatable = new PdfPTable(NumColumns);
		
							datatable.getDefaultCell().setPadding(3);
							int headerwidths4[] = { 10,20, 10, 10, 10,10,10,10,10}; // percentage
							datatable.setWidths(headerwidths4);
							datatable.setWidthPercentage(100); // percentage
		
							datatable.getDefaultCell().setBorderWidth(1);
							datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
							datatable.getDefaultCell().setGrayFill(0.9f);
							datatable.addCell(DIT1);
							datatable.addCell(DIT2);
							datatable.addCell(DIT3);
							datatable.addCell(DIT4);
							datatable.addCell(DIT5);
							datatable.addCell(DIT6);
							datatable.addCell(DIT7);
							datatable.addCell(DIT7);
							datatable.addCell(DIT7);
							datatable.setHeaderRows(1); // this is the end of the table header
		
							datatable.getDefaultCell().setBorderWidth(1);
		
							document.add(datatable);
						}*/
						
						sumaImpTr = sumaImpTr.add(new BigDecimal(bean.getImpTransaccion()));
						sumaImpBa = sumaImpBa.add(new BigDecimal(bean.getImpBase()));
						sumaImpEs = sumaImpEs.add(new BigDecimal(bean.getImpEstimaciones()));
						sumaImpRe = sumaImpRe.add(new BigDecimal(bean.getImpReservas()));
						sumaImpTo = sumaImpTo.add(new BigDecimal(bean.getImpTotales()));
						sumaImpDi = sumaImpDi.add(new BigDecimal(bean.getImpDiferencias()));
					}
					
					document.add(datatable);
					
					//Totales
					datatable = new PdfPTable(9);
					
					datatable.getDefaultCell().setPadding(3);
					int headerwidthsT[] = { 10, 20, 10, 10, 10, 10, 10, 10, 10 }; // percentage
					datatable.setWidths(headerwidthsT);
					datatable.setWidthPercentage(100); // percentage
			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					datatable.getDefaultCell().setGrayFill(1.0f);
					
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					datatable.addCell("");
					//datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					datatable.addCell("");			
					//datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					datatable.addCell("Totales");			
					//datatable.getDefaultCell().setBorderWidth(1);
					
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					datatable.addCell(String.valueOf(Utilitarios.formateoMonto(sumaImpTr.setScale(2, RoundingMode.CEILING).doubleValue())));			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					datatable.addCell(String.valueOf(Utilitarios.formateoMonto(sumaImpBa.setScale(2, RoundingMode.CEILING).doubleValue())));			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					datatable.addCell(String.valueOf(Utilitarios.formateoMonto(sumaImpEs.setScale(2, RoundingMode.CEILING).doubleValue())));			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					datatable.addCell(String.valueOf(Utilitarios.formateoMonto(sumaImpRe.setScale(2, RoundingMode.CEILING).doubleValue())));			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					datatable.addCell(String.valueOf(Utilitarios.formateoMonto(sumaImpTo.setScale(2, RoundingMode.CEILING).doubleValue())));			
					datatable.getDefaultCell().setBorderWidth(1);
					datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					datatable.addCell(String.valueOf(Utilitarios.formateoMonto(sumaImpDi.setScale(2, RoundingMode.CEILING).doubleValue())));			
					datatable.getDefaultCell().setBorderWidth(1);
					
					document.add(datatable);
					
					//linea en blanco
					Table table = new Table(1, 1);
					table.setOffset(5);
					table.setBorderWidth(0);
					table.setCellsFitPage(true);
					table.setPadding(0);
					table.setSpacing(0);
					table.setAlignment(Element.ALIGN_MIDDLE);
					table.setWidth(100);
		
					com.lowagie.text.Cell cell = new com.lowagie.text.Cell("");
					cell.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					
					document.add(table);
				}
				document.close();
	            
				File pdfFile = new File(System.getProperty("java.io.tmpdir") + "Cuadro_Contable_"+selectCuadro.getPeriodo()+".pdf");
				ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();
				HttpServletResponse response = (HttpServletResponse) contexto.getResponse();
				FileInputStream pdfIn = new FileInputStream(pdfFile);

				logger.debug("attachment;filename=" + pdfFile.getName());

				IOUtils.copy(pdfIn, response.getOutputStream());
				response.addHeader("Content-Disposition", "attachment;filename=" + pdfFile.getName());
				response.setContentType("application/");
				pdfIn.close();
				FacesContext.getCurrentInstance().responseComplete();
				
	            logger.info(".....Fin de impresión de PDF.....");
			
			}catch(IOException e1) {
				e1.printStackTrace();
			}catch(DocumentException e2) {
				e2.printStackTrace();
			}
		//}
	}
	/* FIN REPORTTE DE CUADRO CONTROL */

	public String getTipoCarga() {
		return tipoCarga;
	}

	public void setTipoCarga(String tipoCarga) {
		this.tipoCarga = tipoCarga;
	}

	public String getMensajeValidacionUploadFileE() {
		return mensajeValidacionUploadFileE;
	}

	public void setMensajeValidacionUploadFileE(String mensajeValidacionUploadFileE) {
		this.mensajeValidacionUploadFileE = mensajeValidacionUploadFileE;
	}

	public String getMensajeValidacionUploadFileR() {
		return mensajeValidacionUploadFileR;
	}

	public void setMensajeValidacionUploadFileR(String mensajeValidacionUploadFileR) {
		this.mensajeValidacionUploadFileR = mensajeValidacionUploadFileR;
	}

	public UploadedFile getArchivoE() {
		return archivoE;
	}

	public void setArchivoE(UploadedFile archivoE) {
		this.archivoE = archivoE;
	}

	public String getNombreArchivoE() {
		return nombreArchivoE;
	}

	public void setNombreArchivoE(String nombreArchivoE) {
		this.nombreArchivoE = nombreArchivoE;
	}

	public UploadedFile getArchivoR() {
		return archivoR;
	}

	public void setArchivoR(UploadedFile archivoR) {
		this.archivoR = archivoR;
	}

	public String getNombreArchivoR() {
		return nombreArchivoR;
	}

	public void setNombreArchivoR(String nombreArchivoR) {
		this.nombreArchivoR = nombreArchivoR;
	}

	public String getIdFileUploadComponentE() {
		return idFileUploadComponentE;
	}

	public void setIdFileUploadComponentE(String idFileUploadComponentE) {
		this.idFileUploadComponentE = idFileUploadComponentE;
	}

	public String getIdFileUploadComponentR() {
		return idFileUploadComponentR;
	}

	public void setIdFileUploadComponentR(String idFileUploadComponentR) {
		this.idFileUploadComponentR = idFileUploadComponentR;
	}

	public List<DatosCamposLayoutBean> getResultadoCargaE() {
		return resultadoCargaE;
	}

	public void setResultadoCargaE(List<DatosCamposLayoutBean> resultadoCargaE) {
		this.resultadoCargaE = resultadoCargaE;
	}

	public List<DatosCamposLayoutBean> getResultadoCargaR() {
		return resultadoCargaR;
	}

	public void setResultadoCargaR(List<DatosCamposLayoutBean> resultadoCargaR) {
		this.resultadoCargaR = resultadoCargaR;
	}

	public boolean isDisabledProcesoE() {
		return disabledProcesoE;
	}

	public void setDisabledProcesoE(boolean disabledProcesoE) {
		this.disabledProcesoE = disabledProcesoE;
	}
	
	public boolean isDisabledProcesoR() {
		return disabledProcesoR;
	}

	public void setDisabledProcesoR(boolean disabledProcesoR) {
		this.disabledProcesoR = disabledProcesoR;
	}

	public String getTabSeleccionado() {
		return tabSeleccionado;
	}

	public void setTabSeleccionado(String tabSeleccionado) {
		this.tabSeleccionado = tabSeleccionado;
	}

	public String getTAB_DEFAULT() {
		return TAB_DEFAULT;
	}

	public String getTAB_CUADRO_SUN() {
		return TAB_CUADRO_SUN;
	}

	public String getTAB_CUADRO_COMP() {
		return TAB_CUADRO_COMP;
	}

	public String getTAB_CUADRO_CONTABLE() {
		return TAB_CUADRO_CONTABLE;
	}

	public Utilidades getUtiles() {
		return utiles;
	}

	public void setUtiles(Utilidades utiles) {
		this.utiles = utiles;
	}

	public SunsystemsController getControlSun() {
		return controlSun;
	}

	public void setControlSun(SunsystemsController controlSun) {
		this.controlSun = controlSun;
	}

	public String getPeriodoMin() {
		return periodoMin;
	}

	public void setPeriodoMin(String periodoMin) {
		this.periodoMin = periodoMin;
	}

	public String getPeriodoMax() {
		return periodoMax;
	}

	public void setPeriodoMax(String periodoMax) {
		this.periodoMax = periodoMax;
	}

	public String getCuentaMin() {
		return cuentaMin;
	}

	public void setCuentaMin(String cuentaMin) {
		this.cuentaMin = cuentaMin;
	}

	public String getCuentaMax() {
		return cuentaMax;
	}

	public void setCuentaMax(String cuentaMax) {
		this.cuentaMax = cuentaMax;
	}

	public List<SelectItem> getTiposDiarioItems() {
		return tiposDiarioItems;
	}

	public void setTiposDiarioItems(List<SelectItem> tiposDiarioItems) {
		this.tiposDiarioItems = tiposDiarioItems;
	}

	public Collection<Integer> getSelection() {
		return selection;
	}

	public void setSelection(Collection<Integer> selection) {
		this.selection = selection;
	}

	public List<AsientoContableBean> getResultadoBusqueda() {
		return resultadoBusqueda;
	}

	public void setResultadoBusqueda(List<AsientoContableBean> resultadoBusqueda) {
		this.resultadoBusqueda = resultadoBusqueda;
	}

	public List<List<AsientoContableBean>> getSplistaProcesos() {
		return splistaProcesos;
	}

	public void setSplistaProcesos(List<List<AsientoContableBean>> splistaProcesos) {
		this.splistaProcesos = splistaProcesos;
	}

	public int getTotalRegistrosFiltro() {
		return totalRegistrosFiltro;
	}

	public void setTotalRegistrosFiltro(int totalRegistrosFiltro) {
		this.totalRegistrosFiltro = totalRegistrosFiltro;
	}

	public String getTotalImporteFiltro() {
		return totalImporteFiltro;
	}

	public void setTotalImporteFiltro(String totalImporteFiltro) {
		this.totalImporteFiltro = totalImporteFiltro;
	}

	public int getTotalRegistrosFiltroSeleccionados() {
		return totalRegistrosFiltroSeleccionados;
	}

	public void setTotalRegistrosFiltroSeleccionados(int totalRegistrosFiltroSeleccionados) {
		this.totalRegistrosFiltroSeleccionados = totalRegistrosFiltroSeleccionados;
	}

	public String getTotalImporteFiltroSeleccionados() {
		return totalImporteFiltroSeleccionados;
	}

	public void setTotalImporteFiltroSeleccionados(String totalImporteFiltroSeleccionados) {
		this.totalImporteFiltroSeleccionados = totalImporteFiltroSeleccionados;
	}

	public int getSumaLineaAsientosErrores() {
		return sumaLineaAsientosErrores;
	}

	public void setSumaLineaAsientosErrores(int sumaLineaAsientosErrores) {
		this.sumaLineaAsientosErrores = sumaLineaAsientosErrores;
	}

	public int getContAsientosContablesGenerados() {
		return contAsientosContablesGenerados;
	}

	public void setContAsientosContablesGenerados(int contAsientosContablesGenerados) {
		this.contAsientosContablesGenerados = contAsientosContablesGenerados;
	}

	public boolean isDisabledBusqueda() {
		return disabledBusqueda;
	}

	public void setDisabledBusqueda(boolean disabledBusqueda) {
		this.disabledBusqueda = disabledBusqueda;
	}

	public boolean isDisabledGrabar() {
		return disabledGrabar;
	}

	public void setDisabledGrabar(boolean disabledGrabar) {
		this.disabledGrabar = disabledGrabar;
	}

	public Integer getIdProcesoCabecera() {
		return idProcesoCabecera;
	}

	public void setIdProcesoCabecera(Integer idProcesoCabecera) {
		this.idProcesoCabecera = idProcesoCabecera;
	}

	public boolean isDisabledLimpiar() {
		return disabledLimpiar;
	}

	public void setDisabledLimpiar(boolean disabledLimpiar) {
		this.disabledLimpiar = disabledLimpiar;
	}

	public boolean isDisabledVolver() {
		return disabledVolver;
	}

	public void setDisabledVolver(boolean disabledVolver) {
		this.disabledVolver = disabledVolver;
	}

	public List<ProcesoCuadroContableBean> getListaProcesos() {
		return listaProcesos;
	}

	public void setListaProcesos(List<ProcesoCuadroContableBean> listaProcesos) {
		this.listaProcesos = listaProcesos;
	}

	public ProcesoCuadroContableBean getSelectCuadro() {
		return selectCuadro;
	}

	public void setSelectCuadro(ProcesoCuadroContableBean selectCuadro) {
		this.selectCuadro = selectCuadro;
	}

	public List<CuadroContableBean> getListaContable() {
		return listaContable;
	}

	public void setListaContable(List<CuadroContableBean> listaContable) {
		this.listaContable = listaContable;
	}

	public List<ConfigAnalisisBean> getListaAnalisisBean() {
		return listaAnalisisBean;
	}

	public void setListaAnalisisBean(List<ConfigAnalisisBean> listaAnalisisBean) {
		this.listaAnalisisBean = listaAnalisisBean;
	}

	public List<SelectItem> getListaCuentaAnalisis() {
		return listaCuentaAnalisis;
	}

	public void setListaCuentaAnalisis(List<SelectItem> listaCuentaAnalisis) {
		this.listaCuentaAnalisis = listaCuentaAnalisis;
	}

	public String getCodAnalisis() {
		return codAnalisis;
	}

	public void setCodAnalisis(String codAnalisis) {
		this.codAnalisis = codAnalisis;
	}

	public int getTotalRegistrosCuadro() {
		return totalRegistrosCuadro;
	}

	public void setTotalRegistrosCuadro(int totalRegistrosCuadro) {
		this.totalRegistrosCuadro = totalRegistrosCuadro;
	}

	public String getTotalImporteSoles() {
		return totalImporteSoles;
	}

	public void setTotalImporteSoles(String totalImporteSoles) {
		this.totalImporteSoles = totalImporteSoles;
	}

	public String getTotalImporteTrans() {
		return totalImporteTrans;
	}

	public void setTotalImporteTrans(String totalImporteTrans) {
		this.totalImporteTrans = totalImporteTrans;
	}

	public String getTotalImporteEstima() {
		return totalImporteEstima;
	}

	public void setTotalImporteEstima(String totalImporteEstima) {
		this.totalImporteEstima = totalImporteEstima;
	}

	public String getTotalImporteReser() {
		return totalImporteReser;
	}

	public void setTotalImporteReser(String totalImporteReser) {
		this.totalImporteReser = totalImporteReser;
	}

	public String getTotalImporteTotal() {
		return totalImporteTotal;
	}

	public void setTotalImporteTotal(String totalImporteTotal) {
		this.totalImporteTotal = totalImporteTotal;
	}

	public String getTotalImporteDif() {
		return totalImporteDif;
	}

	public void setTotalImporteDif(String totalImporteDif) {
		this.totalImporteDif = totalImporteDif;
	}
	
	public List<ConfigCuentaContableBean> getCuentas() {
		return cuentas;
	}

	public void setCuentas(List<ConfigCuentaContableBean> cuentas) {
		this.cuentas = cuentas;
	}
	
	public boolean isValidaExisteCuentaProceso() {
		return validaExisteCuentaProceso;
	}

	public void setValidaExisteCuentaProceso(boolean validaExisteCuentaProceso) {
		this.validaExisteCuentaProceso = validaExisteCuentaProceso;
	}

	class MyPageEvents extends PdfPageEventHelper {

		TreeSet speakers = new TreeSet();

		PdfContentByte cb;

		PdfTemplate template;

		BaseFont bf = null;

		String act = "";

		// we override the onOpenDocument method
		public void onOpenDocument(PdfWriter writer, Document document) {
			try {
				bf =
					BaseFont.createFont(
						BaseFont.HELVETICA,
						BaseFont.CP1252,
						BaseFont.NOT_EMBEDDED);
				cb = writer.getDirectContent();
				template = cb.createTemplate(50, 50);
			} catch (DocumentException de) {
			} catch (IOException ioe) {
			}
		}

		// we override the onChapter method
		public void onChapter(
			PdfWriter writer,
			Document document,
			float paragraphPosition,
			Paragraph title) {
			StringBuffer buf = new StringBuffer();
			for (Iterator i = title.getChunks().iterator(); i.hasNext();) {
				Chunk chunk = (Chunk) i.next();
				buf.append(chunk.getContent());
			}
			act = buf.toString();
		}

		// we override the onEndPage method
		public void onEndPage(PdfWriter writer, Document document) {
			int pageN = writer.getPageNumber();
			String text =
				"                                                                        Pág "
					+ pageN
					+ " de ";
			float len = bf.getWidthPoint(text, 8);
			cb.beginText();
			cb.setFontAndSize(bf, 8);
			cb.setTextMatrix(280, 30);
			cb.showText(text);
			cb.endText();
			cb.addTemplate(template, 280 + len, 30);
			cb.beginText();
			cb.setFontAndSize(bf, 8);
			//cb.setTextMatrix(280, 900);

			/*if (pageN % 2 == 1) {
				cb.showText("Romeo and Juliet");
			}
			else {
				cb.showText(act);
			}*/
			cb.endText();
		}

		// we override the onEndPage method
		public void onStartPage(PdfWriter writer, Document document) {
			int pageN = writer.getPageNumber();
			String text =
				"                                                                        Pág "
					+ pageN
					+ " de ";
			float len = bf.getWidthPoint(text, 8);
			cb.beginText();
			cb.setFontAndSize(bf, 8);
			cb.setTextMatrix(280, 30);
			cb.showText(text);
			cb.endText();
			cb.addTemplate(template, 280 + len, 30);
			cb.beginText();
			cb.setFontAndSize(bf, 8);
			//cb.setTextMatrix(280, 900);

			/*if (pageN % 2 == 1) {
				cb.showText("Romeo and Juliet");
			}
			else {
				cb.showText(act);
			}*/
			cb.endText();
		}

		// we override the onCloseDocument method
		public void onCloseDocument(PdfWriter writer, Document document) {
			template.beginText();
			template.setFontAndSize(bf, 8);
			template.showText(String.valueOf(writer.getPageNumber() - 1));
			template.endText();
		}

		// we add a method to retrieve the glossary
		public TreeSet getSpeakers() {
			return speakers;
		}
	}
	
	public String formatCCY(String num)
	{
		String num2 = "";
		String result = "";
		String sign = "";
		if(num.startsWith("-"))
		{
			sign = num.substring(0, 1);
			num = num.substring(1);
		}
		int posi = num.indexOf(".");
		if(posi > -1)
		{
			int x = num.length();
			// KGarica 02/11/04 Se agrega esta condicion en caso sea "0.0"
			// KGarcia 25/10/04 Se agrega esta condicion en caso sea ".0" 
			//System.out.println("num="+ num + " x="+ x + "posi="+ posi);           
			if (posi == (x-2)){
				if (x >= 4)
					//num2 = num.substring(x - 4, x) + "0";
					num2 = num.substring(x - 2, x) + "0";
				else
					num2 = num.substring(x - 3, x) + "0";
						
				if (x >= 4)
					//num = num.substring(0, x - 4) ;
					num = num.substring(0, x - 2) ;
				else
					num = num.substring(0, x - 3);	
			}else{
				num2 = num.substring(x - 3, x);
				num = num.substring(0, x - 3);		
			} 
		} else
		{
			num2 = ".00";
		}
		//System.out.println("num2="+ num2+ "num="+ num);
		int count = 0;
		int y = num.length() - 1;
		for(int x = y; x > -1; x--)
		{
			char nx = num.charAt(x);
			result = nx + result;
			if((++count == 3 || count == 6 || count == 9 || count == 12) && x > 0)
				result = "," + result;
		}

		result = sign + result + num2;
		//System.out.println("formatCCY="+ result);
		return result;
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/