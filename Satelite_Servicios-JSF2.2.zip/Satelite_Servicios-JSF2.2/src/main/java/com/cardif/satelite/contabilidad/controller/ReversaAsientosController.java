/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.controller;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.contabilidad.bean.AsientoActuarialBean;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;
import com.cardif.satelite.contabilidad.service.AsientosActuarialService;
import com.cardif.satelite.cpe.bean.UsuarioBean;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.service.UsuarioService;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.tesoreria.bean.JournalBean;
import com.cardif.satelite.tesoreria.bean.ResultadoErroresContable;
import com.cardif.satelite.tesoreria.service.ProcesoPagos;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;
import com.cardif.sunsystems.bean.AsientoContableBean;
import com.cardif.sunsystems.controller.SunsystemsController;
import com.cardif.sunsystems.util.ConstantesSun;
import com.cardif.sunsystems.util.Utilidades;

@Controller("reversaAsientosController")
@Scope("session")
public class ReversaAsientosController implements Serializable {
	
	private static final long serialVersionUID = -8323560799344065774L;
	
	public static final Logger logger = Logger.getLogger(ReversaAsientosController.class);
	
	@Autowired(required = true)
	private ParametroService parametroService;
	
	@Autowired(required = true)
	private UsuarioService usuarioService;
	
	@Autowired(required = true)
	private ProcesoPagos procesoPagos;
	
	@Autowired
	private AsientosActuarialService asientosActuarialService;
	
	private boolean pasoValidaciones;
	private boolean disabledSun;
	private boolean disabledReversa;
	private boolean disabledForma;
	private boolean disabledDatosRev;
	private List<AsientoContableBean> listadoContable;
	private List<ReservasCamposLayoutBean> listaReservas;
	private List<AsientoActuarialBean> listaActuarial;
	private String usuario;
	private String tipoDiario;
	private String periodo;
	private Date fechaTrxDesde;
	private Date fechaTrxHasta;
	private String fechaTrxDesdeStr;
	private String fechaTrxHastaStr;
	private String formaReversa;
	
	private List<SelectItem> tiposDiarioItems;
	private List<SelectItem> usuarioItems;
	
	private Collection<Integer> selection;
	private volatile List<AsientoContableBean> resultadoContable;
	private List<List<AsientoContableBean>> splistaProcesos;
	private List<AsientoContableBean> resultadoContableCopy;
	
	private List<ResultadoErroresContable> resultadoErroresContable;
	private List<ResultadoErroresContable> resultadoCorrectosContable;
	private List<ResultadoErroresContable> listaCorrectosAsientoContable;
	private String outText = "";
	private boolean success = false;
	
	private int totalRegistrosFiltro;
	private String totalImporteFiltro;
	private int totalRegistrosFiltroSeleccionados;
	private String totalImporteFiltroSeleccionados;
	private int sumaLineaAsientosErrores = 0;
	private int contAsientosContablesGenerados = 0;
	
	private Boolean seleccionarTodosError;
	private Boolean seleccionarTodosProcesar;
	private Date fechaTrxRev;
	private String fechaTrxRevStr;
	private String periodoRev;
	
	Utilidades utiles = null;
	private SunsystemsController controlSun = SunsystemsController.getInstance();
	
	@PostConstruct
	public String inicio() {
		try {
			
			formaReversa = "0";
			listaReservas = new ArrayList<ReservasCamposLayoutBean>();
			listadoContable = new ArrayList<AsientoContableBean>();
			listaActuarial = new ArrayList<AsientoActuarialBean>();
			tipoDiario = "*";
			usuario = "";
			periodo = "";
			fechaTrxDesde = null;
			fechaTrxHasta = null;
			visualizarFormaReversa();
			
			tiposDiarioItems = new ArrayList<SelectItem>();
			tiposDiarioItems.add(new SelectItem("*", "Seleccionar..."));
			tiposDiarioItems = obtenerTiposDiario();
			
			usuarioItems = new ArrayList<SelectItem>();
			usuarioItems.add(new SelectItem("*", "Seleccionar Usuario"));
			usuarioItems = obtenerUsuarios();
			
			resultadoContable = new ArrayList<AsientoContableBean>();
			resultadoContableCopy = new ArrayList<AsientoContableBean>();
			disabledSun = true;
			
			disabledForma = true;
			deshabilitarObjetos(true, true, true);
			
			if (resultadoContable != null) {
				resultadoContable.clear();
			}
		
		//} catch (SyncconException e) {
			//logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			//logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			logger.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			logger.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		return null;
	}
	
	public void ejecutarSeleccionarTodoProcesar(){
		if(seleccionarTodosProcesar){
			for(AsientoContableBean bean : resultadoContable){
				bean.setSeleccionado(true);
			}
		}else{
			for(AsientoContableBean bean : resultadoContable){
				bean.setSeleccionado(false);
			}
		}
		obtenerImportesFiltroSeleccionados();
	}
	
	public void onchangeCheckboxRegProcesar(){
		AsientoContableBean bean = (AsientoContableBean)FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{proc}", AsientoContableBean.class);
		if(!bean.isSeleccionado()){
			seleccionarTodosProcesar = false;
		}
		obtenerImportesFiltroSeleccionados();
	}
	
	public void deshabilitarObjetos(boolean disabledReversa, boolean disabledSun, boolean disabledDatosRev) {
		this.disabledReversa = disabledReversa;
		this.disabledSun = disabledSun;
		this.disabledDatosRev = disabledDatosRev;
	}
	
	public void visualizarFormaReversa() {
		//System.out.println("entro forma reversa");
		if(formaReversa.equals("0")) {
			disabledForma = true;
			setearFiltrosAutomatico();
		}else {
			disabledForma = false;
			
			setPeriodo(ConstantesSun.UTL_CHR_VACIO);
			fechaTrxDesde = null;
			fechaTrxHasta = null;
			tipoDiario = "*";
			usuario= "";
			//limpiarFiltros();
		}
	}
	
	public void setearFiltrosAutomatico() {
		fechaTrxDesdeStr = "";
		fechaTrxHastaStr = "";
		//tipoDiario = "*";
		Calendar calendar = Calendar.getInstance();
		String mes = (calendar.get(Calendar.MONTH)<10)?("0"+String.valueOf(calendar.get(Calendar.MONTH))):String.valueOf(calendar.get(Calendar.MONTH)); //MONTH empieza en 0
		String anio = String.valueOf(calendar.get(Calendar.YEAR));
		String mmyyyy = mes+anio;
		periodo = "0"+mmyyyy;
		//usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("userSun").toString();
	}
	
	private List<SelectItem> obtenerTiposDiario() throws Exception {
		List<Parametro> tiposDiario = parametroService.buscarTipoDiario(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE);
		if (tiposDiario != null && tiposDiario.size() > 0) {
			for (Parametro p : tiposDiario) {
				tiposDiarioItems.add(new SelectItem(p.getCodValor(), p.getCodValor()));
			}
		}
		return tiposDiarioItems;
	}
	
	private String[] traerTiposDiario() {
		List<Parametro> tiposDiario = parametroService.buscarTipoDiario(Constantes.CONTA_RESERVA_COD_PARAM_SHEET, Constantes.TIP_PARAM_DETALLE);
		String[] arrayTipoDiario = new String[tiposDiario.size()];
		if (tiposDiario != null && tiposDiario.size() > 0) {
			int i = 0;
			for (Parametro p : tiposDiario) {
				arrayTipoDiario[i] = p.getCodValor();
				i++;
			}
		}
		return arrayTipoDiario;
	}
	
	private List<SelectItem> obtenerUsuarios() throws Exception {
		UsuarioBean usu = new UsuarioBean();
		usu.setEstado(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
		List<UsuarioBean> usuarios = usuarioService.listarUsuario(usu);
		if (usuarios != null && usuarios.size() > 0) {
			for (UsuarioBean u : usuarios) {
				usuarioItems.add(new SelectItem(u.getCodigoUsuario(), u.getNombreUsuario()));
			}
		}
		return usuarioItems;
	}
	
	public String consultarProcesos() {
		String msjError;
		logger.info("Inicio");
		String respuesta = null;
		try {
			
			if(formaReversa.equals("0")) { 
				setearFiltrosAutomatico();
			}
			
			if (!validarObligatoriosBuscar()) {
				msjError = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_VALIDA_OBLIG_BUSQ_REVERSA);
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, msjError);
				respuesta = null;
			} else {
				//if (validarFechaTrx()) {
					//procesarFechaTransaccion();
					
					String[] arrayTipoDiario = new String [tiposDiarioItems.size()];
					arrayTipoDiario = traerTiposDiario();
					if(!tipoDiario.equals("*")) {
						arrayTipoDiario = new String[1];
						arrayTipoDiario[0] = tipoDiario;
					}
					
					splistaProcesos = procesoPagos.consultarRegistrosContabilidad(periodo, fechaTrxDesdeStr, fechaTrxHastaStr, arrayTipoDiario, usuario.toUpperCase());
					
					resultadoContable = ProcesarSuperlista(splistaProcesos);
					if(resultadoContable==null) resultadoContable = new ArrayList<AsientoContableBean>();

					if (resultadoContable.size() != 0) {
						deshabilitarObjetos(false, true, true);
					} else {
						deshabilitarObjetos(true, true, true);
					}
					resultadoContableCopy = new ArrayList<AsientoContableBean>(resultadoContable);
					// datosPagoObligRequerid = true;
					// generarTraza(listaCtaBanco, "traza.txt");
					obtenerImportesFiltro();
					//obtenerImportesFiltroSeleccionados();
				//} else {
					//SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "La fecha de inicio no debe ser mayor a la fecha de fin");
					//respuesta = null;
				//}
				resultadoContableCopy = new ArrayList<AsientoContableBean>(resultadoContable);
				
				if(resultadoContableCopy.size()==0) {
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "No existe información para la busqueda");
					respuesta = null;
				}
			}
		} catch (Exception e) {
			logger.error("Hay un error");
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = "error";
		}
		logger.info("Fin");

		return respuesta;
	}
	
	public void reversarAsientos() {
		
		List<AsientoContableBean> resultadoContableTmp = new ArrayList<AsientoContableBean>();
		if(resultadoContable.size()>0) {
			for(AsientoContableBean asiento:resultadoContable) {
				//if(asiento.isSeleccionado()){ // solo se reversan los seleccionados
					BigDecimal importe = asiento.getImporteSoles();
					BigDecimal importeTrans = asiento.getImporteTransaccion();
					String newDescription = "REV("+String.valueOf(asiento.getDiario())+")_"+asiento.getDescripcion();
					if(importe.doubleValue()>0) {
						asiento.setMarcadorDC("C");
					}else {
						asiento.setMarcadorDC("D");
					}
					asiento.setDescripcion(newDescription);
					asiento.setGlosa(newDescription);
					asiento.setImporteSoles(importe.multiply(new BigDecimal("-1")));
					asiento.setImporteTransaccion(importeTrans.multiply(new BigDecimal("-1")));
					resultadoContableTmp.add(asiento);
				//}else {
					//resultadoContableTmp.add(asiento);
				//}
			}
			resultadoContable = new ArrayList<AsientoContableBean>(resultadoContableTmp);
			deshabilitarObjetos(true, false, false);
		}
	}
	
	public String enviarAsientoSun() {
		String respuesta = null;

		try {
			if (resultadoContable == null || resultadoContable.size() == 0) {
				pasoValidaciones = false;
				throw new SyncconException(ErrorConstants.COD_ERROR_VALIDAR_PROCESAR_ASIENTOS,
						FacesMessage.SEVERITY_INFO);
			}

			if (periodoRev == null || fechaTrxRev==null) {
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar Periodo y Fecha de Trx. para el envío de la reversa a SUN");
				respuesta = null;
			}else {
				if(periodoRev.equals("")) {
					SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_WARN, "Ingresar Periodo y Fecha de Trx. para el envío de la reversa a SUN");
					respuesta = null;
				}else {
					
					//procesar fecha de REV
					Calendar fechaInicioCalendar = Calendar.getInstance();
					fechaInicioCalendar.setTime(fechaTrxRev);
					fechaInicioCalendar.set(Calendar.HOUR_OF_DAY, 0);
					fechaInicioCalendar.set(Calendar.MINUTE, 0);
					fechaInicioCalendar.set(Calendar.SECOND, 0);
					fechaInicioCalendar.set(Calendar.MILLISECOND, 0);
					fechaTrxRevStr = Utilitarios.personalizarFecha(fechaTrxRev, "ddMMyyyy");
					Date fechaRev = Utilitarios.convertStringToDate(fechaTrxRevStr, ConstantesSun.UTL_FORMATO_FECHA_SUNSYSTEMS);
					//--------
					
					//procesar periodo
					if(periodoRev.length()<7) {
						if(periodoRev.length()==5) { 
							periodoRev = "00"+periodoRev;
						}else {
							if(periodoRev.length()==6) { 
								periodoRev = "0"+periodoRev;
							}
						}
					}
					//--------
					
					List<Integer> listDiario;
					List<String> resultado = new ArrayList<String>();
					String result;
					int numDiario = 0;
					int numLineaDiario = 0;
					HashMap<Integer, Object> resultadosValidacion = new HashMap<Integer, Object>();
					String retorno = null;
					HashMap<Integer, String> listaErrores = new HashMap<Integer, String>();
					HashMap<Integer, Integer> listaAsientosCorrectos = new HashMap<Integer, Integer>();
					resultadoErroresContable = new ArrayList<ResultadoErroresContable>();
					resultadoCorrectosContable = new ArrayList<ResultadoErroresContable>();
					
					ArrayList<AsientoContableBean> listaAsiento = new ArrayList<AsientoContableBean>();
					int i = 0;
					utiles = new Utilidades();

					/*int tam = Constantes.CONTA_TAMANIO_ENVIO_SUN;
					int num = resultadoContable.size()-tam;
					if(num<0) num = resultadoContable.size();
					else num = tam;
					int x = 0;*/
					for (AsientoContableBean a : resultadoContable) {
						//if(a.isSeleccionado()) { //solo se envian los seleccionados
							
							//numLineaDiario = 0;
							//numDiario = 0;
							a.setPeriodo(periodoRev);
							a.setFecha(fechaRev);
							listaAsiento.add(a);
							i++;
							/*x++;
							if(i==num) {
								result = controlSun.envioSunContabilidad(listaAsiento.get(0).getMoneda(), listaAsiento);
								listDiario = utiles.seteaDiarioAsientoContable(result);
								resultado.add(result);
								if (listDiario.size() > 0) {
									numLineaDiario = listDiario.get(0);
									numDiario = listDiario.get(1);
								}
								if (numDiario != 0) {
									int j = 0;
									while(j<num) {
										resultadoContable.get((x-num)+j).setDiario(numDiario);
										j++;
									}
								}
								listaAsiento = new ArrayList<AsientoContableBean>();
								i = 0;
								num = resultadoContable.size() - x;
								if(num<tam) num = resultadoContable.size() - x;
								else num = tam;
							}*/
							
							/*if (Utilitarios.esPar(i)) {
			
								result = controlSun.envioSunContabilidad(listaAsiento.get(0).getMoneda(), listaAsiento);
								listDiario = utiles.seteaDiarioAsientoContable(result);
								if (listDiario.size() > 0) {
									numLineaDiario = listDiario.get(0);
									numDiario = listDiario.get(1);
								}
								resultado.add(result);
								// }
								if (numDiario != 0) {
									resultadoContable.get(i - 2).setDiario(numDiario);
									resultadoContable.get(i - 1).setDiario(numDiario);
								}
								// se genera una nueva lista para el sgte par de cuentas
								listaAsiento = new ArrayList<AsientoContableBean>();
							}*/
						//}
					}
					
					/* Enviar WS SUN */
					result = controlSun.envioSunContabilidad(listaAsiento.get(0).getMoneda(), listaAsiento);
					listDiario = utiles.seteaDiarioAsientoContable(result);
					resultado.add(result);
					if (listDiario.size() > 0) {
						for(int j=0; j<resultadoContable.size(); j++) {
							numLineaDiario = listDiario.get(0);
							numDiario = listDiario.get(1);
							//resultado.add(result);
							if (numDiario != 0) {
								resultadoContable.get(j).setDiario(numDiario);
							}
						}
					}
					/* **** */

					sumaLineaAsientosErrores = 0;

					for (i = 0; i < resultado.size(); i++) {
						if (i == 0) {
							contAsientosContablesGenerados = 0;
						}
						listaErrores = procesoPagos.procesarResultadoSun(resultado.get(i));

						if (listaErrores.size() > 0) {
							resultadoErroresContable.addAll(procesarHashMapErroresSun(listaErrores, "ERRORES PROCESO SUN"));
							resultadoErroresContable.add(new ResultadoErroresContable());
						} else {
							listaAsientosCorrectos = procesoPagos.procesarResultadoSunExitoso(resultado.get(i));
							resultadoCorrectosContable.addAll(procesarHashMapCorrectosPago(listaAsientosCorrectos));
							resultadoCorrectosContable.add(new ResultadoErroresContable());
							// Actualizo el estado, cheque, banco, cuentaBanco,
							// cuentaContable

							logger.info(listaAsientosCorrectos);
							// desabActualizarM = false;
						}
					}

					for (i = 0; i < resultadoContable.size(); i++) {
						AsientoContableBean item = resultadoContable.get(i);
						if (item == null || item.getCuentaContable() == null) {
							resultadoContable.remove(i);
						}
					}

					listaCorrectosAsientoContable = resultadoCorrectosContable;

					for (i = 0; i < listaCorrectosAsientoContable.size(); i++) {
						ResultadoErroresContable item = listaCorrectosAsientoContable.get(i);
						if (item == null || item.getDiario() == null) {
							listaCorrectosAsientoContable.remove(i);
						}
					}

					if (resultadoErroresContable.size() > 0) {
						success = false;
						pasoValidaciones = true;
						FacesContext context = FacesContext.getCurrentInstance();
						context.getExternalContext().getSessionMap().remove(ConstantesSun.MDP_FEL_CORRELATIVO_GENERADO);
						return null;
					}

					if (resultadoCorrectosContable.size() > 0) {
						success = true;
						pasoValidaciones = true;
						asientosActuarialService.insertaContaAsientosActuarial(resultadoContable, resultadoCorrectosContable);
						limpiarFiltros();
					}
				}
			}

			FacesContext context = FacesContext.getCurrentInstance();
			context.getExternalContext().getSessionMap().remove(ConstantesSun.MDP_FEL_CORRELATIVO_GENERADO);
			
		} catch (SyncconException ex) {
			logger.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	private List<ResultadoErroresContable> procesarHashMapErroresSun(HashMap<Integer, String> listaErrores,
			String origen) {
		Iterator it = listaErrores.entrySet().iterator();
		List<ResultadoErroresContable> lista = new ArrayList<ResultadoErroresContable>();
		ResultadoErroresContable resul;
		Map.Entry e1;
		int iterador = 0;
		while (it.hasNext()) {
			e1 = (Map.Entry) it.next();
			resul = new ResultadoErroresContable();
			resul.setLineaAsientoError(e1.getKey() + "");

			String[] elementos = e1.getValue().toString().split(ConstantesSun.UTL_CHR_SEPARADOR);

			resul.setDiario(e1.getKey() + "");
			resul.setLineaDiario(elementos[0]);
			resul.setMensajeAsientoError(elementos[1]);
			resul.setProcedenciaError(origen);
			// resul.setLineaAsientoError(
			// resultadoContable.get(iterador + contVaciosErrores +
			// sumaLineaAsientosErrores).getCuentaContable());
			resul.setLineaAsientoError(resultadoContable.get(iterador + sumaLineaAsientosErrores).getCuentaContable());
			lista.add(resul);
			iterador++;
		}
		// contVaciosErrores++;
		sumaLineaAsientosErrores += listaErrores.size();
		return lista;
	}
	
	private List<ResultadoErroresContable> procesarHashMapCorrectosPago(
			HashMap<Integer, Integer> listaAsientosCorrectos) {
		ResultadoErroresContable resul;
		List<ResultadoErroresContable> lista = new ArrayList<ResultadoErroresContable>();
		for (Entry<Integer, Integer> e : listaAsientosCorrectos.entrySet()) {
			resul = new ResultadoErroresContable();
			resul.setDiario(e.getKey() + "");
			resul.setLineaDiario(e.getValue() + "");
			// int ind = e.getKey() + contVacios + sumaLineaAsientos;
			resul.setLineaAsientoError(resultadoContable.get(contAsientosContablesGenerados).getCuentaContable());
			//logger.info("[" + e.getKey() + "=" + e.getValue() + "]");
			lista.add(resul);
			contAsientosContablesGenerados++;
		}
		return lista;
	}
	
	private List<AsientoContableBean> ProcesarSuperlista(List<List<AsientoContableBean>> splistaProcesos2) {
		List<AsientoContableBean> retorno = new ArrayList<AsientoContableBean>();
		logger.info("Inicio");
		for (int i = 0; i < splistaProcesos2.size(); i++) {
			List<AsientoContableBean> aa = splistaProcesos2.get(i);
			retorno.addAll(aa);
		}
		
		//Ordenar por tipoDiario/numDiario/Referencia/Importe
		Collections.sort(retorno, new Comparator<AsientoContableBean>() {
			public int compare(AsientoContableBean a1, AsientoContableBean a2) {
				int retorno;
				//retorno = a1.getTipoDiario().compareTo(a2.getTipoDiario());
				//if(retorno == 0)
					retorno = String.valueOf(a1.getDiario()).compareTo(String.valueOf(a2.getDiario()));
				if(retorno == 0)
					retorno = a1.getReferencia().compareTo(a2.getReferencia());
				if(retorno == 0)
					retorno = Double.valueOf(Math.abs(a1.getImporteSoles().doubleValue())).compareTo(Double.valueOf(Math.abs(a2.getImporteSoles().doubleValue())));
				return retorno;
			}
		});
		/*Collections.sort(retorno, new Comparator<AsientoContableBean>() {
			public int compare(AsientoContableBean a1, AsientoContableBean a2) {
				return a1.getDiario()-a2.getDiario();

			}
		});
		Collections.sort(retorno, new Comparator<AsientoContableBean>() {
			@Override
			public int compare(AsientoContableBean a1, AsientoContableBean a2) {
				return a1.getReferencia().compareTo(a2.getReferencia());

			}
		});
		Collections.sort(retorno, new Comparator<AsientoContableBean>() {
			@Override
			public int compare(AsientoContableBean a1, AsientoContableBean a2) {
				return Double.valueOf(Math.abs(a1.getImporteSoles().doubleValue())).compareTo(Double.valueOf(Math.abs(a2.getImporteSoles().doubleValue())));

			}
		});*/
		//--------
		
		logger.info("Despues de convertir el XML en Objeto");

		logger.info("Fin");
		return retorno;
	}
	
	public void procesarFechaTransaccion() {
		if(formaReversa.equals("1")) {
			if (fechaTrxDesde != null && fechaTrxHasta!=null) {
				Calendar fechaInicioCalendar = Calendar.getInstance();
				Calendar fechaFinCalendar = Calendar.getInstance();
				fechaInicioCalendar.setTime(fechaTrxDesde);
				fechaInicioCalendar.set(Calendar.HOUR_OF_DAY, 0);
				fechaInicioCalendar.set(Calendar.MINUTE, 0);
				fechaInicioCalendar.set(Calendar.SECOND, 0);
				fechaInicioCalendar.set(Calendar.MILLISECOND, 0);
				fechaFinCalendar.setTime(fechaTrxHasta);
				fechaFinCalendar.set(Calendar.HOUR_OF_DAY, 0);
				fechaFinCalendar.set(Calendar.MINUTE, 0);
				fechaFinCalendar.set(Calendar.SECOND, 0);
				fechaFinCalendar.set(Calendar.MILLISECOND, 0);
				fechaTrxDesdeStr = Utilitarios.personalizarFecha(fechaTrxDesde, "ddMMyyyy");
				fechaTrxHastaStr = Utilitarios.personalizarFecha(fechaTrxHasta, "ddMMyyyy");
			} else {
				fechaTrxDesdeStr = "";
				fechaTrxHastaStr = "";
			}
		}
	}
	
	public boolean validarObligatoriosBuscar() {
		boolean resultValidar = false;

		//System.out.println("periodo: "+periodo);
		//System.out.println("tipoDiario: "+tipoDiario);
		if(formaReversa.equals("1")) {
			//if ((periodo == null) || (usuario == null)) {
			if ((periodo == null) || (tipoDiario == null)) {
				resultValidar = false;
			} else {
				//if ((periodo.trim().length()==0) || (usuario.trim().length()==0)) {
				if ((periodo.trim().length()==0) || (tipoDiario.trim().equals("*"))) {
					resultValidar = false;
				}else {
					resultValidar = true;
				}
			}
		}else {
			if((tipoDiario == null)) {
				resultValidar = false;
			}else {
				if((tipoDiario.trim().equals("*"))) {
					resultValidar = false;
				}else {
					resultValidar = true;
				}
			}
		}
		return resultValidar;
	}
	
	public boolean validarFechaTrx() {

		if(formaReversa.equals("1")) {
			if (fechaTrxDesde == null && fechaTrxHasta != null) {
				return false;
			}
			if (fechaTrxDesde != null && fechaTrxHasta == null) {
				return false;
			}
			if (fechaTrxDesde != null && fechaTrxHasta != null) {
				return Utilitarios.validarFechasInicioFin(fechaTrxDesde, fechaTrxHasta);
			}
		}
		return true;
	}

	
	private void obtenerImportesFiltro() {
		int cantidadTotal = 0;
		BigDecimal importeTotaFiltro = new BigDecimal("0");
		if (resultadoContable != null && resultadoContable.size() > 0) {
			for (AsientoContableBean asiento : resultadoContable) {
				cantidadTotal = cantidadTotal + 1;
				importeTotaFiltro = importeTotaFiltro.add(asiento.getImporteSoles());
			}
		}
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		DecimalFormat formateador = (DecimalFormat) nf;
		formateador.applyPattern("###,###.##");

		totalImporteFiltro = formateador.format(importeTotaFiltro) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		logger.debug("totalImporteFiltro: " + totalImporteFiltro + " local" + Locale.US.toString());
		totalRegistrosFiltro = cantidadTotal;
	}
	
	private void obtenerImportesFiltroSeleccionados() {
		int cantidadTotal = 0;
		BigDecimal importeTotaFiltro = new BigDecimal("0");
		if (resultadoContable != null && resultadoContable.size() > 0) {
			for (AsientoContableBean asiento : resultadoContable) {
				if (asiento.isSeleccionado()) {
					cantidadTotal = cantidadTotal + 1;
					importeTotaFiltro = importeTotaFiltro.add(asiento.getImporteSoles());
				}
			}
		}
		NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
		DecimalFormat formateador = (DecimalFormat) nf;
		formateador.applyPattern("###,###.##");
		totalImporteFiltroSeleccionados = formateador.format(importeTotaFiltro) + " " + Constantes.DESCRIPCION_MONEDA_SOLES.toLowerCase();
		totalRegistrosFiltroSeleccionados = cantidadTotal;
	}
	
	public String limpiarFiltros() {
		logger.info("Entra Limpiar");
		String respuesta = null;
		try {
			tipoDiario = "*";
			formaReversa = "1";
			// TODO BSC 05/06/2019 se elimina: selection = new SimpleSelection();
			if (selection != null) {
				selection.clear();
			}

			resultadoContable = new ArrayList<AsientoContableBean>();
			if(!formaReversa.equals("0")) setPeriodo(ConstantesSun.UTL_CHR_VACIO);
			else setearFiltrosAutomatico();
			fechaTrxDesde = null;
			fechaTrxHasta = null;
			usuario= "";
			totalRegistrosFiltro = 0;
			totalRegistrosFiltroSeleccionados = 0;
			periodoRev = "";
			fechaTrxRev = null;
			
			disabledForma = false;
			deshabilitarObjetos(true, true, true);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return respuesta;
	}
	
	public void cambioTipoDiario() {
		logger.info("tipoDiario change: "+tipoDiario);
	}
	
	public void cambioUsuario() {
		logger.info("usuario change: "+usuario);
	}

	public ParametroService getParametroService() {
		return parametroService;
	}

	public void setParametroService(ParametroService parametroService) {
		this.parametroService = parametroService;
	}

	public ProcesoPagos getProcesoPagos() {
		return procesoPagos;
	}

	public void setProcesoPagos(ProcesoPagos procesoPagos) {
		this.procesoPagos = procesoPagos;
	}

	public List<AsientoContableBean> getListadoContable() {
		return listadoContable;
	}

	public void setListadoContable(List<AsientoContableBean> listadoContable) {
		this.listadoContable = listadoContable;
	}

	public List<ReservasCamposLayoutBean> getListaReservas() {
		return listaReservas;
	}

	public void setListaReservas(List<ReservasCamposLayoutBean> listaReservas) {
		this.listaReservas = listaReservas;
	}

	public List<AsientoActuarialBean> getListaActuarial() {
		return listaActuarial;
	}

	public void setListaActuarial(List<AsientoActuarialBean> listaActuarial) {
		this.listaActuarial = listaActuarial;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getTipoDiario() {
		return tipoDiario;
	}

	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}

	public Date getFechaTrxDesde() {
		return fechaTrxDesde;
	}

	public void setFechaTrxDesde(Date fechaTrxDesde) {
		this.fechaTrxDesde = fechaTrxDesde;
	}
	
	public Date getFechaTrxHasta() {
		return fechaTrxHasta;
	}

	public void setFechaTrxHasta(Date fechaTrxHasta) {
		this.fechaTrxHasta = fechaTrxHasta;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public Utilidades getUtiles() {
		return utiles;
	}

	public void setUtiles(Utilidades utiles) {
		this.utiles = utiles;
	}

	public SunsystemsController getControlSun() {
		return controlSun;
	}

	public void setControlSun(SunsystemsController controlSun) {
		this.controlSun = controlSun;
	}

	public UsuarioService getUsuarioService() {
		return usuarioService;
	}

	public void setUsuarioService(UsuarioService usuarioService) {
		this.usuarioService = usuarioService;
	}

	public List<SelectItem> getTiposDiarioItems() {
		return tiposDiarioItems;
	}

	public void setTiposDiarioItems(List<SelectItem> tiposDiarioItems) {
		this.tiposDiarioItems = tiposDiarioItems;
	}

	public List<SelectItem> getUsuarioItems() {
		return usuarioItems;
	}

	public void setUsuarioItems(List<SelectItem> usuarioItems) {
		this.usuarioItems = usuarioItems;
	}

	public Collection<Integer> getSelection() {
		return selection;
	}

	public void setSelection(Collection<Integer> selection) {
		this.selection = selection;
	}

	public boolean isPasoValidaciones() {
		return pasoValidaciones;
	}

	public void setPasoValidaciones(boolean pasoValidaciones) {
		this.pasoValidaciones = pasoValidaciones;
	}

	public List<AsientoContableBean> getResultadoContable() {
		return resultadoContable;
	}

	public void setResultadoContable(List<AsientoContableBean> resultadoContable) {
		this.resultadoContable = resultadoContable;
	}

	public boolean isDisabledSun() {
		return disabledSun;
	}

	public void setDisabledSun(boolean disabledSun) {
		this.disabledSun = disabledSun;
	}

	public int getTotalRegistrosFiltro() {
		return totalRegistrosFiltro;
	}

	public void setTotalRegistrosFiltro(int totalRegistrosFiltro) {
		this.totalRegistrosFiltro = totalRegistrosFiltro;
	}

	public String getTotalImporteFiltro() {
		return totalImporteFiltro;
	}

	public void setTotalImporteFiltro(String totalImporteFiltro) {
		this.totalImporteFiltro = totalImporteFiltro;
	}

	public int getTotalRegistrosFiltroSeleccionados() {
		return totalRegistrosFiltroSeleccionados;
	}

	public void setTotalRegistrosFiltroSeleccionados(int totalRegistrosFiltroSeleccionados) {
		this.totalRegistrosFiltroSeleccionados = totalRegistrosFiltroSeleccionados;
	}

	public String getTotalImporteFiltroSeleccionados() {
		return totalImporteFiltroSeleccionados;
	}

	public void setTotalImporteFiltroSeleccionados(String totalImporteFiltroSeleccionados) {
		this.totalImporteFiltroSeleccionados = totalImporteFiltroSeleccionados;
	}

	public List<AsientoContableBean> getResultadoContableCopy() {
		return resultadoContableCopy;
	}

	public void setResultadoContableCopy(List<AsientoContableBean> resultadoContableCopy) {
		this.resultadoContableCopy = resultadoContableCopy;
	}

	public String getFechaTrxDesdeStr() {
		return fechaTrxDesdeStr;
	}

	public void setFechaTrxDesdeStr(String fechaTrxDesdeStr) {
		this.fechaTrxDesdeStr = fechaTrxDesdeStr;
	}
	
	public String getFechaTrxHastaStr() {
		return fechaTrxHastaStr;
	}

	public void setFechaTrxHastaStr(String fechaTrxHastaStr) {
		this.fechaTrxHastaStr = fechaTrxHastaStr;
	}

	public List<List<AsientoContableBean>> getSplistaProcesos() {
		return splistaProcesos;
	}

	public void setSplistaProcesos(List<List<AsientoContableBean>> splistaProcesos) {
		this.splistaProcesos = splistaProcesos;
	}

	public List<ResultadoErroresContable> getResultadoCorrectosContable() {
		return resultadoCorrectosContable;
	}

	public void setResultadoCorrectosContable(List<ResultadoErroresContable> resultadoCorrectosContable) {
		this.resultadoCorrectosContable = resultadoCorrectosContable;
	}

	public List<ResultadoErroresContable> getListaCorrectosAsientoContable() {
		return listaCorrectosAsientoContable;
	}

	public void setListaCorrectosAsientoContable(List<ResultadoErroresContable> listaCorrectosAsientoContable) {
		this.listaCorrectosAsientoContable = listaCorrectosAsientoContable;
	}

	public String getOutText() {
		return outText;
	}

	public void setOutText(String outText) {
		this.outText = outText;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public int getSumaLineaAsientosErrores() {
		return sumaLineaAsientosErrores;
	}

	public void setSumaLineaAsientosErrores(int sumaLineaAsientosErrores) {
		this.sumaLineaAsientosErrores = sumaLineaAsientosErrores;
	}

	public int getContAsientosContablesGenerados() {
		return contAsientosContablesGenerados;
	}

	public void setContAsientosContablesGenerados(int contAsientosContablesGenerados) {
		this.contAsientosContablesGenerados = contAsientosContablesGenerados;
	}

	public List<ResultadoErroresContable> getResultadoErroresContable() {
		return resultadoErroresContable;
	}

	public void setResultadoErroresContable(List<ResultadoErroresContable> resultadoErroresContable) {
		this.resultadoErroresContable = resultadoErroresContable;
	}

	public boolean isDisabledReversa() {
		return disabledReversa;
	}

	public void setDisabledReversa(boolean disabledReversa) {
		this.disabledReversa = disabledReversa;
	}

	public boolean isDisabledForma() {
		return disabledForma;
	}

	public void setDisabledForma(boolean disabledForma) {
		this.disabledForma = disabledForma;
	}

	public String getFormaReversa() {
		return formaReversa;
	}

	public void setFormaReversa(String formaReversa) {
		this.formaReversa = formaReversa;
	}

	public Boolean getSeleccionarTodosError() {
		return seleccionarTodosError;
	}

	public void setSeleccionarTodosError(Boolean seleccionarTodosError) {
		this.seleccionarTodosError = seleccionarTodosError;
	}

	public Boolean getSeleccionarTodosProcesar() {
		return seleccionarTodosProcesar;
	}

	public void setSeleccionarTodosProcesar(Boolean seleccionarTodosProcesar) {
		this.seleccionarTodosProcesar = seleccionarTodosProcesar;
	}

	public Date getFechaTrxRev() {
		return fechaTrxRev;
	}

	public void setFechaTrxRev(Date fechaTrxRev) {
		this.fechaTrxRev = fechaTrxRev;
	}

	public String getFechaTrxRevStr() {
		return fechaTrxRevStr;
	}

	public void setFechaTrxRevStr(String fechaTrxRevStr) {
		this.fechaTrxRevStr = fechaTrxRevStr;
	}

	public String getPeriodoRev() {
		return periodoRev;
	}

	public void setPeriodoRev(String periodoRev) {
		this.periodoRev = periodoRev;
	}

	public boolean isDisabledDatosRev() {
		return disabledDatosRev;
	}

	public void setDisabledDatosRev(boolean disabledDatosRev) {
		this.disabledDatosRev = disabledDatosRev;
	}
	
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/