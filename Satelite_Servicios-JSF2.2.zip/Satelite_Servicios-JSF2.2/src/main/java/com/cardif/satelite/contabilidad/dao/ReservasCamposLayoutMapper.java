/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.dao;

import java.util.List;

import com.cardif.satelite.contabilidad.bean.AsientoActuarialBean;
import com.cardif.satelite.contabilidad.bean.ConfigAnalisisBean;
import com.cardif.satelite.contabilidad.bean.ConfigCuentaContableBean;
import com.cardif.satelite.contabilidad.bean.ConfigProductoBean;
import com.cardif.satelite.contabilidad.bean.ConsultaCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.CuadroContableBean;
import com.cardif.satelite.contabilidad.bean.DatosCamposLayoutBean;
import com.cardif.satelite.contabilidad.bean.ProcesoCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;
import com.cardif.satelite.contabilidad.model.ReservasCamposLayout;

public interface ReservasCamposLayoutMapper {

	public List<ReservasCamposLayout> obtenerCamposLayoutByCabDet(ReservasCamposLayout reservasCamposLayout);
	public Integer insertarReservas(ReservasCamposLayoutBean reservas);
	public void insertaContaAsientosActurial(AsientoActuarialBean asiento);
	public void actualizarAsientoActuarial(ReservasCamposLayoutBean asiento);
	
	public Integer agregarConfigProducto(ConfigProductoBean productoBean);
	public List<ConfigProductoBean> verConfigProducto(ConfigProductoBean productoBean);
	public void editarConfigProducto(ConfigProductoBean productoBean);
	public void borrarConfigProducto(ConfigProductoBean productoBean);
	public List<ConfigProductoBean> listarConfigProducto(ConfigProductoBean productoBean);
	public List<ConfigProductoBean> itemsConfigProducto(ConfigProductoBean productoBean);
	
	public Integer agregarConfigAnalisis(ConfigAnalisisBean analisisBean);
	public List<ConfigAnalisisBean> verConfigAnalisis(ConfigAnalisisBean analisisBean);
	public void editarConfigAnalisis(ConfigAnalisisBean analisisBean);
	public void borrarConfigAnalisis(ConfigAnalisisBean analisisBean);
	public List<ConfigAnalisisBean> listarConfigAnalisis(ConfigAnalisisBean analisisBean);
	public List<ConfigAnalisisBean> itemsConfigAnalisis(ConfigAnalisisBean analisisBean);
	
	public Integer agregarConfigCuenta(ConfigCuentaContableBean cuentaBean);
	public List<ConfigCuentaContableBean> verConfigCuenta(ConfigCuentaContableBean cuentaBean);
	public void editarConfigCuenta(ConfigCuentaContableBean cuentaBean);
	public void borrarConfigCuenta(ConfigCuentaContableBean cuentaBean);
	public List<ConfigCuentaContableBean> listarConfigCuenta(ConfigCuentaContableBean cuentaBean);
	
	public Integer insertarDatos(DatosCamposLayoutBean datos);
	public Integer insertarProceso(ProcesoCuadroContableBean proceso);
	public Integer guardarBusqueda(ConsultaCuadroContableBean consulta);
	public void borraConsultasxProceso(ProcesoCuadroContableBean proceso);
	public void borraDatosxProceso(ProcesoCuadroContableBean proceso);
	public void borraProceso(ProcesoCuadroContableBean proceso);
	public List<ProcesoCuadroContableBean> obtenerProcesosCC();
	public List<CuadroContableBean> obtenerCuadroContable(CuadroContableBean bean);
	public List<ConfigCuentaContableBean> obtenerCuentasConfig(ConfigCuentaContableBean bean);
	public void actualizarPeriodoProceso(ProcesoCuadroContableBean proceso);
	public void actualizarImportesBalance(ProcesoCuadroContableBean proceso);
	public void borrarImportesBalance(ProcesoCuadroContableBean proceso);
	public void borrarCuentasBalance(ProcesoCuadroContableBean proceso);
	public Integer validarExisteCuentasProceso(ProcesoCuadroContableBean proceso);
	public Integer validarExistePeriodo(ProcesoCuadroContableBean proceso);
	public void cierreImportesFinal(ProcesoCuadroContableBean proceso);
	public void cierreProcesoFinal(ProcesoCuadroContableBean proceso);
	public void borrarConsultasxPeriodo(ProcesoCuadroContableBean proceso);
	public void borrarDatosxPeriodo(ProcesoCuadroContableBean proceso);
	public void borrarProcesoxPeriodo(ProcesoCuadroContableBean proceso);
	public Integer validarExisteCargaReserva(ReservasCamposLayoutBean reserva);
	public void borrarReservas(ReservasCamposLayoutBean reserva);
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/