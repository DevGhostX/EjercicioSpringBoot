/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.model;

import java.io.Serializable;

public class ReservasCamposLayout implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String nomCampo;
	private Integer numOrdCampo;
	private String tipoDato;
	private String formatoColumna;
	private boolean oblCampo;
	private String cabecera;
	private String cabReferencia;
	private String estado;
	private String tipoCarga;
	private String usuarioCrea;
	private String fechaCrea;
	private String usuarioModifica;
	private String fechaModifica;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNomCampo() {
		return nomCampo;
	}
	public void setNomCampo(String nomCampo) {
		this.nomCampo = nomCampo;
	}
	public Integer getNumOrdCampo() {
		return numOrdCampo;
	}
	public void setNumOrdCampo(Integer numOrdCampo) {
		this.numOrdCampo = numOrdCampo;
	}
	public String getTipoDato() {
		return tipoDato;
	}
	public void setTipoDato(String tipoDato) {
		this.tipoDato = tipoDato;
	}
	public String getFormatoColumna() {
		return formatoColumna;
	}
	public void setFormatoColumna(String formatoColumna) {
		this.formatoColumna = formatoColumna;
	}
	public boolean isOblCampo() {
		return oblCampo;
	}
	public void setOblCampo(boolean oblCampo) {
		this.oblCampo = oblCampo;
	}
	public String getCabecera() {
		return cabecera;
	}
	public void setCabecera(String cabecera) {
		this.cabecera = cabecera;
	}
	public String getCabReferencia() {
		return cabReferencia;
	}
	public void setCabReferencia(String cabReferencia) {
		this.cabReferencia = cabReferencia;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getUsuarioCrea() {
		return usuarioCrea;
	}
	public void setUsuarioCrea(String usuarioCrea) {
		this.usuarioCrea = usuarioCrea;
	}
	public String getFechaCrea() {
		return fechaCrea;
	}
	public void setFechaCrea(String fechaCrea) {
		this.fechaCrea = fechaCrea;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public String getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(String fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
	public String getTipoCarga() {
		return tipoCarga;
	}
	public void setTipoCarga(String tipoCarga) {
		this.tipoCarga = tipoCarga;
	}
	@Override
	public String toString() {
		return "ReservasCamposLayout [id=" + id + ", nomCampo=" + nomCampo + ", numOrdCampo=" + numOrdCampo
				+ ", tipoDato=" + tipoDato + ", formatoColumna=" + formatoColumna + ", oblCampo=" + oblCampo
				+ ", cabecera=" + cabecera + ", cabReferencia=" + cabReferencia + ", estado=" + estado + ", tipoCarga="
				+ tipoCarga + ", usuarioCrea=" + usuarioCrea + ", fechaCrea=" + fechaCrea + ", usuarioModifica="
				+ usuarioModifica + ", fechaModifica=" + fechaModifica + "]";
	}
	
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/