/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.service;

import java.io.File;
import java.util.List;

import org.richfaces.model.UploadedFile;

import com.cardif.satelite.contabilidad.bean.ConfigAnalisisBean;
import com.cardif.satelite.contabilidad.bean.ConfigCuentaContableBean;
import com.cardif.satelite.contabilidad.bean.ConfigProductoBean;
import com.cardif.satelite.contabilidad.bean.ConsultaCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.CuadroContableBean;
import com.cardif.satelite.contabilidad.bean.DatosCamposLayoutBean;
import com.cardif.satelite.contabilidad.bean.ProcesoCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;
import com.cardif.satelite.contabilidad.model.ReservasCamposLayout;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.tesoreria.bean.ResultadoErroresContable;
import com.cardif.sunsystems.bean.AsientoContableBean;

public interface AsientosActuarialService {
	
	public String validarReservasCamposLayout(UploadedFile archivoLayout, String nombreArchivo, Parametro prm) throws Exception;
	public List<ReservasCamposLayoutBean> leerReservasLayout(UploadedFile archivoLayout, String nombreArchivo, Parametro prm) throws Exception;
	public List<ReservasCamposLayoutBean> insertarReservas(List<ReservasCamposLayoutBean> lista) throws Exception;
	public void insertaContaAsientosActuarial(List<AsientoContableBean> asientoContableBean, List<ResultadoErroresContable> resultadoContable) throws Exception;
	public void actualizarAsiento(AsientoContableBean asiento) throws Exception;
	
	public Integer agregarConfigProducto(ConfigProductoBean productoBean) throws Exception;
	public ConfigProductoBean verConfigProducto(ConfigProductoBean productoBean) throws Exception;
	public void editarConfigProducto(ConfigProductoBean productoBean) throws Exception;
	public void borrarConfigProducto(ConfigProductoBean productoBean) throws Exception;
	public List<ConfigProductoBean> listarConfigProducto(ConfigProductoBean productoBean);
	public List<ConfigProductoBean> itemsConfigProducto(ConfigProductoBean productoBean);
	
	public Integer agregarConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception;
	public ConfigAnalisisBean verConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception;
	public void editarConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception;
	public void borrarConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception;
	public List<ConfigAnalisisBean> listarConfigAnalisis(ConfigAnalisisBean analisisBean);
	public List<ConfigAnalisisBean> itemsConfigAnalisis(ConfigAnalisisBean analisisBean);
	
	public Integer agregarConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception;
	public ConfigCuentaContableBean verConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception;
	public void editarConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception;
	public void borrarConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception;
	public List<ConfigCuentaContableBean> listarConfigCuenta(ConfigCuentaContableBean cuentaBean);
	
	public String validarDatosCamposLayout(UploadedFile archivoLayout, String nombreArchivo, String tipoCarga) throws Exception;
	public List<DatosCamposLayoutBean> insertarDatos(List<DatosCamposLayoutBean> lista, Integer idProceso) throws Exception;
	public Integer insertarProceso(ProcesoCuadroContableBean proceso) throws Exception;
	public List<ConsultaCuadroContableBean> guardarBusqueda(List<AsientoContableBean> lista, Integer idProceso) throws Exception;
	public void borraConsultasxProceso(ProcesoCuadroContableBean proceso) throws Exception;
	public void borraDatosxProceso(ProcesoCuadroContableBean proceso) throws Exception;
	public void borraProceso(ProcesoCuadroContableBean proceso) throws Exception;
	public List<ProcesoCuadroContableBean> obtenerProcesosCC();
	public List<CuadroContableBean> obtenerCuadroContable(CuadroContableBean bean);
	public List<ConfigCuentaContableBean> obtenerCuentasConfig(ConfigCuentaContableBean bean);
	public void actualizarPeriodoProceso(ProcesoCuadroContableBean proceso) throws Exception;
	public void actualizarImportesBalance(ProcesoCuadroContableBean proceso) throws Exception;
	public void borrarImportesBalance(ProcesoCuadroContableBean proceso) throws Exception;
	public void borrarCuentasBalance(ProcesoCuadroContableBean proceso) throws Exception;
	public Integer validarExisteCuentasProceso(ProcesoCuadroContableBean proceso);
	public Integer validarExistePeriodo(ProcesoCuadroContableBean proceso);
	public void cierreImportesFinal(ProcesoCuadroContableBean proceso) throws Exception;
	public void cierreProcesoFinal(ProcesoCuadroContableBean proceso) throws Exception;
	public void borrarConsultasxPeriodo(ProcesoCuadroContableBean proceso) throws Exception;
	public void borrarDatosxPeriodo(ProcesoCuadroContableBean proceso) throws Exception;
	public void borrarProcesoxPeriodo(ProcesoCuadroContableBean proceso) throws Exception;
	public Integer validarExisteCargaReserva(ReservasCamposLayoutBean reserva);
	public void borrarReservas(ReservasCamposLayoutBean reserva);
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/