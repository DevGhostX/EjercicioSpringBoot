/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.service.impl;

import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.OldExcelFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.dao.ParametroMapper;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.contabilidad.bean.AsientoActuarialBean;
import com.cardif.satelite.contabilidad.bean.ConfigAnalisisBean;
import com.cardif.satelite.contabilidad.bean.ConfigCuentaContableBean;
import com.cardif.satelite.contabilidad.bean.ConfigProductoBean;
import com.cardif.satelite.contabilidad.bean.ConsultaCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.CuadroContableBean;
import com.cardif.satelite.contabilidad.bean.DatosCamposLayoutBean;
import com.cardif.satelite.contabilidad.bean.ProcesoCuadroContableBean;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;
import com.cardif.satelite.contabilidad.dao.ReservasCamposLayoutMapper;
import com.cardif.satelite.contabilidad.model.ReservasCamposLayout;
import com.cardif.satelite.contabilidad.service.AsientosActuarialService;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.model.Parametro;
import com.cardif.satelite.tesoreria.bean.ResultadoErroresContable;
import com.cardif.satelite.tesoreria.bean.TesoRecaComItfBean;
import com.cardif.sunsystems.bean.AsientoContableBean;
import com.cardif.sunsystems.util.ConstantesSun;

@Service("asientosActuarialService")
public class AsientosActuarialServiceImpl implements AsientosActuarialService {
	
	private static final Logger LOGGER = Logger.getLogger(AsientosActuarialServiceImpl.class);
	
	@Autowired
	private ReservasCamposLayoutMapper reservasCamposlayoutMapper;
	
	@Autowired
	private ParametroMapper parametroMapper;
	
	@Override
	public String validarReservasCamposLayout(UploadedFile archivoLayout, String nombreArchivo, Parametro prm) throws Exception {
		try {
			// Obtener lista de campos del layout por banco seleccionado
			ReservasCamposLayout objLayout = new ReservasCamposLayout();
			objLayout.setEstado(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
			objLayout.setCabecera(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
			objLayout.setTipoCarga(Constantes.CONTA_TIPO_CARGA_RESERVA);
			List<ReservasCamposLayout> listaCamposCab = reservasCamposlayoutMapper.obtenerCamposLayoutByCabDet(objLayout);
			
			objLayout = new ReservasCamposLayout();
			objLayout.setEstado(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
			objLayout.setCabecera(String.valueOf(Constantes.COD_ESTADO_INACTIVO));
			objLayout.setTipoCarga(Constantes.CONTA_TIPO_CARGA_RESERVA);
			List<ReservasCamposLayout> listaCamposDet = reservasCamposlayoutMapper.obtenerCamposLayoutByCabDet(objLayout);
			//System.out.println("listaCamposCab: "+listaCamposCab.size());
			//System.out.println("listaCamposDet: "+listaCamposDet.size());
			// Si existe campos configurados para el banco seleccionado
			if ((listaCamposCab != null && listaCamposCab.size() > 0) && (listaCamposDet != null && listaCamposDet.size() > 0)) {
				boolean xlsx = nombreArchivo.substring(nombreArchivo.lastIndexOf(".xls") + 1, nombreArchivo.length()).equalsIgnoreCase("XLSX");
				if (xlsx) {
					//System.out.println("xlsx: "+xlsx);
					return validarXlsx(archivoLayout, listaCamposCab, listaCamposDet, prm);
				} else {
					// TODO LEER .XLS CON HSSF
				}
			} else {
				// return
				// PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_CONFIG_LAYOUT);
				return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
			}
			return null;
		} catch (OldExcelFormatException e) {
			e.printStackTrace();
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ANTIGUO_FORMATO_EXCEL);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	private String validarXlsx(UploadedFile archivoLayout, List<ReservasCamposLayout> camposLayoutCab, List<ReservasCamposLayout> camposLayoutDet, 
			Parametro prm) throws Exception {
		InputStream stream = null;
		try {
			OPCPackage container = OPCPackage.open(archivoLayout.getInputStream());
			ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(container);
			XSSFReader xssfReader = new XSSFReader(container);
			StylesTable styles = xssfReader.getStylesTable();
			//System.out.println("sheet: "+prm.getNomValor()+" - "+prm.getNumOrden());
			
			/*Iterator<InputStream> sheets = xssfReader.getSheetsData();
		    if (sheets instanceof XSSFReader.SheetIterator) {
		     XSSFReader.SheetIterator sheetiterator = (XSSFReader.SheetIterator)sheets;
		     while (sheetiterator.hasNext()) {
		      InputStream dummy = sheetiterator.next();
		      System.out.println("sheets name: "+sheetiterator.getSheetName());
		      dummy.close();
		     }
		    }*/
			  
		    stream = xssfReader.getSheet("rId"+(String.valueOf(prm.getNumOrden()+1))); //seleccionar la hoja a trabajar
			return this.procesarValidacionXlsx(styles, strings, stream, camposLayoutCab, camposLayoutDet, prm.getNomValor(), String.valueOf(prm.getNumOrden()));
		} catch (Exception e) {
			// throw e;
			e.printStackTrace();
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
		} finally {
			if (stream != null) {
				stream.close();
			}
		}
	}

	private String procesarValidacionXlsx(StylesTable styles, ReadOnlySharedStringsTable strings,
			InputStream sheetInputStream, List<ReservasCamposLayout> camposLayoutCab, List<ReservasCamposLayout> camposLayoutDet, String hoja, String orden) {
		InputSource sheetSource = new InputSource(sheetInputStream);
		SAXParserFactory saxFactory = SAXParserFactory.newInstance();
		try {
			SAXParser saxParser = saxFactory.newSAXParser();
			XMLReader sheetParser = saxParser.getXMLReader();
			ValidacionReservasCamposLayout xlsxHandler = new ValidacionReservasCamposLayout(camposLayoutCab, camposLayoutDet, hoja);
			ContentHandler handler = new XSSFSheetXMLHandler(styles, strings, xlsxHandler, false);
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			int contFilas = xlsxHandler.getContFilas();
			boolean error = xlsxHandler.isError();
			// Si no tiene por lo menos una fila de detalle
			// if (contFilas == 0 || contFilas <filaCabera || contFilas
			// <filaInicio) {
			//System.out.println("error: "+error);
			//System.out.println("contFilas: "+contFilas);
			if (error || contFilas == 0) {
				return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
			}
			List<ReservasCamposLayoutBean> listReservasXlsx = xlsxHandler.getListaReservasLayout();
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put((Constantes.KEY_LIST_RESERVAS_XLSX+"_"+orden), listReservasXlsx);
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
			return e.getMessage();
		}
	}
	
	@Override
	public String validarDatosCamposLayout(UploadedFile archivoLayout, String nombreArchivo, String tipoCarga) throws Exception {
		try {
			// Obtener lista de campos del layout por banco seleccionado			
			ReservasCamposLayout objLayout = new ReservasCamposLayout();
			objLayout.setEstado(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
			objLayout.setCabecera(String.valueOf(Constantes.COD_ESTADO_INACTIVO));
			objLayout.setTipoCarga(Constantes.CONTA_TIPO_CARGA_DATOS);
			List<ReservasCamposLayout> listaCamposDet = reservasCamposlayoutMapper.obtenerCamposLayoutByCabDet(objLayout);
			//System.out.println("listaCamposDet: "+listaCamposDet.size());
			if ((listaCamposDet != null && listaCamposDet.size() > 0)) {
				boolean xlsx = nombreArchivo.substring(nombreArchivo.lastIndexOf(".xls") + 1, nombreArchivo.length()).equalsIgnoreCase("XLSX");
				if (xlsx) {
					return validarDatosXlsx(archivoLayout, listaCamposDet, tipoCarga);
				}
			} else {
				return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
			}
			return null;
		} catch (OldExcelFormatException e) {
			e.printStackTrace();
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ANTIGUO_FORMATO_EXCEL);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	private String validarDatosXlsx(UploadedFile archivoLayout, List<ReservasCamposLayout> camposLayoutDet, String tipoCarga) throws Exception {
		InputStream stream = null;
		try {
			OPCPackage container = OPCPackage.open(archivoLayout.getInputStream());
			ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(container);
			XSSFReader xssfReader = new XSSFReader(container);
			StylesTable styles = xssfReader.getStylesTable();
			//System.out.println("entra validarDatosXlsx");
			Iterator<InputStream> sheets = xssfReader.getSheetsData();
		    if (sheets instanceof XSSFReader.SheetIterator) {
		     XSSFReader.SheetIterator sheetiterator = (XSSFReader.SheetIterator)sheets;
		     while (sheetiterator.hasNext()) {
		      InputStream dummy = sheetiterator.next();
		      //System.out.println("sheets name: "+sheetiterator.getSheetName());
		      dummy.close();
		     }
		    }
		    
		    stream = xssfReader.getSheet("rId1"); //seleccionar la hoja a trabajar
			return this.procesarDatosValidacionXlsx(styles, strings, stream, camposLayoutDet, tipoCarga);
		} catch (Exception e) {
			// throw e;
			e.printStackTrace();
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
		} finally {
			if (stream != null) {
				stream.close();
			}
		}
	}
	
	private String procesarDatosValidacionXlsx(StylesTable styles, ReadOnlySharedStringsTable strings,
			InputStream sheetInputStream, List<ReservasCamposLayout> camposLayoutDet, String tipoCarga) {
		InputSource sheetSource = new InputSource(sheetInputStream);
		SAXParserFactory saxFactory = SAXParserFactory.newInstance();
		try {
			SAXParser saxParser = saxFactory.newSAXParser();
			XMLReader sheetParser = saxParser.getXMLReader();
			ValidacionDatosCamposLayout xlsxHandler = new ValidacionDatosCamposLayout(camposLayoutDet, tipoCarga);
			ContentHandler handler = new XSSFSheetXMLHandler(styles, strings, xlsxHandler, false);
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			int contFilas = xlsxHandler.getContFilas();
			boolean error = xlsxHandler.isError();
			
			if (error || contFilas == 0) {
				return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
			}
			
			String keyXlsx = Constantes.KEY_LIST_DATOSE_XLSX;
			if(tipoCarga.equals("2")) keyXlsx = Constantes.KEY_LIST_DATOSR_XLSX;
			List<DatosCamposLayoutBean> listReservasXlsx = xlsxHandler.getListaDatosLayout();
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(keyXlsx, listReservasXlsx);
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
			return e.getMessage();
		}
	}

	@Override
	public List<ReservasCamposLayoutBean> leerReservasLayout(UploadedFile archivoLayout, String nombreArchivo, Parametro prm)
			throws Exception {

		ReservasCamposLayout objLayout = new ReservasCamposLayout();
		objLayout.setEstado(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
		objLayout.setCabecera(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
		List<ReservasCamposLayout> listaCamposCab = reservasCamposlayoutMapper.obtenerCamposLayoutByCabDet(objLayout);
		
		objLayout = new ReservasCamposLayout();
		objLayout.setEstado(String.valueOf(Constantes.COD_ESTADO_ACTIVO));
		objLayout.setCabecera(String.valueOf(Constantes.COD_ESTADO_INACTIVO));
		List<ReservasCamposLayout> listaCamposDet = reservasCamposlayoutMapper.obtenerCamposLayoutByCabDet(objLayout);

		// Si existe campos configurados para el banco seleccionado
		if ((listaCamposCab != null && listaCamposCab.size() > 0) && (listaCamposDet != null && listaCamposDet.size() > 0)) {
			boolean xlsx = nombreArchivo.substring(nombreArchivo.lastIndexOf(".xls") + 1, nombreArchivo.length()).equalsIgnoreCase("XLSX");
			if (xlsx) {
				return abrirXlsx(archivoLayout, listaCamposCab, listaCamposDet, prm);
			} else {
				// TODO LEER .XLS CON HSSF
			}
		}
		return null;
	}

	private List<ReservasCamposLayoutBean> abrirXlsx(UploadedFile archivoLayout, List<ReservasCamposLayout> camposLayoutCab, List<ReservasCamposLayout> camposLayoutDet, 
			Parametro prm) throws Exception {
		InputStream stream = null;
		try {
			
			OPCPackage container = OPCPackage.open(archivoLayout.getInputStream());
			ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(container);
			XSSFReader xssfReader = new XSSFReader(container);
			StylesTable styles = xssfReader.getStylesTable();
			  
		    stream = xssfReader.getSheet("rId"+(String.valueOf(prm.getNumOrden()+1))); //seleccionar la hoja a trabajar
			return this.procesarLecturaXlsx(styles, strings, stream, camposLayoutCab, camposLayoutDet, prm.getNomValor());
		} catch (Exception e) {
			e.printStackTrace();
			// throw e;
			throw new SyncconException(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
		} finally {
			if (stream != null) {
				stream.close();
			}
		}
	}

	private List<ReservasCamposLayoutBean> procesarLecturaXlsx(StylesTable styles, ReadOnlySharedStringsTable strings,
			InputStream sheetInputStream, List<ReservasCamposLayout> camposLayoutCab, List<ReservasCamposLayout> camposLayoutDet, String hoja) throws Exception {
		InputSource sheetSource = new InputSource(sheetInputStream);
		SAXParserFactory saxFactory = SAXParserFactory.newInstance();
		try {

			SAXParser saxParser = saxFactory.newSAXParser();
			XMLReader sheetParser = saxParser.getXMLReader();
			LecturaReservasLayout xlsxHandler = new LecturaReservasLayout(hoja);
			ContentHandler handler = new XSSFSheetXMLHandler(styles, strings, xlsxHandler, false);
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			int contFilas = xlsxHandler.getContFilas();
			//System.out.println("contFilas - excel: " + contFilas);
			if (contFilas == 0) {
				throw new SyncconException(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
			}
			return xlsxHandler.getListaReservasLayout();
		} catch (Exception e) {
			e.printStackTrace();
			// return e.getMessage();
			throw e;
		}
	}
	
	@Override
	public List<ReservasCamposLayoutBean> insertarReservas(List<ReservasCamposLayoutBean> lista) throws Exception {
		try {
			List<ReservasCamposLayoutBean> listaTmp = new ArrayList<ReservasCamposLayoutBean>();
			for(ReservasCamposLayoutBean reserva:lista) {
				//System.out.println("importe a grabar: "+reserva.getImporteTransaccion());
				reservasCamposlayoutMapper.insertarReservas(reserva);
				//reserva.setIdCarga(idCarga);
				//System.out.println("id reserva: "+reserva.getIdCarga());
				//System.out.println("Reserva Cargada: "+reserva);
				listaTmp.add(reserva);
			}
			return listaTmp;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Override
	public List<DatosCamposLayoutBean> insertarDatos(List<DatosCamposLayoutBean> lista, Integer idProceso) throws Exception {
		try {
			List<DatosCamposLayoutBean> listaTmp = new ArrayList<DatosCamposLayoutBean>();
			if(idProceso!=null) {
				for(DatosCamposLayoutBean reserva:lista) {
					reserva.setIdProceso(idProceso);
					//System.out.println("importe RRC a grabar: "+reserva.getRrc());
					reservasCamposlayoutMapper.insertarDatos(reserva);
					listaTmp.add(reserva);
				}
			}
			return listaTmp;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Override
	public List<ConsultaCuadroContableBean> guardarBusqueda(List<AsientoContableBean> lista, Integer idProceso) throws Exception {
		try {
			String usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("userSun").toString();
			List<ConsultaCuadroContableBean> listaTmp = new ArrayList<ConsultaCuadroContableBean>();
			if(idProceso!=null) {
				for(AsientoContableBean consulta:lista) {
					ConsultaCuadroContableBean bean = new ConsultaCuadroContableBean();
					bean.setIdProceso(idProceso);
					bean.setTipoDiario(consulta.getTipoDiario());
					bean.setNumDiario(String.valueOf(consulta.getDiario()));
					bean.setCuentaContable(consulta.getCuentaContable());
					bean.setReferencia(consulta.getReferencia());
					bean.setDescripcion(consulta.getDescripcion());
					bean.setMarcadorDc(consulta.getMarcadorDC());
					bean.setMoneda(consulta.getMoneda());
					bean.setImporteSoles(consulta.getImporteSoles().doubleValue());
					bean.setImporteTrans(consulta.getImporteTransaccion().doubleValue());
					bean.setUsuario(usuario);
					//System.out.println("consulta a grabar: "+bean);
					reservasCamposlayoutMapper.guardarBusqueda(bean);
					listaTmp.add(bean);
				}
			}
			return listaTmp;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Override
	public Integer insertarProceso(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.insertarProceso(proceso);
		return proceso.getIdProceso();
	}
	
	@Override
	public void borraConsultasxProceso(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borraConsultasxProceso(proceso);
	}
	
	@Override
	public void borraDatosxProceso(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borraDatosxProceso(proceso);
	}
	
	@Override
	public void borraProceso(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borraProceso(proceso);
	}
	
	@Override
	public void actualizarAsiento(AsientoContableBean asiento) throws Exception {
		try {
			ReservasCamposLayoutBean cargaAsientoBean = new ReservasCamposLayoutBean();
			cargaAsientoBean.setRefTransaccion(asiento.getReferencia());
			cargaAsientoBean.setDescripcion(asiento.getGlosa());
			cargaAsientoBean.setCodigoCuenta(asiento.getCuentaContable());
			cargaAsientoBean.setImporteTransaccion(asiento.getImporteTransaccion().doubleValue());
			cargaAsientoBean.setIdCarga(asiento.getIdAsiento());
			cargaAsientoBean.setSocioProducto(asiento.getSocioProducto());
			System.out.println("cargaAsientoBean Update: "+cargaAsientoBean);
			reservasCamposlayoutMapper.actualizarAsientoActuarial(cargaAsientoBean);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Override
	public void insertaContaAsientosActuarial(List<AsientoContableBean> listaAsientoContableBean, List<ResultadoErroresContable> resultadoContable) throws Exception {
		try {
			AsientoActuarialBean asientoBean = null;
			DateFormat dateFormat = new SimpleDateFormat(ConstantesSun.UTL_FORMATO_FECHA_SUNSYSTEMS);
			String usuarioParametro = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("userSun").toString();

			//for(ResultadoErroresContable rc:resultadoContable) {
				for (AsientoContableBean a : listaAsientoContableBean) {
					//System.out.println("rc.getDiario(): "+rc.getDiario()+" <-> "+"a.getTipoDiario(): "+a.getTipoDiario()+" -> ProcedenciaError: "+rc.getProcedenciaError()+" -> LineaAsientoError: "+rc.getLineaAsientoError());
					//if(rc.getLineaAsientoError().trim().equals(a.getCuentaContable().trim()) && rc.getProcedenciaError()==null) {
						asientoBean = new AsientoActuarialBean();
						asientoBean.setCodMovimiento(a.getReferencia());
						asientoBean.setFecha(dateFormat.format(a.getFecha()));
						asientoBean.setFechaOperacion(a.getPeriodo());
						asientoBean.setDescripcion(a.getGlosa());
						asientoBean.setCuentaContable(a.getCuentaContable());
						if (a.getImporteSoles().compareTo(new BigDecimal("0")) < 0
								&& a.getMoneda().equals(Constantes.MONEDA_SOLES_SIMBOLO)) {
							asientoBean.setImporteNegativo(a.getImporteSoles().doubleValue());
							asientoBean.setImportePositivo(new BigDecimal("0").doubleValue());
						} else if (a.getImporteTransaccion().compareTo(new BigDecimal("0")) < 0
								&& !a.getMoneda().equals(Constantes.MONEDA_SOLES_SIMBOLO)) {
							asientoBean.setImporteNegativo(a.getImporteTransaccion().doubleValue());
							asientoBean.setImportePositivo(new BigDecimal("0").doubleValue());
						} else if (a.getImporteSoles().compareTo(new BigDecimal("0")) > 0
								&& a.getMoneda().equals(Constantes.MONEDA_SOLES_SIMBOLO)) {
							asientoBean.setImportePositivo(a.getImporteSoles().doubleValue());
							asientoBean.setImporteNegativo(new BigDecimal("0").doubleValue());
						} else if (a.getImporteTransaccion().compareTo(new BigDecimal("0")) > 0
								&& !a.getMoneda().equals(Constantes.MONEDA_SOLES_SIMBOLO)) {
							asientoBean.setImportePositivo(a.getImporteTransaccion().doubleValue());
							asientoBean.setImporteNegativo(new BigDecimal("0").doubleValue());
						}
						asientoBean.setNumCtaBanco(a.getCuentaContable());
						asientoBean.setTipoDiario(a.getTipoDiario());
						asientoBean.setNumDiario(a.getDiario());
						asientoBean.setReferencia(a.getReferencia());
						asientoBean.setNumRef(a.getReferencia());
						asientoBean.setNameCtaBanco((a.getNombreCuenta()!=null)?a.getNombreCuenta():""); //SUN no envía ni trae el nombre de la cuenta
						asientoBean.setUsuarioReg(usuarioParametro);
						asientoBean.setFechaRegistra(dateFormat.format(a.getFecha()));
						//System.out.println("asientoBean a grabar: "+asientoBean);
						reservasCamposlayoutMapper.insertaContaAsientosActurial(asientoBean);
					//}
				}
			//}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Override
	public Integer agregarConfigProducto(ConfigProductoBean productoBean) throws Exception{
		reservasCamposlayoutMapper.agregarConfigProducto(productoBean);
		return productoBean.getId();
	}
	
	@Override
	public ConfigProductoBean verConfigProducto(ConfigProductoBean productoBean) throws Exception{
		ConfigProductoBean producto = new ConfigProductoBean();
		List<ConfigProductoBean> lista = reservasCamposlayoutMapper.verConfigProducto(productoBean);
		return lista.size()>0?lista.get(0):producto;
	}
	
	@Override
	public void editarConfigProducto(ConfigProductoBean productoBean) throws Exception{
		reservasCamposlayoutMapper.editarConfigProducto(productoBean);
	}
	
	@Override
	public void borrarConfigProducto(ConfigProductoBean productoBean) throws Exception{
		reservasCamposlayoutMapper.borrarConfigProducto(productoBean);
	}
	
	@Override
	public List<ConfigProductoBean> listarConfigProducto(ConfigProductoBean productoBean){
		List<ConfigProductoBean> lista = new ArrayList<ConfigProductoBean>();
		lista = reservasCamposlayoutMapper.listarConfigProducto(productoBean);
		return lista;
	}
	
	@Override
	public List<ConfigProductoBean> itemsConfigProducto(ConfigProductoBean productoBean){
		List<ConfigProductoBean> lista = new ArrayList<ConfigProductoBean>();
		lista = reservasCamposlayoutMapper.itemsConfigProducto(productoBean);
		return lista;
	}
	
	@Override
	public Integer agregarConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception{
		reservasCamposlayoutMapper.agregarConfigAnalisis(analisisBean);
		return analisisBean.getId();
	}
	
	@Override
	public ConfigAnalisisBean verConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception{
		ConfigAnalisisBean analisis = new ConfigAnalisisBean();
		List<ConfigAnalisisBean> lista = reservasCamposlayoutMapper.verConfigAnalisis(analisisBean);
		return lista.size()>0?lista.get(0):analisis;
	}
	
	@Override
	public void editarConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception{
		reservasCamposlayoutMapper.editarConfigAnalisis(analisisBean);
	}
	
	@Override
	public void borrarConfigAnalisis(ConfigAnalisisBean analisisBean) throws Exception{
		reservasCamposlayoutMapper.borrarConfigAnalisis(analisisBean);
	}
	
	@Override
	public List<ConfigAnalisisBean> listarConfigAnalisis(ConfigAnalisisBean analisisBean){
		List<ConfigAnalisisBean> lista = new ArrayList<ConfigAnalisisBean>();
		lista = reservasCamposlayoutMapper.listarConfigAnalisis(analisisBean);
		return lista;
	}
	
	@Override
	public List<ConfigAnalisisBean> itemsConfigAnalisis(ConfigAnalisisBean analisisBean){
		List<ConfigAnalisisBean> lista = new ArrayList<ConfigAnalisisBean>();
		lista = reservasCamposlayoutMapper.itemsConfigAnalisis(analisisBean);
		return lista;
	}
	
	@Override
	public Integer agregarConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception{
		reservasCamposlayoutMapper.agregarConfigCuenta(cuentaBean);
		return cuentaBean.getId();
	}
	
	@Override
	public ConfigCuentaContableBean verConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception{
		ConfigCuentaContableBean cuenta = new ConfigCuentaContableBean();
		List<ConfigCuentaContableBean> lista = reservasCamposlayoutMapper.verConfigCuenta(cuentaBean);
		return lista.size()>0?lista.get(0):cuenta;
	}
	
	@Override
	public void editarConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception{
		reservasCamposlayoutMapper.editarConfigCuenta(cuentaBean);
	}
	
	@Override
	public void borrarConfigCuenta(ConfigCuentaContableBean cuentaBean) throws Exception{
		reservasCamposlayoutMapper.borrarConfigCuenta(cuentaBean);
	}
	
	@Override
	public List<ConfigCuentaContableBean> listarConfigCuenta(ConfigCuentaContableBean cuentaBean){
		List<ConfigCuentaContableBean> lista = new ArrayList<ConfigCuentaContableBean>();
		lista = reservasCamposlayoutMapper.listarConfigCuenta(cuentaBean);
		return lista;
	}
	
	@Override
	public List<ProcesoCuadroContableBean> obtenerProcesosCC(){
		List<ProcesoCuadroContableBean> lista = reservasCamposlayoutMapper.obtenerProcesosCC();
		return lista;
	}
	
	@Override
	public List<CuadroContableBean> obtenerCuadroContable(CuadroContableBean bean){
		List<CuadroContableBean> lista = reservasCamposlayoutMapper.obtenerCuadroContable(bean);
		return lista;
	}
	
	@Override
	public List<ConfigCuentaContableBean> obtenerCuentasConfig(ConfigCuentaContableBean bean){
		List<ConfigCuentaContableBean> lista = reservasCamposlayoutMapper.obtenerCuentasConfig(bean);
		return lista;
	}
	
	@Override
	public void actualizarPeriodoProceso(ProcesoCuadroContableBean proceso) throws Exception {
		reservasCamposlayoutMapper.actualizarPeriodoProceso(proceso);
	}
	
	@Override
	public void actualizarImportesBalance(ProcesoCuadroContableBean proceso) throws Exception {
		reservasCamposlayoutMapper.actualizarImportesBalance(proceso);
	}
	
	@Override
	public void borrarImportesBalance(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borrarImportesBalance(proceso);
	}
	
	@Override
	public void borrarCuentasBalance(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borrarCuentasBalance(proceso);
	}
	
	@Override
	public Integer validarExisteCuentasProceso(ProcesoCuadroContableBean proceso) {
		return reservasCamposlayoutMapper.validarExisteCuentasProceso(proceso);
	}
	
	@Override
	public Integer validarExistePeriodo(ProcesoCuadroContableBean proceso) {
		return reservasCamposlayoutMapper.validarExistePeriodo(proceso);
	}

	@Override
	public void cierreImportesFinal(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.cierreImportesFinal(proceso);
	}
	
	@Override
	public void cierreProcesoFinal(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.cierreProcesoFinal(proceso);
	}
	
	@Override
	public void borrarConsultasxPeriodo(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borrarConsultasxPeriodo(proceso);
	}
	
	@Override
	public void borrarDatosxPeriodo(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borrarDatosxPeriodo(proceso);
	}
	
	@Override
	public void borrarProcesoxPeriodo(ProcesoCuadroContableBean proceso) throws Exception{
		reservasCamposlayoutMapper.borrarProcesoxPeriodo(proceso);
	}
	
	@Override
	public Integer validarExisteCargaReserva(ReservasCamposLayoutBean reserva) {
		return reservasCamposlayoutMapper.validarExisteCargaReserva(reserva);
	}
	@Override
	
	public void borrarReservas(ReservasCamposLayoutBean reserva) {
		reservasCamposlayoutMapper.borrarReservas(reserva);
	}
	
}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/