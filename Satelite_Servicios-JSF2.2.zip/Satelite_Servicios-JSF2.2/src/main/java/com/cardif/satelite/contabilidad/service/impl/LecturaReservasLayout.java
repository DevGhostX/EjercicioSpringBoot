/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.service.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;
import org.springframework.stereotype.Service;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;

@Service("lecturaReservasLayout")
public class LecturaReservasLayout implements SheetContentsHandler {

	private static final Logger LOGGER = Logger.getLogger(LecturaReservasLayout.class);
	
	private List<ReservasCamposLayoutBean> listaReservasLayout;
	private ReservasCamposLayoutBean reservasLayout;
	private int contFilas = 0;
	private boolean leerCabecera = false;
	private boolean leerCuerpoDet = false;
	private boolean addLista;
	private HashMap<String, String> mapColumnsValues = new HashMap<String, String>();
	private String periodoContable;
	private String fechaTransaccion;
	private String tipoDiario;
	private String hoja;
	
	public LecturaReservasLayout() {
		super();
	}
	
	public LecturaReservasLayout(String hoja) {
		super();
		this.periodoContable = "";
		this.fechaTransaccion = "";
		this.tipoDiario = "";
		this.hoja = hoja;
		listaReservasLayout = new ArrayList<ReservasCamposLayoutBean>();
	}
	
	@Override
	public void startRow(int rowNum) {
		// TODO Auto-generated method stub
		reservasLayout = new ReservasCamposLayoutBean();
		try {
			contFilas = rowNum+1;
			mapColumnsValues = obtenerColumnsValues();
			//System.out.println("fila: "+rowNum);
			if (rowNum == 2 || rowNum == 3 || rowNum == 4) {
				leerCabecera = true;
				leerCuerpoDet = false;
			}
			if (rowNum == 7) {
				leerCabecera = false;
				leerCuerpoDet = true;
			}
		} catch (Exception e) {
			throw new RuntimeException(
					PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL));
		}
	}

	@Override
	public void endRow() {
		// TODO Auto-generated method stub
		if (leerCabecera) {
			String valor = mapColumnsValues.get(Constantes.CONTA_RESERVA_COL_CAB_VAL);
			//System.out.println("valor cabecera lectura "+Constantes.CONTA_RESERVA_COL_CAB_VAL+contFilas+": "+valor);
			if(!valor.equals("")) {
				if(contFilas==3) periodoContable = valor;
				if(contFilas==4) fechaTransaccion = valor;
				if(contFilas==5) tipoDiario = valor;
			}
		}
		if (leerCuerpoDet) {
			if (addLista && reservasLayout != null) {
				reservasLayout.setPeriodoContable(periodoContable);
				try {
					DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					reservasLayout.setFechaTransaccion(format.parse(formatFecha(fechaTransaccion.trim())));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				reservasLayout.setTipoDiario(tipoDiario);
				reservasLayout.setFechaCarga(new Date());
				String usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString();
				reservasLayout.setUsuario(usuario);
				reservasLayout.setNombreHoja(hoja);
				//System.out.println("reservasLayout: "+reservasLayout);
				listaReservasLayout.add(reservasLayout);
			}
		}
	}

	@Override
	public void cell(String cellReference, String formattedValue) {
		// TODO Auto-generated method stub
		LOGGER.info("[En cell() cellReference: " + cellReference + " formattedValue: " + formattedValue + "]");
		//System.out.println("[En cell() cellReference: " + cellReference + " formattedValue: " + formattedValue + "]");
		String column = "";
		
		if (leerCabecera) {
			column = cellReference.substring(0, 1);
			if(column.equals(Constantes.CONTA_RESERVA_COL_CAB_VAL)) { 
				mapColumnsValues.put(column, formattedValue);
			}
		} else if (leerCuerpoDet) {
			if (!getLength(cellReference)) {
				column = cellReference.substring(0, 1);
				// Establecer el valor de la celda segun la columna
				mapColumnsValues.put(column, formattedValue);
				
				// Construir objeto dependiendo del banco seleccionado
				try {
					leerColumnasReservas(column, (formattedValue!=null?formattedValue:""));
				} catch (Exception ex) { // SyncconException
					ex.printStackTrace();
					//System.out.println("ERROR SYNCCON: " + ex.getMessage());
					LOGGER.error("error exception: ", ex);
				}
			} else {
				column = cellReference.substring(0, 2);
			}
		}
	}

	@Override
	public void headerFooter(String text, boolean isHeader, String tagName) {
		// TODO Auto-generated method stub

	}
	
	public String formatFecha(String fecha) {
		String fechaResult = fecha;
		//System.out.println("fecha: "+fecha);
		String dia = String.valueOf(Calendar.DAY_OF_MONTH);
		String mes = String.valueOf(Calendar.MONTH);
		String anio = String.valueOf(Calendar.YEAR);
		//5/31/20
		if(fecha.length()==7) {
			String[] arrFecha = fecha.split("\\/");
			//System.out.println("arrFecha[0]: "+arrFecha[0]);
			if(Integer.valueOf(arrFecha[0])<10) mes = "0"+String.valueOf(Integer.valueOf(arrFecha[0]));
			else mes = arrFecha[0];
			//System.out.println("arrFecha[1]: "+arrFecha[1]);
			if(Integer.valueOf(arrFecha[1])<10) dia = "0"+String.valueOf(Integer.valueOf(arrFecha[1]));
			else dia = arrFecha[1];
			//System.out.println("arrFecha[2]: "+arrFecha[2]);
			//System.out.println("arrFecha[2].length(): "+arrFecha[2].length());
			if(arrFecha[2].length()==2) anio = "20"+arrFecha[2];
			else anio = arrFecha[2];
			fechaResult = anio+"-"+mes+"-"+dia; 
		}
		//System.out.println("fechaResult: "+fechaResult);
		return fechaResult;
	}
	
	private static synchronized boolean getLength(String cell) {
		boolean res = false;
		int sum = cell.replaceAll("(?i)[^AEIOU]", "").length()
				+ cell.replaceAll("(?i)[^BCDFGHJKLMNPQRSTVWXYZ]", "").length();
		if (sum == 2) {
			res = true;
		}
		return res;
		// return true;
	}
	
	private HashMap<String, String> obtenerColumnsValues() {
		mapColumnsValues.put("A", "");
		mapColumnsValues.put("B", "");
		mapColumnsValues.put("C", "");
		mapColumnsValues.put("D", "");
		mapColumnsValues.put("E", "");
		mapColumnsValues.put("F", "");
		mapColumnsValues.put("G", "");
		mapColumnsValues.put("H", "");
		mapColumnsValues.put("I", "");
		mapColumnsValues.put("J", "");
		mapColumnsValues.put("K", "");
		mapColumnsValues.put("L", "");
		mapColumnsValues.put("M", "");
		mapColumnsValues.put("N", "");
		mapColumnsValues.put("O", "");
		mapColumnsValues.put("P", "");
		mapColumnsValues.put("Q", "");
		mapColumnsValues.put("R", "");
		mapColumnsValues.put("S", "");
		mapColumnsValues.put("T", "");
		mapColumnsValues.put("U", "");
		mapColumnsValues.put("V", "");
		mapColumnsValues.put("W", "");
		mapColumnsValues.put("X", "");
		mapColumnsValues.put("Y", "");
		mapColumnsValues.put("Z", "");
		return mapColumnsValues;
	}
	
	private void leerColumnasReservas(String columna, String valor) throws Exception {
		addLista = true;
		
		if (columna.equals("A")) {
			reservasLayout = new ReservasCamposLayoutBean();
			reservasLayout.setCodigoCuenta(valor);
		}else if (columna.equals("B")) {
			reservasLayout.setNombreCuenta(valor);
		}else if (columna.equals("C")) {
			reservasLayout.setImporteTransaccion(obtenerMontoReserva((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("D")) {
			reservasLayout.setCodigoMoneda(valor);
		}else if (columna.equals("E")) {
			reservasLayout.setRefTransaccion(valor);
		}else if (columna.equals("F")) {
			reservasLayout.setDescripcion(valor);
		}else if (columna.equals("G")) {
			reservasLayout.setCentroCosto(valor);
		}else if (columna.equals("H")) {
			reservasLayout.setSocioProducto(valor);
		}else if (columna.equals("I")) {
			reservasLayout.setCanal(valor);
		}else if (columna.equals("J")) {
			reservasLayout.setProveedorEmpleado(valor);
		}else if (columna.equals("K")) {
			reservasLayout.setDocumentoCliente(valor);
		}else if (columna.equals("L")) {
			reservasLayout.setPolizaCliente(valor);
		}else if (columna.equals("M")) {
			reservasLayout.setInversiones(valor);
		}else if (columna.equals("N")) {
			reservasLayout.setNroSiniestro(valor);
		}else if (columna.equals("O")) {
			reservasLayout.setTipoCdpSunat(valor);
		}else if (columna.equals("P")) {
			reservasLayout.setMedioPago(valor);
		}else if (columna.equals("Q")) {
			reservasLayout.setIndicadorActivo(valor);
		}else if (columna.equals("R")) {
			reservasLayout.setCodigoActivo(valor);
		}else if (columna.equals("S")) {
			reservasLayout.setTasaBase(valor);
		}else if (columna.equals("T")) {
			reservasLayout.setNroRetDet(valor);
		}else if (columna.equals("U")) {
			reservasLayout.setLayout(valor);
		}
	}
	
	private BigDecimal obtenerMontoReserva(String source) {
		BigDecimal monto = obtenerValorNumerico(source.replace("*", ""));
		//return monto.doubleValue() > 0 ? monto.negate() : monto;
		return monto;
	}
	
	private BigDecimal obtenerValorNumerico(String source) {

		if (source != null && source.trim().length() > 0) {
			if (source.contains(".") && source.contains(",")) {
				int indexPunto = source.indexOf(".");
				int indexComa = source.indexOf(",");
				if (indexPunto < indexComa) {
					source = source.replace(".", "");
				} else {
					source = source.replace(",", "");
				}
				//source = source.replace(",", ".");
				source = source.replace(",", "");
			} else if (source.contains(",")) {
				//source = source.replace(",", ".");
				source = source.replace(",", "");
			}

			source = source.replaceAll("[^0-9\\.-]+", "");

			if (source.indexOf(".") != source.lastIndexOf(".")) {

				String alphaAndDigits = "";
				String[] vnum = source.split("\\.");
				int ind = vnum.length - 1;
				//System.out.println("antes if vnum.length-1 : " + ind);
				if (vnum.length > 0) {
					for (int i = 0; i < vnum.length - 1; i++) {
						alphaAndDigits = alphaAndDigits.concat(vnum[i]);
					}
					alphaAndDigits = alphaAndDigits.concat(".");
					ind = vnum.length - 1;
					//System.out.println("vnum.length-1 : " + ind);
					alphaAndDigits = alphaAndDigits.concat(vnum[ind]);

					//System.out.println("alphaAndDigits : " + alphaAndDigits);
					source = alphaAndDigits;
					//System.out.println("source : " + source);
				}
			}
			return new BigDecimal(source.trim());
		}
		return null;
	}

	public List<ReservasCamposLayoutBean> getListaReservasLayout() {
		return listaReservasLayout;
	}

	public void setListaReservasLayout(List<ReservasCamposLayoutBean> listaReservasLayout) {
		this.listaReservasLayout = listaReservasLayout;
	}

	public int getContFilas() {
		return contFilas;
	}

	public void setContFilas(int contFilas) {
		this.contFilas = contFilas;
	}

	public ReservasCamposLayoutBean getReservasLayout() {
		return reservasLayout;
	}

	public void setReservasLayout(ReservasCamposLayoutBean reservasLayout) {
		this.reservasLayout = reservasLayout;
	}

	public boolean isLeerCabecera() {
		return leerCabecera;
	}

	public void setLeerCabecera(boolean leerCabecera) {
		this.leerCabecera = leerCabecera;
	}

	public boolean isLeerCuerpoDet() {
		return leerCuerpoDet;
	}

	public void setLeerCuerpoDet(boolean leerCuerpoDet) {
		this.leerCuerpoDet = leerCuerpoDet;
	}

	public boolean isAddLista() {
		return addLista;
	}

	public void setAddLista(boolean addLista) {
		this.addLista = addLista;
	}

	public HashMap<String, String> getMapColumnsValues() {
		return mapColumnsValues;
	}

	public void setMapColumnsValues(HashMap<String, String> mapColumnsValues) {
		this.mapColumnsValues = mapColumnsValues;
	}

	public String getPeriodoContable() {
		return periodoContable;
	}

	public void setPeriodoContable(String periodoContable) {
		this.periodoContable = periodoContable;
	}

	public String getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public String getTipoDiario() {
		return tipoDiario;
	}

	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/