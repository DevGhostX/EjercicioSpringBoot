/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.service.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.contabilidad.bean.DatosCamposLayoutBean;
import com.cardif.satelite.contabilidad.model.ReservasCamposLayout;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.SateliteUtil;

public class ValidacionDatosCamposLayout implements SheetContentsHandler {
	
	private static final Logger LOGGER = Logger.getLogger(ValidacionDatosCamposLayout.class);
	
	private boolean leerCabecera = false;
	private boolean leerCabeceraDet = false;
	private boolean leerCuerpoDet = false;
	private int colCab = 0;
	private int colCabDet = 0;
	private List<ReservasCamposLayout> listaCamposLayoutDet;
	private int contFilas = 0;
	private HashMap<String, String> mapColumnsValues = new HashMap<String, String>();
	private boolean salir = false;
	private int rowStart = 0;
	private boolean error = false;
	private String tipoCarga;
	private List<DatosCamposLayoutBean> listaDatosLayout;
	private DatosCamposLayoutBean datosLayout;

	public ValidacionDatosCamposLayout() {
		super();
	}

	public ValidacionDatosCamposLayout(List<ReservasCamposLayout> listaCamposLayoutDet, String tipoCarga) {
		super();
		listaDatosLayout = new ArrayList<DatosCamposLayoutBean>();
		this.listaCamposLayoutDet = listaCamposLayoutDet;
		this.tipoCarga = tipoCarga;
	}

	@Override
	public void startRow(int rowNum) {
		// TODO Auto-generated method stub
		datosLayout = new DatosCamposLayoutBean();
		try {
			rowStart = rowNum;
			mapColumnsValues = obtenerColumnsValues();
			//System.out.println("fila: "+rowNum);
			
			if (rowNum == 0) {
				leerCabeceraDet = true;
			}
			if (rowNum == 1) {
				leerCabeceraDet = false;
				leerCuerpoDet = true;
				colCabDet = 0;
			}
		} catch (Exception e) {
			throw new RuntimeException(
					PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL));
		}
	}

	@Override
	public void endRow() {
		// TODO Auto-generated method stub
		if (leerCuerpoDet) {
			for (int i = 0; i < listaCamposLayoutDet.size(); i++) {
				//System.out.println("listaCamposLayoutDet.get(i): "+listaCamposLayoutDet.get(i));
				if (listaCamposLayoutDet.get(i).isOblCampo()) {
					boolean validacion = validarCampoObligatorio(listaCamposLayoutDet.get(i),
							mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
					if (!validacion) {
						throw new RuntimeException(
								PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
					}
				} else {
					boolean validacion = validarCampoNoObligatorio(listaCamposLayoutDet.get(i),
							mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
					if (!validacion) {
						throw new RuntimeException(
								PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
					}
				}
			}
			mapColumnsValues.clear();
			
			if (datosLayout != null) {
				datosLayout.setFechaCarga(new Date());
				String usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("userSun").toString();
				datosLayout.setUsuario(usuario);
				datosLayout.setTipoCarga(tipoCarga);
				listaDatosLayout.add(datosLayout);
			}
		}
	}

	@Override
	public void cell(String cellReference, String formattedValue) {
		// TODO Auto-generated method stub
		int fila = Integer.valueOf(cellReference.substring(1));
		contFilas = fila;
		String column = "";

		if (leerCabeceraDet) {
			//System.out.println("leerCabeceraDet: "+cellReference+" -> "+colCabDet+" : "+formattedValue);
			boolean esCabeceraValida = validarCabeceraOrdenYNombreCol(listaCamposLayoutDet, colCabDet, formattedValue);
			if (!esCabeceraValida) {
				error = true;
				throw new RuntimeException(
						PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAB_EXCEL));
			}
			colCabDet++;
		} else if (leerCuerpoDet) {
			//System.out.println("leerCuerpoDet: "+cellReference+" -> "+formattedValue);
			if (!getLength(cellReference)) {
				column = cellReference.substring(0, 1);
				// Establecer el valor de la celda segun la columna
				mapColumnsValues.put(column, formattedValue);
				
				// Construir objeto dependiendo del banco seleccionado
				try {
					leerColumnasReservas(column, (formattedValue!=null?formattedValue:""));
				} catch (Exception ex) { // SyncconException
					ex.printStackTrace();
					System.out.println("ERROR SYNCCON: " + ex.getMessage());
					LOGGER.error("error exception: ", ex);
				}
			} else {
				column = cellReference.substring(0, 2);
			}
		}
	}

	@Override
	public void headerFooter(String text, boolean isHeader, String tagName) {
		// TODO Auto-generated method stub

	}
	
	private boolean validarCabeceraOrdenYNombreCol(List<ReservasCamposLayout> listaCamposLayout, int nroOrdenCampo, String nombreColumna) {
		if (listaCamposLayout.get(nroOrdenCampo).getNomCampo().trim().equalsIgnoreCase(nombreColumna)) {
			return true;
		}
		return false;
	}

	private boolean validarCampoObligatorio(ReservasCamposLayout campo, String valorCelda) {
		try {
			//System.out.println("campo: "+campo.getNomCampo()+" ~ Tipo: "+campo.getTipoDato()+" ~ "+valorCelda);
			// Si la celda esta vacia y el campo es obligatorio
			if (valorCelda == null || valorCelda.trim().length() == 0) {
				return false;
			}
			// Si es alfanumerico
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_ALFANUMERICO)) {
				return valorCelda == null ? false : valorCelda.trim().length() == 0 ? false : true;
			}
			// Si es Numerico
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {
				// Eliminar comas separadoras de miles
				//valorCelda = valorCelda.replace("*", "").replace(",", "~");
				//valorCelda = valorCelda.replace(".", "").replace("~", ".");
				// Parsear en bigdecimal
				//new BigDecimal(valorCelda.trim());
				
				valorCelda = String.valueOf(obtenerMontoDato((!valorCelda.equals("")?valorCelda:"0")));
				//System.out.println("valorCelda: "+valorCelda);
				Double.parseDouble(valorCelda.trim());
				return true;
			}
			// Si es tipo Fecha
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
				SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoColumna());
				sdf.format(sdf.parse(valorCelda));
				return true;
			}
			return true;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}
	}

	private boolean validarCampoNoObligatorio(ReservasCamposLayout campo, String valorCelda) {
		try {
			// Si no es obligatorio pero la celda tiene valor
			if (valorCelda != null && valorCelda.trim().length() > 0) {
				// Si es Numerico
				if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {
					// Eliminar comas separadoras de miles
					//valorCelda = valorCelda.replace("*", "").replace(",", "~");
					//valorCelda = valorCelda.replace(".", "").replace("~", ".");
					// Parsear en bigdecimal
					//new BigDecimal(valorCelda.trim());
					
					valorCelda = String.valueOf(obtenerMontoDato((!valorCelda.equals("")?valorCelda:"0")));
					//System.out.println("valorCelda: "+valorCelda);
					Double.parseDouble(valorCelda.trim());
					return true;
				}
				// Si es tipo Fecha
				else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
					SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoColumna());
					sdf.format(sdf.parse(valorCelda));
					return true;
				}
			}
			return true;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}
	}
	
	public String formatFecha(String fecha) {
		String fechaResult = fecha;
		//System.out.println("fecha: "+fecha);
		String dia = String.valueOf(Calendar.DAY_OF_MONTH);
		String mes = String.valueOf(Calendar.MONTH);
		String anio = String.valueOf(Calendar.YEAR);
		//5/31/20
		if(fecha.length()==7) {
			String[] arrFecha = fecha.split("\\/");
			//System.out.println("arrFecha[0]: "+arrFecha[0]);
			if(Integer.valueOf(arrFecha[0])<10) mes = "0"+String.valueOf(Integer.valueOf(arrFecha[0]));
			else mes = arrFecha[0];
			//System.out.println("arrFecha[1]: "+arrFecha[1]);
			if(Integer.valueOf(arrFecha[1])<10) dia = "0"+String.valueOf(Integer.valueOf(arrFecha[1]));
			else dia = arrFecha[1];
			//System.out.println("arrFecha[2]: "+arrFecha[2]);
			//System.out.println("arrFecha[2].length(): "+arrFecha[2].length());
			if(arrFecha[2].length()==2) anio = "20"+arrFecha[2];
			else anio = arrFecha[2];
			fechaResult = anio+"-"+mes+"-"+dia; 
		}
		//System.out.println("fechaResult: "+fechaResult);
		return fechaResult;
	}

	private static synchronized boolean getLength(String cell) {
		boolean res = false;
		int sum = cell.replaceAll("(?i)[^AEIOU]", "").length()
				+ cell.replaceAll("(?i)[^BCDFGHJKLMNPQRSTVWXYZ]", "").length();
		if (sum == 2) {
			res = true;
		}
		return res;
		// return true;
	}

	private HashMap<String, String> obtenerColumnsValues() {
		mapColumnsValues.put("A", "");
		mapColumnsValues.put("B", "");
		mapColumnsValues.put("C", "");
		mapColumnsValues.put("D", "");
		mapColumnsValues.put("E", "");
		mapColumnsValues.put("F", "");
		mapColumnsValues.put("G", "");
		mapColumnsValues.put("H", "");
		mapColumnsValues.put("I", "");
		mapColumnsValues.put("J", "");
		mapColumnsValues.put("K", "");
		mapColumnsValues.put("L", "");
		mapColumnsValues.put("M", "");
		mapColumnsValues.put("N", "");
		mapColumnsValues.put("O", "");
		mapColumnsValues.put("P", "");
		mapColumnsValues.put("Q", "");
		mapColumnsValues.put("R", "");
		mapColumnsValues.put("S", "");
		mapColumnsValues.put("T", "");
		mapColumnsValues.put("U", "");
		mapColumnsValues.put("V", "");
		mapColumnsValues.put("W", "");
		mapColumnsValues.put("X", "");
		mapColumnsValues.put("Y", "");
		mapColumnsValues.put("Z", "");
		return mapColumnsValues;
	}
	
	private void leerColumnasReservas(String columna, String valor) throws Exception {
		//System.out.println("valor: "+valor);
		if (columna.equals("A")) {
			datosLayout = new DatosCamposLayoutBean();
			datosLayout.setCodProducto(valor);
		}else if (columna.equals("B")) {
			datosLayout.setMoneda(valor);
		}else if (columna.equals("C")) {
			datosLayout.setSocio(valor);
		}else if (columna.equals("D")) {
			datosLayout.setNomProducto(valor);
		}else if (columna.equals("E")) {
			datosLayout.setCodResumen(valor);
		}else if (columna.equals("F")) {
			datosLayout.setRrc(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("G")) {
			datosLayout.setIngresosDiferidos(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("H")) {
			datosLayout.setRmat(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("I")) {
			datosLayout.setPendientes(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("J")) {
			datosLayout.setIbnr(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("K")) {
			datosLayout.setComDiferidos(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("L")) {
			datosLayout.setDef(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("M")) {
			datosLayout.setPendientesCedidos(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("N")) {
			datosLayout.setIbnrCedidos(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("O")) {
			datosLayout.setRrcCedidos(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("P")) {
			datosLayout.setRmatCedidos(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("Q")) {
			datosLayout.setGasDir(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("R")) {
			datosLayout.setGasInDir(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("S")) {
			datosLayout.setDefCobrar(obtenerMontoDato((!valor.equals("")?valor:"0")).doubleValue());
		}
	}
	
	private BigDecimal obtenerMontoDato(String source) {
		BigDecimal monto = obtenerValorNumerico(source.replace("*", ""));
		//BigDecimal monto = obtenerNuevoNumerico(source);
		//BigDecimal monto = new BigDecimal(source.replace("*", ""));
		//return monto.doubleValue() > 0 ? monto.negate() : monto;
		return monto;
	}
	
	private BigDecimal obtenerNuevoNumerico(String numero) {
		numero = numero.replace("*", "").replace(",", "~");
		numero = numero.replace(".", "").replace("~", ".");
		return new BigDecimal(numero.trim());
	}
	
	private BigDecimal obtenerValorNumerico(String source) {

		if (source != null && source.trim().length() > 0) {
			if (source.contains(".") && source.contains(",")) {
				int indexPunto = source.indexOf(".");
				int indexComa = source.indexOf(",");
				if (indexPunto < indexComa) {
					source = source.replace(".", "");
				} else {
					source = source.replace(",", "");
				}
				source = source.replace(",", ".");
				//source = source.replace(",", "");
			} else if (source.contains(",")) {
				source = source.replace(",", ".");
				//source = source.replace(",", "");
			}

			source = source.replaceAll("[^0-9\\.-]+", "");

			if (source.indexOf(".") != source.lastIndexOf(".")) {

				String alphaAndDigits = "";
				String[] vnum = source.split("\\.");
				int ind = vnum.length - 1;
				//System.out.println("antes if vnum.length-1 : " + ind);
				if (vnum.length > 0) {
					for (int i = 0; i < vnum.length - 1; i++) {
						alphaAndDigits = alphaAndDigits.concat(vnum[i]);
					}
					alphaAndDigits = alphaAndDigits.concat(".");
					ind = vnum.length - 1;
					//System.out.println("vnum.length-1 : " + ind);
					alphaAndDigits = alphaAndDigits.concat(vnum[ind]);

					//System.out.println("alphaAndDigits : " + alphaAndDigits);
					source = alphaAndDigits;
					//System.out.println("source : " + source);
				}
			}
			//System.out.println("source: "+source.trim());
			return new BigDecimal(source.trim());
		}
		return null;
	}

	public boolean isLeerCabecera() {
		return leerCabecera;
	}

	public void setLeerCabecera(boolean leerCabecera) {
		this.leerCabecera = leerCabecera;
	}
	
	public boolean isLeerCabeceraDet() {
		return leerCabeceraDet;
	}

	public void setLeerCabeceraDet(boolean leerCabeceraDet) {
		this.leerCabeceraDet = leerCabeceraDet;
	}

	public boolean isLeerCuerpoDet() {
		return leerCuerpoDet;
	}

	public void setLeerCuerpoDet(boolean leerCuerpoDet) {
		this.leerCuerpoDet = leerCuerpoDet;
	}

	public int getColCabDet() {
		return colCabDet;
	}

	public void setColCabDet(int colCabDet) {
		this.colCabDet = colCabDet;
	}
	
	public List<ReservasCamposLayout> getListaCamposLayoutDet() {
		return listaCamposLayoutDet;
	}

	public void setListaCamposLayoutDet(List<ReservasCamposLayout> listaCamposLayoutDet) {
		this.listaCamposLayoutDet = listaCamposLayoutDet;
	}

	public int getContFilas() {
		return contFilas;
	}

	public void setContFilas(int contFilas) {
		this.contFilas = contFilas;
	}

	public HashMap<String, String> getMapColumnsValues() {
		return mapColumnsValues;
	}

	public void setMapColumnsValues(HashMap<String, String> mapColumnsValues) {
		this.mapColumnsValues = mapColumnsValues;
	}

	public boolean isSalir() {
		return salir;
	}

	public void setSalir(boolean salir) {
		this.salir = salir;
	}

	public int getRowStart() {
		return rowStart;
	}

	public void setRowStart(int rowStart) {
		this.rowStart = rowStart;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public int getColCab() {
		return colCab;
	}

	public void setColCab(int colCab) {
		this.colCab = colCab;
	}

	public List<DatosCamposLayoutBean> getListaDatosLayout() {
		return listaDatosLayout;
	}

	public void setListaDatosLayout(List<DatosCamposLayoutBean> listaDatosLayout) {
		this.listaDatosLayout = listaDatosLayout;
	}

	public DatosCamposLayoutBean getDatosLayout() {
		return datosLayout;
	}

	public void setDatosLayout(DatosCamposLayoutBean datosLayout) {
		this.datosLayout = datosLayout;
	}

	public String getTipoCarga() {
		return tipoCarga;
	}

	public void setTipoCarga(String tipoCarga) {
		this.tipoCarga = tipoCarga;
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/