/** Inicio {Automatización Contabilidad} - {Sprint 1} - {PSS} - {d68954} * ***/
/******* {Carlos Chayguaque} - {25/09/2020} ********/

package com.cardif.satelite.contabilidad.service.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.contabilidad.bean.ReservasCamposLayoutBean;
import com.cardif.satelite.contabilidad.model.ReservasCamposLayout;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.SateliteUtil;

public class ValidacionReservasCamposLayout implements SheetContentsHandler {
	
	private static final Logger LOGGER = Logger.getLogger(ValidacionReservasCamposLayout.class);
	
	private boolean leerCabecera = false;
	private boolean leerCabeceraDet = false;
	private boolean leerCuerpoDet = false;
	private int colCab = 0;
	private int colCabDet = 0;
	private List<ReservasCamposLayout> listaCamposLayoutCab;
	private List<ReservasCamposLayout> listaCamposLayoutDet;
	private int contFilas = 0;
	private HashMap<String, String> mapColumnsValues = new HashMap<String, String>();
	private boolean salir = false;
	private int rowStart = 0;
	private boolean error = false;
	private String periodoContable;
	private String fechaTransaccion;
	private String tipoDiario;
	private String hoja;
	private List<ReservasCamposLayoutBean> listaReservasLayout;
	private ReservasCamposLayoutBean reservasLayout;

	public ValidacionReservasCamposLayout() {
		super();
	}

	public ValidacionReservasCamposLayout(List<ReservasCamposLayout> listaCamposLayoutCab, List<ReservasCamposLayout> listaCamposLayoutDet, String hoja) {
		super();
		listaReservasLayout = new ArrayList<ReservasCamposLayoutBean>();
		this.listaCamposLayoutCab = listaCamposLayoutCab;
		this.listaCamposLayoutDet = listaCamposLayoutDet;
		this.periodoContable = "";
		this.fechaTransaccion = "";
		this.tipoDiario = "";
		this.hoja = hoja;
	}

	@Override
	public void startRow(int rowNum) {
		// TODO Auto-generated method stub
		reservasLayout = new ReservasCamposLayoutBean();
		try {
			rowStart = rowNum;
			mapColumnsValues = obtenerColumnsValues();
			//System.out.println("fila: "+rowNum);
			if (rowNum == 2 || rowNum == 3 || rowNum == 4) {
				leerCabecera = true;
				leerCabeceraDet = false;
				leerCuerpoDet = false;
				colCab++;
			}
			if (rowNum == 6) {
				leerCabecera = false;
				leerCabeceraDet = true;
			}
			if (rowNum == 7) {
				leerCabeceraDet = false;
				leerCuerpoDet = true;
				colCabDet = 0;
			}
		} catch (Exception e) {
			throw new RuntimeException(
					PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL));
		}
	}

	@Override
	public void endRow() {
		// TODO Auto-generated method stub
		if (leerCabecera) {
			String valor = mapColumnsValues.get(Constantes.CONTA_RESERVA_COL_CAB_VAL);
			//System.out.println("valor cabecera "+Constantes.CONTA_RESERVA_COL_CAB_VAL+contFilas+": "+valor);
			if(!valor.equals("")) {
				if(contFilas==3) periodoContable = valor;
				if(contFilas==4) fechaTransaccion = valor;
				if(contFilas==5) tipoDiario = valor;
			}
		}
		if (leerCuerpoDet) {
			for (int i = 0; i < listaCamposLayoutDet.size(); i++) {
				if (listaCamposLayoutDet.get(i).isOblCampo()) {
					boolean validacion = validarCampoObligatorio(listaCamposLayoutDet.get(i),
							mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
					if (!validacion) {
						throw new RuntimeException(
								PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
					}
				} else {
					boolean validacion = validarCampoNoObligatorio(listaCamposLayoutDet.get(i),
							mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
					if (!validacion) {
						throw new RuntimeException(
								PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
					}
				}
			}
			mapColumnsValues.clear();
			
			if (reservasLayout != null) {
				reservasLayout.setPeriodoContable(periodoContable);
				try {
					DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					reservasLayout.setFechaTransaccion(format.parse(formatFecha(fechaTransaccion.trim())));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				reservasLayout.setTipoDiario(tipoDiario);
				reservasLayout.setFechaCarga(new Date());
				String usuario = FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("userSun").toString();
				reservasLayout.setUsuario(usuario);
				reservasLayout.setNombreHoja(hoja);
				// System.out.println("reservasLayout: "+reservasLayout);
				listaReservasLayout.add(reservasLayout);
			}
		}
	}

	@Override
	public void cell(String cellReference, String formattedValue) {
		// TODO Auto-generated method stub
		int fila = Integer.valueOf(cellReference.substring(1));
		contFilas = fila;
		String column = "";

		if (leerCabecera) {
			column = cellReference.substring(0, 1);
			//System.out.println("leerCabecera: "+cellReference+" -> "+colCab+" : "+formattedValue);
			if(column.equals(Constantes.CONTA_RESERVA_COL_CAB)) {
				boolean esCabeceraValida = validarCabeceraOrdenYNombreCol(listaCamposLayoutCab, (colCab-1), formattedValue);
				if (!esCabeceraValida) {
					error = true;
					throw new RuntimeException(
							PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAB_EXCEL));
				}
			}
			if(column.equals(Constantes.CONTA_RESERVA_COL_CAB_VAL)) { 
				mapColumnsValues.put(column, formattedValue);
			}
		}else if (leerCabeceraDet) {
			//System.out.println("leerCabeceraDet: "+cellReference+" -> "+colCabDet+" : "+formattedValue);
			boolean esCabeceraValida = validarCabeceraOrdenYNombreCol(listaCamposLayoutDet, colCabDet, formattedValue);
			if (!esCabeceraValida) {
				error = true;
				throw new RuntimeException(
						PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAB_EXCEL));
			}
			colCabDet++;
		} else if (leerCuerpoDet) {
			//System.out.println("leerCuerpoDet: "+cellReference+" -> "+formattedValue);
			if (!getLength(cellReference)) {
				column = cellReference.substring(0, 1);
				// Establecer el valor de la celda segun la columna
				mapColumnsValues.put(column, formattedValue);
				
				// Construir objeto dependiendo del banco seleccionado
				try {
					leerColumnasReservas(column, (formattedValue!=null?formattedValue:""));
				} catch (Exception ex) { // SyncconException
					ex.printStackTrace();
					System.out.println("ERROR SYNCCON: " + ex.getMessage());
					LOGGER.error("error exception: ", ex);
				}
			} else {
				column = cellReference.substring(0, 2);
			}
		}
	}

	@Override
	public void headerFooter(String text, boolean isHeader, String tagName) {
		// TODO Auto-generated method stub

	}
	
	private boolean validarCabeceraOrdenYNombreCol(List<ReservasCamposLayout> listaCamposLayout, int nroOrdenCampo, String nombreColumna) {
		if (listaCamposLayout.get(nroOrdenCampo).getNomCampo().trim().equalsIgnoreCase(nombreColumna)) {
			return true;
		}
		return false;
	}

	private boolean validarCampoObligatorio(ReservasCamposLayout campo, String valorCelda) {
		try {
			//System.out.println("campo: "+campo.getNomCampo()+" ~ Tipo: "+campo.getTipoDato()+" ~ "+valorCelda);
			// Si la celda esta vacia y el campo es obligatorio
			if (valorCelda == null || valorCelda.trim().length() == 0) {
				return false;
			}
			// Si es alfanumerico
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_ALFANUMERICO)) {
				return valorCelda == null ? false : valorCelda.trim().length() == 0 ? false : true;
			}
			// Si es Numerico
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {
				// Eliminar comas separadoras de miles
				//valorCelda = valorCelda.replace("*", "").replace(",", "~");
				//valorCelda = valorCelda.replace(".", "").replace("~", ".");
				//System.out.println("valorCelda: "+valorCelda);
				// Parsear en bigdecimal
				//new BigDecimal(valorCelda.trim());
				
				valorCelda = String.valueOf(obtenerMontoReserva((!valorCelda.equals("")?valorCelda:"0")));
				//System.out.println("valorCelda: "+valorCelda);
				Double.parseDouble(valorCelda.trim());
				return true;
			}
			// Si es tipo Fecha
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
				SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoColumna());
				sdf.format(sdf.parse(valorCelda));
				return true;
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
			return false;
		}
	}

	private boolean validarCampoNoObligatorio(ReservasCamposLayout campo, String valorCelda) {
		try {
			// Si no es obligatorio pero la celda tiene valor
			if (valorCelda != null && valorCelda.trim().length() > 0) {
				// Si es Numerico
				if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {
					// Eliminar comas separadoras de miles
					//valorCelda = valorCelda.replace("*", "").replace(",", "~");
					//valorCelda = valorCelda.replace(".", "").replace("~", ".");
					//System.out.println("valorCelda: "+valorCelda);
					// Parsear en bigdecimal
					//new BigDecimal(valorCelda.trim());
					
					valorCelda = String.valueOf(obtenerMontoReserva((!valorCelda.equals("")?valorCelda:"0")));
					//System.out.println("valorCelda: "+valorCelda);
					Double.parseDouble(valorCelda.trim());
					return true;
				}
				// Si es tipo Fecha
				else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
					SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoColumna());
					sdf.format(sdf.parse(valorCelda));
					return true;
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage(), e);
			return false;
		}
	}
	
	public String formatFecha(String fecha) {
		String fechaResult = fecha;
		//System.out.println("fecha: "+fecha);
		String dia = String.valueOf(Calendar.DAY_OF_MONTH);
		String mes = String.valueOf(Calendar.MONTH);
		String anio = String.valueOf(Calendar.YEAR);
		//5/31/20
		if(fecha.length()==7) {
			String[] arrFecha = fecha.split("\\/");
			//System.out.println("arrFecha[0]: "+arrFecha[0]);
			if(Integer.valueOf(arrFecha[0])<10) mes = "0"+String.valueOf(Integer.valueOf(arrFecha[0]));
			else mes = arrFecha[0];
			//System.out.println("arrFecha[1]: "+arrFecha[1]);
			if(Integer.valueOf(arrFecha[1])<10) dia = "0"+String.valueOf(Integer.valueOf(arrFecha[1]));
			else dia = arrFecha[1];
			//System.out.println("arrFecha[2]: "+arrFecha[2]);
			//System.out.println("arrFecha[2].length(): "+arrFecha[2].length());
			if(arrFecha[2].length()==2) anio = "20"+arrFecha[2];
			else anio = arrFecha[2];
			fechaResult = anio+"-"+mes+"-"+dia; 
		}
		//System.out.println("fechaResult: "+fechaResult);
		return fechaResult;
	}

	private static synchronized boolean getLength(String cell) {
		boolean res = false;
		int sum = cell.replaceAll("(?i)[^AEIOU]", "").length()
				+ cell.replaceAll("(?i)[^BCDFGHJKLMNPQRSTVWXYZ]", "").length();
		if (sum == 2) {
			res = true;
		}
		return res;
		// return true;
	}

	private HashMap<String, String> obtenerColumnsValues() {
		mapColumnsValues.put("A", "");
		mapColumnsValues.put("B", "");
		mapColumnsValues.put("C", "");
		mapColumnsValues.put("D", "");
		mapColumnsValues.put("E", "");
		mapColumnsValues.put("F", "");
		mapColumnsValues.put("G", "");
		mapColumnsValues.put("H", "");
		mapColumnsValues.put("I", "");
		mapColumnsValues.put("J", "");
		mapColumnsValues.put("K", "");
		mapColumnsValues.put("L", "");
		mapColumnsValues.put("M", "");
		mapColumnsValues.put("N", "");
		mapColumnsValues.put("O", "");
		mapColumnsValues.put("P", "");
		mapColumnsValues.put("Q", "");
		mapColumnsValues.put("R", "");
		mapColumnsValues.put("S", "");
		mapColumnsValues.put("T", "");
		mapColumnsValues.put("U", "");
		mapColumnsValues.put("V", "");
		mapColumnsValues.put("W", "");
		mapColumnsValues.put("X", "");
		mapColumnsValues.put("Y", "");
		mapColumnsValues.put("Z", "");
		return mapColumnsValues;
	}
	
	private void leerColumnasReservas(String columna, String valor) throws Exception {
		
		if (columna.equals("A")) {
			reservasLayout = new ReservasCamposLayoutBean();
			reservasLayout.setCodigoCuenta(valor);
		}else if (columna.equals("B")) {
			reservasLayout.setNombreCuenta(valor);
		}else if (columna.equals("C")) {
			reservasLayout.setImporteTransaccion(obtenerMontoReserva((!valor.equals("")?valor:"0")).doubleValue());
		}else if (columna.equals("D")) {
			reservasLayout.setCodigoMoneda(valor);
		}else if (columna.equals("E")) {
			reservasLayout.setRefTransaccion(valor);
		}else if (columna.equals("F")) {
			reservasLayout.setDescripcion(valor);
		}else if (columna.equals("G")) {
			reservasLayout.setCentroCosto(valor);
		}else if (columna.equals("H")) {
			reservasLayout.setSocioProducto(valor);
		}else if (columna.equals("I")) {
			reservasLayout.setCanal(valor);
		}else if (columna.equals("J")) {
			reservasLayout.setProveedorEmpleado(valor);
		}else if (columna.equals("K")) {
			reservasLayout.setDocumentoCliente(valor);
		}else if (columna.equals("L")) {
			reservasLayout.setPolizaCliente(valor);
		}else if (columna.equals("M")) {
			reservasLayout.setInversiones(valor);
		}else if (columna.equals("N")) {
			reservasLayout.setNroSiniestro(valor);
		}else if (columna.equals("O")) {
			reservasLayout.setTipoCdpSunat(valor);
		}else if (columna.equals("P")) {
			reservasLayout.setMedioPago(valor);
		}else if (columna.equals("Q")) {
			reservasLayout.setIndicadorActivo(valor);
		}else if (columna.equals("R")) {
			reservasLayout.setCodigoActivo(valor);
		}else if (columna.equals("S")) {
			reservasLayout.setTasaBase(valor);
		}else if (columna.equals("T")) {
			reservasLayout.setNroRetDet(valor);
		}else if (columna.equals("U")) {
			reservasLayout.setLayout(valor);
		}
	}
	
	private BigDecimal obtenerMontoReserva(String source) {
		BigDecimal monto = obtenerValorNumerico(source.replace("*", ""));
		//BigDecimal monto = obtenerNuevoNumerico(source);
		//return monto.doubleValue() > 0 ? monto.negate() : monto;
		return monto;
	}
	
	private BigDecimal obtenerNuevoNumerico(String numero) {
		numero = numero.replace("*", "").replace(",", "~");
		numero = numero.replace(".", "").replace("~", ".");
		return new BigDecimal(numero.trim());
	}
	
	private BigDecimal obtenerValorNumerico(String source) {

		if (source != null && source.trim().length() > 0) {
			if (source.contains(".") && source.contains(",")) {
				int indexPunto = source.indexOf(".");
				int indexComa = source.indexOf(",");
				if (indexPunto < indexComa) {
					source = source.replace(".", "");
				} else {
					source = source.replace(",", "");
				}
				source = source.replace(",", ".");
				//source = source.replace(",", "");
			} else if (source.contains(",")) {
				source = source.replace(",", ".");
				//source = source.replace(",", "");
			}

			source = source.replaceAll("[^0-9\\.-]+", "");

			if (source.indexOf(".") != source.lastIndexOf(".")) {

				String alphaAndDigits = "";
				String[] vnum = source.split("\\.");
				int ind = vnum.length - 1;
				//System.out.println("antes if vnum.length-1 : " + ind);
				if (vnum.length > 0) {
					for (int i = 0; i < vnum.length - 1; i++) {
						alphaAndDigits = alphaAndDigits.concat(vnum[i]);
					}
					alphaAndDigits = alphaAndDigits.concat(".");
					ind = vnum.length - 1;
					//System.out.println("vnum.length-1 : " + ind);
					alphaAndDigits = alphaAndDigits.concat(vnum[ind]);

					//System.out.println("alphaAndDigits : " + alphaAndDigits);
					source = alphaAndDigits;
					//System.out.println("source : " + source);
				}
			}
			//System.out.println("source: "+source.trim());
			return new BigDecimal(source.trim());
		}
		return null;
	}

	public boolean isLeerCabecera() {
		return leerCabecera;
	}

	public void setLeerCabecera(boolean leerCabecera) {
		this.leerCabecera = leerCabecera;
	}
	
	public boolean isLeerCabeceraDet() {
		return leerCabeceraDet;
	}

	public void setLeerCabeceraDet(boolean leerCabeceraDet) {
		this.leerCabeceraDet = leerCabeceraDet;
	}

	public boolean isLeerCuerpoDet() {
		return leerCuerpoDet;
	}

	public void setLeerCuerpoDet(boolean leerCuerpoDet) {
		this.leerCuerpoDet = leerCuerpoDet;
	}

	public int getColCabDet() {
		return colCabDet;
	}

	public void setColCabDet(int colCabDet) {
		this.colCabDet = colCabDet;
	}
	
	public List<ReservasCamposLayout> getListaCamposLayoutCab() {
		return listaCamposLayoutCab;
	}

	public void setListaCamposLayoutCab(List<ReservasCamposLayout> listaCamposLayoutCab) {
		this.listaCamposLayoutCab = listaCamposLayoutCab;
	}

	public List<ReservasCamposLayout> getListaCamposLayoutDet() {
		return listaCamposLayoutDet;
	}

	public void setListaCamposLayoutDet(List<ReservasCamposLayout> listaCamposLayoutDet) {
		this.listaCamposLayoutDet = listaCamposLayoutDet;
	}

	public int getContFilas() {
		return contFilas;
	}

	public void setContFilas(int contFilas) {
		this.contFilas = contFilas;
	}

	public HashMap<String, String> getMapColumnsValues() {
		return mapColumnsValues;
	}

	public void setMapColumnsValues(HashMap<String, String> mapColumnsValues) {
		this.mapColumnsValues = mapColumnsValues;
	}

	public boolean isSalir() {
		return salir;
	}

	public void setSalir(boolean salir) {
		this.salir = salir;
	}

	public int getRowStart() {
		return rowStart;
	}

	public void setRowStart(int rowStart) {
		this.rowStart = rowStart;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getPeriodoContable() {
		return periodoContable;
	}

	public void setPeriodoContable(String periodoContable) {
		this.periodoContable = periodoContable;
	}

	public String getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public String getTipoDiario() {
		return tipoDiario;
	}

	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}

	public List<ReservasCamposLayoutBean> getListaReservasLayout() {
		return listaReservasLayout;
	}

	public void setListaReservasLayout(List<ReservasCamposLayoutBean> listaReservasLayout) {
		this.listaReservasLayout = listaReservasLayout;
	}

	public ReservasCamposLayoutBean getReservasLayout() {
		return reservasLayout;
	}

	public void setReservasLayout(ReservasCamposLayoutBean reservasLayout) {
		this.reservasLayout = reservasLayout;
	}

	public String getHoja() {
		return hoja;
	}

	public void setHoja(String hoja) {
		this.hoja = hoja;
	}

}

/*** Fin {Automatización Contabilidad} - {Sprint 1} **/