package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@SuppressWarnings("rawtypes")
public class CampoLayoutCpeBean implements Serializable, Comparable{

	private static final long serialVersionUID = 1L;
	
	private Long idLayout;
	private Long idCampo;
	private String nomCol;
	private Long ordCampo;
	private Long posIni;
	private Long posFin;
	private Long longitud;
	private String tipoDato;
	private String formatoCol;
	private String flgObl;
	private String usuarioCreacion;
	private Date fechaCreacion;
	private String usuarioModificacion;
	private Date fechaModificacion;
	
	/*TIP_PER0100_CC09_13 INICIO 2019/05/02 14:10 Se agregan campos para archivo Layout*/
	/**Atributo que almacena el número de orden de compra*/
	private String ordenCompra;
	/**Atributo que almacena el indicador de aplicación de detracción*/
	private String aplicaDetraccion;
	/**Atributo que almacena el porcentaje de detracción*/
	private BigDecimal porcDetraccion;
	/**Atributo que almacena el título adicional*/
	private String tituloAdicional;
	/**Atributo que almacena el valor adicional*/
	private String valorAdicional;
	/*TIP_PER0100_CC09_13 FIN*/
	
	public Long getIdLayout() {
		return idLayout;
	}

	public void setIdLayout(Long idLayout) {
		this.idLayout = idLayout;
	}
	
	public Long getIdCampo() {
		return idCampo;
	}

	public void setIdCampo(Long idCampo) {
		this.idCampo = idCampo;
	}

	public String getNomCol() {
		return nomCol;
	}

	public void setNomCol(String nomCol) {
		this.nomCol = nomCol;
	}

	public Long getOrdCampo() {
		return ordCampo;
	}

	public void setOrdCampo(Long ordCampo) {
		this.ordCampo = ordCampo;
	}

	public Long getPosIni() {
		return posIni;
	}

	public void setPosIni(Long posIni) {
		this.posIni = posIni;
	}

	public Long getPosFin() {
		return posFin;
	}

	public void setPosFin(Long posFin) {
		this.posFin = posFin;
	}

	public Long getLongitud() {
		return longitud;
	}

	public void setLongitud(Long longitud) {
		this.longitud = longitud;
	}

	public String getTipoDato() {
		return tipoDato;
	}

	public void setTipoDato(String tipoDato) {
		this.tipoDato = tipoDato;
	}

	public String getFormatoCol() {
		return formatoCol;
	}

	public void setFormatoCol(String formatoCol) {
		this.formatoCol = formatoCol;
	}

	public String getFlgObl() {
		return flgObl;
	}

	public void setFlgObl(String flgObl) {
		this.flgObl = flgObl;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	
	/*TIP_PER0100_CC09_13 INICIO 2019/05/02 14:15 Se definen los metodos get y set de los atributos agregados*/
	
	/**
	 * Método que permite obtener el número de orden de compra.
	 * @return ordenCompra Número de orden de compra, tipo String.
	 */
	public String getOrdenCompra() {
		return ordenCompra;
	}

	/**
	 *Método que permite actualizar el número de orden de compra.
	 * @param ordenCompra Número de orden de compra, tipo String.
	 */
	public void setOrdenCompra(String ordenCompra) {
		this.ordenCompra = ordenCompra;
	}

	/**
	 * Método que permite obtener el indicador de aplicación de detracción.
	 * @return aplicaDetraccion Indicador de aplicación de detracción, tipo String.
	 */
	public String getAplicaDetraccion() {
		return aplicaDetraccion;
	}

	/**
	 * Método que permite actualizar el indicador de aplicación de detracción. 
	 * @param aplicaDetraccion Indicador de aplicación de detracción, tipo String.
	 */
	public void setAplicaDetraccion(String aplicaDetraccion) {
		this.aplicaDetraccion = aplicaDetraccion;
	}

	/**
	 * Método que permite obtener el título adicional.
	 * @return tituloAdicional Título adicional, tipo String.
	 */
	public String getTituloAdicional() {
		return tituloAdicional;
	}

	/**
	 * Método que permite actualizar el título adicional.
	 * @param tituloAdicional Título adicional, tipo String.
	 */
	public void setTituloAdicional(String tituloAdicional) {
		this.tituloAdicional = tituloAdicional;
	}

	/**
	 * Método que permite obtener el valor adicional.
	 * @return valorAdicional ValorAdicional, tipo String.
	 */
	public String getValorAdicional() {
		return valorAdicional;
	}

	/**
	 * Método que permite actualizar el valor adicional.
	 * @param valorAdicional Valor Adicional, tipo String.
	 */
	public void setValorAdicional(String valorAdicional) {
		this.valorAdicional = valorAdicional;
	}
	
	/**
	 * Método que permite obtener el porcentaje de detracción.
	 * @return porcDetraccion Porcentaje de Detracción, tipo BigDecimal.
	 */
	public BigDecimal getPorcDetraccion() {
		return porcDetraccion;
	}

	/**
	 * Método que permite actualizar el porcentaje de detracción.
	 * @param porcDetraccion Porcentaje de Detracción, tipo BigDecimal.
	 */
	public void setPorcDetraccion(BigDecimal porcDetraccion) {
		this.porcDetraccion = porcDetraccion;
	}
	
	/*TIP_PER0100_CC09_13 FIN*/
	


	/*TIP_PER0100_CC09_13 INICIO  2019/05/02 11:30 Se agrega método compareTo*/
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
    public int compareTo(Object o) {
         return this.getOrdCampo().compareTo(((CampoLayoutCpeBean) o).getOrdCampo());
    }
	/*TIP_PER0100_CC09_13 FIN*/

}
