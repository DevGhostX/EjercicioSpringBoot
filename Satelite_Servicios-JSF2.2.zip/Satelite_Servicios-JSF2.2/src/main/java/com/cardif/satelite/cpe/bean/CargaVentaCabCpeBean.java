package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class CargaVentaCabCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long idUsuario;
	private Long idCarga;
	private String idOrigen;
	private String idTipoCarga;
	private String nomArchivo;
	private Long numRegistro;
	private String estadoCarga;
	private String usuarioCarga;
	private Date fechaCarga;
	private String fechaArchivo;
	private String pesoArchivo;
	
	private boolean seleccionado;
	
	private Long idTramaUpload;
	private String nombreTramaUpload;

	private List<VentaCpeBean> listDet;

	public CargaVentaCabCpeBean(){}

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getIdOrigen() {
		return idOrigen;
	}

	public void setIdOrigen(String idOrigen) {
		this.idOrigen = idOrigen;
	}

	public String getIdTipoCarga() {
		return idTipoCarga;
	}

	public void setIdTipoCarga(String idTipoCarga) {
		this.idTipoCarga = idTipoCarga;
	}

	public String getNomArchivo() {
		return nomArchivo;
	}

	public void setNomArchivo(String nomArchivo) {
		this.nomArchivo = nomArchivo;
	}

	public String getEstadoCarga() {
		return estadoCarga;
	}

	public void setEstadoCarga(String estadoCarga) {
		this.estadoCarga = estadoCarga;
	}

	public String getUsuarioCarga() {
		return usuarioCarga;
	}

	public void setUsuarioCarga(String usuarioCarga) {
		this.usuarioCarga = usuarioCarga;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public String getFechaArchivo() {
		return fechaArchivo;
	}

	public void setFechaArchivo(String fechaArchivo) {
		this.fechaArchivo = fechaArchivo;
	}

	public String getPesoArchivo() {
		return pesoArchivo;
	}

	public void setPesoArchivo(String pesoArchivo) {
		this.pesoArchivo = pesoArchivo;
	}

	public Long getIdCarga() {
		return idCarga;
	}

	public void setIdCarga(Long idCarga) {
		this.idCarga = idCarga;
	}

	public Long getNumRegistro() {
		return numRegistro;
	}

	public void setNumRegistro(Long numRegistro) {
		this.numRegistro = numRegistro;
	}
	
	public List<VentaCpeBean> getListDet() {
		return listDet;
	}

	public void setListDet(List<VentaCpeBean> listDet) {
		this.listDet = listDet;
	}
	
	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}
	
	public Long getIdTramaUpload() {
		return idTramaUpload;
	}

	public void setIdTramaUpload(Long idTramaUpload) {
		this.idTramaUpload = idTramaUpload;
	}

	public String getNombreTramaUpload() {
		return nombreTramaUpload;
	}

	public void setNombreTramaUpload(String nombreTramaUpload) {
		this.nombreTramaUpload = nombreTramaUpload;
	}
}
