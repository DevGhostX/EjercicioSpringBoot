/**------------------------------------------------------------------------------------------------ 
	Nombre: 		CargaVentaItemCpeBean.java
	Tipo: 			Creación
	Proyecto: 		TIP_PER0100_CC14
	Fecha:			2019/06/14 14:50
	Autor:			TIPROYEC
	Descripción: 	Clase que permite almacenar los datos asociados a los Items de detalle de
					venta de los comprobantes.
 -----------------------------------------------------------------------------------------------*/
package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;

public class CargaVentaItemCpeBean implements Serializable{

	/**id de serialización de la clase*/
	private static final long serialVersionUID = 1L;
	/**Atributo que almacena el id de item de detalle de venta. */
	private Long idItemDetalleVenta;
	/**Atributo que almacena el id de venta. */
	private Long idVenta;
	/**Atributo que almacena el concepto del detalle de venta.*/
	private String concepto;
	/**Atributo que almacena la cantidad por detalle de venta.*/
	private int cantidad;
	/**Atributo que almacena el valor de la venta del detalle de venta.*/
	private BigDecimal valorVenta;
	/**Atributo que almacena el igv del detalle de venta.*/
	private BigDecimal igv;
	/**Atributo que almacena el valor total del detalle de venta.*/
	private BigDecimal valorTotal;
	/**Atributo que almacena el estado de mantenimiento para identificar si es un registro nuevo o no.*/
	private String estadoMantenimiento;
	/**Atributo que almacena el usuario de creación del registro*/
	private String usuarioCreacion;
	
	/**
	 * Método que permite obtener el id de item de detalle de venta.
	 * @return idItemDetalleVenta Id de item de detalle de venta, tipo Long.
	 */
	public Long getIdItemDetalleVenta() {
		return idItemDetalleVenta;
	}
	
	/**
	 * Método que permite actualizar el id de item de detalle de venta. 
	 * @param idItemDetalleVenta Id de item de detalle de venta, tipo Long.
	 */
	public void setIdItemDetalleVenta(Long idItemDetalleVenta) {
		this.idItemDetalleVenta = idItemDetalleVenta;
	}
	
	/**
	 * Método que permite obtener el id de venta.
	 * @return idVenta Id de venta, tipo Long.
	 */
	public Long getIdVenta() {
		return idVenta;
	}
	
	/**
	 * Método que permite actualizar el id de venta.
	 * @param idVenta Id de venta, tipo Long.
	 */
	public void setIdVenta(Long idVenta) {
		this.idVenta = idVenta;
	}
	
	/**
	 * Método que permite obtener el concepto del detalle de venta.
	 * @return concepto Concepto del detalle de venta, tipo String.
	 */
	public String getConcepto() {
		return concepto;
	}
	
	/**
	 * Método que permite actualizar el concepto del detalle de venta. 
	 * @param concepto Concepto del detalle de venta, tipo String.
	 */
	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}
	
	/**
	 * Método que permite obtener la cantidad por detalle de venta.
	 * @return cantidad Cantidad por detalle de venta, tipo int.
	 */
	public int getCantidad() {
		return cantidad;
	}
	
	/**
	 * Método que permite actualizar la cantidad por detalle de venta.
	 * @param cantidad Cantidad por detalle de venta, tipo int.
	 */
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	/**
	 * Método que permite obtener el valor de la venta del detalle de venta.
	 * @return valorVenta Valor de la venta del detalle de venta, tipo BigDecimal.
	 */
	public BigDecimal getValorVenta() {
		return valorVenta;
	}
	
	/**
	 * Método que permite actualizar el valor de la venta del detalle de venta. 
	 * @param valorVenta Valor de la venta del detalle de venta, tipo BigDecimal.
	 */
	public void setValorVenta(BigDecimal valorVenta) {
		this.valorVenta = valorVenta;
	}
	
	/**
	 * Método que permite obtener el igv del detalle de venta.
	 * @return igv Igv del detalle de venta, tipo BigDecimal.
	 */
	public BigDecimal getIgv() {
		return igv;
	}
	
	/**
	 * Método que permite actualizar el igv del detalle de venta.
	 * @param igv Igv del detalle de venta, tipo BigDecimal.
	 */
	public void setIgv(BigDecimal igv) {
		this.igv = igv;
	}
	
	/**
	 * Método que permite obtener el valor total del detalle de venta.
	 * @return valorTotal Valor total del detalle de venta, tipo BigDecimal.
	 */
	public BigDecimal getValorTotal() {
		return valorTotal;
	}
	
	/**
	 * Método que permite actualizar el valor total del detalle de venta. 
	 * @param valorTotal Valor total del detalle de venta, tipo BigDecimal.
	 */
	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	/**
	 * Método que permite obtener el estado de mantenimiento para identificar si es un registro nuevo o no.
	 * @return estadoMantenimiento Estado de mantenimiento para identificar si es un registro nuevo o no, tipo String.
	 */
	public String getEstadoMantenimiento() {
		return estadoMantenimiento;
	}

	/**
	 * Método que permite actualizar el estado de mantenimiento para identificar si es un registro nuevo o no. 
	 * @param estadoMantenimiento Estado de mantenimiento para identificar si es un registro nuevo o no, tipo String.
	 */
	public void setEstadoMantenimiento(String estadoMantenimiento) {
		this.estadoMantenimiento = estadoMantenimiento;
	}

	/**
	 * Método que permite obtener el usuario de creación del registro.
	 * @return usuarioCreacion Usuario de creación del registro, tipo String.
	 */
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	/**
	 * Método que permite actualizar el usuario de creación del registro.
	 * @param usuarioCreacion Usuario de creación del registro, tipo String.
	 */
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}
	
	
}
