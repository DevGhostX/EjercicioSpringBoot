package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class ComprobanteCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long idComprobante;
	private Long idVenta;
	private String idTipoComp;
	private Long idVentaProceso;
	private String idEmpresa;
	private Long idSocio;
	private Long idProducto;
	private String serieComp;
	private String corrComp;
	private String fecEmision;
	private String estadoComp;
	private String usuCrea;
	private Date fecCrea;
	private Long codError;
	private String descError;
	private String numComprobante;
	private Long idPle;
	private Date fechaEmisionDate;

	public ComprobanteCpeBean(){}

	public Long getIdComprobante() {
		return idComprobante;
	}

	public void setIdComprobante(Long idComprobante) {
		this.idComprobante = idComprobante;
	}

	public Long getIdVenta() {
		return idVenta;
	}

	public void setIdVenta(Long idVenta) {
		this.idVenta = idVenta;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}

	public Long getIdVentaProceso() {
		return idVentaProceso;
	}

	public void setIdVentaProceso(Long idVentaProceso) {
		this.idVentaProceso = idVentaProceso;
	}

	public String getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public Long getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Long idSocio) {
		this.idSocio = idSocio;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public String getSerieComp() {
		return serieComp;
	}

	public void setSerieComp(String serieComp) {
		this.serieComp = serieComp;
	}

	public String getCorrComp() {
		return corrComp;
	}

	public void setCorrComp(String corrComp) {
		this.corrComp = corrComp;
	}

	public String getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(String fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getEstadoComp() {
		return estadoComp;
	}

	public void setEstadoComp(String estadoComp) {
		this.estadoComp = estadoComp;
	}

	public String getUsuCrea() {
		return usuCrea;
	}

	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public Long getCodError() {
		return codError;
	}

	public void setCodError(Long codError) {
		this.codError = codError;
	}

	public String getDescError() {
		return descError;
	}

	public void setDescError(String descError) {
		this.descError = descError;
	}

	public String getNumComprobante() {
		return numComprobante;
	}

	public void setNumComprobante(String numComprobante) {
		this.numComprobante = numComprobante;
	}

	public Long getIdPle() {
		return idPle;
	}

	public void setIdPle(Long idPle) {
		this.idPle = idPle;
	}
	
	public Date getFechaEmisionDate() {
		return fechaEmisionDate;
	}

	public void setFechaEmisionDate(Date fechaEmisionDate) {
		this.fechaEmisionDate = fechaEmisionDate;
	}
}
