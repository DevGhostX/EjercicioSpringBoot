package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class ConfiguracionCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;

	private String idEmpresa;
	private Integer idSocio;
	private Integer idProducto;
	private String idTipoComp;
	private String idTipoCompRef;	
	private Integer afectoIgv;
	private String indPims;
	private String estadoConfig;
	private String prefijo;
	private String serie;
	private Integer corInicial;
	private Integer corActual;
	private String observaciones;
	private String usuCrea;
	private Date fecCrea;
	private String usuModifica;
	private Date fecModifica;
	private String flgAgrupado;
	
	/* Campos adiciones para consulta */
	private String nomEmpresa;
	private String nomSocio;
	private String nomProducto;
	private String nomTipoComp;
	private String tipoProducto;
	private String nomTipoProducto;
	private String codParam1;
	private String codParam2;
	private String codParam3;
	
	/*TIP_PER0100_CC09_13 INICIO 2019/05/17 - 12:50 - Se agrega el atributo lista de tipo de movimiento*/
	/** Atributo que almacena el tipo de movimiento de un producto */
	private String tipoMovimiento;
	/*TIP_PER0100_CC09_13 FIN */
	
	public ConfiguracionCpeBean() {}

	public String getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public Integer getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Integer idSocio) {
		this.idSocio = idSocio;
	}

	public Integer getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Integer idProducto) {
		this.idProducto = idProducto;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}
	
	public String getIdTipoCompRef() {
		return idTipoCompRef;
	}

	public void setIdTipoCompRef(String idTipoCompRef) {
		this.idTipoCompRef = idTipoCompRef;
	}

	public Integer getAfectoIgv() {
		return afectoIgv;
	}

	public void setAfectoIgv(Integer afectoIgv) {
		this.afectoIgv = afectoIgv;
	}

	public String getIndPims() {
		return indPims;
	}

	public void setIndPims(String indPims) {
		this.indPims = indPims;
	}

	public String getEstadoConfig() {
		return estadoConfig;
	}

	public void setEstadoConfig(String estadoConfig) {
		this.estadoConfig = estadoConfig;
	}

	public String getPrefijo() {
		return prefijo;
	}

	public void setPrefijo(String prefijo) {
		this.prefijo = prefijo;
	}

	public String getSerie() {
		return serie;
	}

	public void setSerie(String serie) {
		this.serie = serie;
	}

	public Integer getCorInicial() {
		return corInicial;
	}

	public void setCorInicial(Integer corInicial) {
		this.corInicial = corInicial;
	}

	public Integer getCorActual() {
		return corActual;
	}

	public void setCorActual(Integer corActual) {
		this.corActual = corActual;
	}

	public String getUsuCrea() {
		return usuCrea;
	}

	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public String getUsuModifica() {
		return usuModifica;
	}

	public void setUsuModifica(String usuModifica) {
		this.usuModifica = usuModifica;
	}

	public Date getFecModifica() {
		return fecModifica;
	}

	public void setFecModifica(Date fecModifica) {
		this.fecModifica = fecModifica;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getTipoProducto() {
		return tipoProducto;
	}

	public void setTipoProducto(String tipoProducto) {
		this.tipoProducto = tipoProducto;
	}

	public String getCodParam1() {
		return codParam1;
	}

	public void setCodParam1(String codParam1) {
		this.codParam1 = codParam1;
	}

	public String getCodParam2() {
		return codParam2;
	}

	public void setCodParam2(String codParam2) {
		this.codParam2 = codParam2;
	}

	public String getNomEmpresa() {
		return nomEmpresa;
	}

	public void setNomEmpresa(String nomEmpresa) {
		this.nomEmpresa = nomEmpresa;
	}

	public String getNomSocio() {
		return nomSocio;
	}

	public void setNomSocio(String nomSocio) {
		this.nomSocio = nomSocio;
	}

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public String getNomTipoComp() {
		return nomTipoComp;
	}

	public void setNomTipoComp(String nomTipoComp) {
		this.nomTipoComp = nomTipoComp;
	}

	public String getCodParam3() {
		return codParam3;
	}

	public void setCodParam3(String codParam3) {
		this.codParam3 = codParam3;
	}

	public String getNomTipoProducto() {
		return nomTipoProducto;
	}

	public void setNomTipoProducto(String nomTipoProducto) {
		this.nomTipoProducto = nomTipoProducto;
	}

	public String getFlgAgrupado() {
		return flgAgrupado;
	}

	public void setFlgAgrupado(String flgAgrupado) {
		this.flgAgrupado = flgAgrupado;
	}

	/*TIP_PER0100_CC09_13 INICIO 2019/05/17 - 12:54 - Se agrega los métodos get y set del atributo tipoMovimiento*/
	
	public String getTipoMovimiento() {
		return tipoMovimiento;
	}

	public void setTipoMovimiento(String tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}

	/*TIP_PER0100_CC09_13 FIN*/
}