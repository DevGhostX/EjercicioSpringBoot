package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class LayoutCabCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long idLayout;
	private String nomLayout;
	private String extLayout;
	private String nomHoja;
	private String carSepCampo;
	private String carSepRegistro;
	private String usuarioCreacion;
	private Date fechaCreacion;
	private String usuarioModificacion;
	private Date fechaModificacion;
	
	public Long getIdLayout() {
		return idLayout;
	}

	public void setIdLayout(Long idLayout) {
		this.idLayout = idLayout;
	}

	public String getNomLayout() {
		return nomLayout;
	}

	public void setNomLayout(String nomLayout) {
		this.nomLayout = nomLayout;
	}

	public String getExtLayout() {
		return extLayout;
	}

	public void setExtLayout(String extLayout) {
		this.extLayout = extLayout;
	}

	public String getNomHoja() {
		return nomHoja;
	}

	public void setNomHoja(String nomHoja) {
		this.nomHoja = nomHoja;
	}

	public String getCarSepCampo() {
		return carSepCampo;
	}

	public void setCarSepCampo(String carSepCampo) {
		this.carSepCampo = carSepCampo;
	}

	public String getCarSepRegistro() {
		return carSepRegistro;
	}

	public void setCarSepRegistro(String carSepRegistro) {
		this.carSepRegistro = carSepRegistro;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
}
