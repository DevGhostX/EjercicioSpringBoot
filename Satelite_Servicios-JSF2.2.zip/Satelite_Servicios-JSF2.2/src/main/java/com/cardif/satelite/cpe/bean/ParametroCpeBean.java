package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class ParametroCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String codParam;
	private String tipParam;
	private String codValor;
	private String nomValor;
	private String estadoParam;
	private Integer numOrden;
	private String usuCrea;
	private Date fecCrea;
	private String usuModifica;
	private Date fecModifica;
	
	public ParametroCpeBean(){}

	public String getCodParam() {
		return codParam;
	}

	public void setCodParam(String codParam) {
		this.codParam = codParam;
	}

	public String getTipParam() {
		return tipParam;
	}

	public void setTipParam(String tipParam) {
		this.tipParam = tipParam;
	}

	public String getCodValor() {
		return codValor;
	}

	public void setCodValor(String codValor) {
		this.codValor = codValor;
	}

	public String getNomValor() {
		return nomValor;
	}

	public void setNomValor(String nomValor) {
		this.nomValor = nomValor;
	}

	public String getEstadoParam() {
		return estadoParam;
	}

	public void setEstadoParam(String estadoParam) {
		this.estadoParam = estadoParam;
	}

	public Integer getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Integer numOrden) {
		this.numOrden = numOrden;
	}

	public String getUsuCrea() {
		return usuCrea;
	}

	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public String getUsuModifica() {
		return usuModifica;
	}

	public void setUsuModifica(String usuModifica) {
		this.usuModifica = usuModifica;
	}

	public Date getFecModifica() {
		return fecModifica;
	}

	public void setFecModifica(Date fecModifica) {
		this.fecModifica = fecModifica;
	}
	
}
