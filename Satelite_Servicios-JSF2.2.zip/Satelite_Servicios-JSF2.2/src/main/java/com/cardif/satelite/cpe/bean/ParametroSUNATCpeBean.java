package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class ParametroSUNATCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String codParam;
	private String tipParam;
	private String codValor1;
	private String codValor2;
	private String nomValor;
	private String nomAbreviatura;
	private String prefijo1;
	private String prefijo2;
	private String estadoParam;
	private Integer numOrden;
	private String usuCrea;
	private Date fecCrea;
	private String usuModifica;
	private Date fecModifica;
	
	public ParametroSUNATCpeBean(){}
	
	public String getCodParam() {
		return codParam;
	}
	public void setCodParam(String codParam) {
		this.codParam = codParam;
	}
	public String getTipParam() {
		return tipParam;
	}
	public void setTipParam(String tipParam) {
		this.tipParam = tipParam;
	}
	public String getCodValor1() {
		return codValor1;
	}
	public void setCodValor1(String codValor1) {
		this.codValor1 = codValor1;
	}
	public String getCodValor2() {
		return codValor2;
	}
	public void setCodValor2(String codValor2) {
		this.codValor2 = codValor2;
	}
	public String getNomValor() {
		return nomValor;
	}
	public void setNomValor(String nomValor) {
		this.nomValor = nomValor;
	}
	public String getNomAbreviatura() {
		return nomAbreviatura;
	}
	public void setNomAbreviatura(String nomAbreviatura) {
		this.nomAbreviatura = nomAbreviatura;
	}
	public String getPrefijo1() {
		return prefijo1;
	}
	public void setPrefijo1(String prefijo1) {
		this.prefijo1 = prefijo1;
	}
	public String getPrefijo2() {
		return prefijo2;
	}
	public void setPrefijo2(String prefijo2) {
		this.prefijo2 = prefijo2;
	}
	public String getEstadoParam() {
		return estadoParam;
	}
	public void setEstadoParam(String estadoParam) {
		this.estadoParam = estadoParam;
	}
	public Integer getNumOrden() {
		return numOrden;
	}
	public void setNumOrden(Integer numOrden) {
		this.numOrden = numOrden;
	}
	public String getUsuCrea() {
		return usuCrea;
	}
	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}
	public Date getFecCrea() {
		return fecCrea;
	}
	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}
	public String getUsuModifica() {
		return usuModifica;
	}
	public void setUsuModifica(String usuModifica) {
		this.usuModifica = usuModifica;
	}
	public Date getFecModifica() {
		return fecModifica;
	}
	public void setFecModifica(Date fecModifica) {
		this.fecModifica = fecModifica;
	}
}
