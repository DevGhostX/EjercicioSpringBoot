package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class ProcesoCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;

	private Long idProceso;
	private String nombreProceso;
	private String numeroLote;
	private String codUsuarioCreacion;
	private Date fechaCreacion;
	private String tipoProceso;
	private String flgProcesa;

	private String nombreUsuarioCreacion;
	private String codUsuarioModificacion;
	private String nombreUsuarioModificacion;
	private Date fechaModificacion;
	private Long cantidadRegistros;
	private String descEstado;
	
	private String codUsuarioParam;
	private String codEstado;
	private Date fechaDesde;
	private Date fechaHasta;
	private String conRegParam;
	
	private String codigoParametro;
	private String tipoParametro;
	
	public ProcesoCpeBean(){}

	public Long getIdProceso() {
		return idProceso;
	}

	public void setIdProceso(Long idProceso) {
		this.idProceso = idProceso;
	}

	public String getNombreProceso() {
		return nombreProceso;
	}

	public void setNombreProceso(String nombreProceso) {
		this.nombreProceso = nombreProceso;
	}

	public String getNumeroLote() {
		return numeroLote;
	}

	public void setNumeroLote(String numeroLote) {
		this.numeroLote = numeroLote;
	}

	public String getCodUsuarioCreacion() {
		return codUsuarioCreacion;
	}

	public void setCodUsuarioCreacion(String codUsuarioCreacion) {
		this.codUsuarioCreacion = codUsuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getTipoProceso() {
		return tipoProceso;
	}

	public void setTipoProceso(String tipoProceso) {
		this.tipoProceso = tipoProceso;
	}

	public String getNombreUsuarioCreacion() {
		return nombreUsuarioCreacion;
	}

	public void setNombreUsuarioCreacion(String nombreUsuarioCreacion) {
		this.nombreUsuarioCreacion = nombreUsuarioCreacion;
	}

	public String getCodUsuarioModificacion() {
		return codUsuarioModificacion;
	}

	public void setCodUsuarioModificacion(String codUsuarioModificacion) {
		this.codUsuarioModificacion = codUsuarioModificacion;
	}

	public String getNombreUsuarioModificacion() {
		return nombreUsuarioModificacion;
	}

	public void setNombreUsuarioModificacion(String nombreUsuarioModificacion) {
		this.nombreUsuarioModificacion = nombreUsuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public Long getCantidadRegistros() {
		return cantidadRegistros;
	}

	public void setCantidadRegistros(Long cantidadRegistros) {
		this.cantidadRegistros = cantidadRegistros;
	}

	public String getDescEstado() {
		return descEstado;
	}

	public void setDescEstado(String descEstado) {
		this.descEstado = descEstado;
	}

	public String getCodUsuarioParam() {
		return codUsuarioParam;
	}

	public void setCodUsuarioParam(String codUsuarioParam) {
		this.codUsuarioParam = codUsuarioParam;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getConRegParam() {
		return conRegParam;
	}

	public void setConRegParam(String conRegParam) {
		this.conRegParam = conRegParam;
	}

	public String getCodigoParametro() {
		return codigoParametro;
	}

	public void setCodigoParametro(String codigoParametro) {
		this.codigoParametro = codigoParametro;
	}

	public String getTipoParametro() {
		return tipoParametro;
	}

	public void setTipoParametro(String tipoParametro) {
		this.tipoParametro = tipoParametro;
	}
	
	public String getFlgProcesa() {
		return flgProcesa;
	}

	public void setFlgProcesa(String flgProcesa) {
		this.flgProcesa = flgProcesa;
	}
}
