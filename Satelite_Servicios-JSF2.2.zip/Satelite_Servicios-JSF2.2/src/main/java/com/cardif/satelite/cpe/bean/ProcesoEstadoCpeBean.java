package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class ProcesoEstadoCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long idProcesoEstado;
	private Long idProceso;
	private String estadoProceso;
	private String usuModifica;
	private Date fechaModifica;
	
	public ProcesoEstadoCpeBean(){}

	public Long getIdProcesoEstado() {
		return idProcesoEstado;
	}

	public void setIdProcesoEstado(Long idProcesoEstado) {
		this.idProcesoEstado = idProcesoEstado;
	}

	public Long getIdProceso() {
		return idProceso;
	}

	public void setIdProceso(Long idProceso) {
		this.idProceso = idProceso;
	}

	public String getEstadoProceso() {
		return estadoProceso;
	}

	public void setEstadoProceso(String estadoProceso) {
		this.estadoProceso = estadoProceso;
	}

	public String getUsuModifica() {
		return usuModifica;
	}

	public void setUsuModifica(String usuModifica) {
		this.usuModifica = usuModifica;
	}

	public Date getFechaModifica() {
		return fechaModifica;
	}

	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}
}
