package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ProcesoMasivoCpeBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String idTipoComp;
	private String nomTipoComp;
	private String serieComp;
	private String corrComp;
	private Long idSocio;
	private String nomSocio;
	private Long idProducto;
	private String nomProducto;
	private String nomCliRazSoc;
	private String tipoMoneda;
	private String nomMoneda;
	private BigDecimal impTotal;
	private BigDecimal igv;
	private String estadoComp;
	private String nomEstadoComp;
	private String idTipoCarga;
	private String nomTipoCarga;
	private Date fechaCarga;
	
	private Long idProceso;
	private String codigoParametro1;
	private String codigoParametro2;
	private String codigoParametro3;
	private String codigoParametro4;
	private String tipoParametro;
	
	private Long busqIdSocio;
	private Long busqIdProducto;
	private String busqIdTipoComp;
	private String busqIdTipoDocCli;
	private String busqTipoMoneda;
	private String busqConcepto;
	private String busqCliente;
	private Date busqFechaEmision;
	private String busqNumComp;
	private String busqMonto;
	private String busqCertificado;
	private String busqNumDoc;
	
	private String descError;

	public ProcesoMasivoCpeBean(){}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}

	public String getNomTipoComp() {
		return nomTipoComp;
	}

	public void setNomTipoComp(String nomTipoComp) {
		this.nomTipoComp = nomTipoComp;
	}

	public String getSerieComp() {
		return serieComp;
	}

	public void setSerieComp(String serieComp) {
		this.serieComp = serieComp;
	}

	public String getCorrComp() {
		return corrComp;
	}

	public void setCorrComp(String corrComp) {
		this.corrComp = corrComp;
	}

	public Long getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Long idSocio) {
		this.idSocio = idSocio;
	}

	public String getNomSocio() {
		return nomSocio;
	}

	public void setNomSocio(String nomSocio) {
		this.nomSocio = nomSocio;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public String getNomCliRazSoc() {
		return nomCliRazSoc;
	}

	public void setNomCliRazSoc(String nomCliRazSoc) {
		this.nomCliRazSoc = nomCliRazSoc;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public String getNomMoneda() {
		return nomMoneda;
	}

	public void setNomMoneda(String nomMoneda) {
		this.nomMoneda = nomMoneda;
	}

	public BigDecimal getImpTotal() {
		return impTotal;
	}

	public void setImpTotal(BigDecimal impTotal) {
		this.impTotal = impTotal;
	}

	public BigDecimal getIgv() {
		return igv;
	}

	public void setIgv(BigDecimal igv) {
		this.igv = igv;
	}

	public String getEstadoComp() {
		return estadoComp;
	}

	public void setEstadoComp(String estadoComp) {
		this.estadoComp = estadoComp;
	}

	public String getNomEstadoComp() {
		return nomEstadoComp;
	}

	public void setNomEstadoComp(String nomEstadoComp) {
		this.nomEstadoComp = nomEstadoComp;
	}

	public String getIdTipoCarga() {
		return idTipoCarga;
	}

	public void setIdTipoCarga(String idTipoCarga) {
		this.idTipoCarga = idTipoCarga;
	}

	public String getNomTipoCarga() {
		return nomTipoCarga;
	}

	public void setNomTipoCarga(String nomTipoCarga) {
		this.nomTipoCarga = nomTipoCarga;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public Long getIdProceso() {
		return idProceso;
	}

	public void setIdProceso(Long idProceso) {
		this.idProceso = idProceso;
	}

	public String getTipoParametro() {
		return tipoParametro;
	}

	public void setTipoParametro(String tipoParametro) {
		this.tipoParametro = tipoParametro;
	}

	public String getCodigoParametro1() {
		return codigoParametro1;
	}

	public void setCodigoParametro1(String codigoParametro1) {
		this.codigoParametro1 = codigoParametro1;
	}

	public String getCodigoParametro2() {
		return codigoParametro2;
	}

	public void setCodigoParametro2(String codigoParametro2) {
		this.codigoParametro2 = codigoParametro2;
	}

	public String getCodigoParametro3() {
		return codigoParametro3;
	}

	public void setCodigoParametro3(String codigoParametro3) {
		this.codigoParametro3 = codigoParametro3;
	}

	public String getCodigoParametro4() {
		return codigoParametro4;
	}

	public void setCodigoParametro4(String codigoParametro4) {
		this.codigoParametro4 = codigoParametro4;
	}

	public Long getBusqIdSocio() {
		return busqIdSocio;
	}

	public void setBusqIdSocio(Long busqIdSocio) {
		this.busqIdSocio = busqIdSocio;
	}

	public Long getBusqIdProducto() {
		return busqIdProducto;
	}

	public void setBusqIdProducto(Long busqIdProducto) {
		this.busqIdProducto = busqIdProducto;
	}

	public String getBusqIdTipoComp() {
		return busqIdTipoComp;
	}

	public void setBusqIdTipoComp(String busqIdTipoComp) {
		this.busqIdTipoComp = busqIdTipoComp;
	}

	public String getBusqIdTipoDocCli() {
		return busqIdTipoDocCli;
	}

	public void setBusqIdTipoDocCli(String busqIdTipoDocCli) {
		this.busqIdTipoDocCli = busqIdTipoDocCli;
	}

	public String getBusqTipoMoneda() {
		return busqTipoMoneda;
	}

	public void setBusqTipoMoneda(String busqTipoMoneda) {
		this.busqTipoMoneda = busqTipoMoneda;
	}

	public String getBusqConcepto() {
		return busqConcepto;
	}

	public void setBusqConcepto(String busqConcepto) {
		this.busqConcepto = busqConcepto;
	}

	public String getBusqCliente() {
		return busqCliente;
	}

	public void setBusqCliente(String busqCliente) {
		this.busqCliente = busqCliente;
	}

	public Date getBusqFechaEmision() {
		return busqFechaEmision;
	}

	public void setBusqFechaEmision(Date busqFechaEmision) {
		this.busqFechaEmision = busqFechaEmision;
	}

	public String getBusqNumComp() {
		return busqNumComp;
	}

	public void setBusqNumComp(String busqNumComp) {
		this.busqNumComp = busqNumComp;
	}

	public String getBusqMonto() {
		return busqMonto;
	}

	public void setBusqMonto(String busqMonto) {
		this.busqMonto = busqMonto;
	}

	public String getBusqCertificado() {
		return busqCertificado;
	}

	public void setBusqCertificado(String busqCertificado) {
		this.busqCertificado = busqCertificado;
	}

	public String getBusqNumDoc() {
		return busqNumDoc;
	}

	public void setBusqNumDoc(String busqNumDoc) {
		this.busqNumDoc = busqNumDoc;
	}
	
	public String getDescError() {
		return descError;
	}

	public void setDescError(String descError) {
		this.descError = descError;
	}

}
