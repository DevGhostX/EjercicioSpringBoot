package com.cardif.satelite.cpe.bean;

import java.io.Serializable;

public class ProcesoVentaCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idVentaProceso;
	private Long idProceso;
	private Long idVenta;
	private String estado;
	
	public ProcesoVentaCpeBean(){}

	public Long getIdVentaProceso() {
		return idVentaProceso;
	}

	public void setIdVentaProceso(Long idVentaProceso) {
		this.idVentaProceso = idVentaProceso;
	}

	public Long getIdProceso() {
		return idProceso;
	}

	public void setIdProceso(Long idProceso) {
		this.idProceso = idProceso;
	}

	public Long getIdVenta() {
		return idVenta;
	}

	public void setIdVenta(Long idVenta) {
		this.idVenta = idVenta;
	}		
	
	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
}
