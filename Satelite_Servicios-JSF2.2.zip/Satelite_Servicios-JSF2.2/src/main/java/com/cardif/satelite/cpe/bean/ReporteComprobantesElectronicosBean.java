package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ReporteComprobantesElectronicosBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String fecEmision;
	private String serieComp;
	private String corrComp;
	private String idEstadoComp;
	private String idTipoComp;
	private String concepNd;
	private String tipoMoneda;
	private String fechaVenc;
	private Long idSocio;
	private Long idProducto;
	private String idTipoDocCli;
	private String numDocCli;
	private String nomCliRazSoc;
	private String dirCliente;
	private String departamento;
	private String provincia;
	private String distrito;
	private String telefCliente;
	private String mailCliente;
	private String idTipoCompRef;
	private String fechaEmisionRef;
	private String numSerieRef;
	private String numCorrRef;
	private String concepto;
	private String numPoliza;
	private BigDecimal valFactExport;
	private BigDecimal baseImponible;
	private BigDecimal impExonerado;
	private BigDecimal impInafecto;
	private BigDecimal valOpGratuitas;
	private BigDecimal isc;
	private BigDecimal igv;
	private BigDecimal impOtros;
	private BigDecimal impTotal;
	private String modificable;
	private BigDecimal tipoCambio;
	private String estado;
	private String openItem;
	private String openItemRef;
	private String area;
	private String observacion;
	private Integer corActual;
	private String colectIndiv;
	private String linea;
	private String periodo;
	private String usuarioCrea;
	
	private Date fecCargaDesde;
	private Date fecCargaHasta;
	private Long idEmpresa;
	
	private String codigoParametro1;
	private String codigoParametro2;
	private String codigoParametro3;
	private String codigoParametro4;
	private String codigoParametro5;
	private String tipoParametro;
	
	private String nomEmpresa;
	private String nomEstadoComp;
    private String nomTipoComp;
    private String nomMoneda;
    private String nomSocio;
    private String nomProducto;
    private String nomTipoDocCli;
	
	public ReporteComprobantesElectronicosBean(){}

	
	public String getNomEmpresa() {
		return nomEmpresa;
	}


	public void setNomEmpresa(String nomEmpresa) {
		this.nomEmpresa = nomEmpresa;
	}


	public String getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(String fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getSerieComp() {
		return serieComp;
	}

	public void setSerieComp(String serieComp) {
		this.serieComp = serieComp;
	}

	public String getCorrComp() {
		return corrComp;
	}

	public void setCorrComp(String corrComp) {
		this.corrComp = corrComp;
	}

	public String getIdEstadoComp() {
		return idEstadoComp;
	}

	public void setIdEstadoComp(String idEstadoComp) {
		this.idEstadoComp = idEstadoComp;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}

	public String getConcepNd() {
		return concepNd;
	}

	public void setConcepNd(String concepNd) {
		this.concepNd = concepNd;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public String getFechaVenc() {
		return fechaVenc;
	}

	public void setFechaVenc(String fechaVenc) {
		this.fechaVenc = fechaVenc;
	}

	public Long getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Long idSocio) {
		this.idSocio = idSocio;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public String getIdTipoDocCli() {
		return idTipoDocCli;
	}

	public void setIdTipoDocCli(String idTipoDocCli) {
		this.idTipoDocCli = idTipoDocCli;
	}

	public String getNumDocCli() {
		return numDocCli;
	}

	public void setNumDocCli(String numDocCli) {
		this.numDocCli = numDocCli;
	}

	public String getNomCliRazSoc() {
		return nomCliRazSoc;
	}

	public void setNomCliRazSoc(String nomCliRazSoc) {
		this.nomCliRazSoc = nomCliRazSoc;
	}

	public String getDirCliente() {
		return dirCliente;
	}

	public void setDirCliente(String dirCliente) {
		this.dirCliente = dirCliente;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getTelefCliente() {
		return telefCliente;
	}

	public void setTelefCliente(String telefCliente) {
		this.telefCliente = telefCliente;
	}

	public String getMailCliente() {
		return mailCliente;
	}

	public void setMailCliente(String mailCliente) {
		this.mailCliente = mailCliente;
	}

	public String getIdTipoCompRef() {
		return idTipoCompRef;
	}

	public void setIdTipoCompRef(String idTipoCompRef) {
		this.idTipoCompRef = idTipoCompRef;
	}

	public String getFechaEmisionRef() {
		return fechaEmisionRef;
	}

	public void setFechaEmisionRef(String fechaEmisionRef) {
		this.fechaEmisionRef = fechaEmisionRef;
	}

	public String getNumSerieRef() {
		return numSerieRef;
	}

	public void setNumSerieRef(String numSerieRef) {
		this.numSerieRef = numSerieRef;
	}
	
	
	public String getNumCorrRef() {
		return numCorrRef;
	}

	public void setNumCorrRef(String numCorrRef) {
		this.numCorrRef = numCorrRef;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getNumPoliza() {
		return numPoliza;
	}

	public void setNumPoliza(String numPoliza) {
		this.numPoliza = numPoliza;
	}

	public BigDecimal getValFactExport() {
		return valFactExport;
	}

	public void setValFactExport(BigDecimal valFactExport) {
		this.valFactExport = valFactExport;
	}

	public BigDecimal getBaseImponible() {
		return baseImponible;
	}

	public void setBaseImponible(BigDecimal baseImponible) {
		this.baseImponible = baseImponible;
	}

	public BigDecimal getImpExonerado() {
		return impExonerado;
	}

	public void setImpExonerado(BigDecimal impExonerado) {
		this.impExonerado = impExonerado;
	}

	public BigDecimal getImpInafecto() {
		return impInafecto;
	}

	public void setImpInafecto(BigDecimal impInafecto) {
		this.impInafecto = impInafecto;
	}

	public BigDecimal getValOpGratuitas() {
		return valOpGratuitas;
	}

	public void setValOpGratuitas(BigDecimal valOpGratuitas) {
		this.valOpGratuitas = valOpGratuitas;
	}

	public BigDecimal getIsc() {
		return isc;
	}

	public void setIsc(BigDecimal isc) {
		this.isc = isc;
	}

	public BigDecimal getIgv() {
		return igv;
	}

	public void setIgv(BigDecimal igv) {
		this.igv = igv;
	}

	public BigDecimal getImpOtros() {
		return impOtros;
	}

	public void setImpOtros(BigDecimal impOtros) {
		this.impOtros = impOtros;
	}

	public BigDecimal getImpTotal() {
		return impTotal;
	}

	public void setImpTotal(BigDecimal impTotal) {
		this.impTotal = impTotal;
	}

	public String getModificable() {
		return modificable;
	}

	public void setModificable(String modificable) {
		this.modificable = modificable;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getOpenItem() {
		return openItem;
	}

	public void setOpenItem(String openItem) {
		this.openItem = openItem;
	}

	public String getOpenItemRef() {
		return openItemRef;
	}

	public void setOpenItemRef(String openItemRef) {
		this.openItemRef = openItemRef;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public Integer getCorActual() {
		return corActual;
	}

	public void setCorActual(Integer corActual) {
		this.corActual = corActual;
	}

	public String getColectIndiv() {
		return colectIndiv;
	}

	public void setColectIndiv(String colectIndiv) {
		this.colectIndiv = colectIndiv;
	}

	public String getLinea() {
		return linea;
	}

	public void setLinea(String linea) {
		this.linea = linea;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	

	public String getUsuarioCrea() {
		return usuarioCrea;
	}

	public void setUsuarioCrea(String usuarioCrea) {
		this.usuarioCrea = usuarioCrea;
	}

	public Date getFecCargaDesde() {
		return fecCargaDesde;
	}

	public void setFecCargaDesde(Date fecCargaDesde) {
		this.fecCargaDesde = fecCargaDesde;
	}

	public Date getFecCargaHasta() {
		return fecCargaHasta;
	}

	public void setFecCargaHasta(Date fecCargaHasta) {
		this.fecCargaHasta = fecCargaHasta;
	}
	
	
	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(Long idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getCodigoParametro1() {
		return codigoParametro1;
	}

	public void setCodigoParametro1(String codigoParametro1) {
		this.codigoParametro1 = codigoParametro1;
	}

	public String getCodigoParametro2() {
		return codigoParametro2;
	}

	public void setCodigoParametro2(String codigoParametro2) {
		this.codigoParametro2 = codigoParametro2;
	}

	public String getCodigoParametro3() {
		return codigoParametro3;
	}

	public void setCodigoParametro3(String codigoParametro3) {
		this.codigoParametro3 = codigoParametro3;
	}

	public String getCodigoParametro4() {
		return codigoParametro4;
	}

	public void setCodigoParametro4(String codigoParametro4) {
		this.codigoParametro4 = codigoParametro4;
	}
	
	
	public String getCodigoParametro5() {
		return codigoParametro5;
	}

	public void setCodigoParametro5(String codigoParametro5) {
		this.codigoParametro5 = codigoParametro5;
	}

	public String getTipoParametro() {
		return tipoParametro;
	}

	public void setTipoParametro(String tipoParametro) {
		this.tipoParametro = tipoParametro;
	}

	public String getNomEstadoComp() {
		return nomEstadoComp;
	}

	public void setNomEstadoComp(String nomEstadoComp) {
		this.nomEstadoComp = nomEstadoComp;
	}

	public String getNomTipoComp() {
		return nomTipoComp;
	}

	public void setNomTipoComp(String nomTipoComp) {
		this.nomTipoComp = nomTipoComp;
	}

	public String getNomMoneda() {
		return nomMoneda;
	}

	public void setNomMoneda(String nomMoneda) {
		this.nomMoneda = nomMoneda;
	}

	public String getNomSocio() {
		return nomSocio;
	}

	public void setNomSocio(String nomSocio) {
		this.nomSocio = nomSocio;
	}

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public String getNomTipoDocCli() {
		return nomTipoDocCli;
	}

	public void setNomTipoDocCli(String nomTipoDocCli) {
		this.nomTipoDocCli = nomTipoDocCli;
	}

}
