package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ReporteRegistroVentasBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long idEmpresa;
	private String periodo;
	private Long idComprobante;
	private String fecEmision;
	private String fechaVenc;
	private String idTipoComp;
	private String serieComp;
	private String corrComp;
	private String idTipoDocCli;
	private String numDocCli;
	private String nomCliRazSoc;
	private String concepto;
	private BigDecimal valFactExport;
	private BigDecimal baseImponible;
	private BigDecimal impExonerado;
	private BigDecimal impInafecto;
	private BigDecimal valOpGratuitas;
	private BigDecimal isc;
	private BigDecimal igv;
	private BigDecimal impOtros;
	private BigDecimal impTotal;
	private BigDecimal tipoCambio;
	private String fechaEmisionRef;
	private String idTipoCompRef;
	private String numSerieRef;
	private String numCorRef;
	private String modificable;
	private String openItem;
	private String openItemRef;
	private String numPoliza;
	private Long idProducto;
	private String estado;
	private String observacion;
	private Integer corActual;
	private String dirCliente;
	private String departamento;
	private String provincia;
	private String distrito;
	private String periodopresentacion;
	private String colectIndiv;
	private String linea;
	private String consecutivo;
	private Date fechaDesde;
	private Date fechaHasta;
	
	private String tipoParametro;
	private String codigoParametro1;
	private String codigoParametro2;
	private String codigoParametro3;
	private String codigoParametro4;
	
	private String nomEstadoComp;
    private String nomTipoComp;
    private String nomTipoDocCli;
    private String periodoRegistro;
    private String descProducto;
    
    private String moneda;
    private BigDecimal impTotalOrig;
	
	public ReporteRegistroVentasBean(){}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public Long getIdComprobante() {
		return idComprobante;
	}

	public void setIdComprobante(Long idComprobante) {
		this.idComprobante = idComprobante;
	}

	public String getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(String fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getFechaVenc() {
		return fechaVenc;
	}

	public void setFechaVenc(String fechaVenc) {
		this.fechaVenc = fechaVenc;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}

	public String getSerieComp() {
		return serieComp;
	}

	public void setSerieComp(String serieComp) {
		this.serieComp = serieComp;
	}

	public String getCorrComp() {
		return corrComp;
	}

	public void setCorrComp(String corrComp) {
		this.corrComp = corrComp;
	}

	public String getIdTipoDocCli() {
		return idTipoDocCli;
	}

	public void setIdTipoDocCli(String idTipoDocCli) {
		this.idTipoDocCli = idTipoDocCli;
	}

	public String getNumDocCli() {
		return numDocCli;
	}

	public void setNumDocCli(String numDocCli) {
		this.numDocCli = numDocCli;
	}

	public String getNomCliRazSoc() {
		return nomCliRazSoc;
	}

	public void setNomCliRazSoc(String nomCliRazSoc) {
		this.nomCliRazSoc = nomCliRazSoc;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public BigDecimal getValFactExport() {
		return valFactExport;
	}

	public void setValFactExport(BigDecimal valFactExport) {
		this.valFactExport = valFactExport;
	}

	public BigDecimal getBaseImponible() {
		return baseImponible;
	}

	public void setBaseImponible(BigDecimal baseImponible) {
		this.baseImponible = baseImponible;
	}

	public BigDecimal getImpExonerado() {
		return impExonerado;
	}

	public void setImpExonerado(BigDecimal impExonerado) {
		this.impExonerado = impExonerado;
	}

	public BigDecimal getImpInafecto() {
		return impInafecto;
	}

	public void setImpInafecto(BigDecimal impInafecto) {
		this.impInafecto = impInafecto;
	}

	public BigDecimal getValOpGratuitas() {
		return valOpGratuitas;
	}

	public void setValOpGratuitas(BigDecimal valOpGratuitas) {
		this.valOpGratuitas = valOpGratuitas;
	}

	public BigDecimal getIsc() {
		return isc;
	}

	public void setIsc(BigDecimal isc) {
		this.isc = isc;
	}

	public BigDecimal getIgv() {
		return igv;
	}

	public void setIgv(BigDecimal igv) {
		this.igv = igv;
	}

	public BigDecimal getImpOtros() {
		return impOtros;
	}

	public void setImpOtros(BigDecimal impOtros) {
		this.impOtros = impOtros;
	}

	public BigDecimal getImpTotal() {
		return impTotal;
	}

	public void setImpTotal(BigDecimal impTotal) {
		this.impTotal = impTotal;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getFechaEmisionRef() {
		return fechaEmisionRef;
	}

	public void setFechaEmisionRef(String fechaEmisionRef) {
		this.fechaEmisionRef = fechaEmisionRef;
	}

	public String getIdTipoCompRef() {
		return idTipoCompRef;
	}

	public void setIdTipoCompRef(String idTipoCompRef) {
		this.idTipoCompRef = idTipoCompRef;
	}

	public String getNumSerieRef() {
		return numSerieRef;
	}

	public void setNumSerieRef(String numSerieRef) {
		this.numSerieRef = numSerieRef;
	}

	public String getNumCorRef() {
		return numCorRef;
	}

	public void setNumCorRef(String numCorRef) {
		this.numCorRef = numCorRef;
	}

	public String getModificable() {
		return modificable;
	}

	public void setModificable(String modificable) {
		this.modificable = modificable;
	}

	public String getOpenItem() {
		return openItem;
	}

	public void setOpenItem(String openItem) {
		this.openItem = openItem;
	}

	public String getOpenItemRef() {
		return openItemRef;
	}

	public void setOpenItemRef(String openItemRef) {
		this.openItemRef = openItemRef;
	}

	public String getNumPoliza() {
		return numPoliza;
	}

	public void setNumPoliza(String numPoliza) {
		this.numPoliza = numPoliza;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public Integer getCorActual() {
		return corActual;
	}

	public void setCorActual(Integer corActual) {
		this.corActual = corActual;
	}

	public String getDirCliente() {
		return dirCliente;
	}

	public void setDirCliente(String dirCliente) {
		this.dirCliente = dirCliente;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getPeriodopresentacion() {
		return periodopresentacion;
	}

	public void setPeriodopresentacion(String periodopresentacion) {
		this.periodopresentacion = periodopresentacion;
	}

	public String getColectIndiv() {
		return colectIndiv;
	}

	public void setColectIndiv(String colectIndiv) {
		this.colectIndiv = colectIndiv;
	}

	public String getLinea() {
		return linea;
	}

	public void setLinea(String linea) {
		this.linea = linea;
	}

	public String getConsecutivo() {
		return consecutivo;
	}

	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(Long idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getCodigoParametro1() {
		return codigoParametro1;
	}

	public void setCodigoParametro1(String codigoParametro1) {
		this.codigoParametro1 = codigoParametro1;
	}

	public String getCodigoParametro2() {
		return codigoParametro2;
	}

	public void setCodigoParametro2(String codigoParametro2) {
		this.codigoParametro2 = codigoParametro2;
	}

	public String getCodigoParametro3() {
		return codigoParametro3;
	}

	public void setCodigoParametro3(String codigoParametro3) {
		this.codigoParametro3 = codigoParametro3;
	}

	public String getNomEstadoComp() {
		return nomEstadoComp;
	}

	public void setNomEstadoComp(String nomEstadoComp) {
		this.nomEstadoComp = nomEstadoComp;
	}

	public String getNomTipoComp() {
		return nomTipoComp;
	}

	public void setNomTipoComp(String nomTipoComp) {
		this.nomTipoComp = nomTipoComp;
	}

	public String getNomTipoDocCli() {
		return nomTipoDocCli;
	}

	public void setNomTipoDocCli(String nomTipoDocCli) {
		this.nomTipoDocCli = nomTipoDocCli;
	}

	public String getTipoParametro() {
		return tipoParametro;
	}

	public void setTipoParametro(String tipoParametro) {
		this.tipoParametro = tipoParametro;
	}

	public String getPeriodoRegistro() {
		return periodoRegistro;
	}

	public void setPeriodoRegistro(String periodoRegistro) {
		this.periodoRegistro = periodoRegistro;
	}

	public String getDescProducto() {
		return descProducto;
	}

	public void setDescProducto(String descProducto) {
		this.descProducto = descProducto;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public BigDecimal getImpTotalOrig() {
		return impTotalOrig;
	}

	public void setImpTotalOrig(BigDecimal impTotalOrig) {
		this.impTotalOrig = impTotalOrig;
	}

	public String getCodigoParametro4() {
		return codigoParametro4;
	}

	public void setCodigoParametro4(String codigoParametro4) {
		this.codigoParametro4 = codigoParametro4;
	}

}
