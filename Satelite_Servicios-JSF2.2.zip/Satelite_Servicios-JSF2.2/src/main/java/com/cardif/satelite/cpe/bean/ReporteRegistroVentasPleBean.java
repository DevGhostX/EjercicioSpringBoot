package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ReporteRegistroVentasPleBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long idComprobante;
	private String vPeriodo;
	private Long idPle;
	private String mIdPle;
	private Date fecEmision;
	private Date fecVenc;
	private String idTipoComp;
	private String serieComp;
	private String corrComp;
	private String campo9;
	private String idTipoDocCli;
	private String numDocCli;
	private String nomCliRazSoc;
	private BigDecimal valFactExport;
	private BigDecimal baseImponible;
	private BigDecimal dsctoBaseImponible;
	private BigDecimal igv;
	private BigDecimal dsctoIgv;
	private BigDecimal impExonerado;
	private BigDecimal impInafecto;
	private BigDecimal isc;
	private String campo21;
	private String campo22;
	private BigDecimal impOtros;
	private BigDecimal impTotal;
	private String tipoMoneda;
	private BigDecimal tipoCambio;
	private String fechaEmisionRef;
	private Date fechaEmisionRefDate;
	private String idTipoCompRef;
	private String numSerieRef;
	private String numCorRef;
	private String campo31;
	private String campo32;
	private String campo33;
	private String campo34Estado;
	private String campo35;
	private String campo36;
	private String campo37;
	private String campo38;
	
	private Long idEmpresa;
	private String periodoRegistro;
	private String codParamEmpresaPle;
	
	public ReporteRegistroVentasPleBean(){}

	public Long getIdComprobante() {
		return idComprobante;
	}

	public void setIdComprobante(Long idComprobante) {
		this.idComprobante = idComprobante;
	}

	public String getvPeriodo() {
		return vPeriodo;
	}

	public void setvPeriodo(String vPeriodo) {
		this.vPeriodo = vPeriodo;
	}

	public Long getIdPle() {
		return idPle;
	}

	public void setIdPle(Long idPle) {
		this.idPle = idPle;
	}

	public String getmIdPle() {
		return mIdPle;
	}

	public void setmIdPle(String mIdPle) {
		this.mIdPle = mIdPle;
	}

	public Date getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}

	public Date getFecVenc() {
		return fecVenc;
	}

	public void setFecVenc(Date fecVenc) {
		this.fecVenc = fecVenc;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}

	public String getSerieComp() {
		return serieComp;
	}

	public void setSerieComp(String serieComp) {
		this.serieComp = serieComp;
	}

	public String getCorrComp() {
		return corrComp;
	}

	public void setCorrComp(String corrComp) {
		this.corrComp = corrComp;
	}

	public String getCampo9() {
		return campo9;
	}

	public void setCampo9(String campo9) {
		this.campo9 = campo9;
	}

	public String getIdTipoDocCli() {
		return idTipoDocCli;
	}

	public void setIdTipoDocCli(String idTipoDocCli) {
		this.idTipoDocCli = idTipoDocCli;
	}

	public String getNumDocCli() {
		return numDocCli;
	}

	public void setNumDocCli(String numDocCli) {
		this.numDocCli = numDocCli;
	}

	public String getNomCliRazSoc() {
		return nomCliRazSoc;
	}

	public void setNomCliRazSoc(String nomCliRazSoc) {
		this.nomCliRazSoc = nomCliRazSoc;
	}

	public BigDecimal getValFactExport() {
		return valFactExport;
	}

	public void setValFactExport(BigDecimal valFactExport) {
		this.valFactExport = valFactExport;
	}

	public BigDecimal getBaseImponible() {
		return baseImponible;
	}

	public void setBaseImponible(BigDecimal baseImponible) {
		this.baseImponible = baseImponible;
	}

	public BigDecimal getDsctoBaseImponible() {
		return dsctoBaseImponible;
	}

	public void setDsctoBaseImponible(BigDecimal dsctoBaseImponible) {
		this.dsctoBaseImponible = dsctoBaseImponible;
	}

	public BigDecimal getIgv() {
		return igv;
	}

	public void setIgv(BigDecimal igv) {
		this.igv = igv;
	}

	public BigDecimal getDsctoIgv() {
		return dsctoIgv;
	}

	public void setDsctoIgv(BigDecimal dsctoIgv) {
		this.dsctoIgv = dsctoIgv;
	}

	public BigDecimal getImpExonerado() {
		return impExonerado;
	}

	public void setImpExonerado(BigDecimal impExonerado) {
		this.impExonerado = impExonerado;
	}

	public BigDecimal getImpInafecto() {
		return impInafecto;
	}

	public void setImpInafecto(BigDecimal impInafecto) {
		this.impInafecto = impInafecto;
	}

	public BigDecimal getIsc() {
		return isc;
	}

	public void setIsc(BigDecimal isc) {
		this.isc = isc;
	}

	public String getCampo21() {
		return campo21;
	}

	public void setCampo21(String campo21) {
		this.campo21 = campo21;
	}

	public String getCampo22() {
		return campo22;
	}

	public void setCampo22(String campo22) {
		this.campo22 = campo22;
	}

	public BigDecimal getImpOtros() {
		return impOtros;
	}

	public void setImpOtros(BigDecimal impOtros) {
		this.impOtros = impOtros;
	}

	public BigDecimal getImpTotal() {
		return impTotal;
	}

	public void setImpTotal(BigDecimal impTotal) {
		this.impTotal = impTotal;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getFechaEmisionRef() {
		return fechaEmisionRef;
	}

	public void setFechaEmisionRef(String fechaEmisionRef) {
		this.fechaEmisionRef = fechaEmisionRef;
	}

	public String getIdTipoCompRef() {
		return idTipoCompRef;
	}

	public void setIdTipoCompRef(String idTipoCompRef) {
		this.idTipoCompRef = idTipoCompRef;
	}

	public String getNumSerieRef() {
		return numSerieRef;
	}

	public void setNumSerieRef(String numSerieRef) {
		this.numSerieRef = numSerieRef;
	}

	public String getNumCorRef() {
		return numCorRef;
	}

	public void setNumCorRef(String numCorRef) {
		this.numCorRef = numCorRef;
	}

	public String getCampo31() {
		return campo31;
	}

	public void setCampo31(String campo31) {
		this.campo31 = campo31;
	}

	public String getCampo32() {
		return campo32;
	}

	public void setCampo32(String campo32) {
		this.campo32 = campo32;
	}

	public String getCampo33() {
		return campo33;
	}

	public void setCampo33(String campo33) {
		this.campo33 = campo33;
	}

	public String getCampo34Estado() {
		return campo34Estado;
	}

	public void setCampo34Estado(String campo34Estado) {
		this.campo34Estado = campo34Estado;
	}

	public String getCampo35() {
		return campo35;
	}

	public void setCampo35(String campo35) {
		this.campo35 = campo35;
	}

	public String getCampo36() {
		return campo36;
	}

	public void setCampo36(String campo36) {
		this.campo36 = campo36;
	}

	public String getCampo37() {
		return campo37;
	}

	public void setCampo37(String campo37) {
		this.campo37 = campo37;
	}

	public String getCampo38() {
		return campo38;
	}

	public void setCampo38(String campo38) {
		this.campo38 = campo38;
	}

	public Long getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(Long idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getPeriodoRegistro() {
		return periodoRegistro;
	}

	public void setPeriodoRegistro(String periodoRegistro) {
		this.periodoRegistro = periodoRegistro;
	}

	public String getCodParamEmpresaPle() {
		return codParamEmpresaPle;
	}

	public void setCodParamEmpresaPle(String codParamEmpresaPle) {
		this.codParamEmpresaPle = codParamEmpresaPle;
	}

	public Date getFechaEmisionRefDate() {
		return fechaEmisionRefDate;
	}

	public void setFechaEmisionRefDate(Date fechaEmisionRefDate) {
		this.fechaEmisionRefDate = fechaEmisionRefDate;
	}
	
}
