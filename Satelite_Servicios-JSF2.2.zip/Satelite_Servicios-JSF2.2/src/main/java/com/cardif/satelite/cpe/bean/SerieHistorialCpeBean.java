package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class SerieHistorialCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer idSerieHistorial;
	private String idEmpresa;
	private Integer idSocio;
	private Integer idProducto;
	private String idTipoComp;
	private String prefijo;
	private String serie;
	private String usuCrea;
	private Date fecCrea;
	
	public SerieHistorialCpeBean(){}

	public Integer getIdSerieHistorial() {
		return idSerieHistorial;
	}

	public void setIdSerieHistorial(Integer idSerieHistorial) {
		this.idSerieHistorial = idSerieHistorial;
	}

	public String getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public Integer getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Integer idSocio) {
		this.idSocio = idSocio;
	}

	public Integer getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Integer idProducto) {
		this.idProducto = idProducto;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}
	
	public String getPrefijo() {
		return prefijo;
	}

	public void setPrefijo(String prefijo) {
		this.prefijo = prefijo;
	}

	public String getSerie() {
		return serie;
	}

	public void setSerie(String serie) {
		this.serie = serie;
	}

	public String getUsuCrea() {
		return usuCrea;
	}

	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

}
