package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class SocioCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer idSocio;
	private Integer idSocioPims;
	private String nomSocio;
	private String usuCrea;
	private Date fecCrea;
	private String usuModifica;
	private Date fecModifica;
	
	public SocioCpeBean(){}

	public Integer getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Integer idSocio) {
		this.idSocio = idSocio;
	}

	public Integer getIdSocioPims() {
		return idSocioPims;
	}

	public void setIdSocioPims(Integer idSocioPims) {
		this.idSocioPims = idSocioPims;
	}

	public String getNomSocio() {
		return nomSocio;
	}

	public void setNomSocio(String nomSocio) {
		this.nomSocio = nomSocio;
	}

	public String getUsuCrea() {
		return usuCrea;
	}

	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public String getUsuModifica() {
		return usuModifica;
	}

	public void setUsuModifica(String usuModifica) {
		this.usuModifica = usuModifica;
	}

	public Date getFecModifica() {
		return fecModifica;
	}

	public void setFecModifica(Date fecModifica) {
		this.fecModifica = fecModifica;
	}

}
