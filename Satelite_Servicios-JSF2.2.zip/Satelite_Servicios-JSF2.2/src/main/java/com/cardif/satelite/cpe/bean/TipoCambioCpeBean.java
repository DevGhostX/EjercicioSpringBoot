package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class TipoCambioCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String periodo;
	private Date fecTc;
	private String tipoMoneda;
	private BigDecimal valorTc;
	
	public TipoCambioCpeBean(){}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public Date getFecTc() {
		return fecTc;
	}

	public void setFecTc(Date fecTc) {
		this.fecTc = fecTc;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public BigDecimal getValorTc() {
		return valorTc;
	}

	public void setValorTc(BigDecimal valorTc) {
		this.valorTc = valorTc;
	}
	
}
