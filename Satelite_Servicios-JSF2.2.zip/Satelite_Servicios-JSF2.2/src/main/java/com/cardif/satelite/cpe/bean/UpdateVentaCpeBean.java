package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class UpdateVentaCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idVentaProceso;
	private Date fechaVencimiento;
	private String apePatCli;
	private String apeMatCli;
	private String nomCli;
	private String razSocCli;
	private String dirCli;
	private String departamento;
	private String provincia;
	private String distrito;
	private String usuarioCreacion;
	private Date fechaCreacion;
	private String usuarioModificacion;
	private Date fechaModificacion;
	
	public UpdateVentaCpeBean(){}

	public Long getIdVentaProceso() {
		return idVentaProceso;
	}

	public void setIdVentaProceso(Long idVentaProceso) {
		this.idVentaProceso = idVentaProceso;
	}

	public Date getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setFechaVencimiento(Date fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}

	public String getApePatCli() {
		return apePatCli;
	}

	public void setApePatCli(String apePatCli) {
		this.apePatCli = apePatCli;
	}

	public String getApeMatCli() {
		return apeMatCli;
	}

	public void setApeMatCli(String apeMatCli) {
		this.apeMatCli = apeMatCli;
	}

	public String getNomCli() {
		return nomCli;
	}

	public void setNomCli(String nomCli) {
		this.nomCli = nomCli;
	}

	public String getRazSocCli() {
		return razSocCli;
	}

	public void setRazSocCli(String razSocCli) {
		this.razSocCli = razSocCli;
	}

	public String getDirCli() {
		return dirCli;
	}

	public void setDirCli(String dirCli) {
		this.dirCli = dirCli;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
}
