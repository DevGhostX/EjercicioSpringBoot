package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class VentaCpeBean implements Serializable, Cloneable{

	private static final long serialVersionUID = 1L;
	
	private Long idVentaProceso;
	private Long idVenta;
	private Long idCarga;
	private Long idTramaUpload;
	private String nombreTramaUpload;
	private String llaveUpload;
	private String llavePims;
	private String idEmpresa;
	private Long idSocio;
	private String nomSocio;
	private Long idProducto;
	private String nomProducto;
	private String fechaEmision;
	private String idTipoComp;
	private String concepNd;
	private String tipoMoneda;
	private String fechaVenc;
	private String idTipoDocCli;
	private String numDocCli;
	private String nomCliRazSoc;
	private String dirCliente;
	private String departamento;
	private String provincia;
	private String distrito;
	private String telefCliente;
	private String mailCliente;
	private String idTipoCompRef;
	private Long numSerieRef;
	private Long numCorRef;
	private String fechaEmisionRef;
	private String concepto;
	private Long codProdSunat;
	private String numPoliza;
	private Date fechaVenta;
	private BigDecimal valFactExport;
	private BigDecimal baseImponible;
	private BigDecimal impExonerado;
	private BigDecimal impInafecto;
	private BigDecimal valOpGratuitas;
	private BigDecimal isc;
	private BigDecimal igv;
	private BigDecimal impOtros;
	private BigDecimal impTotal;
	private BigDecimal tipoCambio;
	private String estado;
	private String openItem;
	private String openItemRef;
	private String area;
	private String observacion;
	private BigDecimal montoUsd;
	private String colectIndiv;
	private String linea;
	private String periodo;
	private String flgPims;
	private String flgUpload;
	private String flgRv;
	private String flgCompletado;
	private Long idPle;
	private Long idAgrupado;
	private String flgAgrupado;
	private String flgDetraccion;
	private BigDecimal impDetraccion;
	private String tipoAfectacion;

	private Long idProceso;

	private String nombreEmpresa;
	private String nombreMoneda;
	private String nombreEstado;
	private String nombreTipDoc;
	private String origen;
	private String idOrigen;
	private Date fechaCarga;
	private Date fechaEmisionDate;
	private Long numeroComprobante;
	private Date fechaDesde;
	private Date fechaHasta;
	private String estadoVenta;

	private String paramEmpresa;
	private String paramTipParam;
	private String paramMoneda;
	private String paramEstadoVenta;
	private String paramTipDoc;
	
	private boolean seleccionado;
	private String prefijoAlta;
	private Integer idProductoPims;
	
	private String estadoCodigo;
	
	private boolean flagDuplicado;
	private String tipoRegistro;
	
	private String nroSerie;
	private String correlativo;
	
	private String tipoProducto;
	
	private String estadoCarga;
	
	private String motivoRechazo;

	/*TIP_PER0100_CC09_13 INICIO 2019/05/02 16:03 Se agregan campos para archivo Layout*/
	/**Atributo que almacena el número de orden de compra*/
	private String ordenCompra;
	/**Atributo que almacena el indicador de aplicación de detracción*/
	private String aplicaDetraccion;
	/**Atributo que almacena el porcentaje de detracción*/
	private BigDecimal porcDetraccion;
	/**Atributo que almacena el título adicional*/
	private String tituloAdicional;
	/**Atributo que almacena el valor adicional*/
	private String valorAdicional;
	/*TIP_PER0100_CC09_13 FIN*/
	
	/**TIP_PER0100_CC14 INICIO 2019/06/20 10:51 Se agrega atributo para almacenar el indicador asociado al Datamart*/
	/**Atributo que almacena el indicador que especifica si un registro ha sido modificado por los datos almacenados en la Base de datos del Datamart.*/
	private String flgDataMart;
	/**Atributo que almacena Lista de ventas, con idProductoPim y número de documento, a consultar en la base de datos de Datamart*/
	private List<VentaCpeBean> listaConsultaDatamartPorPoliza;
	/**Atributo que almacena Lista de ventas, con idProductoPim y número de póliza, a consultar en la base de datos de Datamart*/
	private List<VentaCpeBean> listaConsultaDatamartPorDocumento;
	/**Atributo que almacena el tipo de lista generado.*/
	private String tipoLista;
	/**Atributo que almacena el id producto pims en formato String.*/
	private String idStrProductoPims;
	/**TIP_PER0100_CC14 FIN*/
	
	/** TIP_PER0100_CC15 INICIO 2019/06/21 16:29 Se agregan los atributos strNumSerieRef, strNumCorRef de tipo String*/
	private String strNumSerieRef;
	private String strNumCorRef;
	/** TIP_PER0100_CC15 FIN*/
	
	public VentaCpeBean(){}

	public Long getIdVenta() {
		return idVenta;
	}

	public void setIdVenta(Long idVenta) {
		this.idVenta = idVenta;
	}

	public Long getIdCarga() {
		return idCarga;
	}

	public void setIdCarga(Long idCarga) {
		this.idCarga = idCarga;
	}

	public Long getIdTramaUpload() {
		return idTramaUpload;
	}

	public void setIdTramaUpload(Long idTramaUpload) {
		this.idTramaUpload = idTramaUpload;
	}

	public String getLlaveUpload() {
		return llaveUpload;
	}

	public void setLlaveUpload(String llaveUpload) {
		this.llaveUpload = llaveUpload;
	}

	public String getLlavePims() {
		return llavePims;
	}

	public void setLlavePims(String llavePims) {
		this.llavePims = llavePims;
	}

	public String getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(String idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public Long getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Long idSocio) {
		this.idSocio = idSocio;
	}

	public String getNomSocio() {
		return nomSocio;
	}

	public void setNomSocio(String nomSocio) {
		this.nomSocio = nomSocio;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public String getFechaEmision() {
		return fechaEmision;
	}

	public void setFechaEmision(String fechaEmision) {
		this.fechaEmision = fechaEmision;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}

	public String getConcepNd() {
		return concepNd;
	}

	public void setConcepNd(String concepNd) {
		this.concepNd = concepNd;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public String getFechaVenc() {
		return fechaVenc;
	}

	public void setFechaVenc(String fechaVenc) {
		this.fechaVenc = fechaVenc;
	}

	public String getIdTipoDocCli() {
		return idTipoDocCli;
	}

	public void setIdTipoDocCli(String idTipoDocCli) {
		this.idTipoDocCli = idTipoDocCli;
	}

	public String getNumDocCli() {
		return numDocCli;
	}

	public void setNumDocCli(String numDocCli) {
		this.numDocCli = numDocCli;
	}

	public String getNomCliRazSoc() {
		return nomCliRazSoc;
	}

	public void setNomCliRazSoc(String nomCliRazSoc) {
		this.nomCliRazSoc = nomCliRazSoc;
	}

	public String getDirCliente() {
		return dirCliente;
	}

	public void setDirCliente(String dirCliente) {
		this.dirCliente = dirCliente;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getTelefCliente() {
		return telefCliente;
	}

	public void setTelefCliente(String telefCliente) {
		this.telefCliente = telefCliente;
	}

	public String getMailCliente() {
		return mailCliente;
	}

	public void setMailCliente(String mailCliente) {
		this.mailCliente = mailCliente;
	}

	public String getIdTipoCompRef() {
		return idTipoCompRef;
	}

	public void setIdTipoCompRef(String idTipoCompRef) {
		this.idTipoCompRef = idTipoCompRef;
	}

	public Long getNumSerieRef() {
		return numSerieRef;
	}

	public void setNumSerieRef(Long numSerieRef) {
		this.numSerieRef = numSerieRef;
	}

	public Long getNumCorRef() {
		return numCorRef;
	}

	public void setNumCorRef(Long numCorRef) {
		this.numCorRef = numCorRef;
	}

	public String getFechaEmisionRef() {
		return fechaEmisionRef;
	}

	public void setFechaEmisionRef(String fechaEmisionRef) {
		this.fechaEmisionRef = fechaEmisionRef;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public Long getCodProdSunat() {
		return codProdSunat;
	}

	public void setCodProdSunat(Long codProdSunat) {
		this.codProdSunat = codProdSunat;
	}

	public String getNumPoliza() {
		return numPoliza;
	}

	public void setNumPoliza(String numPoliza) {
		this.numPoliza = numPoliza;
	}

	public Date getFechaVenta() {
		return fechaVenta;
	}

	public void setFechaVenta(Date fechaVenta) {
		this.fechaVenta = fechaVenta;
	}

	public BigDecimal getValFactExport() {
		return valFactExport;
	}

	public void setValFactExport(BigDecimal valFactExport) {
		this.valFactExport = valFactExport;
	}

	public BigDecimal getBaseImponible() {
		return baseImponible;
	}

	public void setBaseImponible(BigDecimal baseImponible) {
		this.baseImponible = baseImponible;
	}

	public BigDecimal getImpExonerado() {
		return impExonerado;
	}

	public void setImpExonerado(BigDecimal impExonerado) {
		this.impExonerado = impExonerado;
	}

	public BigDecimal getImpInafecto() {
		return impInafecto;
	}

	public void setImpInafecto(BigDecimal impInafecto) {
		this.impInafecto = impInafecto;
	}

	public BigDecimal getValOpGratuitas() {
		return valOpGratuitas;
	}

	public void setValOpGratuitas(BigDecimal valOpGratuitas) {
		this.valOpGratuitas = valOpGratuitas;
	}

	public BigDecimal getIsc() {
		return isc;
	}

	public void setIsc(BigDecimal isc) {
		this.isc = isc;
	}

	public BigDecimal getIgv() {
		return igv;
	}

	public void setIgv(BigDecimal igv) {
		this.igv = igv;
	}

	public BigDecimal getImpOtros() {
		return impOtros;
	}

	public void setImpOtros(BigDecimal impOtros) {
		this.impOtros = impOtros;
	}

	public BigDecimal getImpTotal() {
		return impTotal;
	}

	public void setImpTotal(BigDecimal impTotal) {
		this.impTotal = impTotal;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getOpenItem() {
		return openItem;
	}

	public void setOpenItem(String openItem) {
		this.openItem = openItem;
	}

	public String getOpenItemRef() {
		return openItemRef;
	}

	public void setOpenItemRef(String openItemRef) {
		this.openItemRef = openItemRef;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public BigDecimal getMontoUsd() {
		return montoUsd;
	}

	public void setMontoUsd(BigDecimal montoUsd) {
		this.montoUsd = montoUsd;
	}

	public String getColectIndiv() {
		return colectIndiv;
	}

	public void setColectIndiv(String colectIndiv) {
		this.colectIndiv = colectIndiv;
	}

	public String getLinea() {
		return linea;
	}

	public void setLinea(String linea) {
		this.linea = linea;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public String getFlgPims() {
		return flgPims;
	}

	public void setFlgPims(String flgPims) {
		this.flgPims = flgPims;
	}

	public String getFlgUpload() {
		return flgUpload;
	}

	public void setFlgUpload(String flgUpload) {
		this.flgUpload = flgUpload;
	}

	public String getFlgRv() {
		return flgRv;
	}

	public void setFlgRv(String flgRv) {
		this.flgRv = flgRv;
	}

	public String getFlgCompletado() {
		return flgCompletado;
	}

	public void setFlgCompletado(String flgCompletado) {
		this.flgCompletado = flgCompletado;
	}

	public Long getIdPle() {
		return idPle;
	}

	public void setIdPle(Long idPle) {
		this.idPle = idPle;
	}

	public Long getIdProceso() {
		return idProceso;
	}

	public void setIdProceso(Long idProceso) {
		this.idProceso = idProceso;
	}

	public String getNombreEmpresa() {
		return nombreEmpresa;
	}

	public void setNombreEmpresa(String nombreEmpresa) {
		this.nombreEmpresa = nombreEmpresa;
	}

	public String getNombreMoneda() {
		return nombreMoneda;
	}

	public void setNombreMoneda(String nombreMoneda) {
		this.nombreMoneda = nombreMoneda;
	}

	public String getNombreEstado() {
		return nombreEstado;
	}

	public void setNombreEstado(String nombreEstado) {
		this.nombreEstado = nombreEstado;
	}
	
	
	public String getIdOrigen() {
		return idOrigen;
	}

	public void setIdOrigen(String idOrigen) {
		this.idOrigen = idOrigen;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public Date getFechaEmisionDate() {
		return fechaEmisionDate;
	}

	public void setFechaEmisionDate(Date fechaEmisionDate) {
		this.fechaEmisionDate = fechaEmisionDate;
	}

	public Long getNumeroComprobante() {
		return numeroComprobante;
	}

	public void setNumeroComprobante(Long numeroComprobante) {
		this.numeroComprobante = numeroComprobante;
	}

	public String getParamEmpresa() {
		return paramEmpresa;
	}

	public void setParamEmpresa(String paramEmpresa) {
		this.paramEmpresa = paramEmpresa;
	}

	public String getParamTipParam() {
		return paramTipParam;
	}

	public void setParamTipParam(String paramTipParam) {
		this.paramTipParam = paramTipParam;
	}

	public String getParamMoneda() {
		return paramMoneda;
	}

	public void setParamMoneda(String paramMoneda) {
		this.paramMoneda = paramMoneda;
	}

	public String getParamEstadoVenta() {
		return paramEstadoVenta;
	}

	public void setParamEstadoVenta(String paramEstadoVenta) {
		this.paramEstadoVenta = paramEstadoVenta;
	}
	
	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}
	
	public String getEstadoVenta() {
		return estadoVenta;
	}

	public void setEstadoVenta(String estadoVenta) {
		this.estadoVenta = estadoVenta;
	}
	
	public String getNombreTipDoc() {
		return nombreTipDoc;
	}

	public void setNombreTipDoc(String nombreTipDoc) {
		this.nombreTipDoc = nombreTipDoc;
	}
	
	public String getParamTipDoc() {
		return paramTipDoc;
	}

	public void setParamTipDoc(String paramTipDoc) {
		this.paramTipDoc = paramTipDoc;
	}
	
	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public String getPrefijoAlta() {
		return prefijoAlta;
	}

	public void setPrefijoAlta(String prefijoAlta) {
		this.prefijoAlta = prefijoAlta;
	}

	public Integer getIdProductoPims() {
		return idProductoPims;
	}

	public void setIdProductoPims(Integer idProductoPims) {
		this.idProductoPims = idProductoPims;
	}
	
	public String getEstadoCodigo() {
		return estadoCodigo;
	}

	public void setEstadoCodigo(String estadoCodigo) {
		this.estadoCodigo = estadoCodigo;
	}
	
	public boolean isFlagDuplicado() {
		return flagDuplicado;
	}

	public void setFlagDuplicado(boolean flagDuplicado) {
		this.flagDuplicado = flagDuplicado;
	}

	public String getTipoRegistro() {
		return tipoRegistro;
	}

	public void setTipoRegistro(String tipoRegistro) {
		this.tipoRegistro = tipoRegistro;
	}

	public String getNombreTramaUpload() {
		return nombreTramaUpload;
	}

	public void setNombreTramaUpload(String nombreTramaUpload) {
		this.nombreTramaUpload = nombreTramaUpload;
	}

	public Long getIdVentaProceso() {
		return idVentaProceso;
	}

	public void setIdVentaProceso(Long idVentaProceso) {
		this.idVentaProceso = idVentaProceso;
	}
	
	public Long getIdAgrupado() {
		return idAgrupado;
	}

	public void setIdAgrupado(Long idAgrupado) {
		this.idAgrupado = idAgrupado;
	}

	public String getFlgAgrupado() {
		return flgAgrupado;
	}

	public void setFlgAgrupado(String flgAgrupado) {
		this.flgAgrupado = flgAgrupado;
	}

	public String getFlgDetraccion() {
		return flgDetraccion;
	}

	public void setFlgDetraccion(String flgDetraccion) {
		this.flgDetraccion = flgDetraccion;
	}

	public BigDecimal getImpDetraccion() {
		return impDetraccion;
	}

	public void setImpDetraccion(BigDecimal impDetraccion) {
		this.impDetraccion = impDetraccion;
	}
	
	public String getTipoAfectacion() {
		return tipoAfectacion;
	}

	public void setTipoAfectacion(String tipoAfectacion) {
		this.tipoAfectacion = tipoAfectacion;
	}
	
	public String getNroSerie() {
		return nroSerie;
	}

	public void setNroSerie(String nroSerie) {
		this.nroSerie = nroSerie;
	}

	public String getCorrelativo() {
		return correlativo;
	}

	public void setCorrelativo(String correlativo) {
		this.correlativo = correlativo;
	}
	
	public String getTipoProducto() {
		return tipoProducto;
	}

	public void setTipoProducto(String tipoProducto) {
		this.tipoProducto = tipoProducto;
	}
	
	public String getEstadoCarga() {
		return estadoCarga;
	}

	public void setEstadoCarga(String estadoCarga) {
		this.estadoCarga = estadoCarga;
	}
	
	public String getMotivoRechazo() {
		return motivoRechazo;
	}

	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

/*TIP_PER0100_CC09_13 INICIO 2019/05/02 16:03 Se definen los metodos get y set de los atributos agregados*/
	
	/**
	 * Método que permite obtener el número de orden de compra.
	 * @return ordenCompra Número de orden de compra, tipo String.
	 */
	public String getOrdenCompra() {
		return ordenCompra;
	}

	/**
	 *Método que permite actualizar el número de orden de compra.
	 * @param ordenCompra Número de orden de compra, tipo String.
	 */
	public void setOrdenCompra(String ordenCompra) {
		this.ordenCompra = ordenCompra;
	}

	/**
	 * Método que permite obtener el indicador de aplicación de detracción.
	 * @return aplicaDetraccion Indicador de aplicación de detracción, tipo String.
	 */
	public String getAplicaDetraccion() {
		return aplicaDetraccion;
	}

	/**
	 * Método que permite actualizar el indicador de aplicación de detracción. 
	 * @param aplicaDetraccion Indicador de aplicación de detracción, tipo String.
	 */
	public void setAplicaDetraccion(String aplicaDetraccion) {
		this.aplicaDetraccion = aplicaDetraccion;
	}

	/**
	 * Método que permite obtener el título adicional.
	 * @return tituloAdicional Título adicional, tipo String.
	 */
	public String getTituloAdicional() {
		return tituloAdicional;
	}

	/**
	 * Método que permite actualizar el título adicional.
	 * @param tituloAdicional Título adicional, tipo String.
	 */
	public void setTituloAdicional(String tituloAdicional) {
		this.tituloAdicional = tituloAdicional;
	}

	/**
	 * Método que permite obtener el valor adicional.
	 * @return valorAdicional ValorAdicional, tipo String.
	 */
	public String getValorAdicional() {
		return valorAdicional;
	}

	/**
	 * Método que permite actualizar el valor adicional.
	 * @param valorAdicional Valor Adicional, tipo String.
	 */
	public void setValorAdicional(String valorAdicional) {
		this.valorAdicional = valorAdicional;
	}
	
	/**
	 * Método que permite obtener el porcentaje de detracción.
	 * @return porcDetraccion Porcentaje de Detracción, tipo BigDecimal.
	 */
	public BigDecimal getPorcDetraccion() {
		return porcDetraccion;
	}

	/**
	 * Método que permite actualizar el porcentaje de detracción.
	 * @param porcDetraccion Porcentaje de Detracción, tipo BigDecimal.
	 */
	public void setPorcDetraccion(BigDecimal porcDetraccion) {
		this.porcDetraccion = porcDetraccion;
	}
	/*TIP_PER0100_CC09_13 FIN*/
	
	
	/**TIP_PER0100_CC14 INICIO 2019/06/20 10:53 Se agrega los método get y set asociados al atributo flgDataMart*/
	/**
	 * Método que permite obtener el indicador de DataMart.
	 * @return flgDataMart Indicador de DataMart, tipo String.
	 */
	public String getFlgDataMart() {
		return flgDataMart;
	}

	/**
	 * Método que permite actualizar el indicador de DataMart.
	 * @param flgDataMart Indicador de DataMart, tipo String.
	 */
	public void setFlgDataMart(String flgDataMart) {
		this.flgDataMart = flgDataMart;
	}
	
	
	/**
	 * Método que permite obtener la lista de ventas, con idProductoPim y número póliza, a consultar en la base de datos de Datamart.
	 * @return listaConsultaDatamartPorPoliza Lista de ventas, con idProductoPim y número póliza, a consultar en la base de datos de Datamart, tipo List<VentaCpeBean>.
	 */
	public List<VentaCpeBean> getListaConsultaDatamartPorPoliza() {
		return listaConsultaDatamartPorPoliza;
	}

	/**
	 * Método que permite actualizar la lista de ventas, con idProductoPim y número póliza, a consultar en la base de datos de Datamart. 
	 * @param listaConsultaDatamartPorPoliza Lista de ventas, con idProductoPim y número póliza, a consultar en la base de datos de Datamart, tipo List<VentaCpeBean>.
	 */
	public void setListaConsultaDatamartPorPoliza(List<VentaCpeBean> listaConsultaDatamartPorPoliza) {
		this.listaConsultaDatamartPorPoliza = listaConsultaDatamartPorPoliza;
	}

	/**
	 * Método que permite obtener la lista de ventas, con idProductoPim y número de documento, a consultar en la base de datos de Datamart.
	 * @return listaConsultaDatamartPorDocumento Lista de ventas, con idProductoPim y número de documento, a consultar en la base de datos de Datamart, tipo List<VentaCpeBean>.
	 */
	public List<VentaCpeBean> getListaConsultaDatamartPorDocumento() {
		return listaConsultaDatamartPorDocumento;
	}

	/**
	 * Método que permite actualizar la lista de ventas, con idProductoPim y número de documento, a consultar en la base de datos de Datamart. 
	 * @param listaConsultaDatamartPorDocumento Lista de ventas, con idProductoPim y número de documento, a consultar en la base de datos de Datamart, tipo List<VentaCpeBean>.
	 */
	public void setListaConsultaDatamartPorDocumento(List<VentaCpeBean> listaConsultaDatamartPorDocumento) {
		this.listaConsultaDatamartPorDocumento = listaConsultaDatamartPorDocumento;
	}

	/**
	 * Método que permite obtener el tipo de lista generado en el proceso de consulta a la base de datos del Datamart.
	 * @return tipoLista Tipo de lista generado en el proceso de consulta a la base de datos del Datamart, tipo String.
	 */
	public String getTipoLista() {
		return tipoLista;
	}

	/**
	 * Método que permite actualizar el tipo de lista generado en el proceso de consulta a la base de datos del Datamart. 
	 * @param tipoLista Tipo de lista generado en el proceso de consulta a la base de datos del Datamart, tipo String.
	 */
	public void setTipoLista(String tipoLista) {
		this.tipoLista = tipoLista;
	}

	
	
	/**
	 * Método que permite obtener el id Producto Pims en formato String.
	 * @return idStrProductoPims Id de producto pims en formato String, tipo String.
	 */
	public String getIdStrProductoPims() {
		return idStrProductoPims;
	}

	/**
	 * Método que permite actualizar el id Producto Pims en formato String.
	 * @param idStrProductoPims Id de producto pims en formato String, tipo String.
	 */
	public void setIdStrProductoPims(String idStrProductoPims) {
		this.idStrProductoPims = idStrProductoPims;
	}

	/**TIP_PER0100_CC14 FIN*/
	
	/**TIP_PER0100_CC15 INICIO 2019/06/21 16:33 Se definen los metodos get y set de los atributos agregados */
	
	/**
	 * Método que permite obtener el Número de serie de referencia en formato cadena.
	 * @return strNumSerieRef Número de serie de referencia en formato cadena, tipo String.
	 */
	public String getStrNumSerieRef() {
		return strNumSerieRef;
	}

	/**
	 * Método que permite actualizar el Número de serie de referencia en formato cadena. 
	 * @param strNumSerieRef Número de serie de referencia en formato cadena, tipo String.
	 */
	public void setStrNumSerieRef(String strNumSerieRef) {
		this.strNumSerieRef = strNumSerieRef;
	}

	/**
	 * Método que permite obtener el Número de correlativo de referencia en formato cadena.
	 * @return strNumCorRef Número de correlativo de referencia en formato cadena, tipo String.
	 */
	public String getStrNumCorRef() {
		return strNumCorRef;
	}

	/**
	 * Método que permite actualizar el Número de correlativo de referencia en formato cadena.
	 * @param strNumCorRef Número de correlativo de referencia en formato cadena, tipo String.
	 */
	public void setStrNumCorRef(String strNumCorRef) {
		this.strNumCorRef = strNumCorRef;
	}
	/**TIP_PER0100_CC15 FIN*/
	
	public Object clone(){
		Object obj = null;
		try {
			obj = super.clone();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
}
