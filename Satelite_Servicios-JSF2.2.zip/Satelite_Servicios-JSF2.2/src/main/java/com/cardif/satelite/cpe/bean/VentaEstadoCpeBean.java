package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;

public class VentaEstadoCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idVentaEstado;
	private Long idVenta;
	private String estadoVenta;
	private Date fechaCreacion;
	private String usuarioCreacion;
	
	public VentaEstadoCpeBean(){}

	public Long getIdVentaEstado() {
		return idVentaEstado;
	}

	public void setIdVentaEstado(Long idVentaEstado) {
		this.idVentaEstado = idVentaEstado;
	}

	public Long getIdVenta() {
		return idVenta;
	}

	public void setIdVenta(Long idVenta) {
		this.idVenta = idVenta;
	}

	public String getEstadoVenta() {
		return estadoVenta;
	}

	public void setEstadoVenta(String estadoVenta) {
		this.estadoVenta = estadoVenta;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}
}
