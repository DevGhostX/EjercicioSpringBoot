package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class VentaUploadAgrupadoCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String archivoCardif;
	private String archivoSocioProducto;
	private Integer proceso;
	private Integer lote;
	private Date fechaCarga;
	private String fechaCargaStr;
	private String codEstado;
	private String nEstado;
	private String inicioProceso;
	private String terminoProceso;
	private Integer registros;
	private String tipoMovimiento;
	private Long idSocio;
	private String nomSocio;
	private Long idProducto;
	private String nomProducto;
	
	private Date fecCargaDesde;
	private Date fecCargaHasta;
	private String numCertificado;
	private String prefijoAlta;
	
	private Boolean seleccionado;
	private Integer idProductoPims;
	
	private Integer registrosTrama;

	private List<String> listPrefijo;

	/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 11:45 - Se agrega el atributo lista de tipo de movimiento*/
	private List<String> listTipoMovimiento;
	/*TIP_PER0100_CC09_13 FIN*/
	
	public VentaUploadAgrupadoCpeBean(){}

	public String getArchivoCardif() {
		return archivoCardif;
	}

	public void setArchivoCardif(String archivoCardif) {
		this.archivoCardif = archivoCardif;
	}

	public String getArchivoSocioProducto() {
		return archivoSocioProducto;
	}

	public void setArchivoSocioProducto(String archivoSocioProducto) {
		this.archivoSocioProducto = archivoSocioProducto;
	}

	public Integer getProceso() {
		return proceso;
	}

	public void setProceso(Integer proceso) {
		this.proceso = proceso;
	}

	public Integer getLote() {
		return lote;
	}

	public void setLote(Integer lote) {
		this.lote = lote;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getnEstado() {
		return nEstado;
	}

	public void setnEstado(String nEstado) {
		this.nEstado = nEstado;
	}

	public String getInicioProceso() {
		return inicioProceso;
	}

	public void setInicioProceso(String inicioProceso) {
		this.inicioProceso = inicioProceso;
	}

	public String getTerminoProceso() {
		return terminoProceso;
	}

	public void setTerminoProceso(String terminoProceso) {
		this.terminoProceso = terminoProceso;
	}

	public Integer getRegistros() {
		return registros;
	}

	public void setRegistros(Integer registros) {
		this.registros = registros;
	}

	public String getTipoMovimiento() {
		return tipoMovimiento;
	}

	public void setTipoMovimiento(String tipoMovimiento) {
		this.tipoMovimiento = tipoMovimiento;
	}

	public Boolean getSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(Boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public Long getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Long idSocio) {
		this.idSocio = idSocio;
	}

	public String getNomSocio() {
		return nomSocio;
	}

	public void setNomSocio(String nomSocio) {
		this.nomSocio = nomSocio;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public Date getFecCargaDesde() {
		return fecCargaDesde;
	}

	public void setFecCargaDesde(Date fecCargaDesde) {
		this.fecCargaDesde = fecCargaDesde;
	}

	public Date getFecCargaHasta() {
		return fecCargaHasta;
	}

	public void setFecCargaHasta(Date fecCargaHasta) {
		this.fecCargaHasta = fecCargaHasta;
	}

	public String getNumCertificado() {
		return numCertificado;
	}

	public void setNumCertificado(String numCertificado) {
		this.numCertificado = numCertificado;
	}

	public String getPrefijoAlta() {
		return prefijoAlta;
	}

	public void setPrefijoAlta(String prefijoAlta) {
		this.prefijoAlta = prefijoAlta;
	}

	public Integer getIdProductoPims() {
		return idProductoPims;
	}

	public void setIdProductoPims(Integer idProductoPims) {
		this.idProductoPims = idProductoPims;
	}

	public String getFechaCargaStr() {
		return fechaCargaStr;
	}

	public void setFechaCargaStr(String fechaCargaStr) {
		this.fechaCargaStr = fechaCargaStr;
	}
	
	public List<String> getListPrefijo() {
		return listPrefijo;
	}

	public void setListPrefijo(List<String> listPrefijo) {
		this.listPrefijo = listPrefijo;
	}
	
	public Integer getRegistrosTrama() {
		return registrosTrama;
	}

	public void setRegistrosTrama(Integer registrosTrama) {
		this.registrosTrama = registrosTrama;
	}

	/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 11:45 - Se agrega los métodos get y set del atributo listTipoMovimiento*/
	/**
	 * Método que permite obtener la lista de tipo de movimientos.
	 * @return listTipoMovimiento Lista de tipo de movimientos, tipo List<String>.
	 */
	public List<String> getListTipoMovimiento() {
		return listTipoMovimiento;
	}

	/**
	 * Método que permite actualizar la lista de tipo de movimientos.
	 * @param listTipoMovimiento  Lista de tipo de movimientos, tipo List<String>.
	 */
	public void setListTipoMovimiento(List<String> listTipoMovimiento) {
		this.listTipoMovimiento = listTipoMovimiento;
	}
	/*TIP_PER0100_CC09_13 FIN*/
	
}
