package com.cardif.satelite.cpe.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class VentaUploadCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long idTramaUpload;
	private String nombreTramaUpload;
	private String llaveUpload;
	private String llavePims;
	private Long idSocio;
	private String nomSocio;
	private Long idProducto;
	private String nomProducto;
	private Date fecEmision;
	private String idTipoComp;
	private String concepNd;
	private String tipoMoneda;
	private Date fecVenc;
	private String idTipoDocCli;
	private String nomTipoDocCli;
	private String numDocCli;
	private String nomCliRazSoc;
	private String dirCli;
	private String departamento;
	private String provincia;
	private String distrito;
	private String telfCli;
	private String mailCli;
	private String numPoliza;
	private Date fecVenta;
	private BigDecimal baseImponible;
	private BigDecimal impExonerado;
	private BigDecimal impInafecto;
	private BigDecimal igv;
	private BigDecimal impTotal;
	private Long openItem;
	private String openItemRef;
	private Long colectIndiv;
	private Date fecCarga;
	private String fechaCargaStr;
	private Boolean seleccionado;
	private Integer proceso; 
	
	private String prefijoAlta;
	private String concepto;
	private Long codProdSunat;
	private BigDecimal valFactExport;
	private BigDecimal valOpgratuitas;
	private BigDecimal isc;
	private BigDecimal impOtros;
	private Long upldId;
	private Date fecCargaDesde;
	private Date fecCargaHasta;
	
	private String numCertificado;
	private Integer idProductoPims;
	
	private Long idVenta;
	private String estado;
	private Boolean existe;
	/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 12:48 - Se agrega el atributo lista de tipo de movimiento*/
	private List<String> listTipoMovimiento;
	/*TIP_PER0100_CC09_13 FIN*/
	public VentaUploadCpeBean(){}

	public String getLlaveUpload() {
		return llaveUpload;
	}

	public void setLlaveUpload(String llaveUpload) {
		this.llaveUpload = llaveUpload;
	}

	public String getLlavePims() {
		return llavePims;
	}

	public void setLlavePims(String llavePims) {
		this.llavePims = llavePims;
	}

	public Long getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Long idSocio) {
		this.idSocio = idSocio;
	}

	public String getNomSocio() {
		return nomSocio;
	}

	public void setNomSocio(String nomSocio) {
		this.nomSocio = nomSocio;
	}

	public Long getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Long idProducto) {
		this.idProducto = idProducto;
	}

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public Date getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getIdTipoComp() {
		return idTipoComp;
	}

	public void setIdTipoComp(String idTipoComp) {
		this.idTipoComp = idTipoComp;
	}

	public String getConcepNd() {
		return concepNd;
	}

	public void setConcepNd(String concepNd) {
		this.concepNd = concepNd;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public Date getFecVenc() {
		return fecVenc;
	}

	public void setFecVenc(Date fecVenc) {
		this.fecVenc = fecVenc;
	}

	public String getIdTipoDocCli() {
		return idTipoDocCli;
	}

	public void setIdTipoDocCli(String idTipoDocCli) {
		this.idTipoDocCli = idTipoDocCli;
	}

	public String getNumDocCli() {
		return numDocCli;
	}

	public void setNumDocCli(String numDocCli) {
		this.numDocCli = numDocCli;
	}

	public String getNomCliRazSoc() {
		return nomCliRazSoc;
	}

	public void setNomCliRazSoc(String nomCliRazSoc) {
		this.nomCliRazSoc = nomCliRazSoc;
	}

	public String getDirCli() {
		return dirCli;
	}

	public void setDirCli(String dirCli) {
		this.dirCli = dirCli;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getTelfCli() {
		return telfCli;
	}

	public void setTelfCli(String telfCli) {
		this.telfCli = telfCli;
	}

	public String getMailCli() {
		return mailCli;
	}

	public void setMailCli(String mailCli) {
		this.mailCli = mailCli;
	}

	public String getNumPoliza() {
		return numPoliza;
	}

	public void setNumPoliza(String numPoliza) {
		this.numPoliza = numPoliza;
	}

	public Date getFecVenta() {
		return fecVenta;
	}

	public void setFecVenta(Date fecVenta) {
		this.fecVenta = fecVenta;
	}

	public BigDecimal getBaseImponible() {
		return baseImponible;
	}

	public void setBaseImponible(BigDecimal baseImponible) {
		this.baseImponible = baseImponible;
	}

	public BigDecimal getImpExonerado() {
		return impExonerado;
	}

	public void setImpExonerado(BigDecimal impExonerado) {
		this.impExonerado = impExonerado;
	}

	public BigDecimal getImpInafecto() {
		return impInafecto;
	}

	public void setImpInafecto(BigDecimal impInafecto) {
		this.impInafecto = impInafecto;
	}

	public BigDecimal getIgv() {
		return igv;
	}

	public void setIgv(BigDecimal igv) {
		this.igv = igv;
	}

	public BigDecimal getImpTotal() {
		return impTotal;
	}

	public void setImpTotal(BigDecimal impTotal) {
		this.impTotal = impTotal;
	}

	public Long getOpenItem() {
		return openItem;
	}

	public void setOpenItem(Long openItem) {
		this.openItem = openItem;
	}

	public String getOpenItemRef() {
		return openItemRef;
	}

	public void setOpenItemRef(String openItemRef) {
		this.openItemRef = openItemRef;
	}

	public Long getColectIndiv() {
		return colectIndiv;
	}

	public void setColectIndiv(Long colectIndiv) {
		this.colectIndiv = colectIndiv;
	}

	public Boolean getSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(Boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public Date getFecCarga() {
		return fecCarga;
	}

	public void setFecCarga(Date fecCarga) {
		this.fecCarga = fecCarga;
	}

	public String getNomTipoDocCli() {
		return nomTipoDocCli;
	}

	public void setNomTipoDocCli(String nomTipoDocCli) {
		this.nomTipoDocCli = nomTipoDocCli;
	}

	public Integer getProceso() {
		return proceso;
	}

	public void setProceso(Integer proceso) {
		this.proceso = proceso;
	}

	public String getPrefijoAlta() {
		return prefijoAlta;
	}

	public void setPrefijoAlta(String prefijoAlta) {
		this.prefijoAlta = prefijoAlta;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public Long getCodProdSunat() {
		return codProdSunat;
	}

	public void setCodProdSunat(Long codProdSunat) {
		this.codProdSunat = codProdSunat;
	}

	public BigDecimal getValFactExport() {
		return valFactExport;
	}

	public void setValFactExport(BigDecimal valFactExport) {
		this.valFactExport = valFactExport;
	}

	public BigDecimal getValOpgratuitas() {
		return valOpgratuitas;
	}

	public void setValOpgratuitas(BigDecimal valOpgratuitas) {
		this.valOpgratuitas = valOpgratuitas;
	}

	public BigDecimal getIsc() {
		return isc;
	}

	public void setIsc(BigDecimal isc) {
		this.isc = isc;
	}

	public BigDecimal getImpOtros() {
		return impOtros;
	}

	public void setImpOtros(BigDecimal impOtros) {
		this.impOtros = impOtros;
	}

	public Long getUpldId() {
		return upldId;
	}

	public void setUpldId(Long upldId) {
		this.upldId = upldId;
	}

	public String getNumCertificado() {
		return numCertificado;
	}

	public void setNumCertificado(String numCertificado) {
		this.numCertificado = numCertificado;
	}

	public Date getFecCargaDesde() {
		return fecCargaDesde;
	}

	public void setFecCargaDesde(Date fecCargaDesde) {
		this.fecCargaDesde = fecCargaDesde;
	}

	public Date getFecCargaHasta() {
		return fecCargaHasta;
	}

	public void setFecCargaHasta(Date fecCargaHasta) {
		this.fecCargaHasta = fecCargaHasta;
	}

	public Integer getIdProductoPims() {
		return idProductoPims;
	}

	public void setIdProductoPims(Integer idProductoPims) {
		this.idProductoPims = idProductoPims;
	}

	public Long getIdVenta() {
		return idVenta;
	}

	public void setIdVenta(Long idVenta) {
		this.idVenta = idVenta;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Boolean getExiste() {
		return existe;
	}

	public void setExiste(Boolean existe) {
		this.existe = existe;
	}

	public String getFechaCargaStr() {
		return fechaCargaStr;
	}

	public void setFechaCargaStr(String fechaCargaStr) {
		this.fechaCargaStr = fechaCargaStr;
	}

	public Long getIdTramaUpload() {
		return idTramaUpload;
	}

	public void setIdTramaUpload(Long idTramaUpload) {
		this.idTramaUpload = idTramaUpload;
	}

	public String getNombreTramaUpload() {
		return nombreTramaUpload;
	}

	public void setNombreTramaUpload(String nombreTramaUpload) {
		this.nombreTramaUpload = nombreTramaUpload;
	}
	/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 12:48 - Se agrega los métodos get y set del atributo listTipoMovimiento*/
	/**
	 * Método que permite obtener la lista de tipo de movimientos.
	 * @return listTipoMovimiento Lista de tipo de movimientos, tipo List<String>.
	 */
	public List<String> getListTipoMovimiento() {
		return listTipoMovimiento;
	}

	/**
	 * Método que permite actualizar la lista de tipo de movimientos.
	 * @param listTipoMovimiento  Lista de tipo de movimientos, tipo List<String>.
	 */
	public void setListTipoMovimiento(List<String> listTipoMovimiento) {
		this.listTipoMovimiento = listTipoMovimiento;
	}
	/*TIP_PER0100_CC09_13 FIN*/
}
