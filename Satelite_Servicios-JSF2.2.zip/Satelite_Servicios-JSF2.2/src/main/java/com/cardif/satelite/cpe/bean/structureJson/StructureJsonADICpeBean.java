package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonADICpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String tituloAdicional;
	private String valorAdicional;
	
	public StructureJsonADICpeBean(){}

	public String getTituloAdicional() {
		return tituloAdicional;
	}

	public void setTituloAdicional(String tituloAdicional) {
		this.tituloAdicional = tituloAdicional;
	}

	public String getValorAdicional() {
		return valorAdicional;
	}

	public void setValorAdicional(String valorAdicional) {
		this.valorAdicional = valorAdicional;
	}
}
