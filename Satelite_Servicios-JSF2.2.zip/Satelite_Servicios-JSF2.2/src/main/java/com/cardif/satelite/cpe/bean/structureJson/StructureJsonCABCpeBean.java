package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;
import java.util.List;

public class StructureJsonCABCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private StructureJsonGravadasCpeBean gravadas;
	private StructureJsonInafectasCpeBean inafectas;
	private StructureJsonExoneradasCpeBean exoneradas;
	private StructureJsonGratuitasCpeBean gratuitas;
	private StructureJsonExportadasCpeBean exportadas;
	private StructureJsonPercepcionesCpeBean percepciones;
	private List<StructureJsonTotalImpuestosCpeBean> totalImpuestos;
	private String sumOtrosCargos;
	private StructureJsonTotalDescuentosCpeBean totalDescuentos;
	private String importeTotal;
	private List<StructureJsonInformacionAnticipoCpeBean> informacionAnticipo;
	private String totalAnticipos;
	private String tipoOperacion;
	private List<StructureJsonLeyendaCpeBean> leyenda;
	private String montoTotalImpuestos;
	private List<StructureJsonCargoDescuentoCpeBean> cargoDescuento;
	
	public StructureJsonCABCpeBean(){}

	public StructureJsonGravadasCpeBean getGravadas() {
		return gravadas;
	}

	public void setGravadas(StructureJsonGravadasCpeBean gravadas) {
		this.gravadas = gravadas;
	}

	public StructureJsonInafectasCpeBean getInafectas() {
		return inafectas;
	}

	public void setInafectas(StructureJsonInafectasCpeBean inafectas) {
		this.inafectas = inafectas;
	}

	public StructureJsonExoneradasCpeBean getExoneradas() {
		return exoneradas;
	}

	public void setExoneradas(StructureJsonExoneradasCpeBean exoneradas) {
		this.exoneradas = exoneradas;
	}

	public StructureJsonGratuitasCpeBean getGratuitas() {
		return gratuitas;
	}

	public void setGratuitas(StructureJsonGratuitasCpeBean gratuitas) {
		this.gratuitas = gratuitas;
	}

	public StructureJsonExportadasCpeBean getExportadas() {
		return exportadas;
	}

	public void setExportadas(StructureJsonExportadasCpeBean exportadas) {
		this.exportadas = exportadas;
	}

	public StructureJsonPercepcionesCpeBean getPercepciones() {
		return percepciones;
	}

	public void setPercepciones(StructureJsonPercepcionesCpeBean percepciones) {
		this.percepciones = percepciones;
	}

	public List<StructureJsonTotalImpuestosCpeBean> getTotalImpuestos() {
		return totalImpuestos;
	}

	public void setTotalImpuestos(
			List<StructureJsonTotalImpuestosCpeBean> totalImpuestos) {
		this.totalImpuestos = totalImpuestos;
	}

	public String getSumOtrosCargos() {
		return sumOtrosCargos;
	}

	public void setSumOtrosCargos(String sumOtrosCargos) {
		this.sumOtrosCargos = sumOtrosCargos;
	}

	public StructureJsonTotalDescuentosCpeBean getTotalDescuentos() {
		return totalDescuentos;
	}

	public void setTotalDescuentos(
			StructureJsonTotalDescuentosCpeBean totalDescuentos) {
		this.totalDescuentos = totalDescuentos;
	}

	public String getImporteTotal() {
		return importeTotal;
	}

	public void setImporteTotal(String importeTotal) {
		this.importeTotal = importeTotal;
	}

	public List<StructureJsonInformacionAnticipoCpeBean> getInformacionAnticipo() {
		return informacionAnticipo;
	}

	public void setInformacionAnticipo(
			List<StructureJsonInformacionAnticipoCpeBean> informacionAnticipo) {
		this.informacionAnticipo = informacionAnticipo;
	}

	public String getTotalAnticipos() {
		return totalAnticipos;
	}

	public void setTotalAnticipos(String totalAnticipos) {
		this.totalAnticipos = totalAnticipos;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public List<StructureJsonLeyendaCpeBean> getLeyenda() {
		return leyenda;
	}

	public void setLeyenda(List<StructureJsonLeyendaCpeBean> leyenda) {
		this.leyenda = leyenda;
	}
	
	public String getMontoTotalImpuestos() {
		return montoTotalImpuestos;
	}

	public void setMontoTotalImpuestos(String montoTotalImpuestos) {
		this.montoTotalImpuestos = montoTotalImpuestos;
	}

	public List<StructureJsonCargoDescuentoCpeBean> getCargoDescuento() {
		return cargoDescuento;
	}

	public void setCargoDescuento(
			List<StructureJsonCargoDescuentoCpeBean> cargoDescuento) {
		this.cargoDescuento = cargoDescuento;
	}
}
