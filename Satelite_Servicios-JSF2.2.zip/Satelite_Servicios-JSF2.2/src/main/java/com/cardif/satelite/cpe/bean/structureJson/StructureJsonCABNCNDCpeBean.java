package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;
import java.util.List;

public class StructureJsonCABNCNDCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private StructureJsonGravadasNCNDCpeBean gravadas;
	private StructureJsonInafectasNCNDCpeBean inafectas;
	private StructureJsonExoneradasNCNDCpeBean exoneradas;
	private StructureJsonGratuitasNCNDCpeBean gratuitas;
	private List<StructureJsonTotalImpuestosNCNDCpeBean> totalImpuestos;
	private String sumOtrosCargos;
	private String importeTotal;
	private String tipoOperacion;
	private List<StructureJsonLeyendaNCNDCpeBean> leyenda;
	private String montoTotalImpuestos;

	public StructureJsonCABNCNDCpeBean(){}

	public StructureJsonGravadasNCNDCpeBean getGravadas() {
		return gravadas;
	}

	public void setGravadas(StructureJsonGravadasNCNDCpeBean gravadas) {
		this.gravadas = gravadas;
	}

	public StructureJsonInafectasNCNDCpeBean getInafectas() {
		return inafectas;
	}

	public void setInafectas(StructureJsonInafectasNCNDCpeBean inafectas) {
		this.inafectas = inafectas;
	}

	public StructureJsonExoneradasNCNDCpeBean getExoneradas() {
		return exoneradas;
	}

	public void setExoneradas(StructureJsonExoneradasNCNDCpeBean exoneradas) {
		this.exoneradas = exoneradas;
	}
	
	public StructureJsonGratuitasNCNDCpeBean getGratuitas() {
		return gratuitas;
	}

	public void setGratuitas(StructureJsonGratuitasNCNDCpeBean gratuitas) {
		this.gratuitas = gratuitas;
	}

	public List<StructureJsonTotalImpuestosNCNDCpeBean> getTotalImpuestos() {
		return totalImpuestos;
	}

	public void setTotalImpuestos(
			List<StructureJsonTotalImpuestosNCNDCpeBean> totalImpuestos) {
		this.totalImpuestos = totalImpuestos;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	
	public String getSumOtrosCargos() {
		return sumOtrosCargos;
	}

	public void setSumOtrosCargos(String sumOtrosCargos) {
		this.sumOtrosCargos = sumOtrosCargos;
	}

	public String getImporteTotal() {
		return importeTotal;
	}

	public void setImporteTotal(String importeTotal) {
		this.importeTotal = importeTotal;
	}

	public List<StructureJsonLeyendaNCNDCpeBean> getLeyenda() {
		return leyenda;
	}

	public void setLeyenda(List<StructureJsonLeyendaNCNDCpeBean> leyenda) {
		this.leyenda = leyenda;
	}
	
	public String getMontoTotalImpuestos() {
		return montoTotalImpuestos;
	}

	public void setMontoTotalImpuestos(String montoTotalImpuestos) {
		this.montoTotalImpuestos = montoTotalImpuestos;
	}
}
