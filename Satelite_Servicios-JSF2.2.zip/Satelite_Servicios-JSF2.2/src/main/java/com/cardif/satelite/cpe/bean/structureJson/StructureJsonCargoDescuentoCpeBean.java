package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonCargoDescuentoCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String indicadorCargoDescuento;
	private String codigoCargoDescuento;
	private String factorCargoDescuento;
	private String descuentosGlobales;
	private String montoBaseCargoDescuento;
	
	public StructureJsonCargoDescuentoCpeBean(){}

	public String getIndicadorCargoDescuento() {
		return indicadorCargoDescuento;
	}

	public void setIndicadorCargoDescuento(String indicadorCargoDescuento) {
		this.indicadorCargoDescuento = indicadorCargoDescuento;
	}

	public String getCodigoCargoDescuento() {
		return codigoCargoDescuento;
	}

	public void setCodigoCargoDescuento(String codigoCargoDescuento) {
		this.codigoCargoDescuento = codigoCargoDescuento;
	}

	public String getFactorCargoDescuento() {
		return factorCargoDescuento;
	}

	public void setFactorCargoDescuento(String factorCargoDescuento) {
		this.factorCargoDescuento = factorCargoDescuento;
	}

	public String getDescuentosGlobales() {
		return descuentosGlobales;
	}

	public void setDescuentosGlobales(String descuentosGlobales) {
		this.descuentosGlobales = descuentosGlobales;
	}

	public String getMontoBaseCargoDescuento() {
		return montoBaseCargoDescuento;
	}

	public void setMontoBaseCargoDescuento(String montoBaseCargoDescuento) {
		this.montoBaseCargoDescuento = montoBaseCargoDescuento;
	}
}
