package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;
import java.util.List;

public class StructureJsonDETCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String numeroItem;
	private String codigoProducto;
	private String descripcionProducto;
	private String cantidadItems;
	private String unidad;
	private String valorUnitario;
	private String precioVentaUnitario;
	private List<StructureJsonTotalImpuestosDetCpeBean> totalImpuestos;
	private String valorVenta;
	private String valorRefOpOnerosas;
	private String numeroPlaca;
	private String codProductoSunat;
	private String codNumeroContrato;
	private String numeroContrato;
	private String codFechaOtorgCredito;
	private String fechaOtorgCredito;
	private String codTipoPrestamo;
	private String tipoPrestamo;
	private String codPartidaRegistral;
	private String partidaRegistral;
	private String codIndicadorPrimViv;
	private String indicadorPrimViv;
	private String codDireccionPredio;
	private String direccionPredio;
	private String codCodigoUbigeo;
	private String codigoUbigeo;
	private String codUrbanizacion;
	private String urbanizacion;
	private String codDepartamento;
	private String departamento;
	private String codProvincia;
	private String provincia;
	private String codDistrito;
	private String distrito;
	private String codProductoGS1;
	private String montoTotalImpuestos;
	private List<StructureJsonCargoDescuentoDetCpeBean> cargoDescuento;

	public StructureJsonDETCpeBean(){}

	public String getNumeroItem() {
		return numeroItem;
	}

	public void setNumeroItem(String numeroItem) {
		this.numeroItem = numeroItem;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public String getDescripcionProducto() {
		return descripcionProducto;
	}

	public void setDescripcionProducto(String descripcionProducto) {
		this.descripcionProducto = descripcionProducto;
	}

	public String getCantidadItems() {
		return cantidadItems;
	}

	public void setCantidadItems(String cantidadItems) {
		this.cantidadItems = cantidadItems;
	}

	public String getUnidad() {
		return unidad;
	}

	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}

	public String getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(String valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	public String getPrecioVentaUnitario() {
		return precioVentaUnitario;
	}

	public void setPrecioVentaUnitario(String precioVentaUnitario) {
		this.precioVentaUnitario = precioVentaUnitario;
	}

	public List<StructureJsonTotalImpuestosDetCpeBean> getTotalImpuestos() {
		return totalImpuestos;
	}

	public void setTotalImpuestos(
			List<StructureJsonTotalImpuestosDetCpeBean> totalImpuestos) {
		this.totalImpuestos = totalImpuestos;
	}

	public String getValorVenta() {
		return valorVenta;
	}

	public void setValorVenta(String valorVenta) {
		this.valorVenta = valorVenta;
	}

	public String getValorRefOpOnerosas() {
		return valorRefOpOnerosas;
	}

	public void setValorRefOpOnerosas(String valorRefOpOnerosas) {
		this.valorRefOpOnerosas = valorRefOpOnerosas;
	}

	public String getNumeroPlaca() {
		return numeroPlaca;
	}

	public void setNumeroPlaca(String numeroPlaca) {
		this.numeroPlaca = numeroPlaca;
	}

	public String getCodProductoSunat() {
		return codProductoSunat;
	}

	public void setCodProductoSunat(String codProductoSunat) {
		this.codProductoSunat = codProductoSunat;
	}

	public String getCodNumeroContrato() {
		return codNumeroContrato;
	}

	public void setCodNumeroContrato(String codNumeroContrato) {
		this.codNumeroContrato = codNumeroContrato;
	}

	public String getNumeroContrato() {
		return numeroContrato;
	}

	public void setNumeroContrato(String numeroContrato) {
		this.numeroContrato = numeroContrato;
	}

	public String getCodFechaOtorgCredito() {
		return codFechaOtorgCredito;
	}

	public void setCodFechaOtorgCredito(String codFechaOtorgCredito) {
		this.codFechaOtorgCredito = codFechaOtorgCredito;
	}

	public String getFechaOtorgCredito() {
		return fechaOtorgCredito;
	}

	public void setFechaOtorgCredito(String fechaOtorgCredito) {
		this.fechaOtorgCredito = fechaOtorgCredito;
	}

	public String getCodTipoPrestamo() {
		return codTipoPrestamo;
	}

	public void setCodTipoPrestamo(String codTipoPrestamo) {
		this.codTipoPrestamo = codTipoPrestamo;
	}

	public String getTipoPrestamo() {
		return tipoPrestamo;
	}

	public void setTipoPrestamo(String tipoPrestamo) {
		this.tipoPrestamo = tipoPrestamo;
	}

	public String getCodPartidaRegistral() {
		return codPartidaRegistral;
	}

	public void setCodPartidaRegistral(String codPartidaRegistral) {
		this.codPartidaRegistral = codPartidaRegistral;
	}

	public String getPartidaRegistral() {
		return partidaRegistral;
	}

	public void setPartidaRegistral(String partidaRegistral) {
		this.partidaRegistral = partidaRegistral;
	}

	public String getCodIndicadorPrimViv() {
		return codIndicadorPrimViv;
	}

	public void setCodIndicadorPrimViv(String codIndicadorPrimViv) {
		this.codIndicadorPrimViv = codIndicadorPrimViv;
	}

	public String getIndicadorPrimViv() {
		return indicadorPrimViv;
	}

	public void setIndicadorPrimViv(String indicadorPrimViv) {
		this.indicadorPrimViv = indicadorPrimViv;
	}

	public String getCodDireccionPredio() {
		return codDireccionPredio;
	}

	public void setCodDireccionPredio(String codDireccionPredio) {
		this.codDireccionPredio = codDireccionPredio;
	}

	public String getDireccionPredio() {
		return direccionPredio;
	}

	public void setDireccionPredio(String direccionPredio) {
		this.direccionPredio = direccionPredio;
	}

	public String getCodCodigoUbigeo() {
		return codCodigoUbigeo;
	}

	public void setCodCodigoUbigeo(String codCodigoUbigeo) {
		this.codCodigoUbigeo = codCodigoUbigeo;
	}

	public String getCodigoUbigeo() {
		return codigoUbigeo;
	}

	public void setCodigoUbigeo(String codigoUbigeo) {
		this.codigoUbigeo = codigoUbigeo;
	}

	public String getCodUrbanizacion() {
		return codUrbanizacion;
	}

	public void setCodUrbanizacion(String codUrbanizacion) {
		this.codUrbanizacion = codUrbanizacion;
	}

	public String getUrbanizacion() {
		return urbanizacion;
	}

	public void setUrbanizacion(String urbanizacion) {
		this.urbanizacion = urbanizacion;
	}

	public String getCodDepartamento() {
		return codDepartamento;
	}

	public void setCodDepartamento(String codDepartamento) {
		this.codDepartamento = codDepartamento;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getCodProvincia() {
		return codProvincia;
	}

	public void setCodProvincia(String codProvincia) {
		this.codProvincia = codProvincia;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getCodDistrito() {
		return codDistrito;
	}

	public void setCodDistrito(String codDistrito) {
		this.codDistrito = codDistrito;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}
	
	public String getCodProductoGS1() {
		return codProductoGS1;
	}

	public void setCodProductoGS1(String codProductoGS1) {
		this.codProductoGS1 = codProductoGS1;
	}

	public String getMontoTotalImpuestos() {
		return montoTotalImpuestos;
	}

	public void setMontoTotalImpuestos(String montoTotalImpuestos) {
		this.montoTotalImpuestos = montoTotalImpuestos;
	}

	public List<StructureJsonCargoDescuentoDetCpeBean> getCargoDescuento() {
		return cargoDescuento;
	}

	public void setCargoDescuento(
			List<StructureJsonCargoDescuentoDetCpeBean> cargoDescuento) {
		this.cargoDescuento = cargoDescuento;
	}
}
