package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonDRFCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String tipoDocRelacionado;
	private String numeroDocRelacionado;
	
	public StructureJsonDRFCpeBean(){}

	public String getTipoDocRelacionado() {
		return tipoDocRelacionado;
	}

	public void setTipoDocRelacionado(String tipoDocRelacionado) {
		this.tipoDocRelacionado = tipoDocRelacionado;
	}

	public String getNumeroDocRelacionado() {
		return numeroDocRelacionado;
	}

	public void setNumeroDocRelacionado(String numeroDocRelacionado) {
		this.numeroDocRelacionado = numeroDocRelacionado;
	}
}
