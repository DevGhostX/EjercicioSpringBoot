package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonDRFNCNDCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String tipoDocRelacionado;
	private String numeroDocRelacionado;
	private String codigoMotivo;
	private String descripcionMotivo;
	
	public StructureJsonDRFNCNDCpeBean(){}

	public String getTipoDocRelacionado() {
		return tipoDocRelacionado;
	}

	public void setTipoDocRelacionado(String tipoDocRelacionado) {
		this.tipoDocRelacionado = tipoDocRelacionado;
	}

	public String getNumeroDocRelacionado() {
		return numeroDocRelacionado;
	}

	public void setNumeroDocRelacionado(String numeroDocRelacionado) {
		this.numeroDocRelacionado = numeroDocRelacionado;
	}

	public String getCodigoMotivo() {
		return codigoMotivo;
	}

	public void setCodigoMotivo(String codigoMotivo) {
		this.codigoMotivo = codigoMotivo;
	}

	public String getDescripcionMotivo() {
		return descripcionMotivo;
	}

	public void setDescripcionMotivo(String descripcionMotivo) {
		this.descripcionMotivo = descripcionMotivo;
	}
}
