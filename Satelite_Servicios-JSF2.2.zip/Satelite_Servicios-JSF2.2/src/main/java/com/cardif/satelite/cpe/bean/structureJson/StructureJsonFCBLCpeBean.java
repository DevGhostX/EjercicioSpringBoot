package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;
import java.util.List;

public class StructureJsonFCBLCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private StructureJsonIDECpeBean IDE;
	private StructureJsonEMICpeBean EMI;
	private StructureJsonRECCpeBean REC;
	private List<StructureJsonDRFCpeBean> DRF;
	private StructureJsonCABCpeBean CAB;
	private List<StructureJsonDETCpeBean> DET;
	private List<StructureJsonADICpeBean> ADI;
	
	public StructureJsonFCBLCpeBean(){}

	public StructureJsonIDECpeBean getIDE() {
		return IDE;
	}

	public void setIDE(StructureJsonIDECpeBean iDE) {
		IDE = iDE;
	}

	public StructureJsonEMICpeBean getEMI() {
		return EMI;
	}

	public void setEMI(StructureJsonEMICpeBean eMI) {
		EMI = eMI;
	}

	public StructureJsonRECCpeBean getREC() {
		return REC;
	}

	public void setREC(StructureJsonRECCpeBean rEC) {
		REC = rEC;
	}

	public List<StructureJsonDRFCpeBean> getDRF() {
		return DRF;
	}

	public void setDRF(List<StructureJsonDRFCpeBean> dRF) {
		DRF = dRF;
	}

	public StructureJsonCABCpeBean getCAB() {
		return CAB;
	}

	public void setCAB(StructureJsonCABCpeBean cAB) {
		CAB = cAB;
	}

	public List<StructureJsonDETCpeBean> getDET() {
		return DET;
	}

	public void setDET(List<StructureJsonDETCpeBean> dET) {
		DET = dET;
	}

	public List<StructureJsonADICpeBean> getADI() {
		return ADI;
	}

	public void setADI(List<StructureJsonADICpeBean> aDI) {
		ADI = aDI;
	}
}
