package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonGratuitasCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String codigo;
	private String totalVentas;
	
	public StructureJsonGratuitasCpeBean(){}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getTotalVentas() {
		return totalVentas;
	}

	public void setTotalVentas(String totalVentas) {
		this.totalVentas = totalVentas;
	}
}
