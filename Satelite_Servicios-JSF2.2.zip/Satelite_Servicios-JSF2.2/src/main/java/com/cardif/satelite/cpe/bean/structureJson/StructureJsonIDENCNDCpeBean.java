package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonIDENCNDCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String numeracion;
	private String fechaEmision;
	private String horaEmision;
	private String tipoMoneda;
	
	public StructureJsonIDENCNDCpeBean(){}

	public String getNumeracion() {
		return numeracion;
	}

	public void setNumeracion(String numeracion) {
		this.numeracion = numeracion;
	}

	public String getFechaEmision() {
		return fechaEmision;
	}

	public void setFechaEmision(String fechaEmision) {
		this.fechaEmision = fechaEmision;
	}

	public String getHoraEmision() {
		return horaEmision;
	}

	public void setHoraEmision(String horaEmision) {
		this.horaEmision = horaEmision;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}
}
