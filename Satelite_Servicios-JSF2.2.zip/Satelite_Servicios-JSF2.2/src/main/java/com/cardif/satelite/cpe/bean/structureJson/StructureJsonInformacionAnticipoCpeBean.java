package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonInformacionAnticipoCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String serieNumero;
	private String tipoComprobante;
	private String monto;
	private String tipoMoneda;
	private String fechaAnticipo;
	private String numeroDocEmisor;
	private String tipoDocumentoEmisor;
	private String identificador;

	public StructureJsonInformacionAnticipoCpeBean(){}

	public String getSerieNumero() {
		return serieNumero;
	}

	public void setSerieNumero(String serieNumero) {
		this.serieNumero = serieNumero;
	}

	public String getTipoComprobante() {
		return tipoComprobante;
	}

	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}

	public String getMonto() {
		return monto;
	}

	public void setMonto(String monto) {
		this.monto = monto;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public String getFechaAnticipo() {
		return fechaAnticipo;
	}

	public void setFechaAnticipo(String fechaAnticipo) {
		this.fechaAnticipo = fechaAnticipo;
	}

	public String getNumeroDocEmisor() {
		return numeroDocEmisor;
	}

	public void setNumeroDocEmisor(String numeroDocEmisor) {
		this.numeroDocEmisor = numeroDocEmisor;
	}

	public String getTipoDocumentoEmisor() {
		return tipoDocumentoEmisor;
	}

	public void setTipoDocumentoEmisor(String tipoDocumentoEmisor) {
		this.tipoDocumentoEmisor = tipoDocumentoEmisor;
	}
	
	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
}
