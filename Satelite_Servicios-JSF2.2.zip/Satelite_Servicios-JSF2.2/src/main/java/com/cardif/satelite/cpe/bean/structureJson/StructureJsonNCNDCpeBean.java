package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;
import java.util.List;

public class StructureJsonNCNDCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private StructureJsonIDENCNDCpeBean IDE;
	private StructureJsonEMINCNDCpeBean EMI;
	private StructureJsonRECNCNDCpeBean REC;
	private List<StructureJsonDRFNCNDCpeBean> DRF;
	private StructureJsonCABNCNDCpeBean CAB;
	private List<StructureJsonDETNCNDCpeBean> DET;
	private List<StructureJsonADINCNDCpeBean> ADI;
	
	public StructureJsonNCNDCpeBean(){}

	public StructureJsonIDENCNDCpeBean getIDE() {
		return IDE;
	}

	public void setIDE(StructureJsonIDENCNDCpeBean iDE) {
		IDE = iDE;
	}

	public StructureJsonEMINCNDCpeBean getEMI() {
		return EMI;
	}

	public void setEMI(StructureJsonEMINCNDCpeBean eMI) {
		EMI = eMI;
	}

	public StructureJsonRECNCNDCpeBean getREC() {
		return REC;
	}

	public void setREC(StructureJsonRECNCNDCpeBean rEC) {
		REC = rEC;
	}

	public List<StructureJsonDRFNCNDCpeBean> getDRF() {
		return DRF;
	}

	public void setDRF(List<StructureJsonDRFNCNDCpeBean> dRF) {
		DRF = dRF;
	}

	public StructureJsonCABNCNDCpeBean getCAB() {
		return CAB;
	}

	public void setCAB(StructureJsonCABNCNDCpeBean cAB) {
		CAB = cAB;
	}

	public List<StructureJsonDETNCNDCpeBean> getDET() {
		return DET;
	}

	public void setDET(List<StructureJsonDETNCNDCpeBean> dET) {
		DET = dET;
	}

	public List<StructureJsonADINCNDCpeBean> getADI() {
		return ADI;
	}

	public void setADI(List<StructureJsonADINCNDCpeBean> aDI) {
		ADI = aDI;
	}
}
