package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonPercepcionesCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String indicadorPercepcion;
	private String codRegimenPercepcion;
	private String baseImpPercepcion;
	private String montoPercepcion;
	private String factorPercepcion;
	
	public StructureJsonPercepcionesCpeBean(){}

	public String getIndicadorPercepcion() {
		return indicadorPercepcion;
	}

	public void setIndicadorPercepcion(String indicadorPercepcion) {
		this.indicadorPercepcion = indicadorPercepcion;
	}

	public String getCodRegimenPercepcion() {
		return codRegimenPercepcion;
	}

	public void setCodRegimenPercepcion(String codRegimenPercepcion) {
		this.codRegimenPercepcion = codRegimenPercepcion;
	}

	public String getBaseImpPercepcion() {
		return baseImpPercepcion;
	}

	public void setBaseImpPercepcion(String baseImpPercepcion) {
		this.baseImpPercepcion = baseImpPercepcion;
	}

	public String getMontoPercepcion() {
		return montoPercepcion;
	}

	public void setMontoPercepcion(String montoPercepcion) {
		this.montoPercepcion = montoPercepcion;
	}

	public String getFactorPercepcion() {
		return factorPercepcion;
	}

	public void setFactorPercepcion(String factorPercepcion) {
		this.factorPercepcion = factorPercepcion;
	}
}
