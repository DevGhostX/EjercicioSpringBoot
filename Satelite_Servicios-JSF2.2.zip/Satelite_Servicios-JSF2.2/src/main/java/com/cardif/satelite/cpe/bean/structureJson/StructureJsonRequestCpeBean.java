package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonRequestCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private StructureJsonCustomerCpeBean customer;
	private String fileName;
	private String fileContent;
	
	public StructureJsonRequestCpeBean(){}

	public StructureJsonCustomerCpeBean getCustomer() {
		return customer;
	}

	public void setCustomer(StructureJsonCustomerCpeBean customer) {
		this.customer = customer;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileContent() {
		return fileContent;
	}

	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
}
