package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonResponseCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String responseCode;
	private String responseContent;
	
	public StructureJsonResponseCpeBean(){}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseContent() {
		return responseContent;
	}

	public void setResponseContent(String responseContent) {
		this.responseContent = responseContent;
	}
}
