package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonRootCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private StructureJsonFCBLCpeBean factura;
	private StructureJsonFCBLCpeBean boleta;
	private StructureJsonNCNDCpeBean notaCredito;
	private StructureJsonNCNDCpeBean notaDebito;
	
	public StructureJsonRootCpeBean(){}

	public StructureJsonFCBLCpeBean getFactura() {
		return factura;
	}

	public void setFactura(StructureJsonFCBLCpeBean factura) {
		this.factura = factura;
	}

	public StructureJsonFCBLCpeBean getBoleta() {
		return boleta;
	}

	public void setBoleta(StructureJsonFCBLCpeBean boleta) {
		this.boleta = boleta;
	}

	public StructureJsonNCNDCpeBean getNotaCredito() {
		return notaCredito;
	}

	public void setNotaCredito(StructureJsonNCNDCpeBean notaCredito) {
		this.notaCredito = notaCredito;
	}

	public StructureJsonNCNDCpeBean getNotaDebito() {
		return notaDebito;
	}

	public void setNotaDebito(StructureJsonNCNDCpeBean notaDebito) {
		this.notaDebito = notaDebito;
	}
}
