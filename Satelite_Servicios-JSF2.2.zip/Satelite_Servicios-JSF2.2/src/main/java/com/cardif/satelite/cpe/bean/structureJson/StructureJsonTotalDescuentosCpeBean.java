package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonTotalDescuentosCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String codigo;
	private String totalDescuentos;
	
	public StructureJsonTotalDescuentosCpeBean(){}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getTotalDescuentos() {
		return totalDescuentos;
	}

	public void setTotalDescuentos(String totalDescuentos) {
		this.totalDescuentos = totalDescuentos;
	}
}
