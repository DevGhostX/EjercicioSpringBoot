package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonTotalImpuestosDetNCNDCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String idImpuesto;
	private String montoImpuesto;
	private String tipoAfectacion;
	private String montoBase;
	private String porcentaje;

	public StructureJsonTotalImpuestosDetNCNDCpeBean(){}

	public String getIdImpuesto() {
		return idImpuesto;
	}

	public void setIdImpuesto(String idImpuesto) {
		this.idImpuesto = idImpuesto;
	}

	public String getMontoImpuesto() {
		return montoImpuesto;
	}

	public void setMontoImpuesto(String montoImpuesto) {
		this.montoImpuesto = montoImpuesto;
	}

	public String getTipoAfectacion() {
		return tipoAfectacion;
	}

	public void setTipoAfectacion(String tipoAfectacion) {
		this.tipoAfectacion = tipoAfectacion;
	}
	
	public String getMontoBase() {
		return montoBase;
	}

	public void setMontoBase(String montoBase) {
		this.montoBase = montoBase;
	}

	public String getPorcentaje() {
		return porcentaje;
	}

	public void setPorcentaje(String porcentaje) {
		this.porcentaje = porcentaje;
	}
}
