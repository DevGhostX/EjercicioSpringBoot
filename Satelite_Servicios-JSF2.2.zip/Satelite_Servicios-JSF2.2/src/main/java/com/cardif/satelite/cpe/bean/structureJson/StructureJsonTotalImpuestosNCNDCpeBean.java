package com.cardif.satelite.cpe.bean.structureJson;

import java.io.Serializable;

public class StructureJsonTotalImpuestosNCNDCpeBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String idImpuesto;
	private String montoImpuesto;
	
	public StructureJsonTotalImpuestosNCNDCpeBean(){}

	public String getIdImpuesto() {
		return idImpuesto;
	}

	public void setIdImpuesto(String idImpuesto) {
		this.idImpuesto = idImpuesto;
	}

	public String getMontoImpuesto() {
		return montoImpuesto;
	}

	public void setMontoImpuesto(String montoImpuesto) {
		this.montoImpuesto = montoImpuesto;
	}
}
