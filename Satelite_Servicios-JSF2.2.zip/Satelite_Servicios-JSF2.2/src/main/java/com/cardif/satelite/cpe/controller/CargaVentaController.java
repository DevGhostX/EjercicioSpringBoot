package com.cardif.satelite.cpe.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.CampoLayoutCpeBean;
import com.cardif.satelite.cpe.bean.CargaVentaCabCpeBean;
import com.cardif.satelite.cpe.bean.ConfiguracionCpeBean;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.ParametroSUNATCpeBean;
import com.cardif.satelite.cpe.bean.ProductoCpeBean;
import com.cardif.satelite.cpe.bean.SocioCpeBean;
import com.cardif.satelite.cpe.bean.UbigeoCpeBean;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.bean.VentaEstadoCpeBean;
import com.cardif.satelite.cpe.bean.VentaPimsCpeBean;
import com.cardif.satelite.cpe.bean.VentaUploadAgrupadoCpeBean;
import com.cardif.satelite.cpe.bean.VentaUploadCpeBean;
import com.cardif.satelite.cpe.service.CampoLayoutCpeService;
import com.cardif.satelite.cpe.service.CargaVentaCabCpeService;
import com.cardif.satelite.cpe.service.ConfiguracionCpeService;
import com.cardif.satelite.cpe.service.ParametroCpeService;
import com.cardif.satelite.cpe.service.ParametroSUNATCpeService;
import com.cardif.satelite.cpe.service.ProcesoCpeService;
import com.cardif.satelite.cpe.service.ProductoCpeService;
import com.cardif.satelite.cpe.service.RegistroVentasSuscripcionService;
import com.cardif.satelite.cpe.service.SocioCpeService;
import com.cardif.satelite.cpe.service.UbigeoCpeService;
import com.cardif.satelite.cpe.service.VentaPimsCpeService;
import com.cardif.satelite.cpe.service.VentaUploadCpeService;
import com.cardif.satelite.cpe.util.DataSourceSatelite;
import com.cardif.satelite.model.TstVentas;
import com.cardif.satelite.reportesbs.service.RepParametroService;
import com.cardif.satelite.ssis.service.SsisService;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;

import oracle.jdbc.OracleTypes;

@Controller("cargaVentaController")
@Scope("session")
public class CargaVentaController extends BaseController implements Serializable {
	private static final long serialVersionUID = 1L;
	private Date timeVersion;

	public static final Logger LOGGER = Logger.getLogger(CargaVentaController.class);

	/*************************************************************************************/
	// nuevas variables
	private String origen;
	private boolean bloqueaArchivos;
	private boolean bloqueaArchivosGrilla;
	private boolean bloqueoProcesarArchivo;
	private boolean bloqueaBusqueda;
	private boolean bloqueaPims;
	private boolean bloqueaUpload;
	private boolean bloqueaUploadDetalle;
	private boolean bloqueaUploadAgrupado;
	/************************************/
	private boolean disabledRutaPredeterminada;
	private boolean disabledNomArchivo;
	private boolean disabledPorRuta;
	private boolean disabledTipoBusqueda;
	/************************************/
	private List<SelectItem> origenesItems;
	private List<SelectItem> socioItems;
	private List<SelectItem> monedaItems;
	private List<SelectItem> tipoComprobanteItems;
	private List<SelectItem> estadoVentaItems;
	private List<SelectItem> tipoDocumentoItems;
	private List<SelectItem> productoItems;
	private List<SelectItem> ssisGeneralCfgItems;
	/***************** ARCHIVOS *******************/
	private int tipoCarga;
	private String rutaPredeterminada;
	private String nomArchivo;
	private String RutanombreDestino;
	// TODO BSC 12/09/2019 Con RichFaces 4.x no se puede obtener el objeto java.io.File durante la carga.
	private UploadedFile archivo;
	private List<CampoLayoutCpeBean> listCamposLayoutCpe;
	/***************** PIMS y UPLOAD *******************/
	/* Filtros */
	private int tipoBusqueda;
	private String socio;
	private Date fecCargaDesde;
	private Date fecCargaHasta;
	private String moneda;
	private String tipComprobante;
	private String estado;
	private String numComprobante;
	private String certificado;
	private String codUpload;
	private String lote;
	private String tipoDoc;
	private String numDoc;
	private String cliente;
	private String producto;
	private boolean disableMoneda;
	private boolean disableProducto;
	private boolean disableEstado;
	private boolean disableNumComp;
	private boolean disableCertificado;
	private boolean disableCodUpload;
	private boolean disableLote;
	private boolean disableTipoDoc;
	private boolean disableNumDoc;
	private boolean disableCliente;
	private boolean disableTipoComp;
	/* Pims */
	private Boolean selectAllPims;
	private List<VentaPimsCpeBean> listaVentasPims;
	private List<VentaPimsCpeBean> listaVentasProcesarPims;
	private VentaPimsCpeBean ventaSeleccionada;
	private int numRegBusqueda;
	private int numRegProcesar;
	/* Upload */
	private Boolean selectAllUploadAgrupado;
	private Boolean selectAllUploadDetallado;
	private List<VentaUploadCpeBean> listaVentasUpload;//Detallado
	private List<VentaUploadAgrupadoCpeBean> listaVentasAgrupadoUpload;//Agrupado
	private List<VentaUploadCpeBean> listaVentasProcesarUpload;
	private VentaUploadCpeBean ventaSeleccionadaUpload;
	private VentaUploadAgrupadoCpeBean ventaSeleccionadaAgrupadaUpload;
	private int numRegBusquedaUpload;
	private int numRegProcesarUpload;
	private int numSelecDupliDetUpload;
	private int numRegDupliProcesarUpload;
	/*************************************************************************************/

	// Otras variables
	String usuarioDb;
	private String mensajeValidacionArchivo;
	private boolean disabledCargar;
	private String idFileUploadComponent;
	private List<VentaCpeBean> listVentaCpe;
	private int nroRegistros;
	private boolean actionOnline;
	private SimpleDateFormat formatoddMMaaaa;
	
	//Ubigeo
	List<UbigeoCpeBean> listDepartamento;
	List<UbigeoCpeBean> listProvincia;
	List<UbigeoCpeBean> listDistrito;
	

	// Variables de servicios
	@Autowired
	private ParametroCpeService parametroCpeService;
	@Autowired
	private ParametroSUNATCpeService parametroSUNATCpeService;
	@Autowired
	private SocioCpeService socioCpeService;
	@Autowired
	private ProductoCpeService productoCpeService;
	@Autowired
	private CargaVentaCabCpeService cargaVentaCabCpeService;
	@Autowired
	private CampoLayoutCpeService campoLayoutCpeService;
	@Autowired
	private VentaPimsCpeService ventaPimsCpeService;
	@Autowired
	private UbigeoCpeService ubigeoCpeService;
	@Autowired
	private ProcesoCpeService procesoCpeService;
	@Autowired
	private VentaUploadCpeService ventaUploadCpeService;
	@Autowired
	private RepParametroService repParametroService;
	@Autowired
	private ConfiguracionCpeService configuracionCpeService;
	@Autowired
	private RegistroVentasSuscripcionService registroVentasSuscripcionService;
	@Autowired
	private SsisService ssisService;
	@Autowired
	private DataSourceSatelite dataSourceSatelite;

	/** FACTURACION - METODOS - INICIO **/
	@Override
	@PostConstruct
	public String inicio() {
		try {
			if (tieneAcceso()) {

				usuarioDb = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
				bloqueaArchivos = false;
				bloqueaArchivosGrilla = false;
				bloqueoProcesarArchivo = false;
				bloqueaPims = false;
				bloqueaUpload = false;
				bloqueaBusqueda = false;
				disabledCargar = true;
				idFileUploadComponent = "";
				
				habilitarFiltrosPimsUpload();

				inicializarVariables();
				
				inicializarUbigeo();
				formatoddMMaaaa = new SimpleDateFormat("dd/MM/yyyy");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	
	private void inicializarUbigeo(){
		UbigeoCpeBean ubigeo = new UbigeoCpeBean();
		ubigeo.setIdDepartamento("00");
		ubigeo.setIdProvincia("00");
		listDepartamento = ubigeoCpeService.listarDepartamento();
		listProvincia = ubigeoCpeService.listarProvincia(ubigeo);
		listDistrito = ubigeoCpeService.listarDistrito(ubigeo);
	}
	
	private void habilitarFiltrosPimsUpload(){
		disableMoneda = false;
		disableProducto = false;
		disableEstado = false;
		disableNumComp = false;
		disableCodUpload = false;
		disableLote = false;
		disableTipoDoc = false;
		disableCliente = false;
		disableTipoComp = false;
		disableCertificado = false;
		disableNumDoc = false;
		numRegBusqueda = 0;
		numRegProcesar = 0;
		numRegBusquedaUpload = 0;
		numSelecDupliDetUpload = 0;
		numRegProcesarUpload = 0;
		numRegDupliProcesarUpload = 0;
		selectAllPims = false;
		selectAllUploadAgrupado = false;
		selectAllUploadDetallado = false;
	}

	private void inicializarVariables() {
		origenesItems = new ArrayList<SelectItem>();
		socioItems = new ArrayList<SelectItem>();
		monedaItems = new ArrayList<SelectItem>();
		tipoComprobanteItems = new ArrayList<SelectItem>();
		estadoVentaItems = new ArrayList<SelectItem>();
		tipoDocumentoItems = new ArrayList<SelectItem>();
		productoItems = new ArrayList<SelectItem>();
		ssisGeneralCfgItems = obtieneParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, false);
		origenesItems = obtieneParametro(Constantes.COD_PARAM_CPE_ORIGEN_DATOS, true);
		listaCamposLayout();
		nomArchivo = "";
		RutanombreDestino = "";
		archivo = null;
		mensajeValidacionArchivo = "";
		listVentaCpe = new ArrayList<VentaCpeBean>();
		listaVentasPims = new ArrayList<VentaPimsCpeBean>(); 
		nroRegistros = 0;
		actionOnline = false;
		tipoBusqueda = 1;
		tipoCarga = 1;
	}

	public String muestraMensaje() {
		try {
			throw new SyncconException(ErrorConstants.COD_ERROR_CARGA_DEBE_SELECCIONAR_ORIGEN,
					FacesMessage.SEVERITY_INFO);
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	
	private Date sumarDia(Date fecha){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fecha);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		return calendar.getTime();
	}

	/** BUSQUEDA **/
	public String buscar() {
		try {
			listaVentasPims = new ArrayList<VentaPimsCpeBean>();
			listaVentasUpload = new ArrayList<VentaUploadCpeBean>();
			listaVentasAgrupadoUpload = new ArrayList<VentaUploadAgrupadoCpeBean>();
			if (fecCargaDesde == null) {
				throw new SyncconException(ErrorConstants.COD_ERROR_FECHA_DESDE, FacesMessage.SEVERITY_INFO);
			}
			if(fecCargaHasta == null){
				throw new SyncconException(ErrorConstants.COD_ERROR_FECHA_HASTA, FacesMessage.SEVERITY_INFO);
			}
			if (!validarFechaTrx()) {
				throw new SyncconException(ErrorConstants.COD_ERROR_RANGO_FECHAS, FacesMessage.SEVERITY_INFO);
			}
			if(origen.equals(Constantes.COD_ORIGEN_PIMS)){
				VentaPimsCpeBean ventaPimsCpeBean = new VentaPimsCpeBean();
				List<VentaPimsCpeBean> listaFiltrar = new ArrayList<VentaPimsCpeBean>();
				ProductoCpeBean productoCpeBean = new ProductoCpeBean();
				List<ProductoCpeBean> listaProductoBean = new ArrayList<ProductoCpeBean>();
				
				ventaPimsCpeBean.setFecCargaDesde(fecCargaDesde);
				ventaPimsCpeBean.setFecCargaHasta(sumarDia(fecCargaHasta));
				ventaPimsCpeBean.setIdProducto(producto.trim().equals(Constantes.TEXTO_DEFAULT) ? null : producto.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.valueOf(producto));
				ventaPimsCpeBean.setNumCertificado(certificado.trim().equals(Constantes.TEXTO_DEFAULT) ? null : certificado);
				ventaPimsCpeBean.setNumDocCli(numDoc.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numDoc);
				//ventaPimsCpeBean.setTipoMonedaPims(moneda.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : moneda.trim().equals("105") ? "PEN" : moneda.trim().equals("125") ? "USD");
				
				if(!socio.trim().equals(Constantes.VALOR_DEFECTO_CBX)){
					if(producto.trim().equals(Constantes.VALOR_DEFECTO_CBX)){
						productoCpeBean.setIdSocio(Integer.parseInt(socio));
						listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
					}else{
						productoCpeBean.setIdProducto(Integer.parseInt(producto));
						listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
					}
				}else{
					listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
				}

				for(ProductoCpeBean bean : listaProductoBean){
					ventaPimsCpeBean.setLlavePims(bean.getKeyColumsPims());
					ventaPimsCpeBean.setIdProductoPims(bean.getIdProductoPims());
					if(bean.getTipoProducto().trim().equals(Constantes.COD_TIPO_PRODUCTO_COLECTIVO)){						
						List<VentaPimsCpeBean> listaVentasColectivoPims = ventaPimsCpeService.listarVentasColectivoPims(ventaPimsCpeBean);
						for(VentaPimsCpeBean tmp : listaVentasColectivoPims){
							tmp.setPrefijoAlta(bean.getPrefijoAlta());
							tmp.setIdSocio(Long.valueOf(bean.getIdSocio()));
							tmp.setIdProducto(Long.valueOf(bean.getIdProducto()));
						}
						listaVentasPims.addAll(listaVentasColectivoPims);
					}else{
						List<VentaPimsCpeBean> listaVentasIndividualPims = ventaPimsCpeService.listarVentasIndividualPims(ventaPimsCpeBean);
						for(VentaPimsCpeBean tmp : listaVentasIndividualPims){
							tmp.setPrefijoAlta(bean.getPrefijoAlta());
							tmp.setIdSocio(Long.valueOf(bean.getIdSocio()));
							tmp.setIdProducto(Long.valueOf(bean.getIdProducto()));
						}
						listaVentasPims.addAll(listaVentasIndividualPims);
					}
				}
				
				VentaCpeBean ventaPims;
				List<VentaCpeBean> listaVentaPims;

				for(VentaPimsCpeBean bean : listaVentasPims){
					bean.setSeleccionado(false);
					bean.setNomTipoDocCli(setNomTipoDocCli(bean.getIdTipoDocCli(), bean.getNumDocCli()));
					for(VentaPimsCpeBean beanProcesar : listaVentasProcesarPims){
						if(bean.getLlavePims().trim().equals(beanProcesar.getLlavePims().trim())){
							listaFiltrar.add(bean);
						}
					}
					listaVentaPims = new ArrayList<VentaCpeBean>();
					ventaPims = new VentaCpeBean();
					ventaPims.setLlavePims(bean.getLlavePims());
					listaVentaPims = procesoCpeService.buscarVentaPimsUploadCpe(ventaPims);
					
					bean.setExiste(listaVentaPims.isEmpty() ? false : true);
				}
				for(VentaPimsCpeBean bean : listaFiltrar){
					listaVentasPims.remove(bean);
				}
				
				
				numRegBusqueda = listaVentasPims.size();
				selectAllPims = false;
			}else if(origen.equals(Constantes.COD_ORIGEN_UPLOAD)){
				ProductoCpeBean productoCpeBean = new ProductoCpeBean();
				List<ProductoCpeBean> listaProductoBean = new ArrayList<ProductoCpeBean>();
				
				if(!socio.trim().equals(Constantes.VALOR_DEFECTO_CBX)){
					if(producto.trim().equals(Constantes.VALOR_DEFECTO_CBX)){
						productoCpeBean.setIdSocio(Integer.parseInt(socio));
						listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
					}else{
						productoCpeBean.setIdProducto(Integer.parseInt(producto));
						listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
					}
				}else{
					listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
				}
				
				if(tipoBusqueda == 1){//Agrupado
					for(ProductoCpeBean bean : listaProductoBean){
						VentaUploadAgrupadoCpeBean ventaUploadAgrupadoCpeBean = new VentaUploadAgrupadoCpeBean();
						ventaUploadAgrupadoCpeBean.setFecCargaDesde(fecCargaDesde);
						ventaUploadAgrupadoCpeBean.setFecCargaHasta(sumarDia(fecCargaHasta));
						//ventaUploadAgrupadoCpeBean.setPrefijoAlta(bean.getPrefijoRecaudo());
						
						if(bean.getPrefijoRecaudo() == null){
							ventaUploadAgrupadoCpeBean.setListPrefijo(null);
						}else{
							String[] prefijoArray = bean.getPrefijoRecaudo().split("\\|");
							
							List<String> listPrefijo = new ArrayList<String>();
							for(String str : prefijoArray){
								listPrefijo.add(str);
							}
							
							ventaUploadAgrupadoCpeBean.setListPrefijo(listPrefijo);
						}
						
						/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 11:48 - Se agrega lógica para generar filtro de lista de tipo de movimientos*/
						List<String> listMovimientos = new ArrayList<String>();
						if(bean.getTipoMovimiento() == null){
							ventaUploadAgrupadoCpeBean.setListTipoMovimiento(null);
						}else{
							String[] MovimientosArray = bean.getTipoMovimiento().split(",");
							
							for(String str : MovimientosArray){
								listMovimientos.add(str);
							}
							
							ventaUploadAgrupadoCpeBean.setListTipoMovimiento(listMovimientos);
						}
						/*TIP_PER0100_CC09_13 FIN*/
						
						ventaUploadAgrupadoCpeBean.setProceso(codUpload == null ? null : codUpload.trim().equals("") ? null : Integer.parseInt(codUpload));
						List<VentaUploadAgrupadoCpeBean>  listaVentasAgrupadoUploadTmp = ventaUploadCpeService.listarVentasAgrupadoUpload(ventaUploadAgrupadoCpeBean);
						for(VentaUploadAgrupadoCpeBean tmp : listaVentasAgrupadoUploadTmp){
							tmp.setIdSocio(Long.valueOf(bean.getIdSocio()));
							tmp.setNomSocio(bean.getNomSocio());
							tmp.setIdProducto(Long.valueOf(bean.getIdProducto()));
							tmp.setIdProductoPims(bean.getIdProductoPims());
							tmp.setNomProducto(bean.getNomProducto());
							/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 12:54 - Se agrega lista de tipo de movimientos para cada venta agrupada*/
							tmp.setListTipoMovimiento(listMovimientos);
							/*TIP_PER0100_CC09_13 FIN*/
						}
						listaVentasAgrupadoUpload.addAll(listaVentasAgrupadoUploadTmp);
					}
					for(VentaUploadAgrupadoCpeBean bean : listaVentasAgrupadoUpload){
						bean.setSeleccionado(false);
					}
					numRegBusquedaUpload = listaVentasAgrupadoUpload.size();
				}else{//Detallado
					for(ProductoCpeBean bean : listaProductoBean){
						VentaUploadCpeBean ventaUploadCpeBean = new VentaUploadCpeBean();
						ventaUploadCpeBean.setFecCargaDesde(fecCargaDesde);
						ventaUploadCpeBean.setFecCargaHasta(sumarDia(fecCargaHasta));
						ventaUploadCpeBean.setPrefijoAlta(bean.getPrefijoRecaudo());
						ventaUploadCpeBean.setNumCertificado(certificado.trim().equals(Constantes.TEXTO_DEFAULT) ? null : certificado);
						ventaUploadCpeBean.setTipoMoneda(moneda.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : moneda);
						ventaUploadCpeBean.setNumDocCli(numDoc.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numDoc);
						ventaUploadCpeBean.setLlaveUpload(bean.getKeyColumsUpload());
						//List<VentaUploadCpeBean> listaVentasUploadTmp = ventaUploadCpeService.listarVentasDetalladoUpload(ventaUploadCpeBean);
						List<VentaUploadCpeBean> listaVentasUploadTmp = listarVentasDetalladoUpload(ventaUploadCpeBean);
						for(VentaUploadCpeBean tmp : listaVentasUploadTmp){
							tmp.setIdSocio(Long.valueOf(bean.getIdSocio()));
							tmp.setNomSocio(bean.getNomSocio());
							tmp.setIdProducto(Long.valueOf(bean.getIdProducto()));
							tmp.setIdProductoPims(bean.getIdProductoPims());
							tmp.setNomProducto(bean.getNomProducto());;
						}
						listaVentasUpload.addAll(listaVentasUploadTmp);
					}
					
//					VentaCpeBean ventaUpload;
//					List<VentaCpeBean> listaVentaUpload;
//					
//					for(VentaUploadCpeBean bean : listaVentasUpload){
//						bean.setSeleccionado(false);
//						bean.setNomTipoDocCli(setNomTipoDocCli(bean.getIdTipoDocCli(), bean.getNumDocCli()));
//						
//						listaVentaUpload = new ArrayList<VentaCpeBean>();
//						ventaUpload = new VentaCpeBean();
//						ventaUpload.setLlaveUpload(bean.getLlaveUpload());
//						listaVentaUpload = procesoCpeService.buscarVentaPimsUploadCpe(ventaUpload);
//						
//						bean.setExiste(listaVentaUpload.isEmpty() ? false : true);
//					}
					numRegBusquedaUpload = listaVentasUpload.size();
				}
				selectAllUploadAgrupado = false;
				selectAllUploadDetallado = false;
			}
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	
	public List<VentaUploadCpeBean> listarVentasDetalladoUpload(VentaUploadCpeBean ventaUploadCpeBean){
		
//		Properties prop = new Properties();
//		InputStream is = null;
//		try {
//			FacesContext fc = FacesContext.getCurrentInstance();
//			ServletContext sc = (ServletContext) fc.getExternalContext().getContext();
//			String rutaProp = sc.getRealPath(File.separator + "WEB-INF\\classes\\com\\cardif\\satelite\\recursos\\cardif.properties");
//			
//			is = new FileInputStream(rutaProp);
//			prop.load(is);
//		} catch(Exception e) {
//			System.out.println(e.toString());
//		}
		
//		String url = prop.getProperty("satelite.cpe.upload.url");
//		String user = prop.getProperty("satelite.cpe.upload.user");
//		String password = prop.getProperty("satelite.cpe.upload.password");
		
		List<VentaUploadCpeBean> listaVentas = new ArrayList<VentaUploadCpeBean>();
		VentaUploadCpeBean ventaUpload;
		
		try{ 
//			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
//	
//			final Connection c = DriverManager.getConnection(url, user, password);
			final Connection c = dataSourceSatelite.getDataSourceUpload().getConnection();
	        String plsql = "" +
	                "declare " +
					"    l_rc sys_refcursor; " +
					"begin " +
					"    open l_rc for " +
					"    SELECT " +
					ventaUploadCpeBean.getLlaveUpload() + " AS LLAVE_UPLOAD, " +
					"        '' AS LLAVE_PIMS, " +
					"        '' AS ID_SOCIO, " +
					"        '' AS NOM_SOCIO, " + 
					"        '' AS ID_PRODUCTO, " +
					"        '' AS NOM_PRODUCTO, " +
					"        '' AS FEC_EMISION, " +
					"        CASE WHEN LENGTH(TRIM(UPL.UPLD_AUX_FLD_03)) = 11 AND (SUBSTR(TRIM(UPL.UPLD_AUX_FLD_03),1,2) = '20' OR SUBSTR(TRIM(UPL.UPLD_AUX_FLD_03),1,2) = '10') THEN '01' ELSE '03' END AS ID_TIPO_COMP, " +
					"        '' AS CONCEP_ND, " +
					"        UPL.UPLD_AUX_FLD_17 AS TIPO_MONEDA, " +
					"        UPL.UPLD_EXP_DT AS FEC_VENC, " +    
					"        CASE UPL.UPLD_AUX_FLD_04 WHEN '1' THEN '01' WHEN '2' THEN '04' WHEN '4' THEN '06' WHEN '3' THEN '07' ELSE '00' END AS ID_TIPODOC_CLI, " +
					"        UPL.UPLD_AUX_FLD_03 AS NUMDOC_CLI, " +
					"        TRIM(UPL.UPLD_NME || ' ' || NVL(UPL.UPLD_AUX_FLD_01,'') || ' ' || NVL(UPL.UPLD_AUX_FLD_02,'')) AS NOMCLI_RAZSOC, " +
					"        REPLACE(REPLACE(REPLACE(UPL.UPLD_ADR,'}}}',''),'}}',''),'}','') AS DIR_CLI, " +
					"        UPL.UPLD_CTY AS DEPARTAMENTO, " +
					"        UPL.UPLD_NBH AS PROVINCIA, " +
					"        UPL.UPLD_AUX_FLD_08 AS DISTRITO, " +    
					"        UPL.UPLD_PHO_CMM_NBR AS TELF_CLI, " +
					"        UPL.UPLD_AUX_FLD_05 AS MAIL_CLI, " +
					"        UPL.UPLD_CTR_PTN_NBR AS NUM_POLIZA, " +
					"        UPL.UPLD_EFF_DT AS FEC_VENTA, " +
					"        '' AS BASE_IMPONIBLE, " +
					"        '' AS IMP_EXONERADO, " +
					"        '' AS IMP_INAFECTO, " +
					"        '' AS IGV, " +
					"        UPL.UPLD_PRM_VL AS IMP_TOTAL, " +
					"        '' AS OPEN_ITEM, " +
					"        '' AS OPEN_ITEM_REF, " +
					"        '' AS COLECT_INDIV, " +
					"        FLE.FILEPRC_RCV_DT AS FECHA_CARGA, " +
					"		 TO_CHAR(FLE.FILEPRC_RCV_DT,'DD/MM/YYYY hh24:mi:ss') AS FECHA_CARGA_STR, " +
					"		 UPL.FILEPRC_ID AS ID_TRAMA_UPLOAD, " +
					"		 FILEPRC_PRT_FLE_NME AS NOMBRE_TRAMA_UPLOAD " +
					"    FROM " +
					"        UPLOAD.LIFE_UPL UPL  " +
					"        INNER JOIN UPLOAD.LIFE_FLE_PRC FLE ON FLE.FILEPRC_ID = UPL.FILEPRC_ID " +
					"        INNER JOIN UPLOAD.LIFE_FLE_RUL RUL ON RUL.FILETYPE_ID = FLE.FILETYPE_ID AND RUL.PERSON_ID = FLE.PERSON_ID AND RUL.FILERULE_STCP_COD = SUBSTR(FLE.FILEPRC_PRT_FLE_NME,1,LENGTH(RUL.FILERULE_STCP_COD)) " +
					"	 WHERE " +
					"        UPL.UPLD_PRM_VL > 0 ";
	        
	        if(ventaUploadCpeBean.getFecCargaDesde() != null && ventaUploadCpeBean.getFecCargaHasta() != null){
	        	plsql = plsql.concat("AND FLE.FILEPRC_RCV_DT BETWEEN '" + formatoddMMaaaa.format(ventaUploadCpeBean.getFecCargaDesde()) + "' AND '" + formatoddMMaaaa.format(ventaUploadCpeBean.getFecCargaHasta()) + "' ");
	        }
	        if(ventaUploadCpeBean.getProceso() != null){
	        	plsql = plsql.concat("AND UPL.FILEPRC_ID = " + ventaUploadCpeBean.getProceso() + " ");
	        }
	        if(ventaUploadCpeBean.getPrefijoAlta() != null){
	        	
	        	String [] prefijoIN = ventaUploadCpeBean.getPrefijoAlta().split("\\|");
	        	StringBuilder prefijoStr = new StringBuilder();
	        	
	        	for( int i=0; i<prefijoIN.length; i++){
	        		prefijoStr.append("'" + prefijoIN[i] + "'");
	        		
	        		if(i!=prefijoIN.length - 1){
	        			prefijoStr.append(",");
	        		}
	        	}
	        	
	        	plsql = plsql.concat("AND RUL.FILERULE_STCP_COD IN (" + prefijoStr + ")");
	        }
	        if(ventaUploadCpeBean.getNumCertificado() != null){
	        	plsql = plsql.concat("AND UPL.UPLD_CTR_PTN_NBR = '" + ventaUploadCpeBean.getNumCertificado() + "' ");
	        }
	        if(ventaUploadCpeBean.getTipoMoneda() != null){
	        	plsql = plsql.concat("AND UPL.UPLD_AUX_FLD_17 = '" + ventaUploadCpeBean.getTipoMoneda() + "' ");
	        }
	        if(ventaUploadCpeBean.getNumDocCli() != null){
	        	plsql = plsql.concat("AND UPL.UPLD_AUX_FLD_03 = '" + ventaUploadCpeBean.getNumDocCli() + "' ");
	        }
	        
	        /*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 12:50 - Se recorre la lista de tipo de movimientos*/
	        if(ventaUploadCpeBean.getListTipoMovimiento() != null){
	        	if(!ventaUploadCpeBean.getListTipoMovimiento().isEmpty()){
		        	StringBuilder movimientoStr = new StringBuilder();
		        	
		        	for( int i=0; i<ventaUploadCpeBean.getListTipoMovimiento().size(); i++){
		        		movimientoStr.append("'" + ventaUploadCpeBean.getListTipoMovimiento().get(i) + "'");
		        		
		        		if(i!=ventaUploadCpeBean.getListTipoMovimiento().size() - 1){
		        			movimientoStr.append(",");
		        		}
		        	}
		        	
		        	plsql = plsql.concat("AND UPL.UPLD_OPR_COD IN (" + movimientoStr + ") ");
	        	}
	        }
	        /*TIP_PER0100_CC09_13 FIN*/
	        
	        if(codUpload != null && !codUpload.trim().equals("")){
	        	plsql = plsql.concat("AND FLE.FILEPRC_ID = '" + codUpload + "' ");
	        }
	        plsql = plsql.concat("; ? := l_rc; end;");
	        
	        CallableStatement cs = c.prepareCall(plsql);
	        cs.registerOutParameter(1, OracleTypes.CURSOR);
	
	        cs.execute();
	
	        ResultSet cursorResultSet = (ResultSet) cs.getObject(1);
	        while (cursorResultSet.next ())
	        {
	        	ventaUpload = new VentaUploadCpeBean();
	        	ventaUpload.setLlaveUpload(cursorResultSet.getString("LLAVE_UPLOAD"));
	        	ventaUpload.setLlavePims(cursorResultSet.getString("LLAVE_PIMS"));
	        	ventaUpload.setIdSocio(cursorResultSet.getString("ID_SOCIO") == null ? null : cursorResultSet.getString("ID_SOCIO").trim().equals(Constantes.TEXTO_DEFAULT) ? null : Long.valueOf(cursorResultSet.getString("ID_SOCIO")));
	        	ventaUpload.setNomSocio(cursorResultSet.getString("NOM_SOCIO"));
	        	ventaUpload.setIdProducto(cursorResultSet.getString("ID_PRODUCTO") == null ? null : cursorResultSet.getString("ID_PRODUCTO").trim().equals(Constantes.TEXTO_DEFAULT) ? null : Long.valueOf(cursorResultSet.getString("ID_PRODUCTO")));
	        	ventaUpload.setNomProducto(cursorResultSet.getString("NOM_PRODUCTO"));
	        	ventaUpload.setFecEmision(cursorResultSet.getString("FEC_EMISION") == null ? null : cursorResultSet.getString("FEC_EMISION").trim().equals(Constantes.TEXTO_DEFAULT) ? null : getStringToDate(cursorResultSet.getString("FEC_EMISION").trim()));
	        	ventaUpload.setIdTipoComp(cursorResultSet.getString("ID_TIPO_COMP"));
	        	ventaUpload.setConcepNd(cursorResultSet.getString("CONCEP_ND"));
	        	ventaUpload.setTipoMoneda(cursorResultSet.getString("TIPO_MONEDA"));
	        	//ventaUpload.setFecVenc(cursorResultSet.getString("FEC_VENC") == null ? null : cursorResultSet.getString("FEC_VENC").trim().equals(Constantes.TEXTO_DEFAULT) ? null : getStringToDate(cursorResultSet.getString("FEC_VENC").trim()));
	        	ventaUpload.setFecVenc(null);
	        	ventaUpload.setIdTipoDocCli(cursorResultSet.getString("ID_TIPODOC_CLI"));
	        	ventaUpload.setNumDocCli(cursorResultSet.getString("NUMDOC_CLI"));
	        	ventaUpload.setNomCliRazSoc(cursorResultSet.getString("NOMCLI_RAZSOC"));
	        	ventaUpload.setDirCli(cursorResultSet.getString("DIR_CLI"));
	        	ventaUpload.setDepartamento(cursorResultSet.getString("DEPARTAMENTO"));
	        	ventaUpload.setProvincia(cursorResultSet.getString("PROVINCIA"));
	        	ventaUpload.setDistrito(cursorResultSet.getString("DISTRITO"));
	        	ventaUpload.setTelfCli(cursorResultSet.getString("TELF_CLI"));
	        	ventaUpload.setMailCli(cursorResultSet.getString("MAIL_CLI"));
	        	ventaUpload.setNumPoliza(cursorResultSet.getString("NUM_POLIZA"));
	        	ventaUpload.setFecVenta(cursorResultSet.getString("FEC_VENTA") == null ? null : cursorResultSet.getString("FEC_VENTA").trim().equals(Constantes.TEXTO_DEFAULT) ? null : getStringToDate(cursorResultSet.getString("FEC_VENTA").trim()));
	        	ventaUpload.setBaseImponible(cursorResultSet.getString("BASE_IMPONIBLE") == null ? null : cursorResultSet.getString("BASE_IMPONIBLE").trim().equals(Constantes.TEXTO_DEFAULT) ? null : new BigDecimal(cursorResultSet.getString("ID_PRODUCTO").replace(",", ".")));
	        	ventaUpload.setImpExonerado(cursorResultSet.getString("IMP_EXONERADO") == null ? null : cursorResultSet.getString("IMP_EXONERADO").trim().equals(Constantes.TEXTO_DEFAULT) ? null : new BigDecimal(cursorResultSet.getString("IMP_EXONERADO").replace(",", ".")));
	        	ventaUpload.setImpInafecto(cursorResultSet.getString("IMP_INAFECTO") == null ? null : cursorResultSet.getString("IMP_INAFECTO").trim().equals(Constantes.TEXTO_DEFAULT) ? null : new BigDecimal(cursorResultSet.getString("IMP_INAFECTO").replace(",", ".")));
	        	ventaUpload.setIgv(cursorResultSet.getString("IGV") == null ? null : cursorResultSet.getString("IGV").trim().equals(Constantes.TEXTO_DEFAULT) ? null : new BigDecimal(cursorResultSet.getString("IGV").replace(",", ".")));
	        	ventaUpload.setImpTotal(cursorResultSet.getString("IMP_TOTAL") == null ? null : cursorResultSet.getString("IMP_TOTAL").trim().equals(Constantes.TEXTO_DEFAULT) ? null : new BigDecimal(cursorResultSet.getString("IMP_TOTAL").replace(",", ".")));
	        	ventaUpload.setOpenItem(cursorResultSet.getString("OPEN_ITEM") == null ? null : cursorResultSet.getString("OPEN_ITEM").trim().equals(Constantes.TEXTO_DEFAULT) ? null : Long.valueOf(cursorResultSet.getString("OPEN_ITEM")));
	        	ventaUpload.setOpenItemRef(cursorResultSet.getString("OPEN_ITEM_REF"));
	        	ventaUpload.setColectIndiv(cursorResultSet.getString("COLECT_INDIV") == null ? null : cursorResultSet.getString("COLECT_INDIV").trim().equals(Constantes.TEXTO_DEFAULT) ? null : Long.valueOf(cursorResultSet.getString("COLECT_INDIV")));
	        	ventaUpload.setFecCarga(cursorResultSet.getString("FECHA_CARGA") == null ? null : cursorResultSet.getString("FECHA_CARGA").trim().equals(Constantes.TEXTO_DEFAULT) ? null : getStringToDate(cursorResultSet.getString("FECHA_CARGA").trim()));
	        	ventaUpload.setFechaCargaStr(cursorResultSet.getString("FECHA_CARGA_STR") == null ? null : cursorResultSet.getString("FECHA_CARGA_STR").trim().equals(Constantes.TEXTO_DEFAULT) ? null : cursorResultSet.getString("FECHA_CARGA_STR").trim());
	        	ventaUpload.setIdTramaUpload(cursorResultSet.getString("ID_TRAMA_UPLOAD") == null ? null : cursorResultSet.getString("ID_TRAMA_UPLOAD").trim().equals(Constantes.TEXTO_DEFAULT) ? null : Long.valueOf(cursorResultSet.getString("ID_TRAMA_UPLOAD").trim()));
	        	ventaUpload.setNombreTramaUpload(cursorResultSet.getString("NOMBRE_TRAMA_UPLOAD") == null ? null : cursorResultSet.getString("NOMBRE_TRAMA_UPLOAD").trim().equals(Constantes.TEXTO_DEFAULT) ? null : cursorResultSet.getString("NOMBRE_TRAMA_UPLOAD").trim());
	        	
	        	
	        	listaVentas.add(ventaUpload);
	        	
//	        	String name=cursorResultSet.getString("LLAVE_UPLOAD");
//	        	System.out.print(name);
	        } 
	        cs.close();
	        c.close();
	        
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
        
		return listaVentas;
	}
	
	private Date getStringToDate(String dateStr){
		Date date = null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	        date = formatter.parse(dateStr);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		}
        return date;
	}
	
	private String setNomTipoDocCli(String tipoDocCli, String numDocCli){
		
		String nomDocCli = "";
		
		if(tipoDocCli == null || tipoDocCli.trim().equals(Constantes.TEXTO_DEFAULT)){
			nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC;
		}if(tipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC)){
			if(numDocCli == null || numDocCli.trim().equals(Constantes.TEXTO_DEFAULT)){
				nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC;
			}else if(numDocCli.trim().length() == 8){
				nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_DNI;
			}else if(numDocCli.trim().length() == 11){
				nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_RUC;
			}else{
				nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC;
			}
		}else if (tipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DNI)) {
			nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_DNI;
		}else if (tipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_CARNET_EXTRANJERIA)){
			nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_CARNET_EXTRANJERIA;
		}else if (tipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC)){
			nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_RUC;
		}else if (tipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_PASAPORTE)){
			nomDocCli = Constantes.NOM_TIPO_DOC_CLIENTE_PASAPORTE;
		}
		
		return nomDocCli;
	}

	public boolean validarFechaTrx() {

		if (fecCargaDesde != null && fecCargaHasta == null) {
			if (fecCargaDesde == null && fecCargaHasta != null) {
				return false;
			}
			return false;
		}
		if (fecCargaDesde != null && fecCargaHasta != null) {
			return Utilitarios.validarFechasInicioFin(fecCargaDesde, fecCargaHasta);
		}
		return true;
	}

	public String aplicar() {
		String respuesta = null;

		try {

			switch (Integer.parseInt(origen)) {
			case 0:
				cargaPantallaArchivo();
				break;
			case 1:
				habilitarFiltrosPimsUpload();
				camposbloqueados(false, false, false, false, true, true);
				deshabilitarFiltrosUploadAgrupado();
				tipoBusqueda = 1;
				listarFiltrosUpload();
				disableProducto = true;
				disableEstado = true;
				disabledTipoBusqueda = true;
				selecRadioTipoBusqueda();
				break;
			case 2:
				habilitarFiltrosPimsUpload();
				camposbloqueados(false, false, false, true, false, true);
				deshabilitarFiltrosPims();
				tipoBusqueda = 2;
				listarFiltrosPims();
				disabledTipoBusqueda = true;
				break;
			default:
				camposbloqueados(false, false, false, false, false, false);
				muestraMensaje();
				break;
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	private void deshabilitarFiltrosPims(){
		disableProducto = true;
		disableEstado = true;
		disableNumComp = true;
		disableCodUpload = true;
		disableLote = true;
		disableTipoDoc = true;
		disableCliente = true;
		disableTipoComp = true;
	}
	
	private void deshabilitarFiltrosUploadAgrupado(){
		disableMoneda = true;
		disableProducto = true;
		disableEstado = true;
		disableNumComp = true;
		disableLote = true;
		disableTipoDoc = true;
		disableCliente = true;
		disableTipoComp = true;
		disableCertificado = true;
		disableNumDoc = true;
	}
	
	private void deshabilitarFiltrosUploadDetallado(){
		disableMoneda = false;
		disableProducto = true;
		disableEstado = true;
		disableNumComp = true;
		disableLote = true;
		disableTipoDoc = true;
		disableCliente = true;
		disableTipoComp = true;
		disableCertificado = false;
		disableNumDoc = false;
	}
	
	private String cargaPantallaArchivo() {
		camposbloqueados(true, true, true, false, false, false);
		tipoCarga = 1;
		selecRadioTipoProceso();
		return null;
	}

	private void cargaProcesoMasivo() {
		camposDeshabilitados(true, false, true, false, true);
		for (SelectItem var : ssisGeneralCfgItems) {
			if (var.getValue().equals(Constantes.COD_VALOR_SIS_GENERAL_RUTA_CARGA))
				rutaPredeterminada = var.getLabel();
		}
	}

	private void cargaProcesoOnline() {
		camposDeshabilitados(true, true, false, true, true);
		rutaPredeterminada = "";
		actionOnline = true;
	}

	private void listarFiltrosUpload() {
		listarSocio();
		monedaItems = obtieneParametro(Constantes.COD_PARAM_CPE_TIPO_MONEDA, true);
		tipoComprobanteItems = obtieneParametro(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES, true);
		estadoVentaItems = obtieneParametro(Constantes.COD_PARAM_CPE_ESTADO_VENTA, false);
		tipoDocumentoItems = obtieneParametro(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO, true);
		listaVentasUpload = new ArrayList<VentaUploadCpeBean>();
		listaVentasAgrupadoUpload = new ArrayList<VentaUploadAgrupadoCpeBean>();
		listaVentasProcesarUpload = new ArrayList<VentaUploadCpeBean>();
		ventaSeleccionadaUpload = new VentaUploadCpeBean();
		ventaSeleccionadaAgrupadaUpload = new VentaUploadAgrupadoCpeBean();
	}

	// public void actualizarValoresCtasBancariasBusq() {
	// productoItems = new ArrayList<SelectItem>();
	// productoItems = listarProducto();
	// }

	private List<SelectItem> listarProducto(String socio) {
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		List<ProductoCpeBean> listaProductoBean = new ArrayList<ProductoCpeBean>();
		productoCpeBean.setIdSocio(Integer.parseInt(socio));
		listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
		productoItems = new ArrayList<SelectItem>();
		productoItems.add(new SelectItem("-1", "- Seleccionar -"));

		for (Iterator<ProductoCpeBean> iterator = listaProductoBean.iterator(); iterator.hasNext();) {
			ProductoCpeBean producto = (ProductoCpeBean) iterator.next();
			productoItems.add(new SelectItem(producto.getIdProducto(), producto.getNomProducto()));
		}
		return productoItems;
	}

	private void listarSocio() {
		SocioCpeBean socioCpeBean = new SocioCpeBean();
		List<SocioCpeBean> listaSocioBean = new ArrayList<SocioCpeBean>();
		listaSocioBean = socioCpeService.listarSocio(socioCpeBean);
		socioItems = new ArrayList<SelectItem>();
		socioItems.add(new SelectItem("-1", "- Seleccionar -"));

		for (Iterator<SocioCpeBean> iterator = listaSocioBean.iterator(); iterator.hasNext();) {
			SocioCpeBean listaOrigenDatos = (SocioCpeBean) iterator.next();
			socioItems.add(new SelectItem(listaOrigenDatos.getIdSocio(), listaOrigenDatos.getNomSocio()));
		}
	}

	private String listaCamposLayout() {
		CampoLayoutCpeBean campoLayoutCpeBean = new CampoLayoutCpeBean();
		listCamposLayoutCpe = campoLayoutCpeService.listarLayoutDet(campoLayoutCpeBean);
		return null;
	}

	private List<SelectItem> obtieneParametro(String codParametro, boolean insertarSeleccionar) {
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listaParametroBean = new ArrayList<ParametroCpeBean>();
		listaParametroBean = parametroCpeService.listarParametro(parametroBean);
		List<SelectItem> combo = new ArrayList<SelectItem>();
		if (insertarSeleccionar) {
			combo.add(new SelectItem("-1", "- Seleccionar -"));
		}

		for (Iterator<ParametroCpeBean> iterator = listaParametroBean.iterator(); iterator.hasNext();) {
			ParametroCpeBean parametro = (ParametroCpeBean) iterator.next();
			combo.add(new SelectItem(parametro.getCodValor(), parametro.getNomValor()));
		}
		return combo;
	}

	public void camposbloqueados(boolean Archivos, boolean ArchivosGrilla, boolean ProcesarArchivo, boolean Pims,
			boolean Upload, boolean Busqueda) {
		bloqueaArchivos = Archivos;
		bloqueaArchivosGrilla = ArchivosGrilla;
		bloqueoProcesarArchivo = ProcesarArchivo;
		bloqueaPims = Pims;
		bloqueaUpload = Upload;
		bloqueaBusqueda = Busqueda;
	}

	public void camposDeshabilitados(boolean RutaPredeterminada, boolean NomArchivo, boolean PorRuta,
			boolean ArchivosGrilla, boolean ProcesarArchivo) {
		disabledRutaPredeterminada = RutaPredeterminada;
		disabledNomArchivo = NomArchivo;
		disabledPorRuta = PorRuta;
		bloqueaArchivosGrilla = ArchivosGrilla;
		bloqueoProcesarArchivo = ProcesarArchivo;
	}

	public String selecRadioTipoProceso() {
		String respuesta = null;
		actionOnline = false;
		try {
			switch (tipoCarga) {
				case 1:
					cargaProcesoOnline();
					break;
				case 2:
					cargaProcesoMasivo();
					break;
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}

	public String selecRadioTipoBusqueda() {
		String respuesta = null;
		try {
			limpiaBusqueda();
			switch (tipoBusqueda) {
			case 1:
				bloqueaUploadAgrupado = true;
				bloqueaUploadDetalle = false;
				if(origen.equals(Constantes.COD_ORIGEN_UPLOAD)){
					deshabilitarFiltrosUploadAgrupado();
				}
				break;
			case 2:
				bloqueaUploadAgrupado = false;
				bloqueaUploadDetalle = true;
				if(origen.equals(Constantes.COD_ORIGEN_UPLOAD)){
					deshabilitarFiltrosUploadDetallado();
				}
				break;
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}

	/****************************************** BACKGROUND *****************************************/
	/*
	 * TODO BSC 12/09/2019
	 * La clase org.richfaces.event.UploadEvent fue eliminada en RichFaces 4.x. En su lugar, se usa org.richfaces.event.FileUploadEvent
	 * La clase org.richfaces.model.UploadItem fue eliminada en RichFaces 4.x. En su lugar, se usa org.richfaces.model.UploadedFile
	 * 
	 * El procesamiento cambia totalmente, ya que desde UploadedFile no se puede obtener el objeto java.io.File y en su lugar se usa arreglod bytes
	 * 
	public String listener(UploadEvent event) {
		try {
			archivo = event.getUploadItem().getFile();
			// nombre del archivo
			nomArchivo = event.getUploadItem().getFileName()
					.substring(event.getUploadItem().getFileName().lastIndexOf("\\") + 1);
			// ruta destino con el nombre del archivo
			RutanombreDestino = rutaPredeterminada + nomArchivo;

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	*/

	public String listener(FileUploadEvent event) {
		try {
			archivo = event.getUploadedFile();
			// Se necesita esta línea para que el archivo no desaparesca cuando el método termine
			archivo.getInputStream();
			// nombre del archivo
			nomArchivo = archivo.getName().substring(archivo.getName().lastIndexOf("\\") + 1);
			// ruta destino con el nombre del archivo
			RutanombreDestino = rutaPredeterminada + nomArchivo;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}

	public String procesaCargaArchivoBackground() {
		try {
			if(actionOnline){
				procesarCargaArchivoOnline();
				return null;
			}
			camposObligatoriosBackGround();
			copiaArchivo(archivo, RutanombreDestino);
			CargaVentaCabCpeBean bean = new CargaVentaCabCpeBean();
			bean.setIdOrigen(origen);
			bean.setIdTipoCarga(Constantes.ID_TIPO_CARGA_BACKGROUND);
			bean.setNomArchivo(nomArchivo);
			bean.setNumRegistro(Long.valueOf(0));
			bean.setEstadoCarga(Constantes.COD_VALOR_EN_PROCESO);
			bean.setUsuarioCarga(usuarioDb);
			cargaVentaCabCpeService.insertarCargaVentaCab(bean);
			
			ParametroCpeBean prmPackage = new ParametroCpeBean();
			prmPackage.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
			prmPackage.setTipParam(Constantes.TIP_PARAM_DETALLE);
			List<ParametroCpeBean> listPrmPkg = parametroCpeService.listarParametro(prmPackage);
			
			String indGenera = "";
			
			for(ParametroCpeBean prm : listPrmPkg){
				if(prm.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_PACKAGE_CARGAVENTA_FLG)){
					indGenera = prm.getNomValor().trim();
				}
			}
			
			if(indGenera.equalsIgnoreCase(Constantes.FLG_SSIS_CARGAVENTA_ESCON_GENERAR)){
				try {
					LOGGER.info("Inicio Carga Venta PACKAGE");
					ssisService.lanzarJob(Constantes.CPE_JOB_NAME_PACKAGE_CARGAVENTA_BG);
					ParametroCpeBean prmSSIS = new ParametroCpeBean();
					prmSSIS.setNomValor(Constantes.FLG_SSIS_CARGAVENTA_ESCON_OCUPADO);
					prmSSIS.setUsuModifica(usuarioDb);
					prmSSIS.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
					prmSSIS.setTipParam(Constantes.TIP_PARAM_DETALLE);
					prmSSIS.setCodValor(Constantes.COD_VALOR_PACKAGE_CARGAVENTA_FLG);
					parametroCpeService.actualizarParametro(prmSSIS);
					LOGGER.info("Fin Carga Venta PACKAGE");
				} catch (Exception e) {
					e.printStackTrace();
					LOGGER.error(e.getMessage());
				}
			}

			limpiaVariablesBackGround();
			enviarMensaje(ErrorConstants.COD_ERROR_CARGA_REGISTRADO_SATISFACTORIAMENTO);

		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}

		return null;
	}
	
	private void procesarCargaArchivoOnline() throws SyncconException{
		
		if(listVentaCpe == null || listVentaCpe.isEmpty()){
			enviarMensaje(ErrorConstants.COD_ERROR_NO_REGISTROS_GRILLA);
			return;
		}
		
		boolean noExiste = false;
		boolean noAplicaIGV = false;
		boolean siAplicaIGV = false;
		
		LOGGER.error("Inicio validación de Configuración Productos");
		for(VentaCpeBean vnt : listVentaCpe){
			
//			ProductoCpeBean productoRequest = new ProductoCpeBean();
//			productoRequest.setIdProducto(Integer.parseInt(String.valueOf(vnt.getIdProducto())));
//			productoRequest.setIdSocio(Integer.parseInt(String.valueOf(vnt.getIdSocio())));
//			List<ProductoCpeBean> list = productoCpeService.listarProducto(productoRequest);

			ConfiguracionCpeBean configurarRequest = new ConfiguracionCpeBean();
			configurarRequest.setIdEmpresa(vnt.getIdEmpresa());
			configurarRequest.setIdSocio(Integer.parseInt(String.valueOf(vnt.getIdSocio())));
			configurarRequest.setIdProducto(Integer.parseInt(String.valueOf(vnt.getIdProducto())));
			configurarRequest.setEstadoConfig(Constantes.ACTIVO);
			configurarRequest.setIdTipoComp(vnt.getIdTipoComp());
			configurarRequest.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
			configurarRequest.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
			configurarRequest.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
			if (vnt.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA))
			{
				configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
			}
			else if (vnt.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA))
			{
				configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_BOLETA);
			}
			else if (vnt.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) 
					|| vnt.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO))
			{
				if (vnt.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC) )
					configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
				else if (vnt.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) )
					configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
				else
					configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_BOLETA);
			}
			else
			{
				if (vnt.getIdTipoDocCli().trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC))
					configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
				else
					configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_BOLETA);
			}
			
			List<ConfiguracionCpeBean> listConfiguracion = configuracionCpeService.listarConfiguracion(configurarRequest);
			
			if(listConfiguracion == null || listConfiguracion.isEmpty() || listConfiguracion.size() == 0){
				noExiste = true;
				break;
			}
			
			if(!listConfiguracion.get(0).getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO))
			{
				if (listConfiguracion.get(0).getAfectoIgv() == 0)
				{
					if ((vnt.getBaseImponible().compareTo(BigDecimal.ZERO) > 0) ||  (vnt.getIgv().compareTo(BigDecimal.ZERO) > 0))
					{
						noAplicaIGV = true;
						break;
					}
					if ((vnt.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0) && (vnt.getIgv().compareTo(BigDecimal.ZERO) > 0))
					{
						noAplicaIGV = true;
						break;
					}
				}
				else 
				{
					if ((vnt.getImpInafecto().compareTo(BigDecimal.ZERO) > 0)  || (vnt.getIgv().compareTo(BigDecimal.ZERO) == 0))
					{
						siAplicaIGV = true;
						break;
					}
					if ((vnt.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0) && (vnt.getIgv().compareTo(BigDecimal.ZERO) == 0))
					{
						noAplicaIGV = true;
						break;
					}
				}
			}
		}
		LOGGER.error("Fin validación de Configuración Productos");
		
		if(noExiste){
			enviarMensaje(ErrorConstants.COD_ERROR_VENTA_SIN_CONF_SOCIO_PRODUCTO);
			return;
		}
		
		if(noAplicaIGV){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_CONFIG_SIN_AFECTOIGV);
			return;
		}
		if(siAplicaIGV){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_CONFIG_CON_AFECTOIGV);
			return;
		}
		// Para validar codigo producto sunat
//		boolean flgCPS = false;
//		
//		for(VentaCpeBean vntCPS : listVentaCpe){
//			
//			ProductoCpeBean productoRequest = new ProductoCpeBean();
//			productoRequest.setIdProducto(Integer.parseInt(String.valueOf(vntCPS.getIdProducto())));
//			productoRequest.setIdSocio(Integer.parseInt(String.valueOf(vntCPS.getIdSocio())));
//			
//			List<ProductoCpeBean> list = productoCpeService.listarProducto(productoRequest);
//			
//			for(int i = 0; i<list.size();i++){
//				if(list.get(i).getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO) && (vntCPS.getCodProdSunat() == null || vntCPS.getCodProdSunat().equals(""))){
//					flgCPS = true;
//					break;
//				}
//			}
//		}
//		
//		if(flgCPS){
//			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_PRODUCTO_SUNAT);
//			return;
//		}
		
		ParametroSUNATCpeBean paramSunat = new ParametroSUNATCpeBean();
		paramSunat.setCodParam(Constantes.COD_PARAM_SUNAT_TIPO_AFECTACION);
		paramSunat.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroSUNATCpeBean> lstParamSunat = new ArrayList<ParametroSUNATCpeBean>();
		lstParamSunat = parametroSUNATCpeService.listarParametro(paramSunat);
		
		boolean flgNCND = false;
		boolean flgND_P = false;
		boolean flgCcptoNCND = false;
		boolean flgNCND_TD = false;
		boolean flgNoDom = false;
		boolean flgNoDomInafecto = false;
		boolean flgNoDomAfecto = false;
		boolean flgNDINF = false;
		boolean flgGttas = false;
		boolean flgGttasTtl = false;
		boolean flgTipoAfectacion = false;
		boolean flgTipoAfectExiste = false;
		boolean flgBoletaNoDom = false;
		/**TIP_PER0100_CC15 INICIO 2019/06/24 - 14:50 - Se agrega flag de validación de campos de referencia*/
		boolean flgCamposRefObl = false;
		boolean flgCampoCorMenorIgualCero = false;
		/**TIP_PER0100_CC15 FIN*/
		LOGGER.error("Inicio validación de Ventas");
		for(VentaCpeBean vntTemp : listVentaCpe){
			
			if(vntTemp.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) 
					|| vntTemp.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO))
			{				
				if (Integer.parseInt(vntTemp.getIdTipoCompRef()) == Integer.parseInt(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO)){
					
					//Validamos campos de referencia ya que no pueden ser nulos ni vacios en caso de notas de débito ni de crédito
					/**TIP_PER0100_CC15 INICIO 2019/06/24 - 14:30 - Se valida los campos de referencia*/
					if(vntTemp.getStrNumSerieRef() == null || vntTemp.getStrNumSerieRef().trim().equals("") 
						|| vntTemp.getStrNumCorRef() == null || vntTemp.getStrNumCorRef().trim().equals("") 
						|| vntTemp.getFechaEmisionRef()==null || vntTemp.getFechaEmisionRef().trim().equals("")){
						flgCamposRefObl = true;
						break;
					}else if(Integer.valueOf(vntTemp.getStrNumCorRef())<=0){
						flgCampoCorMenorIgualCero = true;
						break;
					}
					/**TIP_PER0100_CC15 FIN*/
				}else{
				
					if(Integer.parseInt(vntTemp.getIdTipoComp()+ ""+String.format("%02d",Integer.parseInt(vntTemp.getConcepNd()))) 
						== Integer.parseInt(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO+""+Constantes.CPE_ND_PENALIDAD) &&
						(vntTemp.getIdTipoCompRef() == null || vntTemp.getNumSerieRef() != null || vntTemp.getNumCorRef() != null))
					{
						flgND_P = true;
						break;
					}
					else if(Integer.parseInt(vntTemp.getIdTipoComp()+ ""+String.format("%02d",Integer.parseInt(vntTemp.getConcepNd()))) 
						!= Integer.parseInt(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO+""+Constantes.CPE_ND_PENALIDAD) &&
						(vntTemp.getIdTipoCompRef() == null || vntTemp.getNumSerieRef() == null || vntTemp.getNumCorRef() == null))
					{
						flgNCND = true;
						break;
					}
				}
				
				//Validación de nota debito tipo penalidad, solo para inafectos a IGV
				if(Integer.parseInt(vntTemp.getIdTipoComp()+ ""+String.format("%02d",Integer.parseInt(vntTemp.getConcepNd()))) 
						== Integer.parseInt(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO+""+Constantes.CPE_ND_PENALIDAD) &&
						(vntTemp.getBaseImponible().compareTo(BigDecimal.ZERO) > 0 || vntTemp.getIgv().compareTo(BigDecimal.ZERO) > 0))
					{
						flgNDINF = true;
						break;
					}
				
				// Validacion de tipo de notas
				if(vntTemp.getConcepNd() == null || vntTemp.getConcepNd().equals("")){
					flgCcptoNCND = true;
					break;
				}
				
				// Validacion de tipo de documento y referencia de notas
				
				/**TIP_PER0100_CC15 INICIO 2019/06/20 - 18:26 - Se agrega validación de tipo d comprobante de referencia 13*/
				if(Integer.parseInt(vntTemp.getIdTipoCompRef()) == Integer.parseInt(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO)){
					
					ConfiguracionCpeBean configurarRequest = new ConfiguracionCpeBean();
					configurarRequest.setIdEmpresa(vntTemp.getIdEmpresa());
					configurarRequest.setIdSocio(Integer.parseInt(String.valueOf(vntTemp.getIdSocio())));
					configurarRequest.setIdProducto(Integer.parseInt(String.valueOf(vntTemp.getIdProducto())));
					configurarRequest.setEstadoConfig(Constantes.ACTIVO);
					configurarRequest.setIdTipoComp(vntTemp.getIdTipoComp());
					configurarRequest.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
					configurarRequest.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
					configurarRequest.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
					configurarRequest.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
					
					List<ConfiguracionCpeBean> listConfiguracion = configuracionCpeService.listarConfiguracion(configurarRequest);
					
					if(listConfiguracion == null || listConfiguracion.isEmpty() || listConfiguracion.size() == 0){
						noExiste = true;
						break;
					}
				}else{
				/**TIP_PER0100_CC15 FIN*/
					if(Integer.parseInt(vntTemp.getIdTipoCompRef()) == Integer.parseInt(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)){
						if(Integer.parseInt(vntTemp.getIdTipoDocCli()) != Integer.parseInt(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC) && 
								Integer.parseInt(vntTemp.getIdTipoDocCli()) != Integer.parseInt(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC)){
							flgNCND_TD = true;
							break;
						}
					}else if(Integer.parseInt(vntTemp.getIdTipoCompRef()) == Integer.parseInt(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
						if(Integer.parseInt(vntTemp.getIdTipoDocCli()) == Integer.parseInt(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC)){
							flgNCND_TD = true;
							break;
						}else if (Integer.parseInt(vntTemp.getIdTipoDocCli()) == Integer.parseInt(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC)) {
							flgNCND_TD = true;
							break;
						}
					}
				}
				//****** Validar Comprobantes No Domiciliado //
				if (vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) && 
						(!vntTemp.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA))
						&& (!vntTemp.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO))) /**TIP_PER0100_CC15 Se agrega validación para tipo de documento 13*/
				{
					flgNoDom = true;
					break;
				}
				else if (vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) &&
						(vntTemp.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)
							|| vntTemp.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO)) && /**TIP_PER0100_CC15 Se agrega validación para tipo de documento 13*/
								vntTemp.getImpInafecto().compareTo(BigDecimal.ZERO) == 0)
				{
					flgNoDomInafecto = true;
					break;
				}
				else if (vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) &&
						((vntTemp.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)
							||vntTemp.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO)) && /**TIP_PER0100_CC15 Se agrega validación para tipo de documento 13*/
						(vntTemp.getImpInafecto().compareTo(BigDecimal.ZERO) > 0) && 
						(vntTemp.getBaseImponible().compareTo(BigDecimal.ZERO) > 0 || vntTemp.getIgv().compareTo(BigDecimal.ZERO) > 0)))
				{
					flgNoDomAfecto = true;
					break;
				}
				
				//****** Validar Comprobantes Gratuitas //
				BigDecimal sumatoria = BigDecimal.ZERO;
				BigDecimal total = BigDecimal.ZERO;
				if (!vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) && 
						(vntTemp.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0))
				{
					if ((vntTemp.getBaseImponible().compareTo(BigDecimal.ZERO) > 0 || vntTemp.getImpInafecto().compareTo(BigDecimal.ZERO) > 0))
					{
						flgGttas = true;
						break;
					}
					sumatoria = vntTemp.getValOpGratuitas().add(vntTemp.getIgv());
					total = vntTemp.getImpTotal();
					if (!sumatoria.equals(total))
					{
						flgGttasTtl = true;
						break;
					}
					if (vntTemp.getTipoAfectacion() == null || vntTemp.getTipoAfectacion().length() == 0)
					{
						flgTipoAfectacion = true;
						break;
					}
					else
					{
						boolean existe = false;
						for(ParametroSUNATCpeBean paramSunatBean : lstParamSunat)
						{
							if (vntTemp.getTipoAfectacion().equals(paramSunatBean.getCodValor1()))
							{
								existe = true;
								break;
							}
						}
						if (!existe)
						{
							flgTipoAfectExiste = true;
							break;
						}
						break;
					}
				}
			}
			
			if(vntTemp.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)) 
			{
				//****** Validar Comprobantes No Domiciliado //
				if (vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) &&
								(vntTemp.getImpInafecto().compareTo(BigDecimal.ZERO) == 0))
				{
					flgNoDomInafecto = true;
					break;
				}
				else if (vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) &&
						(vntTemp.getImpInafecto().compareTo(BigDecimal.ZERO) > 0) && 
						(vntTemp.getBaseImponible().compareTo(BigDecimal.ZERO) > 0 || vntTemp.getIgv().compareTo(BigDecimal.ZERO) > 0))
				{
					flgNoDomAfecto = true;
					break;
				}
				
				//****** Validar Comprobantes Gratuitas //
				BigDecimal sumatoria = BigDecimal.ZERO;
				BigDecimal total = BigDecimal.ZERO;
				if (!vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) && 
						(vntTemp.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0))
				{
					if ((vntTemp.getBaseImponible().compareTo(BigDecimal.ZERO) > 0 || vntTemp.getImpInafecto().compareTo(BigDecimal.ZERO) > 0))
					{
						flgGttas = true;
						break;
					}
					sumatoria = vntTemp.getValOpGratuitas().add(vntTemp.getIgv());
					total = vntTemp.getImpTotal();
					if (sumatoria.compareTo(total) > 0)
					{
						flgGttasTtl = true;
						break;
					}
					if (vntTemp.getTipoAfectacion() == null || vntTemp.getTipoAfectacion().length() == 0)
					{
						flgTipoAfectacion = true;
						break;
					}
					else
					{
						boolean existe = false;
						String Tipo = "";
						for(ParametroSUNATCpeBean paramSunatBean : lstParamSunat)
						{
							if (vntTemp.getTipoAfectacion().equals(paramSunatBean.getCodValor1()))
							{
								Tipo = paramSunatBean.getNomAbreviatura().toString();
								existe = true;
								break;
							}
						}
						if (!existe)
						{
							flgTipoAfectExiste = true;
							break;
						}
						else
						{
							if (vntTemp.getIgv().compareTo(BigDecimal.ZERO) > 0)
							{
								if((!Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_GRAV)) || (Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_EXON)))
								{
									flgTipoAfectExiste = true;
									break;
								}
							}
							else
							{
								if ((!Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_INAF)) || (Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_EXON)))
								{
									flgTipoAfectExiste = true;
									break;
								}
							}
						}
						break;
					}
				}
			}
			if(vntTemp.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)) 
			{
				//****** Validar Comprobantes No Domiciliado No Aplica //
				if (vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC))
				{
					flgBoletaNoDom = true;
					break;
				}
				
				//****** Validar Comprobantes Gratuitas //
				BigDecimal sumatoria = BigDecimal.ZERO;
				BigDecimal total = BigDecimal.ZERO;
				if (!vntTemp.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) && 
						(vntTemp.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0))
				{
					if ((vntTemp.getBaseImponible().compareTo(BigDecimal.ZERO) > 0 || vntTemp.getImpInafecto().compareTo(BigDecimal.ZERO) > 0))
					{
						flgGttas = true;
						break;
					}
					sumatoria = vntTemp.getValOpGratuitas().add(vntTemp.getIgv());
					total = vntTemp.getImpTotal();
					if (sumatoria.compareTo(total) > 0)
					{
						flgGttasTtl = true;
						break;
					}
					if (vntTemp.getTipoAfectacion() == null || vntTemp.getTipoAfectacion().length() == 0)
					{
						flgTipoAfectacion = true;
						break;
					}
					else
					{
						boolean existe = false;
						String Tipo = "";
						for(ParametroSUNATCpeBean paramSunatBean : lstParamSunat)
						{
							if (vntTemp.getTipoAfectacion().equals(paramSunatBean.getCodValor1()))
							{
								Tipo = paramSunatBean.getNomAbreviatura().toString();
								existe = true;
								break;
							}
						}
						if (!existe)
						{
							flgTipoAfectExiste = true;
							break;
						}
						else
						{
							if (vntTemp.getIgv().compareTo(BigDecimal.ZERO) > 0)
							{
								if((!Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_GRAV)) || (Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_EXON)))
								{
									flgTipoAfectExiste = true;
									break;
								}
							}
							else
							{
								if ((!Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_INAF)) || (Tipo.trim().equals(Constantes.COD_VALOR_DESCRIP_TIPO_AFECTACION_EXON)))
								{
									flgTipoAfectExiste = true;
									break;
								}
							}
						}
						//break;
					}
				}
				
			}
		}
		LOGGER.error("Fin validación de Ventas");
		
		/**TIP_PER0100_CC15 INICIO 2019/06/20 - 18:40 - Se retorna mensaje de validación de tipo de comprobante de referencia 13*/
														/**Se retorna mensaje de validación de campos de referencia*/
		if(noExiste){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_CONF_SOCIO_PRODUCTO_COD_REFERENC_13_PREFIJ_F);
			return;
		}

		if(flgCamposRefObl){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_CAMPOS_COMPROBANTES_REFERENCIA_OBLIGATORIOS);
			return;
		}
		
		if(flgCampoCorMenorIgualCero){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_CAMPO_CORRELATIVO_REF_NO_PUEDE_SER_MENOR_IGUAL_CERO);
			return;
		}
		/**TIP_PER0100_CC15 FIN*/
		
		if(flgNCND){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NCND_REFERENCIA);
			return;
		}
		
		if(flgND_P){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NCND_REFERENCIA_NULL);
			return;
		}
		
		if(flgCcptoNCND){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NCND_CONCEPTO);
			return;
		}
		
		if(flgNCND_TD){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_ND_TIPOCOMPROBANTE);
			return;
		}
		
		if(flgNDINF){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_ND_PENALIDAD_INAFECTO);
			return;
		}
		
		if (flgNoDom){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_DOM_COMPROBANTE);
			return;
		}
		
		if (flgNoDomInafecto){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_DOM_INAFECTO_IGV);
			return;
		}
		if (flgNoDomAfecto){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_DOM_AFECTO_IGV);
			return;
		}
			
		if (flgGttas){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_TRANSF_GRATUITAS);
			return;
		}
		if (flgGttasTtl){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_TRANSF_GRATUITAS_TOTAL);
			return;
		}
		if (flgTipoAfectacion){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_TRANSF_GRATUITAS_TIPO_AFECTACION);
			return;
		}		
		if (flgTipoAfectExiste){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_TRANSF_GRATUITAS_TIPO_AFECT_EXISTE);
			return;
		}
		if (flgBoletaNoDom){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_DOM_NO_APLICA_BOLETA);
			return;
		}
		
		CargaVentaCabCpeBean bean = new CargaVentaCabCpeBean();
		bean.setIdOrigen(origen);
		bean.setIdTipoCarga(Constantes.ID_TIPO_CARGA_ONLINE);
		bean.setNomArchivo(nomArchivo);
		bean.setNumRegistro(Long.parseLong(String.valueOf(nroRegistros)));
		bean.setEstadoCarga(Constantes.COD_VALOR_COMPLETADA);
		bean.setUsuarioCarga(usuarioDb);
		LOGGER.error("Inicio Registro de Ventas Cabecera");
		cargaVentaCabCpeService.insertarCargaVentaCab(bean);
		LOGGER.error("Fin Registro de Ventas Cabecera");
		
		//*** Parametros Detracción ***//
		LOGGER.error("Inicio Calculo de Detracción");
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(Constantes.COD_PARAM_DETRACCION_SERVICIOS);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listaParametroBean = new ArrayList<ParametroCpeBean>();
		listaParametroBean = parametroCpeService.listarParametro(parametroBean);
		
		/*TIP_PER0100_CC09_13 INICIO 2019/05/14 - 10:40 - Se comenta versión anterior del código*/
//		BigDecimal porcentaje = new BigDecimal(listaParametroBean.get(0).getCodValor());
		/*TIP_PER0100_CC09_13 FIN*/
		BigDecimal monto_aplicar = new BigDecimal(listaParametroBean.get(1).getCodValor());
		BigDecimal dividendo = new BigDecimal(100.00);
		BigDecimal multiplicador;
		double imp_detraccion;
		
		//Valimos si Empresa aplica calcular detracción
		String empresa;
		String aplica_Detraccion = null; // 0= No aplica, 1= Si aplica
		empresa = listVentaCpe.get(0).getIdEmpresa().toString();
		ParametroCpeBean param = new ParametroCpeBean();
		param.setCodParam(Constantes.COD_PARAM_CPE_EMPRESA_CON_DETRACCION);
		param.setTipParam(Constantes.TIP_PARAM_DETALLE);
		param.setCodValor(empresa);
		List<ParametroCpeBean> lstParam = new ArrayList<ParametroCpeBean>();
		lstParam = parametroCpeService.listarParametro(param);
		aplica_Detraccion =lstParam.get(0).getNomValor().toString();
		
		for(VentaCpeBean venta : listVentaCpe){
			venta.setIdCarga(bean.getIdCarga());
			venta.setNomSocio(obtenerSocio(venta.getIdSocio()));
			venta.setFlgPims("0");
			venta.setFlgUpload("0");
			venta.setFlgRv("0");
			venta.setFlgCompletado("1");
			venta.setIdPle(Long.parseLong("0"));
			venta.setNomProducto(obtenerProducto(venta.getIdSocio(),venta.getIdProducto()));
			venta.setEstado("1");
			setUbigeos(venta);

			//*** Validamos Detracción ***//
			if (aplica_Detraccion.equals(Constantes.FLG_DETRACCION_SI)) // 1= Si aplica detracción
			{
				if (venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)) {
					if (venta.getTipoMoneda().equals(Constantes.MONEDA_PEN)){
						if ((venta.getIgv().compareTo(BigDecimal.ZERO) > 0) && venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0) //Para aquellos con igv EXCEPTO Gratuitas
						{
							if (venta.getImpTotal().compareTo(monto_aplicar) == 1) // Mayor de monto aplicar
							{
								
								/*TIP_PER0100_CC09_13 INICIO 2019/05/14 - 10:40 - Se comenta versión anterior del código*/
//								multiplicador = porcentaje.divide(dividendo, 2, RoundingMode.HALF_UP);
//								imp_detraccion = redondeoDouble((multiplicador.multiply(venta.getImpTotal())).doubleValue());
//							
//								venta.setFlgDetraccion(Constantes.FLG_DETRACCION_SI);
//								venta.setImpDetraccion(new BigDecimal(imp_detraccion));
								/*TIP_PER0100_CC09_13 FIN*/
									
								/*TIP_PER0100_CC09_13 INICIO 2019/05/14 - 10:40 - Se agrega una condicional para validar si por excel se envia "S" o "N"
								 * en señal que aplique o no aplique detracción */
								String aplicaDetraccion = venta.getAplicaDetraccion()==null?"0":venta.getAplicaDetraccion().trim().equals("S")?"1":"0";
								if(aplicaDetraccion.equals(Constantes.FLG_DETRACCION_SI)){
									BigDecimal porcentaje = venta.getPorcDetraccion();
									multiplicador = porcentaje.divide(dividendo, 2, RoundingMode.HALF_UP);
									imp_detraccion = redondeoDouble((multiplicador.multiply(venta.getImpTotal())).doubleValue());
								
									venta.setFlgDetraccion(Constantes.FLG_DETRACCION_SI);
									venta.setImpDetraccion(new BigDecimal(imp_detraccion));
								}else{
									venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
									venta.setImpDetraccion(BigDecimal.ZERO);
								}
								/*TIP_PER0100_CC09_13 FIN*/
							}
							else {
								venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
								venta.setImpDetraccion(BigDecimal.ZERO);
							}
						}
						else {
							venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
							venta.setImpDetraccion(BigDecimal.ZERO);
						}
					}
					else {
						venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
						venta.setImpDetraccion(BigDecimal.ZERO);
					}
				}
				else if (venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO) && 
						venta.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)){
					if (venta.getTipoMoneda().equals(Constantes.MONEDA_PEN)){
						if (venta.getIgv().compareTo(BigDecimal.ZERO) > 0 && venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0) //Para aquellos con igv EXCEPTO Gratuitas
						{
							if (venta.getImpTotal().compareTo(monto_aplicar) == 1) // Mayor de monto aplicar
							{
								/*TIP_PER0100_CC09_13 INICIO 2019/05/14 - 10:55 - Se comenta versión anterior del código*/
//								multiplicador = porcentaje.divide(dividendo, 2, RoundingMode.HALF_UP);
//								imp_detraccion = redondeoDouble((multiplicador.multiply(venta.getImpTotal())).doubleValue());
//								
//								venta.setFlgDetraccion(Constantes.FLG_DETRACCION_SI);
//								venta.setImpDetraccion(new BigDecimal(imp_detraccion));
								/*TIP_PER0100_CC09_13 FIN*/
								
								/*TIP_PER0100_CC09_13 INICIO 2019/05/14 - 10:55 - Se agrega una condicional para validar si por excel se envia "S" o "N"
								 * en señal que aplique o no aplique detracción */
								String aplicaDetraccion = venta.getAplicaDetraccion()==null?"0":venta.getAplicaDetraccion().trim().equals("S")?"1":"0";
								if(aplicaDetraccion.equals(Constantes.FLG_DETRACCION_SI)){
									BigDecimal porcentaje = venta.getPorcDetraccion();
									multiplicador = porcentaje.divide(dividendo, 2, RoundingMode.HALF_UP);
									imp_detraccion = redondeoDouble((multiplicador.multiply(venta.getImpTotal())).doubleValue());
									
									venta.setFlgDetraccion(Constantes.FLG_DETRACCION_SI);
									venta.setImpDetraccion(new BigDecimal(imp_detraccion));
								}else{
									venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
									venta.setImpDetraccion(BigDecimal.ZERO);
								}
								/*TIP_PER0100_CC09_13 FIN*/
							}
							else {
								venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
								venta.setImpDetraccion(BigDecimal.ZERO);
							}
						}
						else {
							venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
							venta.setImpDetraccion(BigDecimal.ZERO);
						}
					}
					else {
						venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
						venta.setImpDetraccion(BigDecimal.ZERO);
					}					
				}
				else {
					venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
					venta.setImpDetraccion(BigDecimal.ZERO);
				}
			}
			else
			{
				venta.setFlgDetraccion(Constantes.FLG_DETRACCION_NO);
				venta.setImpDetraccion(BigDecimal.ZERO);
			}
			
			if (venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) || 
					venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO))
			{
				if (venta.getConcepNd().length() == 1)
					venta.setConcepNd("0" + venta.getConcepNd());
			}
			
			/**TIP_PER0100_CC15 INICIO 2019/06/24 - 14:20 - Se agrega bifurcación de inserción para los casos que tengan codReferencia sea 13 */
			if(venta.getIdTipoCompRef()!=null && venta.getIdTipoCompRef().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO)){
				procesoCpeService.guardarVentaCpeRef13(venta);
			}else{
				procesoCpeService.guardarVentaCpe(venta);
			}
			
			/**TIP_PER0100_CC15 FIN */
			VentaEstadoCpeBean ventaEstadoCpeBean = new VentaEstadoCpeBean();
			ventaEstadoCpeBean.setIdVenta(venta.getIdVenta());
			ventaEstadoCpeBean.setEstadoVenta(Constantes.COD_VALOR_ESTADO_PROCESO_PENDIENTE);
			ventaEstadoCpeBean.setUsuarioCreacion(usuarioDb);
			
			procesoCpeService.guardarVentaEstadoCpe(ventaEstadoCpeBean);
		}
		LOGGER.error("Fin Calculo de Detracción");
		
		limpiaVariablesOnline();
		LOGGER.error("Inicio Actualiza CodProdSunatPLSQL");
		setActualizaCodProdSunatPLSQL(bean.getIdCarga().intValue());
		LOGGER.error("Fin Actualiza CodProdSunatPLSQL");
		
		enviarMensaje(ErrorConstants.COD_ERROR_INFO_REGISTRADA_EXITO);
		
	}
	
	private String obtenerSocio(Long idSocio){
		SocioCpeBean socioCpeBeanRequest = new SocioCpeBean();
		socioCpeBeanRequest.setIdSocio(Integer.parseInt(idSocio.toString()));
		List<SocioCpeBean> listSocio = socioCpeService.listarSocio(socioCpeBeanRequest);
		return listSocio.get(0).getNomSocio() == null ? "" : listSocio.get(0).getNomSocio();
	}
	
	private String obtenerProducto(Long idSocio, Long idProducto){
		String descProducto = "";
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		productoCpeBean.setIdSocio(Integer.parseInt(idSocio.toString()));
		productoCpeBean.setIdProducto(Integer.parseInt(idProducto.toString()));
		List<ProductoCpeBean> listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
		
		if(listaProductoBean != null && !listaProductoBean.isEmpty() && listaProductoBean.size()> 0){
			descProducto = listaProductoBean.get(0).getNomProducto();
		}
		
		return descProducto;
	}
	
	private void setUbigeos(VentaCpeBean venta){
		if((venta.getDepartamento() != null && !venta.getDepartamento().equals("")) 
				&& (venta.getProvincia() != null && !venta.getProvincia().equals(""))
				&& (venta.getDistrito() != null && !venta.getDistrito().equals(""))){
			
			if(obtenerDepartamento(venta)){
				if(obtenerProvincia(venta)){
					obtenerDistrito(venta);
				}
			}
			
		}else{
			setUbigeoNulls(venta);
		}
	}
	
    public static String cleanString(String texto) {
        texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
        texto = texto.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
        return texto;
    }
    
	private boolean obtenerDepartamento(VentaCpeBean venta){
		boolean ind = false;
		List<UbigeoCpeBean> listDepartamento = new ArrayList<UbigeoCpeBean>();
		listDepartamento = ubigeoCpeService.listarDepartamento();
		
		for(UbigeoCpeBean dep : listDepartamento){
			if(dep.getNombreUbigeo().trim().equalsIgnoreCase(cleanString(venta.getDepartamento().trim()))){
				venta.setDepartamento(dep.getCodigoUbigeo());
				ind=true;
				break;
			}
		}
		if(!ind){
			setUbigeoNulls(venta);
		}
		
		return ind;
	}
	
	private boolean obtenerProvincia(VentaCpeBean venta){
		boolean ind = false;
		UbigeoCpeBean ubigeo = new UbigeoCpeBean();
		ubigeo.setIdDepartamento(venta.getDepartamento().trim().substring(0, 2));
		List<UbigeoCpeBean> listProvincia = new ArrayList<UbigeoCpeBean>();
		listProvincia = ubigeoCpeService.listarProvincia(ubigeo);
		
		for(UbigeoCpeBean prov : listProvincia){
			if(prov.getNombreUbigeo().trim().equalsIgnoreCase(cleanString(venta.getProvincia().trim()))){
				venta.setProvincia(prov.getCodigoUbigeo());
				ind = true;
				break;
			}
		}
		if(!ind){
			setUbigeoNulls(venta);
		}
		
		return ind;
	}
	
	private boolean obtenerDistrito(VentaCpeBean venta){
		boolean ind = false;
		UbigeoCpeBean ubigeo = new UbigeoCpeBean();
		ubigeo.setIdProvincia(venta.getProvincia().substring(2, 4));
		ubigeo.setIdDepartamento(venta.getDepartamento().substring(0, 2));
		List<UbigeoCpeBean> listDistrito = new ArrayList<UbigeoCpeBean>();
		listDistrito = ubigeoCpeService.listarDistrito(ubigeo);
		
		for(UbigeoCpeBean dist : listDistrito){
			if(dist.getNombreUbigeo().trim().equalsIgnoreCase(cleanString(venta.getDistrito().trim()))){
				venta.setDistrito(dist.getCodigoUbigeo());
				ind = true;
				break;
			}
		}
		if(!ind){
			setUbigeoNulls(venta);
		}
		return ind;
	}
	
	private void setUbigeoNulls(VentaCpeBean venta){
		venta.setDepartamento("");
		venta.setProvincia("");
		venta.setDistrito("");
	}

	private void copiaArchivo(UploadedFile archivoOrigen, String rutadestino) {
		try {
			// archivo de origen
			BufferedInputStream bufferedInput = new BufferedInputStream(archivoOrigen.getInputStream());
			// Se abre el fichero donde se hará la copia
			FileOutputStream fileOutput = new FileOutputStream(rutadestino);
			BufferedOutputStream bufferedOutput = new BufferedOutputStream(fileOutput);

			// BUCLE PARA LEER DE UN FICHERO Y ESCRIBIR EN EL OTRO.
			byte[] array = new byte[1000];// MODIFICAR
			int leidos = bufferedInput.read(array);
			while (leidos > 0) {
				bufferedOutput.write(array, 0, leidos);
				leidos = bufferedInput.read(array);
			}

			// Cierre de los ficheros
			bufferedInput.close();
			bufferedOutput.close();
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}

	}

	private void enviarMensaje(String codMensaje) {
		String mensaje = PropertiesErrorUtil.getProperty(codMensaje);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje, null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	}

	private void limpiaVariablesBackGround() {
		nomArchivo = "";
		RutanombreDestino = "";
		// Borrar archivo para limpiar temporales
		if (archivo != null) {
			try {
				archivo.delete();
			} catch (IOException e) {
			}
		}
		archivo = null;
	}

	private void camposObligatoriosBackGround() throws SyncconException {
		boolean compoObligatorio = false;
		if (nomArchivo == null || nomArchivo.trim().length() <= 0)
			compoObligatorio = true;
		else if (archivo == null)
			compoObligatorio = true;
		else if (RutanombreDestino == null || RutanombreDestino.trim().length() <= 0)
			compoObligatorio = true;

		if (compoObligatorio)
			throw new SyncconException(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS, FacesMessage.SEVERITY_INFO);
	}

	public String clearUploadBackGround() {
		String respuesta = null;
		try {
			limpiaVariablesBackGround();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}

	/****************************************** ONLINE *********************************************/
	/*
	 * TODO BSC 12/09/2019
	 * La clase org.richfaces.event.UploadEvent fue eliminada en RichFaces 4.x. En su lugar, se usa org.richfaces.event.FileUploadEvent
	 * La clase org.richfaces.model.UploadItem fue eliminada en RichFaces 4.x. En su lugar, se usa org.richfaces.model.UploadedFile
	 * 
	 * El procesamiento cambia totalmente, ya que desde UploadedFile no se puede obtener el objeto java.io.File y en su lugar se usa arreglod bytes
	 * 
	@SuppressWarnings("unchecked")
	public String listenerOnline(UploadEvent event) {
		String respuesta = null;
		try {
			listVentaCpe = new ArrayList<VentaCpeBean>();
			mensajeValidacionArchivo = "";
			archivo = event.getUploadItem().getFile();
			nomArchivo = event.getUploadItem().getFileName();
			
			CargaVentaCabCpeBean carga = new CargaVentaCabCpeBean();
			carga.setNomArchivo(nomArchivo);
			List<CargaVentaCabCpeBean> listCarga = cargaVentaCabCpeService.listarCargaVentaCab(carga);
			
			if(listCarga == null || listCarga.isEmpty() || listCarga.size() == 0){
				mensajeValidacionArchivo = campoLayoutCpeService.validarArchivoCamposLayout(archivo, nomArchivo, 
						Constantes.ID_LAYOUT_ARCHIVO);
			}else{
				mensajeValidacionArchivo = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ARCHIVO_RECHAZADO);
			}
			
			if(mensajeValidacionArchivo != null){
				clearUpload();
				listVentaCpe = new ArrayList<VentaCpeBean>();
				return null;
			}else{
				mensajeValidacionArchivo = null;
				disabledCargar = false;
				listVentaCpe = FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
									.get(Constantes.KEY_LIST_VENTA_XLSX) == null ? new ArrayList<VentaCpeBean>() 
											: (List<VentaCpeBean>) FacesContext.getCurrentInstance()
												.getExternalContext().getSessionMap().get(Constantes.KEY_LIST_VENTA_XLSX);
			    
				mensajeValidacionArchivo = detectarMismaEmpresa(listVentaCpe);
				
				if(mensajeValidacionArchivo != null){
					clearUpload();
					listVentaCpe = new ArrayList<VentaCpeBean>();
					return null;
				}
				else 
				{
					mensajeValidacionArchivo = null;
					disabledCargar = false;
					detectarDuplicadosArchivo(listVentaCpe);
				}
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			mensajeValidacionArchivo = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_CARGA_EXCEL);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	*/

	@SuppressWarnings("unchecked")
	public String listenerOnline(FileUploadEvent event) {
		String respuesta = null;
		try {
			listVentaCpe = new ArrayList<VentaCpeBean>();
			mensajeValidacionArchivo = "";
			archivo = event.getUploadedFile();
			nomArchivo = archivo.getName();

			CargaVentaCabCpeBean carga = new CargaVentaCabCpeBean();
			carga.setNomArchivo(nomArchivo);
			List<CargaVentaCabCpeBean> listCarga = cargaVentaCabCpeService.listarCargaVentaCab(carga);

			if(listCarga == null || listCarga.isEmpty() || listCarga.size() == 0){
				mensajeValidacionArchivo = campoLayoutCpeService.validarArchivoCamposLayout(archivo, nomArchivo, Constantes.ID_LAYOUT_ARCHIVO);
			}else{
				mensajeValidacionArchivo = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ARCHIVO_RECHAZADO);
			}

			if(mensajeValidacionArchivo != null){
				clearUpload();
				listVentaCpe = new ArrayList<VentaCpeBean>();
				return null;
			}else{
				mensajeValidacionArchivo = null;
				disabledCargar = false;
				listVentaCpe = FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
									.get(Constantes.KEY_LIST_VENTA_XLSX) == null ? new ArrayList<VentaCpeBean>() 
											: (List<VentaCpeBean>) FacesContext.getCurrentInstance()
												.getExternalContext().getSessionMap().get(Constantes.KEY_LIST_VENTA_XLSX);
			    
				mensajeValidacionArchivo = detectarMismaEmpresa(listVentaCpe);

				if(mensajeValidacionArchivo != null){
					clearUpload();
					listVentaCpe = new ArrayList<VentaCpeBean>();
					return null;
				}
				else 
				{
					mensajeValidacionArchivo = null;
					disabledCargar = false;
					detectarDuplicadosArchivo(listVentaCpe);
				}
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			mensajeValidacionArchivo = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_CARGA_EXCEL);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}

	private String detectarMismaEmpresa(List<VentaCpeBean> listVenta)
	{
		String respuesta = null;
		int contadorSeguros = 0;
		int contadorServicios = 0;
		
		for(VentaCpeBean bean : listVenta){
			
			if (bean.getIdEmpresa().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS))
				contadorSeguros = contadorSeguros + 1;
			else 
				contadorServicios = contadorServicios + 1;
			
			if (contadorSeguros > 0 && contadorServicios > 0)
			{
				respuesta = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_VENTA_MISMA_EMPRESA);
				break;
			}
		}
		return respuesta;
	}
	
	private void detectarDuplicadosArchivo(List<VentaCpeBean> listVenta){
		List<VentaCpeBean> lista = new ArrayList<VentaCpeBean>();
		lista.addAll(listVenta);
		
		for(VentaCpeBean bean : listVenta){
			if(!bean.isFlagDuplicado()){
				int cantDupli = 0;
				for(VentaCpeBean dupli : lista){
					if(ventaArchivoIguales(dupli, bean)){
						cantDupli++;
					}
				}
				if(cantDupli>1){
					bean.setFlagDuplicado(true);
					bean.setTipoRegistro(Constantes.CPE_DESCRIPCION_DUPLI_ARCHIVO);
				}else{
					bean.setTipoRegistro(Constantes.CPE_DESCRIPCION_VENTA_NUEVA);
				}
			}
		}
	}
	
	private boolean ventaArchivoIguales(VentaCpeBean ventaUno, VentaCpeBean ventaDos){
		boolean flag = false;
		
		if(
			(ventaUno.getIdEmpresa() == null ? "" : ventaUno.getIdEmpresa()).equals((ventaDos.getIdEmpresa() == null ? "" : ventaDos.getIdEmpresa()))
			&& (ventaUno.getIdSocio() == null ? new Long(0) : ventaUno.getIdSocio()).equals((ventaDos.getIdSocio() == null ? new Long(0) : ventaDos.getIdSocio()))
			&& (ventaUno.getIdProducto() == null ? new Long(0) : ventaUno.getIdProducto()).equals((ventaDos.getIdProducto() == null ? new Long(0) : ventaDos.getIdProducto()))
			&& (ventaUno.getFechaEmision() == null ? "" : ventaUno.getFechaEmision()).equals((ventaDos.getFechaEmision() == null ? "" : ventaDos.getFechaEmision()))
			&& (ventaUno.getIdTipoComp() == null ? "" : ventaUno.getIdTipoComp()).equals((ventaDos.getIdTipoComp() == null ? "" : ventaDos.getIdTipoComp()))
			&& (ventaUno.getConcepNd() == null ? "" : ventaUno.getConcepNd()).equals((ventaDos.getConcepNd() == null ? "" : ventaDos.getConcepNd()))
			&& (ventaUno.getTipoMoneda() == null ? "" : ventaUno.getTipoMoneda()).equals((ventaDos.getTipoMoneda() == null ? "" : ventaDos.getTipoMoneda()))
			&& (ventaUno.getFechaVenc() == null ? "" : ventaUno.getFechaVenc()).equals((ventaDos.getFechaVenc() == null ? "" : ventaDos.getFechaVenc()))
			&& (ventaUno.getIdTipoDocCli() == null ? "" : ventaUno.getIdTipoDocCli()).equals((ventaDos.getIdTipoDocCli() == null ? "" : ventaDos.getIdTipoDocCli()))
			&& (ventaUno.getNumDocCli() == null ? "" : ventaUno.getNumDocCli()).equals((ventaDos.getNumDocCli() == null ? "" : ventaDos.getNumDocCli()))
			&& (ventaUno.getNomCliRazSoc() == null ? "" : ventaUno.getNomCliRazSoc()).equals((ventaDos.getNomCliRazSoc() == null ? "" : ventaDos.getNomCliRazSoc()))
			&& (ventaUno.getDirCliente() == null ? "" : ventaUno.getDirCliente()).equals((ventaDos.getDirCliente() == null ? "" : ventaDos.getDirCliente()))
			&& (ventaUno.getDepartamento() == null ? "" : ventaUno.getDepartamento()).equals((ventaDos.getDepartamento() == null ? "" : ventaDos.getDepartamento()))
			&& (ventaUno.getProvincia() == null ? "" : ventaUno.getProvincia()).equals((ventaDos.getProvincia() == null ? "" : ventaDos.getProvincia()))
			&& (ventaUno.getDistrito() == null ? "" : ventaUno.getDistrito()).equals((ventaDos.getDistrito() == null ? "" : ventaDos.getDistrito()))
			&& (ventaUno.getTelefCliente() == null ? "" : ventaUno.getTelefCliente()).equals((ventaDos.getTelefCliente() == null ? "" : ventaDos.getTelefCliente()))
			&& (ventaUno.getMailCliente() == null ? "" : ventaUno.getMailCliente()).equals((ventaDos.getMailCliente() == null ? "" : ventaDos.getMailCliente()))
			&& (ventaUno.getIdTipoCompRef() == null ? "" : ventaUno.getIdTipoCompRef()).equals((ventaDos.getIdTipoCompRef() == null ? "" : ventaDos.getIdTipoCompRef()))
			&& (ventaUno.getFechaEmisionRef() == null ? "" : ventaUno.getFechaEmisionRef()).equals((ventaDos.getFechaEmisionRef() == null ? "" : ventaDos.getFechaEmisionRef()))
			&& (ventaUno.getNumSerieRef() == null ? new Long(0) : ventaUno.getNumSerieRef()).equals((ventaDos.getNumSerieRef() == null ? new Long(0) : ventaDos.getNumSerieRef()))
			&& (ventaUno.getNumCorRef() == null ? new Long(0) : ventaUno.getNumCorRef()).equals((ventaDos.getNumCorRef() == null ? new Long(0) : ventaDos.getNumCorRef()))
			&& (ventaUno.getConcepto() == null ? "" : ventaUno.getConcepto()).equals((ventaDos.getConcepto() == null ? "" : ventaDos.getConcepto()))
			&& (ventaUno.getCodProdSunat() == null ? "" : ventaUno.getCodProdSunat()).equals((ventaDos.getCodProdSunat() == null ? "" : ventaDos.getCodProdSunat()))
			&& (ventaUno.getNumPoliza() == null ? "" : ventaUno.getNumPoliza()).equals((ventaDos.getNumPoliza() == null ? "" : ventaDos.getNumPoliza()))
			&& ventaUno.getValFactExport().compareTo(ventaDos.getValFactExport()) == 0
			&& ventaUno.getBaseImponible().compareTo(ventaDos.getBaseImponible()) == 0
			&& ventaUno.getImpExonerado().compareTo(ventaDos.getImpExonerado()) == 0
			&& ventaUno.getImpInafecto().compareTo(ventaDos.getImpInafecto()) == 0
			&& ventaUno.getValOpGratuitas().compareTo(ventaDos.getValOpGratuitas()) == 0
			&& ventaUno.getIsc().compareTo(ventaDos.getIsc()) == 0
			&& ventaUno.getIgv().compareTo(ventaDos.getIgv()) == 0
			&& ventaUno.getImpOtros().compareTo(ventaDos.getImpOtros()) == 0
			&& ventaUno.getImpTotal().compareTo(ventaDos.getImpTotal()) == 0
			&& (ventaUno.getTipoCambio() == null ? BigDecimal.ZERO : ventaUno.getTipoCambio()).compareTo((ventaDos.getTipoCambio() == null ? BigDecimal.ZERO : ventaDos.getTipoCambio())) == 0
			&& (ventaUno.getEstado() == null ? "" : ventaUno.getEstado()).equals((ventaDos.getEstado() == null ? "" : ventaDos.getEstado()))
			&& (ventaUno.getOpenItem() == null ? "" : ventaUno.getOpenItem()).equals((ventaDos.getOpenItem() == null ? "" : ventaDos.getOpenItem()))
			&& (ventaUno.getOpenItemRef() == null ? "" : ventaUno.getOpenItemRef()).equals((ventaDos.getOpenItemRef() == null ? "" : ventaDos.getOpenItemRef()))
			&& (ventaUno.getArea() == null ? "" : ventaUno.getArea()).equals((ventaDos.getArea() == null ? "" : ventaDos.getArea()))
			&& (ventaUno.getObservacion() == null ? "" : ventaUno.getObservacion()).equals((ventaDos.getObservacion() == null ? "" : ventaDos.getObservacion()))
			&& (ventaUno.getMontoUsd() == null ? BigDecimal.ZERO : ventaUno.getMontoUsd()).compareTo((ventaDos.getMontoUsd() == null ? BigDecimal.ZERO : ventaDos.getMontoUsd())) == 0
			&& (ventaUno.getColectIndiv() == null ? "" : ventaUno.getColectIndiv()).equals((ventaDos.getColectIndiv() == null ? "" : ventaDos.getColectIndiv()))
			&& (ventaUno.getLinea() == null ? "" : ventaUno.getLinea()).equals((ventaDos.getLinea() == null ? "" : ventaDos.getLinea()))
			&& (ventaUno.getPeriodo() == null ? "" : ventaUno.getPeriodo()).equals((ventaDos.getPeriodo() == null ? "" : ventaDos.getPeriodo()))){
			flag = true;
		}
		
		return flag;
	}

	// TODO BSC 12/09/2019 Con RichFaces 4.x no se puede obtener el objeto java.io.File durante la carga.
	public String clearUpload() {
		String respuesta = null;
		try {
			if (archivo != null) {
				// BSC Se elimina validación de existencia de archivo directamente se borra el documento
				archivo.delete();
				archivo = null;
			}
			this.nomArchivo = null;
			this.disabledCargar = true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public String mostrarMensajeUploadFile() {
		String respuesta = null;
		try {
			if (mensajeValidacionArchivo != null) {
				clearUpload();
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO, mensajeValidacionArchivo);
				mensajeValidacionArchivo = null;
				idFileUploadComponent = "uploaderCarga";
			} else {
				idFileUploadComponent = "txtHidden";
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}

	public void limpiaVariablesOnline() {
		nomArchivo = "";
		archivo = null;
		disabledCargar = true;
		listVentaCpe = new ArrayList<VentaCpeBean>();
		nroRegistros = 0;
	}

	private void camposObligatoriosOnline() throws SyncconException {
		boolean compoObligatorio = false;
		if (nomArchivo == null || nomArchivo.trim().length() <= 0)
			compoObligatorio = true;
		else if (archivo == null)
			compoObligatorio = true;

		if (compoObligatorio)
			throw new SyncconException(ErrorConstants.COD_ERROR_CARGA_CAMPOS_OBLIGATORIOS, FacesMessage.SEVERITY_INFO);
	}

	public String cargaArchivoOnline() {
		try {
			camposObligatoriosOnline();
			
			nroRegistros = listVentaCpe.size();

			//limpiaVariablesOnline();

		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}

		return null;
	}

	public String procesaCargaArchivoOnline() {

		return null;
	}

	public String actualizarValoresProducto() {
		productoItems = listarProducto(socio);
			if (productoItems.size() > 1)
				disableProducto = false;
			else
				disableProducto = true;
		
		return null;
	}

	/***********************************************************************************************************************************/
	/*********************************************************** INICIO PIMS ***********************************************************/
	/***********************************************************************************************************************************/
	public void limpiaBusqueda(){
		socio = "-1";
		fecCargaDesde =null;
		fecCargaHasta = null;
		moneda = "-1";
		tipComprobante = "-1";
		numComprobante = "";
		certificado = "";
		codUpload = "";
		lote = "";
		tipoDoc = "-1";
		numDoc="";
		cliente = "";
		actualizarValoresProducto();
		listaVentasPims = new ArrayList<VentaPimsCpeBean>();
		numRegBusqueda = listaVentasPims.size();
		listaVentasUpload = new ArrayList<VentaUploadCpeBean>();
		listaVentasAgrupadoUpload = new ArrayList<VentaUploadAgrupadoCpeBean>();
		numRegBusquedaUpload  = listaVentasUpload.size();
		numSelecDupliDetUpload = listaVentasUpload.size();
		selectAllPims = false;
		selectAllUploadAgrupado = false;
		selectAllUploadDetallado = false;
	}
	
	private void listarFiltrosPims(){
		listarSocio();
		monedaItems = obtieneParametro(Constantes.COD_PARAM_CPE_TIPO_MONEDA, true);
		estadoVentaItems = obtieneParametro(Constantes.COD_PARAM_CPE_ESTADO_VENTA, false);
		listaVentasPims = new ArrayList<VentaPimsCpeBean>();
		listaVentasProcesarPims = new ArrayList<VentaPimsCpeBean>();
		ventaSeleccionada = new VentaPimsCpeBean();
	}
	
	public void agregarRegistrosProcesar(){
		Boolean regSeleccionados = false;
		for(VentaPimsCpeBean bean : listaVentasPims){
			if(bean.getSeleccionado()){
				listaVentasProcesarPims.add(bean);
				regSeleccionados = true;
			}
		}
		if(regSeleccionados){
			for(VentaPimsCpeBean bean : listaVentasProcesarPims){
				listaVentasPims.remove(bean);
			}
			numRegBusqueda = listaVentasPims.size();
			numRegProcesar = listaVentasProcesarPims.size();
		}else{
			enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
		}
		selectAllPims = false;
	}
	
	public void limpiarTodo(){
		limpiaBusqueda();
		listaVentasPims = new ArrayList<VentaPimsCpeBean>();
		listaVentasProcesarPims = new ArrayList<VentaPimsCpeBean>();
		numRegProcesar = listaVentasProcesarPims.size();
		listaVentasUpload = new ArrayList<VentaUploadCpeBean>();
		listaVentasAgrupadoUpload = new ArrayList<VentaUploadAgrupadoCpeBean>();
		listaVentasProcesarUpload = new ArrayList<VentaUploadCpeBean>();
		numRegProcesarUpload = listaVentasProcesarUpload.size();
		numRegDupliProcesarUpload = listaVentasProcesarUpload.size();
	}
	
	public void eliminarVentaProceso(){
		listaVentasProcesarPims.remove(ventaSeleccionada);
		numRegProcesar = listaVentasProcesarPims.size();
	}
	
	private void setCalculasMontosVenta(VentaCpeBean ventaCpeBean){
		BigDecimal importeTotal =  ventaCpeBean.getImpTotal();
		ConfiguracionCpeBean conf = new ConfiguracionCpeBean();
		List<ConfiguracionCpeBean> listaConf = new ArrayList<ConfiguracionCpeBean>();
		conf.setIdEmpresa(Constantes.COD_EMPRESA_CARDIF_SEGUROS);
		conf.setIdSocio(ventaCpeBean.getIdSocio().intValue());
		conf.setIdProducto(ventaCpeBean.getIdProducto().intValue());
		conf.setIdTipoComp(ventaCpeBean.getIdTipoComp());
		conf.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
		conf.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		conf.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
		conf.setEstadoConfig(Constantes.ACTIVO);
		listaConf = configuracionCpeService.listarConfiguracion(conf);
		
		if(listaConf.get(0).getAfectoIgv() == 1){
			BigDecimal igv = new BigDecimal(0);
			try {
				//igv = new BigDecimal(Integer.parseInt(repParametroService.listarDetalleCuenta(Constantes.COD_IGV).get(0).getCodValor()));
				ParametroCpeBean param = new ParametroCpeBean();
				param.setTipParam(Constantes.TIP_PARAM_DETALLE);
				param.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
				param.setCodValor(Constantes.COD_VALOR_GENERAL_IGV);
				igv = new BigDecimal(parametroCpeService.listarParametro(param).get(0).getNomValor());
				//igv = igv.divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
				igv = igv.add(new BigDecimal(1));
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
			BigDecimal baseImponible = importeTotal.divide(igv, 2, RoundingMode.HALF_UP);
			BigDecimal igvVenta = importeTotal.subtract(baseImponible);
			
			ventaCpeBean.setBaseImponible(baseImponible);
			ventaCpeBean.setIgv(igvVenta);
			ventaCpeBean.setImpInafecto(new BigDecimal(0));
		}else{
			ventaCpeBean.setBaseImponible(new BigDecimal(0));
			ventaCpeBean.setIgv(new BigDecimal(0));
			ventaCpeBean.setImpInafecto(importeTotal);
		}
		
		ventaCpeBean.setValFactExport(new BigDecimal(0));
		ventaCpeBean.setImpExonerado(new BigDecimal(0));
		ventaCpeBean.setValOpGratuitas(new BigDecimal(0));
		ventaCpeBean.setIsc(new BigDecimal(0));
		ventaCpeBean.setImpOtros(new BigDecimal(0));
	}
	
	public void procesarPims(){
		
		if(listaVentasProcesarPims.isEmpty()){
			enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
		}else{
//			VentaCpeBean ventaPims = new VentaCpeBean();
//			List<VentaCpeBean> listaVentaPims = new ArrayList<VentaCpeBean>();
			List<VentaPimsCpeBean> ventasInsertar = new ArrayList<VentaPimsCpeBean>();
//			List<VentaPimsCpeBean> ventasActualizar = new ArrayList<VentaPimsCpeBean>();
			List<VentaPimsCpeBean> ventasSinConfSocioProducto = new ArrayList<VentaPimsCpeBean>();
			for(VentaPimsCpeBean bean : listaVentasProcesarPims){
				ConfiguracionCpeBean conf = new ConfiguracionCpeBean();
				List<ConfiguracionCpeBean> listaConf = new ArrayList<ConfiguracionCpeBean>();
				conf.setIdEmpresa(Constantes.COD_EMPRESA_CARDIF_SEGUROS);
				conf.setIdSocio(bean.getIdSocio().intValue());
				conf.setIdProducto(bean.getIdProducto().intValue());
				conf.setIdTipoComp(bean.getIdTipoComp());
				conf.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
				conf.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
				conf.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
				conf.setEstadoConfig(Constantes.ACTIVO);
				listaConf = configuracionCpeService.listarConfiguracion(conf);
				
				if(!listaConf.isEmpty()){
//					ventaPims.setLlavePims(bean.getLlavePims());
//					listaVentaPims = procesoCpeService.buscarVentaPimsUploadCpe(ventaPims);
//					if(listaVentaPims.isEmpty()){
						ventasInsertar.add(bean);
//					}else{
//						ventaPims = listaVentaPims.get(0);
//						bean.setIdVenta(ventaPims.getIdVenta());
//						bean.setEstado(ventaPims.getEstado());
//						ventasActualizar.add(bean);
//					}
				}else {
					ventasSinConfSocioProducto.add(bean);
				}
			}
			
			if(!ventasInsertar.isEmpty()){
				CargaVentaCabCpeBean cargaVentaCabCpeBean = new CargaVentaCabCpeBean();
				cargaVentaCabCpeBean.setIdOrigen(origen);
				cargaVentaCabCpeBean.setIdTipoCarga(Constantes.ID_TIPO_CARGA_ONLINE);
				cargaVentaCabCpeBean.setNomArchivo(Constantes.TEXTO_DEFAULT);
				cargaVentaCabCpeBean.setNumRegistro(Long.valueOf(ventasInsertar.size()));
				cargaVentaCabCpeBean.setEstadoCarga(Constantes.COD_VALOR_COMPLETADA);
				cargaVentaCabCpeBean.setUsuarioCarga(usuarioDb);
				cargaVentaCabCpeService.insertarCargaVentaCab(cargaVentaCabCpeBean);
				
				for(VentaPimsCpeBean bean : ventasInsertar){
					VentaCpeBean ventaCpeBean = new VentaCpeBean();
					ventaCpeBean.setIdCarga(cargaVentaCabCpeBean.getIdCarga());
					ventaCpeBean.setLlavePims(bean.getLlavePims());
					ventaCpeBean.setIdEmpresa(Constantes.COD_EMPRESA_CARDIF_SEGUROS);
					ventaCpeBean.setIdSocio(bean.getIdSocio());
					ventaCpeBean.setNomSocio(bean.getNomSocio());
					ventaCpeBean.setIdProducto(bean.getIdProducto());
					ventaCpeBean.setNomProducto(bean.getNomProducto());
					ventaCpeBean.setFechaEmisionDate(bean.getFecEmision());
					ventaCpeBean.setFechaEmision(getDateToString(bean.getFecEmision()));
					ventaCpeBean.setIdTipoComp(bean.getIdTipoComp());
					ventaCpeBean.setConcepNd(bean.getConcepNd());
					ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
					ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
					ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
					ventaCpeBean.setNumDocCli(bean.getNumDocCli());
					ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
					ventaCpeBean.setDirCliente(bean.getDirCli());
					ventaCpeBean.setDepartamento(bean.getDepartamento());
					ventaCpeBean.setProvincia(bean.getProvincia());
					ventaCpeBean.setDistrito(bean.getDistrito());
					ventaCpeBean.setTelefCliente(bean.getTelfCli());
					ventaCpeBean.setMailCliente(bean.getMailCli());
					ventaCpeBean.setNumPoliza(bean.getNumPoliza());
					ventaCpeBean.setFechaVenta(bean.getFecVenta());
//					ventaCpeBean.setValFactExport(new BigDecimal(0));//prueba
//					ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//					ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//					ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//					ventaCpeBean.setValOpGratuitas(new BigDecimal(0));//prueba
//					ventaCpeBean.setIsc(new BigDecimal(0));//prueba
//					ventaCpeBean.setIgv(bean.getIgv());
//					ventaCpeBean.setImpOtros(new BigDecimal(0));//prueba
					ventaCpeBean.setImpTotal(bean.getImpTotal());
					ventaCpeBean.setEstado(Constantes.COD_ESTADO_VENTA_PENDIENTE);
					ventaCpeBean.setOpenItem(bean.getOpenItem() == null ? "" : bean.getOpenItem().toString());
					ventaCpeBean.setOpenItemRef(bean.getOpenItemRef());
					ventaCpeBean.setColectIndiv(bean.getColectIndiv() == null ? "" : bean.getColectIndiv().toString());
					ventaCpeBean.setPeriodo(getPeriodoActual());
					ventaCpeBean.setFlgPims("0");
					ventaCpeBean.setFlgUpload("0");
					ventaCpeBean.setFlgRv("0");
					ventaCpeBean.setFlgCompletado("0");
					ventaCpeBean.setIdPle(Long.parseLong("0"));
					ventaCpeBean.setPrefijoAlta(bean.getPrefijoAlta());
					
					setUbigeos(ventaCpeBean);
					setCalculasMontosVenta(ventaCpeBean);
					
//					if(requiereCompletarDatos(ventaCpeBean)){
//						completarDatosUpload(ventaCpeBean);
//					}
//					
//					if(requiereCompletarDatos(ventaCpeBean)){
//						completarDatosRegVentasNuevo(ventaCpeBean);
//					}
//					
//					if(requiereCompletarDatos(ventaCpeBean)){
//						completarDatosRegVentasAntiguo(ventaCpeBean);
//					}
					
					procesoCpeService.guardarVentaCpe(ventaCpeBean);
					
					VentaEstadoCpeBean ventaEstadoCpeBean = new VentaEstadoCpeBean();
					ventaEstadoCpeBean.setIdVenta(ventaCpeBean.getIdVenta());
					ventaEstadoCpeBean.setEstadoVenta(Constantes.COD_ESTADO_VENTA_PENDIENTE);
					ventaEstadoCpeBean.setUsuarioCreacion(usuarioDb);
					
					procesoCpeService.guardarVentaEstadoCpe(ventaEstadoCpeBean);
				}
				ventasInsertar = new ArrayList<VentaPimsCpeBean>();
			}
			
//			Boolean existe = false;
//			if(!ventasActualizar.isEmpty()){
//				for(VentaPimsCpeBean bean : ventasActualizar){
//					if(!bean.getEstado().trim().equals(Constantes.COD_ESTADO_VENTA_PENDIENTE)){
//						existe = true;
//						bean.setExiste(true);
//					}else{
//						VentaCpeBean ventaCpeBean = new VentaCpeBean();
//						bean.setExiste(false);
//						ventaCpeBean.setIdVenta(bean.getIdVenta());
//						ventaCpeBean.setLlavePims(bean.getLlavePims());
//						ventaCpeBean.setIdEmpresa(Constantes.COD_EMPRESA_CARDIF_SEGUROS);
//						ventaCpeBean.setIdSocio(bean.getIdSocio());
//						ventaCpeBean.setNomSocio(bean.getNomSocio());
//						ventaCpeBean.setIdProducto(bean.getIdProducto());
//						ventaCpeBean.setNomProducto(bean.getNomProducto());
//						ventaCpeBean.setFechaEmisionDate(bean.getFecEmision());
//						ventaCpeBean.setFechaEmision(getDateToString(bean.getFecEmision()));
//						ventaCpeBean.setIdTipoComp(bean.getIdTipoComp());
//						ventaCpeBean.setConcepNd(bean.getConcepNd());
//						ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
//						ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//						//ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
//						ventaCpeBean.setIdTipoDocCli("1");//prueba
//						ventaCpeBean.setNumDocCli(bean.getNumDocCli());
//						ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
//						ventaCpeBean.setDirCliente(bean.getDirCli());
//						ventaCpeBean.setDepartamento(bean.getDepartamento());
//						ventaCpeBean.setProvincia(bean.getProvincia());
//						ventaCpeBean.setDistrito(bean.getDistrito());
//						ventaCpeBean.setTelefCliente(bean.getTelfCli());
//						ventaCpeBean.setMailCliente(bean.getMailCli());
//						ventaCpeBean.setNumPoliza(bean.getNumPoliza());
//						ventaCpeBean.setFechaVenta(bean.getFecVenta());
////						ventaCpeBean.setValFactExport(new BigDecimal(0));//prueba
////						ventaCpeBean.setBaseImponible(bean.getBaseImponible());
////						ventaCpeBean.setImpExonerado(bean.getImpExonerado());
////						ventaCpeBean.setImpInafecto(bean.getImpInafecto());
////						ventaCpeBean.setValOpGratuitas(new BigDecimal(0));//prueba
////						ventaCpeBean.setIsc(new BigDecimal(0));//prueba
////						ventaCpeBean.setIgv(bean.getIgv());
////						ventaCpeBean.setImpOtros(new BigDecimal(0));//prueba
//						ventaCpeBean.setImpTotal(bean.getImpTotal());
//						ventaCpeBean.setEstado(Constantes.COD_ESTADO_VENTA_PENDIENTE);
//						ventaCpeBean.setOpenItem(bean.getOpenItem().toString());
//						ventaCpeBean.setOpenItemRef(bean.getOpenItemRef());
//						ventaCpeBean.setColectIndiv(bean.getColectIndiv().toString());
//						ventaCpeBean.setPeriodo(getPeriodoActual());
//						ventaCpeBean.setFlgPims("0");
//						ventaCpeBean.setFlgUpload("0");
//						ventaCpeBean.setFlgRv("0");
//						ventaCpeBean.setFlgCompletado("0");
//						ventaCpeBean.setIdPle(Long.parseLong("0"));
//						ventaCpeBean.setPrefijoAlta(bean.getPrefijoAlta());
//						
//						setUbigeos(ventaCpeBean);
//						setCalculasMontosVenta(ventaCpeBean);
//						
//						if(requiereCompletarDatos(ventaCpeBean)){
//							completarDatosUpload(ventaCpeBean);
//						}
//						
//						if(requiereCompletarDatos(ventaCpeBean)){
//							completarDatosRegVentasNuevo(ventaCpeBean);
//						}
//						
//						if(requiereCompletarDatos(ventaCpeBean)){
//							completarDatosRegVentasAntiguo(ventaCpeBean);
//						}
//						
//						procesoCpeService.actualizarVentaPimsCpe(ventaCpeBean);
//					}
//				}
//			}
			
			listaVentasProcesarPims = new ArrayList<VentaPimsCpeBean>();
			
			for(VentaPimsCpeBean bean : ventasSinConfSocioProducto){
				listaVentasProcesarPims.add(bean);
			}
			
//			if(existe){
//				for(VentaPimsCpeBean bean : ventasActualizar){
//					if(bean.getExiste()){
//						listaVentasProcesarPims.add(bean);
//					}
//				}
//				ventasActualizar = new ArrayList<VentaPimsCpeBean>();
//				enviarMensaje(ErrorConstants.COD_ERROR_VENTA_NO_PENDIENTE);
//			}else{
				if(listaVentasProcesarPims.isEmpty()){
					enviarMensaje(ErrorConstants.COD_ERROR_INFO_REGISTRADA_EXITO);
				}else{
					enviarMensaje(ErrorConstants.COD_ERROR_VENTA_SIN_CONF_SOCIO_PRODUCTO);
				}
//			}
				numRegProcesar = listaVentasProcesarPims.size();
		}
	}
	
	public void procesarUpload(){
		
		// Consultar esquema
		
		ParametroCpeBean parametroCpeBean = new ParametroCpeBean();
		parametroCpeBean.setCodParam(Constantes.COD_PARAM_ESQUEMA);
		parametroCpeBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		parametroCpeBean.setCodValor(Constantes.COD_VALOR_ESQUEMA_SEGUROS);
		String eqm = parametroCpeService.listarParametro(parametroCpeBean).get(0).getNomValor();
				
		if(listaVentasProcesarUpload.isEmpty()){
			enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
		}else{
			List<VentaUploadCpeBean> ventasInsertar = new ArrayList<VentaUploadCpeBean>();
			List<VentaUploadCpeBean> ventasSinConfSocioProducto = new ArrayList<VentaUploadCpeBean>();
			
			List<VentaUploadCpeBean> listaTmp = new ArrayList<VentaUploadCpeBean>();
			listaTmp.add(listaVentasProcesarUpload.get(0));
			boolean flagInsertar;
			for(VentaUploadCpeBean bean : listaVentasProcesarUpload){
				flagInsertar = true;
				for(VentaUploadCpeBean beanTmp : listaTmp){
					if(bean.getIdSocio().equals(beanTmp.getIdSocio()) &&
							bean.getIdProducto().equals(beanTmp.getIdProducto()) &&
							bean.getIdTipoComp().equals(beanTmp.getIdTipoComp())){
						flagInsertar = false;
						break;
					}
				}
				if(flagInsertar){
					listaTmp.add(bean);
				}
			}
			
			System.out.println("termino buscqueda agrupada de socio-producto-tipocomprobante");
			for(VentaUploadCpeBean beanTmp : listaTmp){
				ConfiguracionCpeBean conf = new ConfiguracionCpeBean();
				List<ConfiguracionCpeBean> listaConf = new ArrayList<ConfiguracionCpeBean>();
				conf.setIdEmpresa(Constantes.COD_EMPRESA_CARDIF_SEGUROS);
				conf.setIdSocio(beanTmp.getIdSocio().intValue());
				conf.setIdProducto(beanTmp.getIdProducto().intValue());
				conf.setIdTipoComp(beanTmp.getIdTipoComp());
				conf.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
				conf.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
				conf.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
				conf.setEstadoConfig(Constantes.ACTIVO);
				listaConf = configuracionCpeService.listarConfiguracion(conf);
				if(ventasSinConfSocioProducto.isEmpty()){
					if(!listaConf.isEmpty()){
						for(VentaUploadCpeBean bean : listaVentasProcesarUpload){
							if(bean.getIdSocio().equals(beanTmp.getIdSocio()) &&
									bean.getIdProducto().equals(beanTmp.getIdProducto()) &&
									bean.getIdTipoComp().equals(beanTmp.getIdTipoComp())){
								ventasInsertar.add(bean);
							}else{
								ventasSinConfSocioProducto.add(bean);
							}
						}
					}else{
						ventasSinConfSocioProducto.addAll(listaVentasProcesarUpload);
					}
				}else{
					List<VentaUploadCpeBean> ventasSinConfSocioProductoTmp = new ArrayList<VentaUploadCpeBean>();
					if(!listaConf.isEmpty()){
						for(VentaUploadCpeBean bean : ventasSinConfSocioProducto){
							if(bean.getIdSocio().equals(beanTmp.getIdSocio()) &&
									bean.getIdProducto().equals(beanTmp.getIdProducto()) &&
									bean.getIdTipoComp().equals(beanTmp.getIdTipoComp())){
								ventasInsertar.add(bean);
							}else{
								ventasSinConfSocioProductoTmp.add(bean);
							}
						}
						ventasSinConfSocioProducto = new ArrayList<VentaUploadCpeBean>();
						ventasSinConfSocioProducto.addAll(ventasSinConfSocioProductoTmp);
					}
				}
			}
				
			if(!ventasInsertar.isEmpty()){
				CargaVentaCabCpeBean cargaVentaCabCpeBean = new CargaVentaCabCpeBean();
				cargaVentaCabCpeBean.setIdOrigen(origen);
				cargaVentaCabCpeBean.setIdTipoCarga(Constantes.ID_TIPO_CARGA_ONLINE);
				cargaVentaCabCpeBean.setNomArchivo(Constantes.TEXTO_DEFAULT);
				cargaVentaCabCpeBean.setNumRegistro(Long.valueOf(ventasInsertar.size()));
				cargaVentaCabCpeBean.setEstadoCarga(Constantes.COD_VALOR_COMPLETADA);
				cargaVentaCabCpeBean.setUsuarioCarga(usuarioDb);
				cargaVentaCabCpeService.insertarCargaVentaCab(cargaVentaCabCpeBean);
				
				List<VentaCpeBean> listMasivo = new ArrayList<VentaCpeBean>();
				
				for(VentaUploadCpeBean bean : ventasInsertar){
					VentaCpeBean ventaCpeBean = new VentaCpeBean();
					ventaCpeBean.setIdCarga(cargaVentaCabCpeBean.getIdCarga());
					ventaCpeBean.setLlavePims(bean.getLlavePims());
					ventaCpeBean.setLlaveUpload(bean.getLlaveUpload());
					ventaCpeBean.setIdEmpresa(Constantes.COD_EMPRESA_CARDIF_SEGUROS);
					ventaCpeBean.setIdSocio(bean.getIdSocio());
					ventaCpeBean.setNomSocio(bean.getNomSocio());
					ventaCpeBean.setIdProducto(bean.getIdProducto());
					ventaCpeBean.setNomProducto(bean.getNomProducto());
					ventaCpeBean.setFechaEmisionDate(bean.getFecEmision());
					ventaCpeBean.setFechaEmision(getDateToString(bean.getFecEmision()));
					ventaCpeBean.setIdTipoComp(bean.getIdTipoComp());
					ventaCpeBean.setConcepNd(bean.getConcepNd());
					ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
					ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
					ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
					//ventaCpeBean.setIdTipoDocCli("1");//prueba
					ventaCpeBean.setNumDocCli(bean.getNumDocCli());
					ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
					ventaCpeBean.setDirCliente(bean.getDirCli());
					ventaCpeBean.setDepartamento(bean.getDepartamento());
					ventaCpeBean.setProvincia(bean.getProvincia());
					ventaCpeBean.setDistrito(bean.getDistrito());
					ventaCpeBean.setTelefCliente(bean.getTelfCli());
					ventaCpeBean.setMailCliente(bean.getMailCli());
					ventaCpeBean.setNumPoliza(bean.getNumPoliza());
					ventaCpeBean.setFechaVenta(bean.getFecVenta());
					/* Importes Inicio */
					ventaCpeBean.setValFactExport(new BigDecimal(0));
					ventaCpeBean.setBaseImponible(new BigDecimal(0));
					ventaCpeBean.setImpExonerado(new BigDecimal(0));
					ventaCpeBean.setImpInafecto(new BigDecimal(0));
					ventaCpeBean.setValOpGratuitas(new BigDecimal(0));
					ventaCpeBean.setIsc(new BigDecimal(0));
					ventaCpeBean.setIgv(new BigDecimal(0));
					ventaCpeBean.setImpOtros(new BigDecimal(0));
					ventaCpeBean.setImpTotal(bean.getImpTotal());
					/* Importes Fin */
					ventaCpeBean.setEstado(Constantes.COD_ESTADO_VENTA_PENDIENTE);
					ventaCpeBean.setOpenItem(bean.getOpenItem() == null ? "" : bean.getOpenItem().toString());
					ventaCpeBean.setOpenItemRef(bean.getOpenItemRef());
					ventaCpeBean.setColectIndiv(bean.getColectIndiv() == null ? "" : bean.getColectIndiv().toString());
					ventaCpeBean.setPeriodo(getPeriodoActual());
					ventaCpeBean.setFlgPims("0");
					ventaCpeBean.setFlgUpload("0");
					ventaCpeBean.setFlgRv("0");
					ventaCpeBean.setFlgCompletado("0");
					ventaCpeBean.setIdPle(Long.parseLong("0"));
					ventaCpeBean.setPrefijoAlta(bean.getPrefijoAlta());
					
					ventaCpeBean.setIdTramaUpload(bean.getIdTramaUpload());
					ventaCpeBean.setNombreTramaUpload(bean.getNombreTramaUpload());
					
					setUbigeos(ventaCpeBean);
					//setCalculasMontosVenta(ventaCpeBean);
					
//					if(requiereCompletarDatos(ventaCpeBean)){
//						completarDatosPims(ventaCpeBean);
//					}
//					
//					if(requiereCompletarDatos(ventaCpeBean)){
//						completarDatosUpload(ventaCpeBean);
//					}
//					
//					if(requiereCompletarDatos(ventaCpeBean)){
//						completarDatosRegVentasNuevo(ventaCpeBean);
//					}
//					
//					if(requiereCompletarDatos(ventaCpeBean)){
//						completarDatosRegVentasAntiguo(ventaCpeBean);
//					}
					
					listMasivo.add(ventaCpeBean);
				}
				
				guardarVentasMasivoPLSQL(listMasivo);
				
//				VentaCpeBean ventaRequest = new VentaCpeBean();
//				ventaRequest.setIdCarga(cargaVentaCabCpeBean.getIdCarga());
//				List<VentaCpeBean> listVentaCarga = procesoCpeService.listarVentaByIdCarga(ventaRequest);				
//				guardarVentaEstadoMasivoPLSQL(listVentaCarga);
				
				guardarVentaEstadoMasivoPLSQL(cargaVentaCabCpeBean.getIdCarga().intValue(),eqm);
				
				ventasInsertar = new ArrayList<VentaUploadCpeBean>();
				
				setCalcularMontosVentaPLSQL(cargaVentaCabCpeBean.getIdCarga().intValue());
				setActualizaCodProdSunatPLSQL(cargaVentaCabCpeBean.getIdCarga().intValue());
			}
			
//			Boolean existe = false;
//			if(!ventasActualizar.isEmpty()){
//				for(VentaUploadCpeBean bean : ventasActualizar){
//					if(!bean.getEstado().trim().equals(Constantes.COD_ESTADO_VENTA_PENDIENTE)){
//						existe = true;
//						bean.setExiste(true);
//					}else{
//						VentaCpeBean ventaCpeBean = new VentaCpeBean();
//						bean.setExiste(false);
//						ventaCpeBean.setIdVenta(bean.getIdVenta());
//						ventaCpeBean.setLlavePims(bean.getLlavePims());
//						ventaCpeBean.setIdEmpresa(Constantes.COD_EMPRESA_CARDIF_SEGUROS);
//						ventaCpeBean.setIdSocio(bean.getIdSocio());
//						ventaCpeBean.setNomSocio(bean.getNomSocio());
//						ventaCpeBean.setIdProducto(bean.getIdProducto());
//						ventaCpeBean.setNomProducto(bean.getNomProducto());
//						ventaCpeBean.setFechaEmisionDate(bean.getFecEmision());
//						ventaCpeBean.setFechaEmision(getDateToString(bean.getFecEmision()));
//						ventaCpeBean.setIdTipoComp(bean.getIdTipoComp());
//						ventaCpeBean.setConcepNd(bean.getConcepNd());
//						ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
//						ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//						//ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
//						ventaCpeBean.setIdTipoDocCli("1");//prueba
//						ventaCpeBean.setNumDocCli(bean.getNumDocCli());
//						ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
//						ventaCpeBean.setDirCliente(bean.getDirCli());
//						ventaCpeBean.setDepartamento(bean.getDepartamento());
//						ventaCpeBean.setProvincia(bean.getProvincia());
//						ventaCpeBean.setDistrito(bean.getDistrito());
//						ventaCpeBean.setTelefCliente(bean.getTelfCli());
//						ventaCpeBean.setMailCliente(bean.getMailCli());
//						ventaCpeBean.setNumPoliza(bean.getNumPoliza());
//						ventaCpeBean.setFechaVenta(bean.getFecVenta());
////						ventaCpeBean.setValFactExport(new BigDecimal(0));//prueba
////						ventaCpeBean.setBaseImponible(bean.getBaseImponible());
////						ventaCpeBean.setImpExonerado(bean.getImpExonerado());
////						ventaCpeBean.setImpInafecto(bean.getImpInafecto());
////						ventaCpeBean.setValOpGratuitas(new BigDecimal(0));//prueba
////						ventaCpeBean.setIsc(new BigDecimal(0));//prueba
////						ventaCpeBean.setIgv(bean.getIgv());
////						ventaCpeBean.setImpOtros(new BigDecimal(0));//prueba
//						ventaCpeBean.setImpTotal(bean.getImpTotal());
//						ventaCpeBean.setEstado(Constantes.COD_ESTADO_VENTA_PENDIENTE);
//						ventaCpeBean.setOpenItem(bean.getOpenItem().toString());
//						ventaCpeBean.setOpenItemRef(bean.getOpenItemRef());
//						ventaCpeBean.setColectIndiv(bean.getColectIndiv().toString());
//						ventaCpeBean.setPeriodo(getPeriodoActual());
//						ventaCpeBean.setFlgPims("0");
//						ventaCpeBean.setFlgUpload("0");
//						ventaCpeBean.setFlgRv("0");
//						ventaCpeBean.setFlgCompletado("0");
//						ventaCpeBean.setIdPle(Long.parseLong("0"));
//						ventaCpeBean.setPrefijoAlta(bean.getPrefijoAlta());
//						
//						setUbigeos(ventaCpeBean);
//						setCalculasMontosVenta(ventaCpeBean);
//						
//						if(requiereCompletarDatos(ventaCpeBean)){
//							completarDatosPims(ventaCpeBean);
//						}
//						
//						if(requiereCompletarDatos(ventaCpeBean)){
//							completarDatosUpload(ventaCpeBean);
//						}
//						
//						if(requiereCompletarDatos(ventaCpeBean)){
//							completarDatosRegVentasNuevo(ventaCpeBean);
//						}
//						
//						if(requiereCompletarDatos(ventaCpeBean)){
//							completarDatosRegVentasAntiguo(ventaCpeBean);
//						}
//						
//						procesoCpeService.actualizarVentaPimsCpe(ventaCpeBean);
//					}
//				}
//			}
			
			listaVentasProcesarUpload = new ArrayList<VentaUploadCpeBean>();
			
			for(VentaUploadCpeBean bean : ventasSinConfSocioProducto){
				listaVentasProcesarUpload.add(bean);
			}
			
//			if(existe){
//				for(VentaUploadCpeBean bean : ventasActualizar){
//					if(bean.getExiste()){
//						listaVentasProcesarUpload.add(bean);
//					}
//				}
//				ventasActualizar = new ArrayList<VentaUploadCpeBean>();
//				enviarMensaje(ErrorConstants.COD_ERROR_VENTA_NO_PENDIENTE);
//			}else{
				if(listaVentasProcesarUpload.isEmpty()){
					enviarMensaje(ErrorConstants.COD_ERROR_INFO_REGISTRADA_EXITO);
				}else{
					enviarMensaje(ErrorConstants.COD_ERROR_VENTA_SIN_CONF_SOCIO_PRODUCTO);
				}
//			}
				numRegProcesarUpload = listaVentasProcesarUpload.size();
				numRegDupliProcesarUpload = listaVentasProcesarUpload.size();
		}
	}
	
	private void setCalcularMontosVentaPLSQL(int idCarga){
			
//		Properties prop = new Properties();
//		InputStream is = null;
//		try {
//			FacesContext fc = FacesContext.getCurrentInstance();
//			ServletContext sc = (ServletContext) fc.getExternalContext().getContext();
//			String rutaProp = sc.getRealPath(File.separator + "WEB-INF\\classes\\com\\cardif\\satelite\\recursos\\cardif.properties");
//			
//			is = new FileInputStream(rutaProp);
//			prop.load(is);
//		} catch(Exception e) {
//			System.out.println(e.toString());
//		}
		
//		String url = prop.getProperty("satelite.cpe.url");
//		String user = prop.getProperty("satelite.cpe.user");
//		String password = prop.getProperty("satelite.cpe.password");
		
		try{ 
//			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
//	
//			final Connection c = DriverManager.getConnection(url, user, password);
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "" +
	        	"	DECLARE " +
	        	"	  V_IDCARGA CPE_CARGAVENTA_DET.ID_CARGA%TYPE; " +
	        	"	  V_IDEMPRESA CPE_CARGAVENTA_DET.ID_EMPRESA%TYPE; " +
	        	"	  V_IDSOCIO CPE_CARGAVENTA_DET.ID_SOCIO%TYPE; " +
	        	"	  V_IDPRODUCTO CPE_CARGAVENTA_DET.ID_PRODUCTO%TYPE; " +
	        	"	  V_IDTIPOCOMP CPE_CARGAVENTA_DET.ID_TIPO_COMP%TYPE; " +
	        	"	  V_AFECTO_IGV CPE_CONFIGURACION.AFECTO_IGV%TYPE; " +
	        	"	   " +
	        	"	  CURSOR C_VENTAS  IS " + 
	        	"	    SELECT ID_CARGA, ID_EMPRESA,ID_SOCIO,ID_PRODUCTO,ID_TIPO_COMP FROM CPE_CARGAVENTA_DET WHERE ID_CARGA = " + idCarga +
	        	"	    GROUP BY ID_CARGA, ID_EMPRESA,ID_SOCIO,ID_PRODUCTO,ID_TIPO_COMP; " +
	        	" 	   " +	      
	        	"	  CURSOR C_CONFIGURACION(P_IDEMPRESA IN NUMBER,P_IDSOCIO IN NUMBER,P_IDPRODUCTO IN NUMBER,P_IDTIPOCOMP IN NUMBER)  IS " + 
	        	"	    SELECT DISTINCT AFECTO_IGV FROM CPE_CONFIGURACION " +
	        	"	    WHERE ID_SOCIO = P_IDSOCIO AND ID_PRODUCTO = P_IDPRODUCTO AND ID_EMPRESA = P_IDEMPRESA AND ID_TIPO_COMP = P_IDTIPOCOMP AND ESTADO_CONFIG = 1; " +
	        	"	   	" +
	        	"	BEGIN " +
	        	"	  OPEN C_VENTAS; " +
	        	"	  LOOP " +
	        	"	  FETCH C_VENTAS INTO V_IDCARGA, V_IDEMPRESA,V_IDSOCIO,V_IDPRODUCTO,V_IDTIPOCOMP; " +
	        	"	  EXIT WHEN C_VENTAS%NOTFOUND; " +
	        	"	    OPEN C_CONFIGURACION(V_IDEMPRESA,V_IDSOCIO,V_IDPRODUCTO, V_IDTIPOCOMP); " +
	        	"	    LOOP " +
	        	"	    FETCH C_CONFIGURACION INTO V_AFECTO_IGV; " +
	        	"	    EXIT WHEN C_CONFIGURACION%NOTFOUND; " +
	        	"      " +
	        	"	      UPDATE CPE_CARGAVENTA_DET SET BASE_IMPONIBLE = CASE V_AFECTO_IGV WHEN '1' THEN ROUND(IMP_TOTAL/1.18,2) ELSE 0 END,  " +
	        	"	      IGV = CASE V_AFECTO_IGV WHEN '1' THEN IMP_TOTAL - ROUND(IMP_TOTAL/1.18,2) ELSE 0 END, " +
	        	"	      IMP_INAFECTO = CASE V_AFECTO_IGV WHEN '0' THEN IMP_TOTAL ELSE 0 END  " +
	        	"	      WHERE ID_SOCIO = V_IDSOCIO AND ID_PRODUCTO = V_IDPRODUCTO AND ID_EMPRESA = V_IDEMPRESA " +
	        	"			AND ID_TIPO_COMP = V_IDTIPOCOMP AND ID_CARGA = V_IDCARGA; " +
	        	"	   " +
	        	"	    END LOOP; " +
	        	"	    CLOSE C_CONFIGURACION;  " +
	        	"	  END LOOP; " +
	        	"	  CLOSE C_VENTAS;  " +
	        	"	END; ";
	        
	        CallableStatement cs = c.prepareCall(plsql);	
	        cs.execute();
	        cs.close();
	        c.close();
	        
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	private void guardarVentasMasivoPLSQL(List<VentaCpeBean> list){
		
//		Properties prop = new Properties();
//		InputStream is = null;
//		try {
//			FacesContext fc = FacesContext.getCurrentInstance();
//			ServletContext sc = (ServletContext) fc.getExternalContext().getContext();
//			String rutaProp = sc.getRealPath(File.separator + "WEB-INF\\classes\\com\\cardif\\satelite\\recursos\\cardif.properties");
//			
//			is = new FileInputStream(rutaProp);
//			prop.load(is);
//		} catch(Exception e) {
//			System.out.println(e.toString());
//		}
//		
//		String url = prop.getProperty("satelite.cpe.url");
//		String user = prop.getProperty("satelite.cpe.user");
//		String password = prop.getProperty("satelite.cpe.password");
		
		try{
//			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
//	
//			final Connection c = DriverManager.getConnection(url, user, password);
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "Insert Into Cpe_Cargaventa_Det"
	        				+"(Id_Venta, Id_Carga, Id_Trama_Upload, Llave_Upload, Llave_Pims, Id_Empresa," 
	        				+"Id_Socio, Nom_Socio, Id_Producto, Nom_Producto, Fec_Emision, Id_Tipo_Comp, Concep_Nd,"
	        				+"Tipo_Moneda, Fec_Venc, Id_Tipodoc_Cli, Numdoc_Cli, Nomcli_Razsoc, Dir_Cli, Departamento, Provincia, Distrito,"
	        				+"Telf_Cli, Mail_Cli, Id_Tipo_Comp_Ref, Num_Serie_Ref, Num_Cor_Ref, Fec_Emision_Ref, Concepto,"
	        				+"Cod_Prod_Sunat, Num_Poliza, Fec_Venta, Val_Fact_Export, Base_Imponible, Imp_Exonerado, Imp_Inafecto,"
	        				+"Val_Opgratuitas, Isc, Igv, Imp_Otros, Imp_Total, Tipo_Cambio, Estado, Open_Item, Open_Item_Ref,"
	        				+"Area, Observacion, Monto_Usd, Colect_Indiv, Linea, Periodo, Flg_Pims, Flg_Upload, Flg_Rv, Flg_Completado, Id_Ple, NOMBRE_TRAMA_UPLOAD"
	        				+", ID_AGRUPADO, FLG_AGRUPADO)"
	        				+"Values("
	        				+"SEC_CPE_CARGAVENTA_DET.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
	        				+"?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	        
	        PreparedStatement ps = c.prepareStatement(plsql);

	        for(VentaCpeBean bean : list){

	        	ps.setObject(1, bean.getIdCarga());
	        	ps.setObject(2, bean.getIdTramaUpload()); 
				ps.setString(3, bean.getLlaveUpload()); 
				ps.setString(4, bean.getLlavePims()); 
				ps.setString(5, bean.getIdEmpresa()); 
				ps.setObject(6, bean.getIdSocio());
				ps.setString(7, bean.getNomSocio());
				ps.setObject(8, bean.getIdProducto()); 
				ps.setString(9, bean.getNomProducto());
				ps.setString(10, bean.getFechaEmision()); 
				ps.setString(11, bean.getIdTipoComp()); 
				ps.setString(12, bean.getConcepNd());
				ps.setString(13, bean.getTipoMoneda());
				ps.setString(14, bean.getFechaVenc());
				ps.setString(15, bean.getIdTipoDocCli());
				ps.setString(16, bean.getNumDocCli());
				ps.setString(17, bean.getNomCliRazSoc());
				ps.setString(18, bean.getDirCliente());
				ps.setString(19, bean.getDepartamento());
				ps.setString(20, bean.getProvincia());
				ps.setString(21, bean.getDistrito()); 
				ps.setString(22, bean.getTelefCliente()); 
				ps.setString(23, bean.getMailCliente());
				ps.setString(24, bean.getIdTipoCompRef());
				ps.setObject(25, bean.getNumSerieRef());
				ps.setObject(26, bean.getNumCorRef());
				ps.setString(27, bean.getFechaEmisionRef());
				ps.setString(28, bean.getConcepto());
				ps.setObject(29, bean.getCodProdSunat()); 
				ps.setString(30, bean.getNumPoliza());
				ps.setDate(31, bean.getFechaVenta() == null ? null : new java.sql.Date(bean.getFechaVenta().getTime())); 
				ps.setBigDecimal(32, bean.getValFactExport());
				ps.setBigDecimal(33, bean.getBaseImponible());
				ps.setBigDecimal(34, bean.getImpExonerado());
				ps.setBigDecimal(35, bean.getImpInafecto());
				ps.setBigDecimal(36, bean.getValOpGratuitas());
				ps.setBigDecimal(37, bean.getIsc());
				ps.setBigDecimal(38, bean.getIgv());
				ps.setBigDecimal(39, bean.getImpOtros());
				ps.setBigDecimal(40, bean.getImpTotal());
				ps.setBigDecimal(41, bean.getTipoCambio());
				ps.setString(42, bean.getEstado());
				ps.setString(43, bean.getOpenItem()); 
				ps.setString(44, bean.getOpenItemRef()); 
				ps.setString(45, bean.getArea());
				ps.setString(46, bean.getObservacion()); 
				ps.setBigDecimal(47, bean.getMontoUsd());
				ps.setString(48, bean.getColectIndiv());
				ps.setString(49, bean.getLinea());
				ps.setString(50, bean.getPeriodo());
				ps.setString(51, bean.getFlgPims());
				ps.setString(52, bean.getFlgUpload());
				ps.setString(53, bean.getFlgRv());
				ps.setString(54, bean.getFlgCompletado());
				ps.setObject(55, bean.getIdPle());
				ps.setString(56, bean.getNombreTramaUpload());
				ps.setObject(57, bean.getIdAgrupado());
				ps.setString(58, bean.getFlgAgrupado());
				
				ps.addBatch();

	        }
	        
	        ps.executeBatch();
	        ps.close();
	        c.close();
	        
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
//	private void guardarVentaEstadoMasivoPLSQL(List<VentaCpeBean> list){
	private void guardarVentaEstadoMasivoPLSQL(int idCarga, String esquema){
		
		try{
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "" +
	        	"	DECLARE " +
	        	"	  TYPE CPE_VENTA_ESTADO IS TABLE OF "+ esquema + ".CPE_VENTA_ESTADO%ROWTYPE  INDEX BY BINARY_INTEGER; " +
	        	"	   " +
	        	"	  CURSOR C_VENTA_ESTADO IS " + 
	        	"	    SELECT ROW_NUMBER() OVER (ORDER BY CVD.ID_VENTA ) AS ID_VENTAESTADO, CVD.ID_VENTA,1 ESTADO_VENTA, SYSDATE FEC_CREA,CVC.USU_CARGA USU_CREA " +
	        	"	    FROM CPE_CARGAVENTA_DET CVD " + 
	        	"	    INNER JOIN CPE_CARGAVENTA_CAB CVC ON CVD.ID_CARGA = CVC.ID_CARGA " + 
	        	"	    WHERE CVC.ID_CARGA = " + idCarga +
	        	" 	   ;" +	      
	        	"	  A_DATOS CPE_VENTA_ESTADO; " + 
	        	"	   	" +
	        	"	BEGIN " +
	        	"	  OPEN C_VENTA_ESTADO; " +
	        	"	  LOOP " +
	        	"	  	FETCH C_VENTA_ESTADO BULK COLLECT INTO A_DATOS LIMIT 10000; " +
	        	"	  	BEGIN " +
	        	"	    	FORALL i IN 1..A_DATOS.COUNT SAVE EXCEPTIONS " +
	        	"	    	INSERT INTO CPE_VENTA_ESTADO VALUES (SEC_CPE_VENTA_ESTADO.NEXTVAL, A_DATOS(i).ID_VENTA,1,SYSDATE,A_DATOS(i).USU_CREA); " +
	        	"	    EXCEPTION " +
	        	"	    	WHEN OTHERS THEN " +
	        	"      			SYS.DBMS_OUTPUT.PUT_LINE(SQLERRM);" +
	        	"	    END; " +
	        	"	    EXIT WHEN C_VENTA_ESTADO%NOTFOUND; " +
	        	"	  END LOOP;  " +
	        	"	  CLOSE C_VENTA_ESTADO; " +
	        	"	  EXCEPTION " +
	        	"	  	WHEN OTHERS THEN " +
	        	"	    SYS.DBMS_OUTPUT.PUT_LINE(SQLERRM); " +
	        	"	END; ";
	        
	        CallableStatement cs = c.prepareCall(plsql);	
	        cs.execute();
	        cs.close();
	        c.close();
	        
//			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
//	
//			final Connection c = DriverManager.getConnection(url, user, password);
//			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
//	        String plsql = "Insert Into Cpe_Venta_Estado (Id_Ventaestado, Id_Venta, Estado_Venta, Fec_Crea, Usu_Crea) Values"
//	        				+"(SEC_CPE_VENTA_ESTADO.NEXTVAL, ?, ?, SYSDATE, ?)";
//	        
//	        PreparedStatement ps = c.prepareStatement(plsql);
//	        
//	        for(VentaCpeBean bean : list){
//	        	ps.setLong(1, bean.getIdVenta());
//	        	ps.setString(2, Constantes.COD_ESTADO_VENTA_PENDIENTE);
//	        	ps.setString(3, usuarioDb);
//				
//				ps.addBatch();
//	        }
//	        
//	        ps.executeBatch();
//	        ps.close();
//	        c.close();
	        
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	private Boolean requiereCompletarDatos(VentaCpeBean ventaCpeBean){
		if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT) ||
				//ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0) ||
				ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT) ||
				//ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO ||
				//ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO ||
				//ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO ||
				//ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO ||
				//ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO ||
				//ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO ||
				//ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO ||
				//ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO ||
				ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
			return true;
		}else{
			return false;
		}
	}
	
	private void completarDatosUpload(VentaCpeBean ventaCpeBean){
		VentaUploadCpeBean ventaUploadCpeBean = new VentaUploadCpeBean();
		List<VentaUploadCpeBean> listaVentaUploadCpeBean = new ArrayList<VentaUploadCpeBean>();
		ventaUploadCpeBean.setPrefijoAlta(ventaCpeBean.getPrefijoAlta());
		if(ventaCpeBean.getNumDocCli() != null && !ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
			ventaUploadCpeBean.setNumPoliza(null);
			ventaUploadCpeBean.setNumDocCli(ventaCpeBean.getNumDocCli());
		}else{
			ventaUploadCpeBean.setNumPoliza(ventaCpeBean.getNumPoliza());
		}
		listaVentaUploadCpeBean = ventaUploadCpeService.listaCompletarDatosUpload(ventaUploadCpeBean);
		
		for(VentaUploadCpeBean bean : listaVentaUploadCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelfCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
				ventaCpeBean.setImpTotal(bean.getImpTotal());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
			}
		}
	}
	
	private void completarDatosPims(VentaCpeBean ventaCpeBean){
		VentaPimsCpeBean ventaPimsCpeBean = new VentaPimsCpeBean();
		List<VentaPimsCpeBean> listaVentaPimsCpeBean = new ArrayList<VentaPimsCpeBean>();
		ventaPimsCpeBean.setIdProductoPims(ventaCpeBean.getIdProductoPims());
		if(ventaCpeBean.getNumDocCli() != null && !ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
			ventaPimsCpeBean.setNumPoliza(null);
			ventaPimsCpeBean.setNumDocCli(ventaCpeBean.getNumDocCli());
		}else{
			ventaPimsCpeBean.setNumPoliza(ventaCpeBean.getNumPoliza());
		}
		listaVentaPimsCpeBean = ventaPimsCpeService.listaCompletarDatosPims(ventaPimsCpeBean);
		
		for(VentaPimsCpeBean bean : listaVentaPimsCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelfCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
				ventaCpeBean.setImpTotal(bean.getImpTotal());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
			}
		}
	}
	
	private void completarDatosRegVentasNuevo(VentaCpeBean ventaCpeBean){
		VentaCpeBean beanTmp = new VentaCpeBean();
		List<VentaCpeBean> listaVentaCpeBean = new ArrayList<VentaCpeBean>();
		beanTmp.setNumDocCli(ventaCpeBean.getNumDocCli());	
		listaVentaCpeBean = procesoCpeService.buscarVentaCpe(beanTmp);
		
		for(VentaCpeBean bean : listaVentaCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelefCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
				ventaCpeBean.setImpTotal(bean.getImpTotal());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
		}
	}
	
	private void completarDatosRegVentasAntiguo(VentaCpeBean ventaCpeBean){
		TstVentas beanTmp = new TstVentas();
		List<VentaCpeBean> listaVentaCpeBean = new ArrayList<VentaCpeBean>();
		beanTmp.setNumerodoccliente(ventaCpeBean.getNumDocCli());	
		listaVentaCpeBean = registroVentasSuscripcionService.listarRegistroVentas(beanTmp);
		
		for(VentaCpeBean bean : listaVentaCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelefCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
				ventaCpeBean.setImpTotal(bean.getImpTotal());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
			}
		}
	}
	
	public double redondeoDouble(Double numero) {

		double valor = numero;
		String val = valor + "";
		BigDecimal big = new BigDecimal(val);
		big = big.setScale(0, RoundingMode.HALF_UP);

		return big.doubleValue();

	}
	
	private String getDateToString(Date date){
		String strDate = "";
		
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		
		strDate = date == null ? null : dateFormat.format(date);
		
		return strDate;
	}
	
	private String getPeriodoActual(){
		String periodo = "";
		DateFormat dateFormat = new SimpleDateFormat("MMyyyy");
		
		periodo = dateFormat.format(new Date());
		
		return periodo;
	}
	
	public void onchangeSelectAll(){
		if(selectAllPims){
			for(VentaPimsCpeBean bean : listaVentasPims){
				bean.setSeleccionado(true);
			}
		}else{
			for(VentaPimsCpeBean bean : listaVentasPims){
				bean.setSeleccionado(false);
			}
		}
	}
	
	/***********************************************************************************************************************************/
	/*********************************************************** FIN PIMS **************************************************************/
	/***********************************************************************************************************************************/
	
	/***********************************************************************************************************************************/
	/********************************************************* INICIO UPLOAD ***********************************************************/
	/***********************************************************************************************************************************/
	
	public void agregarRegistrosProcesarUpload(){
		Boolean regSeleccionados = false;
		if(tipoBusqueda == 1){//Agrupado
			VentaUploadCpeBean beanAgrupado;
			List<VentaUploadCpeBean> listaPorAgrupado;
			List<VentaUploadAgrupadoCpeBean> listaTmp = new ArrayList<VentaUploadAgrupadoCpeBean>();
			for(VentaUploadAgrupadoCpeBean bean : listaVentasAgrupadoUpload){
				if(bean.getSeleccionado()){
					beanAgrupado = new VentaUploadCpeBean();
					listaPorAgrupado = new ArrayList<VentaUploadCpeBean>();
					beanAgrupado.setProceso(bean.getProceso());
					beanAgrupado.setLlaveUpload(setLLaveUploadAgrupado(bean));
					//listaPorAgrupado = ventaUploadCpeService.listarVentasDetalladoUpload(beanAgrupado);
					/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 12:50 - Se envia por parametro la lista de tipo movimiento*/
					beanAgrupado.setListTipoMovimiento(bean.getListTipoMovimiento());
					/*TIP_PER0100_CC09_13 FIN*/
					listaPorAgrupado = listarVentasDetalladoUpload(beanAgrupado);
					for(VentaUploadCpeBean det : listaPorAgrupado){
						det.setIdSocio(bean.getIdSocio());
						det.setIdProducto(bean.getIdProducto());
						det.setIdProductoPims(bean.getIdProductoPims());
						det.setNomSocio(bean.getNomSocio());
						det.setNomProducto(bean.getNomProducto());
						det.setNomTipoDocCli(setNomTipoDocCli(det.getIdTipoDocCli(), det.getNumDocCli()));
						listaVentasProcesarUpload.add(det);
					}
					regSeleccionados = true;
					listaTmp.add(bean);
				}
			}
			
//			VentaCpeBean ventaUpload;
//			List<VentaCpeBean> listaVentaUpload;
//			
//			for(VentaUploadCpeBean bean : listaVentasProcesarUpload){
//				listaVentaUpload = new ArrayList<VentaCpeBean>();
//				ventaUpload = new VentaCpeBean();
//				ventaUpload.setLlaveUpload(bean.getLlaveUpload());
//				listaVentaUpload = procesoCpeService.buscarVentaPimsUploadCpe(ventaUpload);
//				
//				bean.setExiste(listaVentaUpload.isEmpty() ? false : true);
//			}
			
			if(regSeleccionados){
				for(VentaUploadAgrupadoCpeBean bean : listaTmp){
					listaVentasAgrupadoUpload.remove(bean);
				}
				numRegBusquedaUpload = listaVentasAgrupadoUpload.size();
				numRegProcesarUpload = listaVentasProcesarUpload.size();
				//numRegDupliProcesarUpload = obtenerNumSeleccionadosDuplicadosUpload(listaVentasProcesarUpload);
				numRegDupliProcesarUpload = 0;
			}else{
				enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
			}
		}else{//Detallado
			for(VentaUploadCpeBean bean : listaVentasUpload){
				if(bean.getSeleccionado()){
					listaVentasProcesarUpload.add(bean);
					regSeleccionados = true;
				}
			}
			if(regSeleccionados){
				for(VentaUploadCpeBean bean : listaVentasProcesarUpload){
					listaVentasUpload.remove(bean);
				}
				numRegBusquedaUpload = listaVentasUpload.size();
				numSelecDupliDetUpload = obtenerNumSeleccionadosDuplicadosUpload(listaVentasUpload);
				numRegProcesarUpload = listaVentasProcesarUpload.size();
				numRegDupliProcesarUpload = obtenerNumSeleccionadosDuplicadosUpload(listaVentasProcesarUpload);
			}else{
				enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
			}
		}		
		selectAllUploadAgrupado = false;
		selectAllUploadDetallado = false;
	}
	
	private int obtenerNumSeleccionadosDuplicadosUpload(List<VentaUploadCpeBean> listaVentaUpload){
		int numDuplicados = 0;
		for(VentaUploadCpeBean venta : listaVentaUpload){
			if(venta.getSeleccionado() != null){
				if(venta.getSeleccionado()){
					if(venta.getExiste()){
						numDuplicados = numDuplicados+1;
					}
				}
			}else{//SOLO PARA AGRUPADO
				if(venta.getExiste()){
					numDuplicados = numDuplicados+1;
				}
			}
		}
		return numDuplicados;
	}
	
	private String setLLaveUploadAgrupado(VentaUploadAgrupadoCpeBean ventaAgrupada){
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		productoCpeBean.setIdSocio(ventaAgrupada.getIdSocio().intValue());
		productoCpeBean.setIdProducto(ventaAgrupada.getIdProducto().intValue());
		productoCpeBean = productoCpeService.listarProducto(productoCpeBean).get(0);
		
		return productoCpeBean.getKeyColumsUpload();
	}
	
	public void eliminarVentaProcesoUpload(){
		listaVentasProcesarUpload.remove(ventaSeleccionadaUpload);
		numRegProcesarUpload = listaVentasProcesarUpload.size();
		//numRegDupliProcesarUpload = obtenerNumSeleccionadosDuplicadosUpload(listaVentasProcesarUpload);
		numRegDupliProcesarUpload = 0;
	}
	
	public void onchangeSelectAllUploadDetallado(){
		numSelecDupliDetUpload = 0;
		if(selectAllUploadDetallado){
			for(VentaUploadCpeBean bean : listaVentasUpload){
				bean.setSeleccionado(true);
				if(bean.getExiste()){
					numSelecDupliDetUpload = numSelecDupliDetUpload+1;
				}
			}
		}else{
			for(VentaUploadCpeBean bean : listaVentasUpload){
				bean.setSeleccionado(false);
			}
		}
	}
	
	public void onchangeSelectUploadDetallado(){
		VentaUploadCpeBean bean = (VentaUploadCpeBean)FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{upload}", VentaUploadCpeBean.class);
		if(bean.getSeleccionado()){
			if(bean.getExiste()){
				numSelecDupliDetUpload = numSelecDupliDetUpload+1;
			}
		}else{
			if(bean.getExiste()){
				numSelecDupliDetUpload = numSelecDupliDetUpload-1;
			}
		}
	}
	
	public void deseleccionarDuplicados(){
		for(VentaUploadCpeBean bean : listaVentasUpload){
			if(bean.getSeleccionado()){
				if(bean.getExiste()){
					bean.setSeleccionado(false);
					numSelecDupliDetUpload = numSelecDupliDetUpload-1;
				}
			}
		}
	}
	
	public void onchangeSelectAllUploadAgrupado(){
		if(selectAllUploadAgrupado){
			for(VentaUploadAgrupadoCpeBean bean : listaVentasAgrupadoUpload){
				bean.setSeleccionado(true);
			}
		}else{
			for(VentaUploadAgrupadoCpeBean bean : listaVentasAgrupadoUpload){
				bean.setSeleccionado(false);
			}
		}
	}
	
	public void eliminarDuplicados(){
		List<VentaUploadCpeBean> listaTmp = new ArrayList<VentaUploadCpeBean>();
		for(VentaUploadCpeBean bean : listaVentasProcesarUpload){
			if(bean.getExiste()){
				numRegDupliProcesarUpload = numRegDupliProcesarUpload-1;
			}else{
				listaTmp.add(bean);
			}
		}
		listaVentasProcesarUpload = new ArrayList<VentaUploadCpeBean>();
		listaVentasProcesarUpload.addAll(listaTmp);
		
		numRegProcesarUpload = listaVentasProcesarUpload.size();
	}
	
	/***********************************************************************************************************************************/
	/********************************************************** FIN UPLOAD *************************************************************/
	/***********************************************************************************************************************************/
	
	
	/***********************************************************************************************************************************/
	/************************************************** ACTUALIZAR CODIGO PROD SUNAT ***************************************************/
	/***********************************************************************************************************************************/
	private void setActualizaCodProdSunatPLSQL(int idCarga){
//		Properties prop = new Properties();
//		InputStream is = null;
		try {
//			FacesContext fc = FacesContext.getCurrentInstance();
//			ServletContext sc = (ServletContext) fc.getExternalContext().getContext();
//			String rutaProp = sc.getRealPath(File.separator + "WEB-INF\\classes\\com\\cardif\\satelite\\recursos\\cardif.properties");
//			
//			is = new FileInputStream(rutaProp);
//			prop.load(is);
//		
//			String url = prop.getProperty("satelite.cpe.url");
//			String user = prop.getProperty("satelite.cpe.user");
//			String password = prop.getProperty("satelite.cpe.password");
//		
//		
//			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
//	
//			final Connection c = DriverManager.getConnection(url, user, password);
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "" +
	        	"	DECLARE " +
	        	"	  V_IDCARGA CPE_CARGAVENTA_DET.ID_CARGA%TYPE; " +
	        	"	  V_IDSOCIO CPE_CARGAVENTA_DET.ID_SOCIO%TYPE; " +
	        	"	  V_IDPRODUCTO CPE_CARGAVENTA_DET.ID_PRODUCTO%TYPE; " +
	        	"	  V_CODPRODSUNAT CPE_PRODUCTO.COD_PROD_SUNAT%TYPE; " +
	        	"	   " +
	        	"	  CURSOR C_VENTAS  IS " + 
	        	"	    SELECT ID_CARGA, ID_SOCIO,ID_PRODUCTO FROM CPE_CARGAVENTA_DET WHERE ID_CARGA = " + idCarga +
	        	"	    GROUP BY ID_CARGA, ID_SOCIO,ID_PRODUCTO; " +
	        	" 	   " +	      
	        	"	  CURSOR C_PRODUCTO(P_IDSOCIO IN NUMBER,P_IDPRODUCTO IN NUMBER)  IS  " + 
	        	"	    SELECT COD_PROD_SUNAT FROM CPE_PRODUCTO " +
	        	"	    WHERE ID_SOCIO = P_IDSOCIO AND ID_PRODUCTO = P_IDPRODUCTO AND TIPO_PRODUCTO IN (1,2); " +
	        	"	   	" +
	        	"	BEGIN " +
	        	"	  OPEN C_VENTAS; " +
	        	"	  LOOP " +
	        	"	  FETCH C_VENTAS INTO V_IDCARGA, V_IDSOCIO,V_IDPRODUCTO; " +
	        	"	  EXIT WHEN C_VENTAS%NOTFOUND; " +
	        	"	    OPEN C_PRODUCTO(V_IDSOCIO,V_IDPRODUCTO); " +
	        	"	    LOOP " +
	        	"	    FETCH C_PRODUCTO INTO V_CODPRODSUNAT; " +
	        	"	    EXIT WHEN C_PRODUCTO%NOTFOUND; " +
	        	"      " +
	        	"	      UPDATE CPE_CARGAVENTA_DET SET COD_PROD_SUNAT = V_CODPRODSUNAT  " +
	        	"	      WHERE ID_SOCIO = V_IDSOCIO AND ID_PRODUCTO = V_IDPRODUCTO AND ID_CARGA = V_IDCARGA; " +
	        	"	   " +
	        	"	    END LOOP; " +
	        	"	    CLOSE C_PRODUCTO;  " +
	        	"	  END LOOP; " +
	        	"	  CLOSE C_VENTAS;  " +
	        	"	END; ";
	        
	        CallableStatement cs = c.prepareCall(plsql);	
	        cs.execute();
	        cs.close();
	        c.close();
	        
		} catch (Exception e) {
			System.out.println(e.toString());
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/***********************************************************************************************************************************/
	/******************************************************* FIN CODIGO PROD SUNAT *****************************************************/
	/***********************************************************************************************************************************/
	
	public Date getTimeVersion() {
		return timeVersion;
	}

	public void setTimeVersion(Date timeVersion) {
		this.timeVersion = timeVersion;
	}

	public boolean isBloqueaArchivos() {
		return bloqueaArchivos;
	}

	public void setBloqueaArchivos(boolean bloqueaArchivos) {
		this.bloqueaArchivos = bloqueaArchivos;
	}

	public boolean isBloqueaPims() {
		return bloqueaPims;
	}

	public void setBloqueaPims(boolean bloqueaPims) {
		this.bloqueaPims = bloqueaPims;
	}

	public boolean isBloqueaUpload() {
		return bloqueaUpload;
	}

	public void setBloqueaUpload(boolean bloqueaUpload) {
		this.bloqueaUpload = bloqueaUpload;
	}

	public boolean isBloqueaUploadDetalle() {
		return bloqueaUploadDetalle;
	}

	public void setBloqueaUploadDetalle(boolean bloqueaUploadDetalle) {
		this.bloqueaUploadDetalle = bloqueaUploadDetalle;
	}

	public boolean isBloqueaUploadAgrupado() {
		return bloqueaUploadAgrupado;
	}

	public void setBloqueaUploadAgrupado(boolean bloqueaUploadAgrupado) {
		this.bloqueaUploadAgrupado = bloqueaUploadAgrupado;
	}

	public boolean isBloqueaArchivosGrilla() {
		return bloqueaArchivosGrilla;
	}

	public void setBloqueaArchivosGrilla(boolean bloqueaArchivosGrilla) {
		this.bloqueaArchivosGrilla = bloqueaArchivosGrilla;
	}

	public boolean isBloqueaBusqueda() {
		return bloqueaBusqueda;
	}

	public void setBloqueaBusqueda(boolean bloqueaBusqueda) {
		this.bloqueaBusqueda = bloqueaBusqueda;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public List<SelectItem> getOrigenesItems() {
		return origenesItems;
	}

	public void setOrigenesItems(List<SelectItem> origenesItems) {
		this.origenesItems = origenesItems;
	}

	public int getTipoCarga() {
		return tipoCarga;
	}

	public void setTipoCarga(int tipoCarga) {
		this.tipoCarga = tipoCarga;
	}

	public boolean isDisabledRutaPredeterminada() {
		return disabledRutaPredeterminada;
	}

	public void setDisabledRutaPredeterminada(boolean disabledRutaPredeterminada) {
		this.disabledRutaPredeterminada = disabledRutaPredeterminada;
	}

	public boolean isDisabledNomArchivo() {
		return disabledNomArchivo;
	}

	public void setDisabledNomArchivo(boolean disabledNomArchivo) {
		this.disabledNomArchivo = disabledNomArchivo;
	}

	public String getRutaPredeterminada() {
		return rutaPredeterminada;
	}

	public void setRutaPredeterminada(String rutaPredeterminada) {
		this.rutaPredeterminada = rutaPredeterminada;
	}

	public boolean isDisabledPorRuta() {
		return disabledPorRuta;
	}

	public void setDisabledPorRuta(boolean disabledPorRuta) {
		this.disabledPorRuta = disabledPorRuta;
	}

	public boolean isBloqueoProcesarArchivo() {
		return bloqueoProcesarArchivo;
	}

	public void setBloqueoProcesarArchivo(boolean bloqueoProcesarArchivo) {
		this.bloqueoProcesarArchivo = bloqueoProcesarArchivo;
	}

	public int getTipoBusqueda() {
		return tipoBusqueda;
	}

	public void setTipoBusqueda(int tipoBusqueda) {
		this.tipoBusqueda = tipoBusqueda;
	}

	public String getSocio() {
		return socio;
	}

	public void setSocio(String socio) {
		this.socio = socio;
	}

	public Date getFecCargaDesde() {
		return fecCargaDesde;
	}

	public void setFecCargaDesde(Date fecCargaDesde) {
		this.fecCargaDesde = fecCargaDesde;
	}

	public Date getFecCargaHasta() {
		return fecCargaHasta;
	}

	public void setFecCargaHasta(Date fecCargaHasta) {
		this.fecCargaHasta = fecCargaHasta;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getTipComprobante() {
		return tipComprobante;
	}

	public void setTipComprobante(String tipComprobante) {
		this.tipComprobante = tipComprobante;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getNumComprobante() {
		return numComprobante;
	}

	public void setNumComprobante(String numComprobante) {
		this.numComprobante = numComprobante;
	}

	public String getCertificado() {
		return certificado;
	}

	public void setCertificado(String certificado) {
		this.certificado = certificado;
	}

	public String getCodUpload() {
		return codUpload;
	}

	public void setCodUpload(String codUpload) {
		this.codUpload = codUpload;
	}

	public String getLote() {
		return lote;
	}

	public void setLote(String lote) {
		this.lote = lote;
	}

	public String getTipoDoc() {
		return tipoDoc;
	}

	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getProducto() {
		return producto;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public boolean isDisabledTipoBusqueda() {
		return disabledTipoBusqueda;
	}

	public void setDisabledTipoBusqueda(boolean disabledTipoBusqueda) {
		this.disabledTipoBusqueda = disabledTipoBusqueda;
	}

	public ParametroCpeService getParametroCpeService() {
		return parametroCpeService;
	}

	public void setParametroCpeService(ParametroCpeService parametroService) {
		this.parametroCpeService = parametroService;
	}

	public List<SelectItem> getSocioItems() {
		return socioItems;
	}

	public void setSocioItems(List<SelectItem> socioItems) {
		this.socioItems = socioItems;
	}

	public SocioCpeService getSocioCpeService() {
		return socioCpeService;
	}

	public void setSocioCpeService(SocioCpeService socioCpeService) {
		this.socioCpeService = socioCpeService;
	}

	public List<SelectItem> getMonedaItems() {
		return monedaItems;
	}

	public void setMonedaItems(List<SelectItem> monedaItems) {
		this.monedaItems = monedaItems;
	}

	public List<SelectItem> getTipoComprobanteItems() {
		return tipoComprobanteItems;
	}

	public void setTipoComprobanteItems(List<SelectItem> tipoComprobanteItems) {
		this.tipoComprobanteItems = tipoComprobanteItems;
	}

	public List<SelectItem> getEstadoVentaItems() {
		return estadoVentaItems;
	}

	public void setEstadoVentaItems(List<SelectItem> estadoVentaItems) {
		this.estadoVentaItems = estadoVentaItems;
	}

	public List<SelectItem> getTipoDocumentoItems() {
		return tipoDocumentoItems;
	}

	public void setTipoDocumentoItems(List<SelectItem> tipoDocumentoItems) {
		this.tipoDocumentoItems = tipoDocumentoItems;
	}

	public List<SelectItem> getProductoItems() {
		return productoItems;
	}

	public void setProductoItems(List<SelectItem> productoItems) {
		this.productoItems = productoItems;
	}

	public ProductoCpeService getProductoCpeService() {
		return productoCpeService;
	}

	public void setProductoCpeService(ProductoCpeService productoCpeService) {
		this.productoCpeService = productoCpeService;
	}

	public List<SelectItem> getSsisGeneralCfgItems() {
		return ssisGeneralCfgItems;
	}

	public void setSsisGeneralCfgItems(List<SelectItem> ssisGeneralCfgItems) {
		this.ssisGeneralCfgItems = ssisGeneralCfgItems;
	}

	public String getNomArchivo() {
		return nomArchivo;
	}

	public void setNomArchivo(String nomArchivo) {
		this.nomArchivo = nomArchivo;
	}

	public String getRutanombreDestino() {
		return RutanombreDestino;
	}

	public void setRutanombreDestino(String rutanombreDestino) {
		RutanombreDestino = rutanombreDestino;
	}

	/*
	 * TODO BSC 12/09/2019 No se usa
	public File getArchivo() {
		return archivo;
	}

	public void setArchivo(File archivo) {
		this.archivo = archivo;
	}
	 */

	public List<CampoLayoutCpeBean> getListCamposLayoutCpe() {
		return listCamposLayoutCpe;
	}

	public void setListCamposLayoutCpe(List<CampoLayoutCpeBean> listCamposLayoutCpe) {
		this.listCamposLayoutCpe = listCamposLayoutCpe;
	}

	public boolean isDisableProducto() {
		return disableProducto;
	}

	public void setDisableProducto(boolean disableProducto) {
		this.disableProducto = disableProducto;
	}

	public boolean isDisableEstado() {
		return disableEstado;
	}

	public void setDisableEstado(boolean disableEstado) {
		this.disableEstado = disableEstado;
	}

	public List<VentaPimsCpeBean> getListaVentasPims() {
		return listaVentasPims;
	}

	public void setListaVentasPims(List<VentaPimsCpeBean> listaVentasPims) {
		this.listaVentasPims = listaVentasPims;
	}

	public CargaVentaCabCpeService getCargaVentaCabCpeService() {
		return cargaVentaCabCpeService;
	}

	public void setCargaVentaCabCpeService(
			CargaVentaCabCpeService cargaVentaCabCpeService) {
		this.cargaVentaCabCpeService = cargaVentaCabCpeService;
	}

	public CampoLayoutCpeService getCampoLayoutCpeService() {
		return campoLayoutCpeService;
	}

	public void setCampoLayoutCpeService(CampoLayoutCpeService campoLayoutCpeService) {
		this.campoLayoutCpeService = campoLayoutCpeService;
	}

	public VentaPimsCpeService getVentaPimsCpeService() {
		return ventaPimsCpeService;
	}

	public void setVentaPimsCpeService(VentaPimsCpeService ventaPimsCpeService) {
		this.ventaPimsCpeService = ventaPimsCpeService;
	}

	public boolean isDisableNumComp() {
		return disableNumComp;
	}

	public void setDisableNumComp(boolean disableNumComp) {
		this.disableNumComp = disableNumComp;
	}

	public boolean isDisableCodUpload() {
		return disableCodUpload;
	}

	public void setDisableCodUpload(boolean disableCodUpload) {
		this.disableCodUpload = disableCodUpload;
	}

	public boolean isDisableLote() {
		return disableLote;
	}

	public void setDisableLote(boolean disableLote) {
		this.disableLote = disableLote;
	}

	public boolean isDisableTipoDoc() {
		return disableTipoDoc;
	}

	public void setDisableTipoDoc(boolean disableTipoDoc) {
		this.disableTipoDoc = disableTipoDoc;
	}

	public boolean isDisableCliente() {
		return disableCliente;
	}

	public void setDisableCliente(boolean disableCliente) {
		this.disableCliente = disableCliente;
	}

	public boolean isDisableTipoComp() {
		return disableTipoComp;
	}

	public void setDisableTipoComp(boolean disableTipoComp) {
		this.disableTipoComp = disableTipoComp;
	}

	public List<VentaPimsCpeBean> getListaVentasProcesarPims() {
		return listaVentasProcesarPims;
	}

	public void setListaVentasProcesarPims(
			List<VentaPimsCpeBean> listaVentasProcesarPims) {
		this.listaVentasProcesarPims = listaVentasProcesarPims;
	}

	public VentaPimsCpeBean getVentaSeleccionada() {
		return ventaSeleccionada;
	}

	public void setVentaSeleccionada(VentaPimsCpeBean ventaSeleccionada) {
		this.ventaSeleccionada = ventaSeleccionada;
	}

	public UbigeoCpeService getUbigeoCpeService() {
		return ubigeoCpeService;
	}

	public void setUbigeoCpeService(UbigeoCpeService ubigeoCpeService) {
		this.ubigeoCpeService = ubigeoCpeService;
	}

	public ProcesoCpeService getProcesoCpeService() {
		return procesoCpeService;
	}

	public void setProcesoCpeService(ProcesoCpeService procesoCpeService) {
		this.procesoCpeService = procesoCpeService;
	}

	public int getNumRegBusqueda() {
		return numRegBusqueda;
	}

	public void setNumRegBusqueda(int numRegBusqueda) {
		this.numRegBusqueda = numRegBusqueda;
	}

	public int getNumRegProcesar() {
		return numRegProcesar;
	}

	public void setNumRegProcesar(int numRegProcesar) {
		this.numRegProcesar = numRegProcesar;
	}
	
	public String getMensajeValidacionArchivo() {
		return mensajeValidacionArchivo;
	}

	public void setMensajeValidacionArchivo(String mensajeValidacionArchivo) {
		this.mensajeValidacionArchivo = mensajeValidacionArchivo;
	}
	
	public boolean isDisabledCargar() {
		return disabledCargar;
	}

	public void setDisabledCargar(boolean disabledCargar) {
		this.disabledCargar = disabledCargar;
	}
	
	public String getIdFileUploadComponent() {
		return idFileUploadComponent;
	}

	public void setIdFileUploadComponent(String idFileUploadComponent) {
		this.idFileUploadComponent = idFileUploadComponent;
	}
	
	public List<VentaCpeBean> getListVentaCpe() {
		return listVentaCpe;
	}

	public void setListVentaCpe(List<VentaCpeBean> listVentaCpe) {
		this.listVentaCpe = listVentaCpe;
	}
	
	public int getNroRegistros() {
		return nroRegistros;
	}

	public void setNroRegistros(int nroRegistros) {
		this.nroRegistros = nroRegistros;
	}
	
	public boolean isActionOnline() {
		return actionOnline;
	}

	public void setActionOnline(boolean actionOnline) {
		this.actionOnline = actionOnline;
	}

	public List<VentaUploadCpeBean> getListaVentasUpload() {
		return listaVentasUpload;
	}

	public void setListaVentasUpload(List<VentaUploadCpeBean> listaVentasUpload) {
		this.listaVentasUpload = listaVentasUpload;
	}

	public List<VentaUploadCpeBean> getListaVentasProcesarUpload() {
		return listaVentasProcesarUpload;
	}

	public void setListaVentasProcesarUpload(
			List<VentaUploadCpeBean> listaVentasProcesarUpload) {
		this.listaVentasProcesarUpload = listaVentasProcesarUpload;
	}

	public VentaUploadCpeBean getVentaSeleccionadaUpload() {
		return ventaSeleccionadaUpload;
	}

	public void setVentaSeleccionadaUpload(
			VentaUploadCpeBean ventaSeleccionadaUpload) {
		this.ventaSeleccionadaUpload = ventaSeleccionadaUpload;
	}

	public int getNumRegBusquedaUpload() {
		return numRegBusquedaUpload;
	}

	public void setNumRegBusquedaUpload(int numRegBusquedaUpload) {
		this.numRegBusquedaUpload = numRegBusquedaUpload;
	}

	public int getNumRegProcesarUpload() {
		return numRegProcesarUpload;
	}

	public void setNumRegProcesarUpload(int numRegProcesarUpload) {
		this.numRegProcesarUpload = numRegProcesarUpload;
	}

	public boolean isDisableMoneda() {
		return disableMoneda;
	}

	public void setDisableMoneda(boolean disableMoneda) {
		this.disableMoneda = disableMoneda;
	}

	public boolean isDisableCertificado() {
		return disableCertificado;
	}

	public void setDisableCertificado(boolean disableCertificado) {
		this.disableCertificado = disableCertificado;
	}

	public boolean isDisableNumDoc() {
		return disableNumDoc;
	}

	public void setDisableNumDoc(boolean disableNumDoc) {
		this.disableNumDoc = disableNumDoc;
	}

	public VentaUploadCpeService getVentaUploadCpeService() {
		return ventaUploadCpeService;
	}

	public void setVentaUploadCpeService(VentaUploadCpeService ventaUploadCpeService) {
		this.ventaUploadCpeService = ventaUploadCpeService;
	}

	public Boolean getSelectAllPims() {
		return selectAllPims;
	}

	public void setSelectAllPims(Boolean selectAllPims) {
		this.selectAllPims = selectAllPims;
	}

	public Boolean getSelectAllUploadAgrupado() {
		return selectAllUploadAgrupado;
	}

	public void setSelectAllUploadAgrupado(Boolean selectAllUploadAgrupado) {
		this.selectAllUploadAgrupado = selectAllUploadAgrupado;
	}

	public Boolean getSelectAllUploadDetallado() {
		return selectAllUploadDetallado;
	}

	public void setSelectAllUploadDetallado(Boolean selectAllUploadDetallado) {
		this.selectAllUploadDetallado = selectAllUploadDetallado;
	}

	public List<VentaUploadAgrupadoCpeBean> getListaVentasAgrupadoUpload() {
		return listaVentasAgrupadoUpload;
	}

	public void setListaVentasAgrupadoUpload(
			List<VentaUploadAgrupadoCpeBean> listaVentasAgrupadoUpload) {
		this.listaVentasAgrupadoUpload = listaVentasAgrupadoUpload;
	}

	public VentaUploadAgrupadoCpeBean getVentaSeleccionadaAgrupadaUpload() {
		return ventaSeleccionadaAgrupadaUpload;
	}

	public void setVentaSeleccionadaAgrupadaUpload(
			VentaUploadAgrupadoCpeBean ventaSeleccionadaAgrupadaUpload) {
		this.ventaSeleccionadaAgrupadaUpload = ventaSeleccionadaAgrupadaUpload;
	}

	public RepParametroService getRepParametroService() {
		return repParametroService;
	}

	public void setRepParametroService(RepParametroService repParametroService) {
		this.repParametroService = repParametroService;
	}

	public ConfiguracionCpeService getConfiguracionCpeService() {
		return configuracionCpeService;
	}

	public void setConfiguracionCpeService(
			ConfiguracionCpeService configuracionCpeService) {
		this.configuracionCpeService = configuracionCpeService;
	}

	public RegistroVentasSuscripcionService getRegistroVentasSuscripcionService() {
		return registroVentasSuscripcionService;
	}

	public void setRegistroVentasSuscripcionService(
			RegistroVentasSuscripcionService registroVentasSuscripcionService) {
		this.registroVentasSuscripcionService = registroVentasSuscripcionService;
	}

	public SsisService getSsisService() {
		return ssisService;
	}

	public void setSsisService(SsisService ssisService) {
		this.ssisService = ssisService;
	}

	public SimpleDateFormat getFormatoddMMaaaa() {
		return formatoddMMaaaa;
	}

	public void setFormatoddMMaaaa(SimpleDateFormat formatoddMMaaaa) {
		this.formatoddMMaaaa = formatoddMMaaaa;
	}

	public int getNumSelecDupliDetUpload() {
		return numSelecDupliDetUpload;
	}

	public void setNumSelecDupliDetUpload(int numSelecDupliDetUpload) {
		this.numSelecDupliDetUpload = numSelecDupliDetUpload;
	}

	public int getNumRegDupliProcesarUpload() {
		return numRegDupliProcesarUpload;
	}

	public void setNumRegDupliProcesarUpload(int numRegDupliProcesarUpload) {
		this.numRegDupliProcesarUpload = numRegDupliProcesarUpload;
	}
	
}
