 package com.cardif.satelite.cpe.controller;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.HistorialReporteCpeBean;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.ReporteComprobantesElectronicosBean;
import com.cardif.satelite.cpe.bean.ReporteRegistroVentasBean;
import com.cardif.satelite.cpe.bean.ReporteRegistroVentasPleBean;
import com.cardif.satelite.cpe.bean.TipoCambioCpeBean;
import com.cardif.satelite.cpe.service.HistorialReporteCpeService;
import com.cardif.satelite.cpe.service.ParametroCpeService;
import com.cardif.satelite.cpe.service.ProcesoCpeService;
import com.cardif.satelite.cpe.service.ReportesCpeService;
import com.cardif.satelite.cpe.service.TipoCambioCpeService;
import com.cardif.satelite.cpe.service.UbigeoCpeService;
import com.cardif.satelite.cpe.util.DataSourceSatelite;
import com.cardif.satelite.util.Utilitarios;
import com.cardif.sunsystems.services.SunComponenteService;
import com.cardif.sunsystems.services.SunSeguridadService;
import com.cardif.sunsystems.util.ConstantesSun;

@Controller("cpeGeneraReporteController")
@Scope("session")
public class CpeGeneraReporteController extends BaseController implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final Logger LOGGER = Logger.getLogger(CargaVentaController.class);

	private String usuarioSesion;
	private Boolean mostrarPeriodoRegVentas;
	private String periodoReporte;
	private String cambioUsdPen;
	private Date fecCargaDesde;
	private Date fecCargaHasta;

	private String user;
	private String pass;
	private String Token;

	private boolean flagPeriodo;
	private boolean flagExportar;
	private boolean mostrarBoton;

	private String reporteSelected;
	private List<SelectItem> reporteItems;
	private String tipoComprobanteSelected;
	private List<SelectItem> tipoComprobanteItems;
	private String estadoSelected;
	private List<SelectItem> estadoItems;
	private String empresa;
	private List<SelectItem> empresaItems;

	private SimpleDateFormat formatoddMMaaaa;

	SunSeguridadService seguridad = null;
	SunComponenteService componentes = null;

	@Autowired
	private ParametroCpeService parametroCpeService;
	@Autowired
	private ReportesCpeService reportesCpeService;
	@Autowired
	private HistorialReporteCpeService historialReporteCpeService;
	@Autowired
	private ProcesoCpeService procesoCpeService;
	@Autowired
	private UbigeoCpeService ubigeoCpeService;
	@Autowired
	private TipoCambioCpeService tipoCambioCpeService;

	@Autowired
	private DataSourceSatelite dataSourceSatelite;

	@Override
	@PostConstruct
	public String inicio() {
		try {
			if (tieneAcceso()) {
				usuarioSesion = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
				inicializarVariables();
				llenarCombos();
				formatoddMMaaaa = new SimpleDateFormat("dd/MM/yyyy");
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}

	public CpeGeneraReporteController() {
		seguridad = new SunSeguridadService();
	}

	public void inicializarVariables() {
		mostrarPeriodoRegVentas = false;
		mostrarBoton = false;
	}

	private void llenarCombos() {
		empresaItems = listarParametro(Constantes.COD_PARAM_CPE_EMPRESA, false);
		reporteItems = listarParametro(Constantes.COD_PARAM_TIPO_REPORTES, false);
		tipoComprobanteItems = listarParametro(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES, true);
		estadoItems = listarParametro(Constantes.COD_PARAM_CPE_ESTADO_VENTA, true);
	}

	private List<SelectItem> listarParametro(String codParametro, boolean insertarSeleccionar) {
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listaParametroBean = new ArrayList<ParametroCpeBean>();
		listaParametroBean = parametroCpeService.listarParametro(parametroBean);
		List<SelectItem> combo = new ArrayList<SelectItem>();
		if (insertarSeleccionar) {
			combo.add(new SelectItem(Constantes.VALOR_DEFECTO_CBX, "- Seleccionar -"));
		}

		for (Iterator<ParametroCpeBean> iterator = listaParametroBean.iterator(); iterator.hasNext();) {
			ParametroCpeBean parametro = (ParametroCpeBean) iterator.next();
			combo.add(new SelectItem(parametro.getCodValor(), parametro.getNomValor()));
		}
		return combo;
	}

	public void obtenerReporteSeleccionado() {
		if (reporteSelected.trim().equals(Constantes.COD_VALOR_TIPO_REPORTE_COMPROBANTES_ELECTRÓNICOS)) {
			fecCargaDesde = null;
			fecCargaHasta = null;
			tipoComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
			estadoSelected = Constantes.VALOR_DEFECTO_CBX;
			mostrarPeriodoRegVentas = false;
			mostrarBoton = false;
		} else if (reporteSelected.trim().equals(Constantes.COD_VALOR_TIPO_REPORTE_REGISTRO_DE_VENTAS))  {
			periodoReporte = Constantes.TEXTO_DEFAULT;
			mostrarPeriodoRegVentas = true;
			mostrarBoton = false;
		} else {
			periodoReporte = Constantes.TEXTO_DEFAULT;
			mostrarPeriodoRegVentas = true;
			mostrarBoton = true;
		}
	}

	public void exportar() {
		try {
			if (reporteSelected.trim().equals(Constantes.COD_VALOR_TIPO_REPORTE_COMPROBANTES_ELECTRÓNICOS)) {
				validarRangoFechas();
				generarReporteComprobantesElectronicos();
			} else if (reporteSelected.trim().equals(Constantes.COD_VALOR_TIPO_REPORTE_REGISTRO_DE_VENTAS)) {
				if (obtenerTiposCambioSun()) {
					LOGGER.info("Inicia Registro Ventas");
					generarReporteRegistroVentas();
					LOGGER.info("Fin Registro Ventas");
				}
			} else if (reporteSelected.trim().equals(Constantes.COD_VALOR_TIPO_REPORTE_PLE_REGISTRO_DE_VENTAS)) {
				if (obtenerTiposCambioSun()) {
					LOGGER.info("Inicia Registro Ventas PLE");
					generarReportePleRegistroVentas();
					LOGGER.info("Fin Registro Ventas PLE");
				}
			}
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCON: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}

	private void validarRangoFechas() throws SyncconException {
		if (fecCargaDesde == null) {
			throw new SyncconException(ErrorConstants.COD_ERROR_FECHA_DESDE, FacesMessage.SEVERITY_INFO);
		}
		if (fecCargaHasta == null) {
			throw new SyncconException(ErrorConstants.COD_ERROR_FECHA_HASTA, FacesMessage.SEVERITY_INFO);
		}
		if (fecCargaDesde != null && fecCargaHasta == null) {
			if (fecCargaDesde == null && fecCargaHasta != null) {
				throw new SyncconException(ErrorConstants.COD_ERROR_RANGO_FECHAS, FacesMessage.SEVERITY_INFO);
			}
			throw new SyncconException(ErrorConstants.COD_ERROR_RANGO_FECHAS, FacesMessage.SEVERITY_INFO);
		}
		if (fecCargaDesde != null && fecCargaHasta != null) {
			if (!Utilitarios.validarFechasInicioFin(fecCargaDesde, fecCargaHasta)) {
				throw new SyncconException(ErrorConstants.COD_ERROR_RANGO_FECHAS, FacesMessage.SEVERITY_INFO);
			}
		}
	}

	public String autentificarWebService(String user, String pass) throws Exception {
		try {
			LOGGER.info("Ingresando AutenticacionWSDL");
			String auth = seguridad.autentificarUsuario(user, pass);
			LOGGER.info("Luego de llamar al WSDL");
			componentes = new SunComponenteService();
			LOGGER.info("Devuele el componente SunServiceComponente");
			return auth;
		} catch (NullPointerException e) {
			return null;
		}
	}

	private Boolean obtenerTiposCambioSun() {

		List<TipoCambioCpeBean> lista_val = null;
		cambioUsdPen = "";
		SimpleDateFormat formatoFechaSun = new SimpleDateFormat(ConstantesSun.UTL_FORMATO_FECHA_SUNSYSTEMS);

		String mes;

		try {

			if (periodoReporte.length() != 6) {
				enviarMensaje("Periodo Incorrecto.");
				return false;
			}
			ParametroCpeBean parametroBean = new ParametroCpeBean();
			parametroBean.setCodParam(Constantes.COD_PARAM_ACCESO_SUNSYSTEMS);
			parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
			List<ParametroCpeBean> listaParametroBean = new ArrayList<ParametroCpeBean>();
			listaParametroBean = parametroCpeService.listarParametro(parametroBean);

			user = listaParametroBean.get(0).getNomValor().toString();
			pass = listaParametroBean.get(1).getNomValor().toString();
			LOGGER.error("Credenciales SunSystems: " + user.toString() + " - " + pass.toString());

			LOGGER.info("Ini Validando ingreso a SUN");
			Token = autentificarWebService(user, pass);
			LOGGER.info("Fin Validando ingreso a SUN: " + Token.toString());

			if (Token == null) {
				FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN,"La autentificacion de SUN ha fallado", null);
				FacesContext.getCurrentInstance().addMessage(null, facesMsg);
				System.out.println("Autentificacion Fallida en SunSystems");

			} else {

				mes = periodoReporte.substring(4);
				
				if(mes.equals("01") ||
						mes.equals("02") ||
						mes.equals("03") ||
						mes.equals("04") ||
						mes.equals("05") ||
						mes.equals("06") ||
						mes.equals("07") ||
						mes.equals("08") ||
						mes.equals("09") ||
						mes.equals("10") ||
						mes.equals("11") ||
						mes.equals("12")){
					
					lista_val = tipoCambioCpeService.obtenerTipoCambioMes(formatoFechaSun.format(setPrimerDiaMes()), formatoFechaSun.format(setUltimoDiaMes()), Token);
					
					if (lista_val != null && lista_val.isEmpty()) {
						enviarMensaje("No hay tipo de cambio para el periodo ingresado");
						return false;
					}
					
					List<TipoCambioCpeBean> listaTipoCambioCpeBean = new ArrayList<TipoCambioCpeBean>();
					for(TipoCambioCpeBean bean : lista_val){
						bean.setPeriodo(periodoReporte);
						listaTipoCambioCpeBean = tipoCambioCpeService.listaTipoCambioCpe(bean);
						if(listaTipoCambioCpeBean.isEmpty()){
							tipoCambioCpeService.insertarTipoCambioCpe(bean);
						}
					}

				}else{
					enviarMensaje("Mes incorrecto.");
					return false;
				}
			}
			

		} catch (Exception e) {
			LOGGER.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			LOGGER.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));
		}
		return true;
	}

	private Date sumarDia(Date fecha) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fecha);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		return calendar.getTime();
	}

	private Date setPrimerDiaMes() {
		Date dia = new Date();
		Integer mes = Integer.parseInt(periodoReporte.substring(4));
		Integer anio = Integer.parseInt(periodoReporte.substring(0, 4));

		Calendar cal = Calendar.getInstance();
		cal.set(anio, mes-1, 1);
		dia = cal.getTime();
		
		return dia;
	}
	
	private Date setUltimoDiaMes(){
		Date dia = new Date();
		Integer mes = Integer.parseInt(periodoReporte.substring(4));
		Integer anio = Integer.parseInt(periodoReporte.substring(0,4));

		Calendar cal = Calendar.getInstance();
		cal.set(anio, mes-1, 1);
		cal.set(anio, mes-1, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		dia = cal.getTime();
		
		return dia;
	}
	
	private void generarReporteComprobantesElectronicos(){
		SXSSFWorkbook book = new SXSSFWorkbook();
		Sheet sheet = null;
		
		ReporteComprobantesElectronicosBean reporte = new ReporteComprobantesElectronicosBean();
		List<ReporteComprobantesElectronicosBean> listaReporte = new ArrayList<ReporteComprobantesElectronicosBean>();
		reporte.setIdTipoComp(tipoComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipoComprobanteSelected.trim());
		reporte.setIdEstadoComp(estadoSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : estadoSelected.trim());
		reporte.setFecCargaDesde(fecCargaDesde);
		reporte.setFecCargaHasta(sumarDia(fecCargaHasta));
		reporte.setIdEmpresa(Long.parseLong(empresa));
		reporte.setCodigoParametro1(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		reporte.setCodigoParametro2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		reporte.setCodigoParametro3(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		reporte.setCodigoParametro4(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
		reporte.setCodigoParametro5(Constantes.COD_PARAM_CPE_EMPRESA);
		reporte.setTipoParametro(Constantes.TIP_PARAM_DETALLE);
		listaReporte = reportesCpeService.listarReporteComprobantesElectronicos(reporte);
		
		if(listaReporte.isEmpty()){
			enviarMensaje("No existen registros a mostrar para el reporte seleccionado.");
			return;
		}

		try {

			sheet = book.createSheet("Reporte Comprobantes Electrónicos");
			sheet.setColumnWidth(0, 6000);
			sheet.setColumnWidth(1, 7000);
			sheet.setColumnWidth(2, 7000);
			sheet.setColumnWidth(3, 5000);
			sheet.setColumnWidth(4, 5000);
			sheet.setColumnWidth(5, 7000);
			sheet.setColumnWidth(6, 7000);
			sheet.setColumnWidth(7, 5000);
			sheet.setColumnWidth(8, 5000);
			sheet.setColumnWidth(9, 7000);
			sheet.setColumnWidth(10, 5000);
			sheet.setColumnWidth(11, 7000);
			sheet.setColumnWidth(12, 5000);
			sheet.setColumnWidth(13, 7000);
			sheet.setColumnWidth(14, 3000);
			sheet.setColumnWidth(15, 4000);
			sheet.setColumnWidth(16, 6000);
			sheet.setColumnWidth(17, 7000);
			sheet.setColumnWidth(18, 4000);
			sheet.setColumnWidth(19, 6000);
			sheet.setColumnWidth(20, 5000);
			sheet.setColumnWidth(21, 6000);
			sheet.setColumnWidth(22, 6000);
			sheet.setColumnWidth(23, 4000);
			sheet.setColumnWidth(24, 4000);
			sheet.setColumnWidth(25, 4000);
			sheet.setColumnWidth(26, 4000);
			sheet.setColumnWidth(27, 3000);
			sheet.setColumnWidth(28, 4000);
			sheet.setColumnWidth(29, 4000);
			sheet.setColumnWidth(30, 4000);
			sheet.setColumnWidth(31, 4000);
			sheet.setColumnWidth(32, 4000);
			sheet.setColumnWidth(33, 3000);
			sheet.setColumnWidth(34, 7000);
			sheet.setColumnWidth(35, 7000);
			sheet.setColumnWidth(36, 7000);
			sheet.setColumnWidth(37, 7000);
			sheet.setColumnWidth(38, 7000);
			sheet.setColumnWidth(39, 7000);
			sheet.setColumnWidth(40, 7000);
			sheet.setColumnWidth(41, 7000);
			sheet.setColumnWidth(42, 3000);
			sheet.setColumnWidth(43, 4000);

			// Estilos para el cuerpo del documento
			CellStyle bodyStyle = book.createCellStyle();

			Font bodyFont = book.createFont();
			bodyFont.setFontHeightInPoints((short) 11);
			bodyFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			bodyFont.setColor(HSSFColor.BLACK.index);

			bodyStyle.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyle.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyle.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyle.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyle.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
			bodyStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
			bodyStyle.setFont(bodyFont);

			// Estilos para el cuerpo del documento secundario 1
			CellStyle bodyStyleSec1 = book.createCellStyle();
			Font bodyFontSec1 = book.createFont();
			bodyFontSec1.setFontHeightInPoints((short) 9);
			bodyFontSec1.setColor(HSSFColor.BLACK.index);

			bodyStyleSec1.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyleSec1.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyleSec1.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyleSec1.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyleSec1.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyleSec1.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyleSec1.setFont(bodyFontSec1);

			// Colores de Celda
			CellStyle bodyCellColor = book.createCellStyle();
			bodyCellColor.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
			bodyCellColor.setFillPattern(CellStyle.SOLID_FOREGROUND);

			// Construyendo cuerpo
			int rowPosition = 0;
			int columnPosition = 0;

			Row row = sheet.createRow(rowPosition);

			Cell cell = row.createCell(columnPosition);
			RichTextString val = new XSSFRichTextString("Empresa");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Socio");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Producto");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoDocCliente");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NumDocCliente");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Nombres-RazonSocial");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Direccion");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Departamento");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Provincia");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Distrito");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Telefono");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Correo");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FechaEmision");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FechaVencimiento");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NroSerie");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CorrelativoSerie");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("EstadoComprobante");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoComprobante");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ConceptoND");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
					
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoComprobanteRef");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FechaEmisionRef");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("SerieComprobanteRef");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CorrelativoSerieOrig");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoMoneda");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("BaseImponible");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ImporteInafecto");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IGV");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ISC");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ImporteExonerado");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ValorFactExport");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ValorOpGratuitas");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Otros Importes");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Importe Total");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);

			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoCambio");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Concepto");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);			
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NumeroPoliza");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);	
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OpenItem");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OpenItemRef");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Area");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Observaciones");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Colect / indiv");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Linea");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Periodo");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Usuario");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			
			
			//Cuerpo
			for (int i = 0; i < listaReporte.size(); i++) {
				row = sheet.createRow(i + 1);
				for (int j = 0; j < 44; j++) {
					cell = row.createCell(j);
					if (j == 0) {
						// Empresa
						cell.setCellValue(listaReporte.get(i).getNomEmpresa());
					} else if (j == 1) {
						// Socio
						cell.setCellValue(listaReporte.get(i).getNomSocio());
					} else if (j == 2) {
						// producto
						cell.setCellValue(listaReporte.get(i).getNomProducto());
					} else if (j == 3) {
						// TipoDocumento
						cell.setCellValue(listaReporte.get(i).getNomTipoDocCli());
					} else if (j == 4) {
						// NumDocumento
						cell.setCellValue(listaReporte.get(i).getNumDocCli());
					} else if (j == 5) {
						// RazonSocial
						cell.setCellValue(listaReporte.get(i).getNomCliRazSoc());
					} else if (j == 6) {
						// Direccion
						cell.setCellValue(listaReporte.get(i).getDirCliente());
					} else if (j == 7) {
						// Departamento
						cell.setCellValue(listaReporte.get(i).getDepartamento());
					} else if (j == 8) {
						// Provincia
						cell.setCellValue(listaReporte.get(i).getProvincia());
					} else if (j == 9) {
						// Distrito
						cell.setCellValue(listaReporte.get(i).getDistrito());
					} else if (j == 10) {
						// Telefono
						cell.setCellValue(listaReporte.get(i).getTelefCliente());
					} else if (j == 11) {
						// Correo
						cell.setCellValue(listaReporte.get(i).getMailCliente());
					} else if (j == 12) {
						// FechaEmision
						cell.setCellValue(listaReporte.get(i).getFecEmision());
					} else if (j == 13) {
						// FechaVencimiento
						cell.setCellValue(listaReporte.get(i).getFechaVenc());
					} else if (j == 14) {
						// Serie
						cell.setCellValue(listaReporte.get(i).getSerieComp());
					} else if (j == 15) {
						// Correlativo
						cell.setCellValue(listaReporte.get(i).getCorrComp());
					} else if (j == 16) {
						// EstadoComprobante
						cell.setCellValue(listaReporte.get(i).getNomEstadoComp());
					} else if (j == 17) {
						// TipoComprobante
						cell.setCellValue(listaReporte.get(i).getNomTipoComp());
					} else if (j == 18) {
						// ConceptoNC/ND
						cell.setCellValue(listaReporte.get(i).getConcepNd());
					} else if (j == 19) {
						// TipoComprobanteRef
						cell.setCellValue(listaReporte.get(i).getIdTipoCompRef());
					} else if (j == 20) {
						// FechaEmisionRef
						cell.setCellValue(listaReporte.get(i).getFechaEmisionRef());
					} else if (j == 21) {
						// SerieComprobanteRef
						cell.setCellValue(listaReporte.get(i).getNumSerieRef());
					} else if (j == 22) {
						// CorrelativoSerieOrig
						cell.setCellValue(listaReporte.get(i).getNumCorrRef());
					} else if (j == 23) {
						// Moneda
						cell.setCellValue(listaReporte.get(i).getNomMoneda());
					} else if (j == 24) {
						// BaseImponible
						cell.setCellValue(String.valueOf(listaReporte.get(i).getBaseImponible()));
					} else if (j == 25) {
						// ImporteInafecto
						cell.setCellValue(String.valueOf(listaReporte.get(i).getImpInafecto()));
					} else if (j == 26) {
						// IGV
						cell.setCellValue(String.valueOf(listaReporte.get(i).getIgv()));
					} else if (j == 27) {
						// ISC
						cell.setCellValue(String.valueOf(listaReporte.get(i).getIsc()));
					} else if (j == 28) {
						// ImporteExonerado
						cell.setCellValue(String.valueOf(listaReporte.get(i).getImpExonerado()));
					} else if (j == 29) {
						// ValorFactExport
						cell.setCellValue(String.valueOf(listaReporte.get(i).getValFactExport()));
					} else if (j == 30) {
						// ValorOpGratuitas
						cell.setCellValue(String.valueOf(listaReporte.get(i).getValOpGratuitas()));
					} else if (j == 31) {
						// Otros Importes
						cell.setCellValue(String.valueOf(listaReporte.get(i).getImpOtros()));
					} else if (j == 32) {
						// Importe Total
						cell.setCellValue(String.valueOf(listaReporte.get(i).getImpTotal()));
					} else if (j == 33) {
						// TipoCambio
						cell.setCellValue(String.valueOf(listaReporte.get(i).getTipoCambio()));
					} else if (j == 34) {
						// Concepto
						cell.setCellValue(listaReporte.get(i).getConcepto());
					} else if (j == 35) {
						// NumeroPoliza
						cell.setCellValue(listaReporte.get(i).getNumPoliza());
					} else if (j == 36) {
						// OpenItem
						cell.setCellValue(listaReporte.get(i).getOpenItem());
					} else if (j == 37) {
						// OpenItemRef
						cell.setCellValue(listaReporte.get(i).getOpenItemRef());
					} else if (j == 38) {
						// Area
						cell.setCellValue(listaReporte.get(i).getArea());
					} else if (j == 39) {
						// Observaciones
						cell.setCellValue(listaReporte.get(i).getObservacion());
					} else if (j == 40) {
						// Colect / indiv
						cell.setCellValue(listaReporte.get(i).getColectIndiv());
					} else if (j == 41) {
						// Linea
						cell.setCellValue(listaReporte.get(i).getLinea());
					} else if (j == 42) {
						// Periodo
						cell.setCellValue(listaReporte.get(i).getPeriodo());
					} else if (j == 43) {
						// CorrelativoRegistro
						cell.setCellValue(listaReporte.get(i).getUsuarioCrea());
					} 
					
					
					cell.setCellStyle(bodyStyleSec1);
				}
			}

			String fileName = "Reporte_Comprobantes_Electrónicos.xlsx";

			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			response.addHeader("Content-Disposition", "attachment; filename=" + fileName);
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			OutputStream out = response.getOutputStream();
			book.write(out);
			out.close();

			FacesContext.getCurrentInstance().responseComplete();

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	private void generarReportePleRegistroVentas(){
		try{
			
			flagPeriodo = false;
			flagExportar =false;
			
			LOGGER.info("Inicio Consulta Historial Reporte - PLE");
			HistorialReporteCpeBean historialReporte = new HistorialReporteCpeBean();
			historialReporte.setPeriodo(periodoReporte);
			historialReporte.setTipoReporte(reporteSelected);
			historialReporte.setIdEmpresa(empresa);
			historialReporte = historialReporteCpeService.obtenerHistorialPorPeriodo(historialReporte);
			
			if(historialReporte == null){
				LOGGER.info("No existe periodo registrado - PLE");
				
				ReporteRegistroVentasPleBean ple = new ReporteRegistroVentasPleBean();
				ple.setIdEmpresa(Long.parseLong(empresa));
				ple.setPeriodoRegistro(periodoReporte);
				int contador = reportesCpeService.contadorComprobantes(ple);
				
				if(contador == 0){
					flagPeriodo = false;
					LOGGER.info("No existe registro - PLE");
					enviarMensaje("No existen comprobantes validados y/o anulados para el periodo ingresado.");
					return;
				}	
				else {
										 
					Date Fecha = new Date();
					DateFormat Periodo = new SimpleDateFormat("yyyyMM");
					String convertido = Periodo.format(Fecha);
					
			        
					if (periodoReporte.equals(convertido)){
						flagPeriodo = false;
						flagExportar =  true;
					}else{
						flagPeriodo = true;
						LOGGER.info("Si existe registro - PLE");
					}
				}
			}
			else {
				flagPeriodo = false;
				flagExportar =  true;
				LOGGER.info("Si existe periodo registrado - PLE");
				//exportarReportePleRegistroVentasGenerados();
			}
			LOGGER.info("Fin Consulta Historial Reporte - PLE");
			
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void exportarReportePleRegistroVentas(){
		try {
			
			actualizarPLE(empresa,periodoReporte);
			
			ReporteRegistroVentasPleBean ple = new ReporteRegistroVentasPleBean();
			ple.setIdEmpresa(Long.parseLong(empresa));
			ple.setPeriodoRegistro(periodoReporte);
//			ple.setCodParamEmpresaPle(empresa.equals(Constantes.COD_CARDIF_SEGUROS)
//					? Constantes.COD_PARAM_CORRELATIVO_PLE_SEGUROS : Constantes.COD_PARAM_CORRELATIVO_PLE_SERVICIOS);
			
			List<ReporteRegistroVentasPleBean> listaPle = new ArrayList<ReporteRegistroVentasPleBean>();
			listaPle = reportesCpeService.listarReporteRegistroVentasPle(ple);
			
			HistorialReporteCpeBean historialReporte = new HistorialReporteCpeBean();
			historialReporte = new HistorialReporteCpeBean();
			historialReporte.setTipoReporte(reporteSelected);
			historialReporte.setPeriodo(periodoReporte);
			historialReporte.setUsuCrea(usuarioSesion);
			historialReporte.setIdEmpresa(empresa);
			historialReporteCpeService.insertarHistorialReporte(historialReporte);
			
//			ComprobanteCpeBean comprobante;
//			for(ReporteRegistroVentasPleBean bean : listaPle){
//				comprobante = new ComprobanteCpeBean();
//				comprobante.setIdComprobante(bean.getIdComprobante());
//				comprobante.setIdPle(bean.getIdPle());
//				reportesCpeService.actualizarComprobantePleCpe(comprobante);
//			 }
//			
//			Long ultimoCorrelativo = listaPle.get(listaPle.size() - 1).getIdPle();
			
			Long ultimoCorrelativo = reportesCpeService.maxRegistroPLE(ple);
			LOGGER.info("CorrelativoPLE " + ultimoCorrelativo);
			
			ParametroCpeBean parametroBean = new ParametroCpeBean();
			parametroBean.setCodParam(empresa.equals(Constantes.COD_CARDIF_SEGUROS) ? Constantes.COD_PARAM_CORRELATIVO_PLE_SEGUROS : Constantes.COD_PARAM_CORRELATIVO_PLE_SERVICIOS);
			parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
			parametroBean.setCodValor("ID_PLE");
			parametroBean.setNomValor(String.valueOf(ultimoCorrelativo));
			parametroBean.setUsuModifica(usuarioSesion);
			parametroCpeService.actualizarParametro(parametroBean);
				
			LOGGER.info("Inicio Generar Archivo Plano RV - PLE");
			ParametroCpeBean parametroRucBean = new ParametroCpeBean();
			parametroRucBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
			parametroRucBean.setCodValor(Constantes.CPE_PARAM_COD_VALOR_RUC);
			parametroRucBean.setCodParam(empresa.equals(Constantes.COD_CARDIF_SEGUROS) ? Constantes.COD_PARAM_CPE_CARDIF_SEGUROS : Constantes.COD_PARAM_CPE_CARDIF_SERVICIOS);
			String rucEmpresaSeleccionada = parametroCpeService.listarParametro(parametroRucBean).get(0).getNomValor();
			

			String nameFile = "LE"//Iniciales Libro Electrónico
								.concat(rucEmpresaSeleccionada)//Ruc Generador del Libro Electrónico
								.concat(periodoReporte.concat("00"))//Periodo del libro electrónico, al ser mensual las últimas dos posiciones se expresan como 00.
								.concat(Constantes.CPE_IDENTIFICADOR_LIBRO_REG_VENTAS_E_INGRESOS)//Identificador del libro Registro de Ventas e Ingresos (14.1) debe expresarse como 140100.
								.concat("00")//oportunidad en que se está presentando el Libro Inventarios y Balances. Si se trata de otro libro se consigna 00.
								.concat("1")//la empresa seguirá operando o no (cierre), es decir 1 o 0.
								.concat("1")//se consigna 1 si el Libro Electrónico tiene información, caso contrario se consigna 0.
								.concat("1")//se consigna 1 si el Libro Electrónico utiliza la moneda nacional y 2 si es moneda extranjera.
								.concat("1");//se consigna siempre 1 por tratarse de un Libro Electrónico generado mediante el Programa de Libros Electrónicos - PLE.
		
			
			File file = new File(nameFile);

			if (file.exists()) {
				file.delete();
			}

			FileWriter fileWriter = new FileWriter(file, true);

			StringBuilder texto = new StringBuilder();
			
			int size = listaPle.size();
			
			Long[] ArrayidComprobante = new Long[size];
			
			size = 0;
			
			for(ReporteRegistroVentasPleBean bean : listaPle){
				texto.append(bean.getvPeriodo() == null ? "" : bean.getvPeriodo());
				texto.append("|");
				texto.append(bean.getIdPle() == null ? "" : bean.getIdPle());
				texto.append("|");
				texto.append(bean.getmIdPle() == null ? "" : bean.getmIdPle());
				texto.append("|");
				texto.append(bean.getFecEmision() == null ? "" : formatoddMMaaaa.format(bean.getFecEmision()));
				texto.append("|");
				//texto.append(bean.getFecVenc() == null ? "" : formatoddMMaaaa.format(bean.getFecVenc()));
				texto.append("");
				texto.append("|");
				texto.append(bean.getIdTipoComp() == null ? "" : bean.getIdTipoComp());
				texto.append("|");
				texto.append(bean.getSerieComp() == null ? "" : bean.getSerieComp());
				texto.append("|");
				texto.append(bean.getCorrComp() == null ? "" : bean.getCorrComp());
				texto.append("|");
				texto.append(bean.getCampo9() == null ? "" : bean.getCampo9());
				texto.append("|");
				texto.append(bean.getIdTipoDocCli() == null ? "" : bean.getIdTipoDocCli());
				texto.append("|");
				texto.append(bean.getNumDocCli() == null ? "" : bean.getNumDocCli());
				texto.append("|");
				texto.append(bean.getNomCliRazSoc() == null ? "" : bean.getNomCliRazSoc());
				texto.append("|");
				texto.append(bean.getValFactExport() == null ? "" : bean.getValFactExport());
				texto.append("|");
				texto.append(bean.getBaseImponible() == null ? "" : bean.getBaseImponible());
				texto.append("|");
				texto.append(bean.getDsctoBaseImponible() == null ? "" : bean.getDsctoBaseImponible());
				texto.append("|");
				texto.append(bean.getIgv() == null ? "" : bean.getIgv());
				texto.append("|");
				texto.append(bean.getDsctoIgv() == null ? "" : bean.getDsctoIgv());
				texto.append("|");
				texto.append(bean.getImpExonerado() == null ? "" : bean.getImpExonerado());
				texto.append("|");
				texto.append(bean.getImpInafecto() == null ? "" : bean.getImpInafecto());
				texto.append("|");
				texto.append(bean.getIsc() == null ? "" : bean.getIsc());
				texto.append("|");
				texto.append(bean.getCampo21() == null ? "" : bean.getCampo21());
				texto.append("|");
				texto.append(bean.getCampo22() == null ? "" : bean.getCampo22());
				texto.append("|");
				texto.append(bean.getImpOtros() == null ? "" : bean.getImpOtros());
				texto.append("|");
				texto.append(bean.getImpTotal() == null ? "" : bean.getImpTotal());
				texto.append("|");
				texto.append(bean.getTipoMoneda() == null ? "" : bean.getTipoMoneda());
				texto.append("|");
				texto.append(bean.getTipoCambio() == null ? "" : bean.getTipoCambio());
				texto.append("|");
				texto.append(bean.getFechaEmisionRef() == null ? "" : bean.getFechaEmisionRef());
				texto.append("|");
				texto.append(bean.getIdTipoCompRef() == null ? "" : bean.getIdTipoCompRef());
				texto.append("|");
				texto.append(bean.getNumSerieRef() == null ? "" : bean.getNumSerieRef());
				texto.append("|");
				texto.append(bean.getNumCorRef() == null ? "" : bean.getNumCorRef());
				texto.append("|");
				texto.append(bean.getCampo31() == null ? "" : bean.getCampo31());
				texto.append("|");
				texto.append(bean.getCampo32() == null ? "" : bean.getCampo32());
				texto.append("|");
				texto.append(bean.getCampo33() == null ? "" : bean.getCampo33());
				texto.append("|");
				texto.append(bean.getCampo34Estado() == null ? "" : bean.getCampo34Estado());
				texto.append("|");
				texto.append(bean.getCampo35() == null ? "" : bean.getCampo35());
				texto.append("|");
				texto.append(bean.getCampo36() == null ? "" : bean.getCampo36());
				texto.append("|");
				texto.append(bean.getCampo37() == null ? "" : bean.getCampo37());
//				texto.append("|");
//				texto.append(bean.getCampo38() == null ? "" : bean.getCampo38());
				texto.append("\r\n");

				ArrayidComprobante[size] = bean.getIdComprobante();
				size++;
			}

			fileWriter.write(texto.toString());
			fileWriter.close();

			HttpServletResponse responseTXT = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();

			FileInputStream isTXT = new FileInputStream(file);

			byte[] loaderTXT = new byte[(int) file.length()];

			responseTXT.addHeader("Content-Disposition", "attachment; filename=" + nameFile.concat(".txt"));
			responseTXT.setContentType("text/plain");

			ServletOutputStream outTXT = responseTXT.getOutputStream();

			while ((isTXT.read(loaderTXT)) > 0) {
				outTXT.write(loaderTXT, 0, loaderTXT.length);
			}

			isTXT.close();
			outTXT.close();

			FacesContext.getCurrentInstance().responseComplete();
			
			LOGGER.info("Fin Generar Archivo Plano RV - PLE");
			
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void exportarReportePleRegistroVentasGenerados(){
		
		try {
			
			ReporteRegistroVentasPleBean ple = new ReporteRegistroVentasPleBean();
			ple.setIdEmpresa(Long.parseLong(empresa));
			ple.setPeriodoRegistro(periodoReporte);
			
			int contador = reportesCpeService.contadorComprobantes(ple);
			
			if(contador == 0){
				enviarMensaje("No existen comprobantes validados y/o anulados para el periodo ingresado.");
				return;
			}
			
			List<ReporteRegistroVentasPleBean> listaPle = new ArrayList<ReporteRegistroVentasPleBean>();
			
			listaPle = reportesCpeService.listarReporteRegistroVentasPle(ple);
			
			ParametroCpeBean parametroPLEBean = new ParametroCpeBean();
			parametroPLEBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
			parametroPLEBean.setCodValor("ID_PLE");
			parametroPLEBean.setCodParam(empresa.equals(Constantes.COD_CARDIF_SEGUROS) ? Constantes.COD_PARAM_CORRELATIVO_PLE_SEGUROS : Constantes.COD_PARAM_CORRELATIVO_PLE_SERVICIOS);
			Long ultimoCorrelativo = Long.parseLong(parametroCpeService.listarParametro(parametroPLEBean).get(0).getNomValor());
			
			Long CorrelativoPLE = reportesCpeService.maxRegistroPLE(ple);
			
			CorrelativoPLE = CorrelativoPLE == null ? 0 : CorrelativoPLE;
			LOGGER.info("CorrelativoPLE " + CorrelativoPLE); 
			
			LOGGER.info("Inicio Generar Archivo Plano RV - PLE");
			ParametroCpeBean parametroRucBean = new ParametroCpeBean();
			parametroRucBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
			parametroRucBean.setCodValor(Constantes.CPE_PARAM_COD_VALOR_RUC);
			parametroRucBean.setCodParam(empresa.equals(Constantes.COD_CARDIF_SEGUROS) ? Constantes.COD_PARAM_CPE_CARDIF_SEGUROS : Constantes.COD_PARAM_CPE_CARDIF_SERVICIOS);
			String rucEmpresaSeleccionada = parametroCpeService.listarParametro(parametroRucBean).get(0).getNomValor();
			

			String nameFile = "LE"//Iniciales Libro Electrónico
								.concat(rucEmpresaSeleccionada)//Ruc Generador del Libro Electrónico
								.concat(periodoReporte.concat("00"))//Periodo del libro electrónico, al ser mensual las últimas dos posiciones se expresan como 00.
								.concat(Constantes.CPE_IDENTIFICADOR_LIBRO_REG_VENTAS_E_INGRESOS)//Identificador del libro Registro de Ventas e Ingresos (14.1) debe expresarse como 140100.
								.concat("00")//oportunidad en que se está presentando el Libro Inventarios y Balances. Si se trata de otro libro se consigna 00.
								.concat("1")//la empresa seguirá operando o no (cierre), es decir 1 o 0.
								.concat("1")//se consigna 1 si el Libro Electrónico tiene información, caso contrario se consigna 0.
								.concat("1")//se consigna 1 si el Libro Electrónico utiliza la moneda nacional y 2 si es moneda extranjera.
								.concat("1");//se consigna siempre 1 por tratarse de un Libro Electrónico generado mediante el Programa de Libros Electrónicos - PLE.
		
			
			File file = new File(nameFile);

			if (file.exists()) {
				file.delete();
			}

			FileWriter fileWriter = new FileWriter(file, true);

			StringBuilder texto = new StringBuilder();
			
			int size = listaPle.size();
			
			Long[] ArrayidComprobante = new Long[size];
			
			size = 0;
			
			for(ReporteRegistroVentasPleBean bean : listaPle){
				ultimoCorrelativo = ultimoCorrelativo +1;
				texto.append(bean.getvPeriodo() == null ? "" : bean.getvPeriodo());
				texto.append("|");
//				texto.append(bean.getIdPle() == null ? "" : bean.getIdPle());
				texto.append(CorrelativoPLE == 0 ? ultimoCorrelativo : bean.getIdPle());
				texto.append("|");
//				texto.append(bean.getmIdPle() == null ? "" : bean.getmIdPle());
				texto.append(CorrelativoPLE == 0 ? "M" + ultimoCorrelativo : "M" + bean.getIdPle());
				texto.append("|");
				texto.append(bean.getFecEmision() == null ? "" : formatoddMMaaaa.format(bean.getFecEmision()));
				texto.append("|");
				//texto.append(bean.getFecVenc() == null ? "" : formatoddMMaaaa.format(bean.getFecVenc()));
				texto.append("");
				texto.append("|");
				texto.append(bean.getIdTipoComp() == null ? "" : bean.getIdTipoComp());
				texto.append("|");
				texto.append(bean.getSerieComp() == null ? "" : bean.getSerieComp());
				texto.append("|");
				texto.append(bean.getCorrComp() == null ? "" : bean.getCorrComp());
				texto.append("|");
				texto.append(bean.getCampo9() == null ? "" : bean.getCampo9());
				texto.append("|");
				texto.append(bean.getIdTipoDocCli() == null ? "" : bean.getIdTipoDocCli());
				texto.append("|");
				texto.append(bean.getNumDocCli() == null ? "" : bean.getNumDocCli());
				texto.append("|");
				texto.append(bean.getNomCliRazSoc() == null ? "" : bean.getNomCliRazSoc());
				texto.append("|");
				texto.append(bean.getValFactExport() == null ? "" : bean.getValFactExport());
				texto.append("|");
				texto.append(bean.getBaseImponible() == null ? "" : bean.getBaseImponible());
				texto.append("|");
				texto.append(bean.getDsctoBaseImponible() == null ? "" : bean.getDsctoBaseImponible());
				texto.append("|");
				texto.append(bean.getIgv() == null ? "" : bean.getIgv());
				texto.append("|");
				texto.append(bean.getDsctoIgv() == null ? "" : bean.getDsctoIgv());
				texto.append("|");
				texto.append(bean.getImpExonerado() == null ? "" : bean.getImpExonerado());
				texto.append("|");
				texto.append(bean.getImpInafecto() == null ? "" : bean.getImpInafecto());
				texto.append("|");
				texto.append(bean.getIsc() == null ? "" : bean.getIsc());
				texto.append("|");
				texto.append(bean.getCampo21() == null ? "" : bean.getCampo21());
				texto.append("|");
				texto.append(bean.getCampo22() == null ? "" : bean.getCampo22());
				texto.append("|");
				texto.append(bean.getImpOtros() == null ? "" : bean.getImpOtros());
				texto.append("|");
				texto.append(bean.getImpTotal() == null ? "" : bean.getImpTotal());
				texto.append("|");
				texto.append(bean.getTipoMoneda() == null ? "" : bean.getTipoMoneda());
				texto.append("|");
				texto.append(bean.getTipoCambio() == null ? "" : bean.getTipoCambio());
				texto.append("|");
				texto.append(bean.getFechaEmisionRef() == null ? "" : bean.getFechaEmisionRef());
				texto.append("|");
				texto.append(bean.getIdTipoCompRef() == null ? "" : bean.getIdTipoCompRef());
				texto.append("|");
				texto.append(bean.getNumSerieRef() == null ? "" : bean.getNumSerieRef());
				texto.append("|");
				texto.append(bean.getNumCorRef() == null ? "" : bean.getNumCorRef());
				texto.append("|");
				texto.append(bean.getCampo31() == null ? "" : bean.getCampo31());
				texto.append("|");
				texto.append(bean.getCampo32() == null ? "" : bean.getCampo32());
				texto.append("|");
				texto.append(bean.getCampo33() == null ? "" : bean.getCampo33());
				texto.append("|");
				texto.append(bean.getCampo34Estado() == null ? "" : bean.getCampo34Estado());
				texto.append("|");
				texto.append(bean.getCampo35() == null ? "" : bean.getCampo35());
				texto.append("|");
				texto.append(bean.getCampo36() == null ? "" : bean.getCampo36());
				texto.append("|");
				texto.append(bean.getCampo37() == null ? "" : bean.getCampo37());
//				texto.append("|");
//				texto.append(bean.getCampo38() == null ? "" : bean.getCampo38());
				texto.append("\r\n");

				ArrayidComprobante[size] = bean.getIdComprobante();
				size++;
			}

			fileWriter.write(texto.toString());
			fileWriter.close();

			HttpServletResponse responseTXT = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();

			FileInputStream isTXT = new FileInputStream(file);

			byte[] loaderTXT = new byte[(int) file.length()];

			responseTXT.addHeader("Content-Disposition", "attachment; filename=" + nameFile.concat(".txt"));
			responseTXT.setContentType("text/plain");

			ServletOutputStream outTXT = responseTXT.getOutputStream();

			while ((isTXT.read(loaderTXT)) > 0) {
				outTXT.write(loaderTXT, 0, loaderTXT.length);
			}

			isTXT.close();
			outTXT.close();

			FacesContext.getCurrentInstance().responseComplete();
			
			LOGGER.info("Fin Generar Archivo Plano RV - PLE");
			
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	private void generarReporteRegistroVentas(){

		SXSSFWorkbook book = new SXSSFWorkbook();
		Sheet sheet = null;

		ReporteRegistroVentasBean registroVentas = new ReporteRegistroVentasBean();
		List<ReporteRegistroVentasBean> listaregistroVentas = new ArrayList<ReporteRegistroVentasBean>();
		registroVentas.setIdEmpresa(Long.parseLong(empresa));
		/*registroVentas.setFechaDesde(setPrimerDiaMes());
		registroVentas.setFechaHasta(setUltimoDiaMes());*/
		registroVentas.setPeriodoRegistro(periodoReporte);
		registroVentas.setCodigoParametro1(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		registroVentas.setCodigoParametro2(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
		registroVentas.setCodigoParametro3(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		registroVentas.setCodigoParametro4(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
		registroVentas.setTipoParametro(Constantes.TIP_PARAM_DETALLE);
		LOGGER.info("Inicia Busqueda RegistroVentas");
		listaregistroVentas = reportesCpeService.listarReporteRegistroVentas(registroVentas);
		LOGGER.info("Fin Busqueda RegistroVentas");
		if (listaregistroVentas.isEmpty()) {
			enviarMensaje("No existen registros a mostrar para el reporte seleccionado.");
			return;
		}
		
		try {
			LOGGER.info("Valida RegistroVentas");
			sheet = book.createSheet("Reporte Registro de Ventas");
			sheet.setColumnWidth(0, 7000);
			sheet.setColumnWidth(1, 7000);
			sheet.setColumnWidth(2, 7000);
			sheet.setColumnWidth(3, 7000);
			sheet.setColumnWidth(4, 7000);
			sheet.setColumnWidth(5, 7000);
			sheet.setColumnWidth(6, 7000);
			sheet.setColumnWidth(7, 7000);
			sheet.setColumnWidth(8, 7000);
			sheet.setColumnWidth(9, 7000);
			sheet.setColumnWidth(10, 7000);
			sheet.setColumnWidth(11, 7000);
			sheet.setColumnWidth(12, 7000);
			sheet.setColumnWidth(13, 7000);
			sheet.setColumnWidth(14, 7000);
			sheet.setColumnWidth(15, 7000);
			sheet.setColumnWidth(16, 7000);
			sheet.setColumnWidth(17, 7000);
			sheet.setColumnWidth(18, 7000);
			sheet.setColumnWidth(19, 7000);
			sheet.setColumnWidth(20, 7000);
			sheet.setColumnWidth(21, 7000);
			sheet.setColumnWidth(22, 7000);
			sheet.setColumnWidth(23, 7000);
			sheet.setColumnWidth(24, 7000);
			sheet.setColumnWidth(25, 7000);
			sheet.setColumnWidth(26, 7000);
			sheet.setColumnWidth(27, 7000);
			sheet.setColumnWidth(28, 7000);
			sheet.setColumnWidth(29, 7000);
			sheet.setColumnWidth(30, 7000);
			sheet.setColumnWidth(31, 7000);
			sheet.setColumnWidth(32, 7000);
			sheet.setColumnWidth(33, 7000);
			sheet.setColumnWidth(34, 7000);
			sheet.setColumnWidth(35, 7000);
			sheet.setColumnWidth(36, 7000);
			sheet.setColumnWidth(37, 7000);
			sheet.setColumnWidth(38, 7000);
			sheet.setColumnWidth(39, 7000);
			sheet.setColumnWidth(40, 7000);
			sheet.setColumnWidth(41, 7000);

			// Estilos para el cuerpo del documento
			CellStyle bodyStyle = book.createCellStyle();

			Font bodyFont = book.createFont();
			bodyFont.setFontHeightInPoints((short) 11);
			bodyFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			bodyFont.setColor(HSSFColor.BLACK.index);

			bodyStyle.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyle.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyle.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyle.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyle.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
			bodyStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
			bodyStyle.setFont(bodyFont);

			// Estilos para el cuerpo del documento secundario 1
			CellStyle bodyStyleSec1 = book.createCellStyle();
			Font bodyFontSec1 = book.createFont();
			bodyFontSec1.setFontHeightInPoints((short) 9);
			bodyFontSec1.setColor(HSSFColor.BLACK.index);

			bodyStyleSec1.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyleSec1.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyleSec1.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyleSec1.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyleSec1.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyleSec1.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyleSec1.setFont(bodyFontSec1);

			// Colores de Celda
			CellStyle bodyCellColor = book.createCellStyle();
			bodyCellColor.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
			bodyCellColor.setFillPattern(CellStyle.SOLID_FOREGROUND);

			// Construyendo cuerpo
			int rowPosition = 0;
			int columnPosition = 0;

			Row row = sheet.createRow(rowPosition);

			Cell cell = row.createCell(columnPosition);
			RichTextString val = new XSSFRichTextString("PERIODO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);

			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CORRELATIVO_REGISTRO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FECHAEMISION");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FECHAVENCIMIENTO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TIPOCOMPROBANTE");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NRO_SERIE");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CORRELATIVO_SERIE");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TIPODOCCLIENTE");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);

			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NUMERODOCCLIENTE");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NOMBRES_RAZON_SOCIAL");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CONCEPTO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("VALOR_FACT_EXPORT");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("BASE_IMPONIBLE");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IMPORTE_EXONERADO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IMPORTE_INAFECTO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("VALOROPGRATUITAS");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ISC");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IGV");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OTROS_IMPORTES");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IMPORTE_TOTAL");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TIPO_CAMBIO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("MONEDA");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FECHA_EMISION_REF");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TIPO_COMPROBANTE_REF");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("SERIE_COMPROBANTE_REF");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CORRELATIVO_SERIE_ORIG");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("MODIFICABLE");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OPENITEM");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OPENITEM_REF");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NUMERO_POLIZA");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("PRODUCTO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ESTADO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OBSERVACIONES");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CORELATIVO FINAL");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("DIRECCION");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("DISTRITO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("PROVINCIA");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("DEPARTAMENTO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IMPORTE TOTAL ORIGINAL");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("COLECT / INDIV");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("LINEA");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CONSECUTIVO");
			cell.setCellValue(val);
			cell.setCellStyle(bodyStyle);
			
			//Cuerpo
			for (int i = 0; i < listaregistroVentas.size(); i++) {
				row = sheet.createRow(i + 1);
				for (int j = 0; j <= 41; j++) {
					cell = row.createCell(j);
					if (j == 0) {
						// PERIODO
						cell.setCellValue(listaregistroVentas.get(i).getPeriodo());
					} else if (j == 1) {
						// CORRELATIVO_REGISTRO
						cell.setCellValue(listaregistroVentas.get(i).getIdComprobante());
					} else if (j == 2) {
						// FECHAEMISION
						cell.setCellValue(listaregistroVentas.get(i).getFecEmision());
					} else if (j == 3) {
						// FECHAVENCIMIENTO
						//cell.setCellValue(listaregistroVentas.get(i).getFechaVenc());
						cell.setCellValue("");
					} else if (j == 4) {
						// TIPOCOMPROBANTE
						//cell.setCellValue(listaregistroVentas.get(i).getIdTipoComp());
						cell.setCellValue(listaregistroVentas.get(i).getNomTipoComp());
					} else if (j == 5) {
						// NRO_SERIE
						cell.setCellValue(listaregistroVentas.get(i).getSerieComp());
					} else if (j == 6) {
						// CORRELATIVO_SERIE
						cell.setCellValue(listaregistroVentas.get(i).getCorrComp());
					} else if (j == 7) {
						// TIPODOCCLIENTE
						//cell.setCellValue(listaregistroVentas.get(i).getIdTipoDocCli1());
						cell.setCellValue(listaregistroVentas.get(i).getNomTipoDocCli());
					} else if (j == 8) {
						// NUMERODOCCLIENTE
						cell.setCellValue(listaregistroVentas.get(i).getNumDocCli());
					} else if (j == 9) {
						// NOMBRES_RAZON_SOCIAL
						cell.setCellValue(listaregistroVentas.get(i).getNomCliRazSoc());
					} else if (j == 10) {
						// CONCEPTO
						cell.setCellValue(listaregistroVentas.get(i).getConcepto());
					} else if (j == 11) {
						// VALOR_FACT_EXPORT
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getValFactExport()));
					} else if (j == 12) {
						// BASE_IMPONIBLE
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getBaseImponible()));
					} else if (j == 13) {
						// IMPORTE_EXONERADO
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getImpExonerado()));
					} else if (j == 14) {
						// IMPORTE_INAFECTO
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getImpInafecto()));
					} else if (j == 15) {
						// VALOROPGRATUITAS
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getValOpGratuitas()));
					} else if (j == 16) {
						// ISC
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getIsc()));
					} else if (j == 17) {
						// IGV
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getIgv()));
					} else if (j == 18) {
						// OTROS_IMPORTES
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getImpOtros()));
					} else if (j == 19) {
						// IMPORTE_TOTAL
						cell.setCellValue(String.valueOf(listaregistroVentas.get(i).getImpTotal()));
					} else if (j == 20) {
						// TIPO_CAMBIO
						cell.setCellValue(listaregistroVentas.get(i).getTipoCambio() == null ? "" : String.valueOf(listaregistroVentas.get(i).getTipoCambio()));
					} else if (j == 21) {
						// MONEDA
						cell.setCellValue(listaregistroVentas.get(i).getMoneda());
					} else if (j == 22) {
						// FECHA_EMISION_REF
						cell.setCellValue(listaregistroVentas.get(i).getFechaEmisionRef());
					} else if (j == 23) {
						// TIPO_COMPROBANTE_REF
						cell.setCellValue(listaregistroVentas.get(i).getIdTipoCompRef());
					} else if (j == 24) {
						// SERIE_COMPROBANTE_REF
						//cell.setCellValue(listaregistroVentas.get(i).getNumSerieRef() == null ? "" : String.valueOf(listaregistroVentas.get(i).getNumSerieRef()));
						cell.setCellValue(listaregistroVentas.get(i).getNumSerieRef() == null ? "" : listaregistroVentas.get(i).getNumSerieRef());
					} else if (j == 25) {
						// CORRELATIVO_SERIE_ORIG
						//cell.setCellValue(listaregistroVentas.get(i).getNumCorRef()  == null ? "" : String.valueOf(listaregistroVentas.get(i).getNumCorRef()));
						cell.setCellValue(listaregistroVentas.get(i).getNumCorRef()  == null ? "" : listaregistroVentas.get(i).getNumCorRef());
					} else if (j == 26) {
						// MODIFICABLE
						cell.setCellValue(listaregistroVentas.get(i).getModificable());
					} else if (j == 27) {
						// OPENITEM
						cell.setCellValue(listaregistroVentas.get(i).getOpenItem());
					} else if (j == 28) {
						// OPENITEM_REF
						cell.setCellValue(listaregistroVentas.get(i).getOpenItemRef());
					} else if (j == 29) {
						// NUMERO_POLIZA
						cell.setCellValue(listaregistroVentas.get(i).getNumPoliza());
					} else if (j == 30) {
						// PRODUCTO
						//cell.setCellValue(listaregistroVentas.get(i).getIdProducto() == null ? "" : String.valueOf(listaregistroVentas.get(i).getIdProducto()));
						cell.setCellValue(listaregistroVentas.get(i).getDescProducto() == null ? "" : listaregistroVentas.get(i).getDescProducto());
					} else if (j == 31) {
						// ESTADO
						//cell.setCellValue(listaregistroVentas.get(i).getEstado());
						cell.setCellValue(listaregistroVentas.get(i).getNomEstadoComp());
					} else if (j == 32) {
						// OBSERVACIONES
						cell.setCellValue(listaregistroVentas.get(i).getObservacion());
					} else if (j == 33) {
						// CORELATIVO FINAL
						cell.setCellValue(listaregistroVentas.get(i).getCorActual() == null ? "" : String.valueOf(listaregistroVentas.get(i).getCorActual()));
					} else if (j == 34) {
						// DIRECCION
						cell.setCellValue(listaregistroVentas.get(i).getDirCliente());
					} else if (j == 35) {
						// DISTRITO
						cell.setCellValue(listaregistroVentas.get(i).getDistrito());
					} else if (j == 36) {
						// PROVINCIA
						cell.setCellValue(listaregistroVentas.get(i).getProvincia());
					} else if (j == 37) {
						// DEPARTAMENTO
						cell.setCellValue(listaregistroVentas.get(i).getDepartamento());
					} else if (j == 38) {
						// IMPORTE TOTAL ORIGINAL
						cell.setCellValue(listaregistroVentas.get(i).getImpTotalOrig() == null ? "" : String.valueOf(listaregistroVentas.get(i).getImpTotalOrig()));
					} else if (j == 39) {
						// COLECT / INDIV
						cell.setCellValue(listaregistroVentas.get(i).getColectIndiv());
					} else if (j == 40) {
						// LINEA
						cell.setCellValue(listaregistroVentas.get(i).getLinea());
					} else if (j == 41) {
						// CONSECUTIVO
						cell.setCellValue(listaregistroVentas.get(i).getConsecutivo());
					}					
					
					cell.setCellStyle(bodyStyleSec1);
				}
			}

			String fileName = "Reporte_Registro_de_Ventas.xlsx";

			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			response.addHeader("Content-Disposition", "attachment; filename=" + fileName);
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			OutputStream out = response.getOutputStream();
			book.write(out);
			out.close();

			FacesContext.getCurrentInstance().responseComplete();

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/********************************************************************************************************************/
	/******************************************** PLSQL ACTUALIZAR PLE **************************************************/
	/************************ GENERADO: 20/08/2019    - AUTOR: STEVE BARRERA    *****************************************/
	/********************************************************************************************************************/
	private void actualizarPLE(String empresa,String periodo){
		try{
			
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "" +
	        	"	DECLARE " +
				"  	V_IDCOMPROBANTE   CPE_ECOMPROBANTE.ID_COMPROBANTE%TYPE; " +
				"  	V_IDPLE           CPE_ECOMPROBANTE.ID_PLE%TYPE; " +
				""  +
				"  	CURSOR C_ECOMPROBANTE  IS " + 
				"          SELECT ECP.ID_COMPROBANTE " +
				"              ,(SELECT NOM_VALOR FROM CPE_PARAMETRO WHERE COD_PARAM = '037' AND COD_VALOR='ID_PLE')+ ROWNUM ID_PLE " +
				"              FROM CPE_CARGAVENTA_DET CVD " +
				"              INNER JOIN CPE_ECOMPROBANTE ECP ON ECP.ID_EMPRESA = '" + empresa + "'" +
				"				AND ECP.ID_VENTA = CVD.ID_VENTA " +
				"              AND ECP.ID_TIPO_COMP IN ('01','03','07','08') AND ECP.ESTADO_COMP IN ('3','6') " +
				"              WHERE EXTRACT(YEAR FROM ECP.FEC_EMISION)|| LPAD(EXTRACT(MONTH FROM ECP.FEC_EMISION),2,'0') = '" + periodo + "' " +
				"              ORDER BY ECP.ID_COMPROBANTE;" +
				""    +
				"	BEGIN " +
				"  		OPEN C_ECOMPROBANTE; " +
				"  		LOOP " +
				"  		FETCH C_ECOMPROBANTE INTO V_IDCOMPROBANTE,V_IDPLE; " +
				"  		EXIT WHEN C_ECOMPROBANTE%NOTFOUND; " +
				"" +
				"      		UPDATE CPE_ECOMPROBANTE SET ID_PLE = V_IDPLE " + 
				"      		WHERE ID_COMPROBANTE = V_IDCOMPROBANTE; " +
				""  +
				"  		END LOOP; " +
				"  		CLOSE C_ECOMPROBANTE; " + 
				"	END; ";
	        
	        CallableStatement cs = c.prepareCall(plsql);	
	        cs.execute();
	        cs.close();
	        c.close();
	        
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/********************************************************************************************************************/
	/******************************************* FIN PLSQL ACTUALIZAR PLE ***********************************************/
	/********************************************************************************************************************/
	

	private void enviarMensaje(String mensaje) {
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, mensaje, null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	}
	
	public List<SelectItem> getReporteItems() {
		return reporteItems;
	}

	public void setReporteItems(List<SelectItem> reporteItems) {
		this.reporteItems = reporteItems;
	}

	public ParametroCpeService getParametroCpeService() {
		return parametroCpeService;
	}

	public void setParametroCpeService(ParametroCpeService parametroCpeService) {
		this.parametroCpeService = parametroCpeService;
	}

	public String getReporteSelected() {
		return reporteSelected;
	}

	public void setReporteSelected(String reporteSelected) {
		this.reporteSelected = reporteSelected;
	}

	public String getTipoComprobanteSelected() {
		return tipoComprobanteSelected;
	}

	public void setTipoComprobanteSelected(String tipoComprobanteSelected) {
		this.tipoComprobanteSelected = tipoComprobanteSelected;
	}

	public List<SelectItem> getTipoComprobanteItems() {
		return tipoComprobanteItems;
	}

	public void setTipoComprobanteItems(List<SelectItem> tipoComprobanteItems) {
		this.tipoComprobanteItems = tipoComprobanteItems;
	}

	public String getEstadoSelected() {
		return estadoSelected;
	}

	public void setEstadoSelected(String estadoSelected) {
		this.estadoSelected = estadoSelected;
	}

	public List<SelectItem> getEstadoItems() {
		return estadoItems;
	}

	public void setEstadoItems(List<SelectItem> estadoItems) {
		this.estadoItems = estadoItems;
	}

	public Boolean getMostrarPeriodoRegVentas() {
		return mostrarPeriodoRegVentas;
	}

	public void setMostrarPeriodoRegVentas(Boolean mostrarPeriodoRegVentas) {
		this.mostrarPeriodoRegVentas = mostrarPeriodoRegVentas;
	}

	public String getPeriodoReporte() {
		return periodoReporte;
	}

	public void setPeriodoReporte(String periodoReporte) {
		this.periodoReporte = periodoReporte;
	}

	public String getCambioUsdPen() {
		return cambioUsdPen;
	}

	public void setCambioUsdPen(String cambioUsdPen) {
		this.cambioUsdPen = cambioUsdPen;
	}

	public Date getFecCargaDesde() {
		return fecCargaDesde;
	}

	public void setFecCargaDesde(Date fecCargaDesde) {
		this.fecCargaDesde = fecCargaDesde;
	}

	public Date getFecCargaHasta() {
		return fecCargaHasta;
	}

	public void setFecCargaHasta(Date fecCargaHasta) {
		this.fecCargaHasta = fecCargaHasta;
	}

	public String getUsuarioSesion() {
		return usuarioSesion;
	}

	public void setUsuarioSesion(String usuarioSesion) {
		this.usuarioSesion = usuarioSesion;
	}

	public ReportesCpeService getReportesCpeService() {
		return reportesCpeService;
	}

	public void setReportesCpeService(ReportesCpeService reportesCpeService) {
		this.reportesCpeService = reportesCpeService;
	}

	public HistorialReporteCpeService getHistorialReporteCpeService() {
		return historialReporteCpeService;
	}

	public void setHistorialReporteCpeService(
			HistorialReporteCpeService historialReporteCpeService) {
		this.historialReporteCpeService = historialReporteCpeService;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public List<SelectItem> getEmpresaItems() {
		return empresaItems;
	}

	public void setEmpresaItems(List<SelectItem> empresaItems) {
		this.empresaItems = empresaItems;
	}

	public ProcesoCpeService getProcesoCpeService() {
		return procesoCpeService;
	}

	public void setProcesoCpeService(ProcesoCpeService procesoCpeService) {
		this.procesoCpeService = procesoCpeService;
	}

	public UbigeoCpeService getUbigeoCpeService() {
		return ubigeoCpeService;
	}

	public void setUbigeoCpeService(UbigeoCpeService ubigeoCpeService) {
		this.ubigeoCpeService = ubigeoCpeService;
	}

	public TipoCambioCpeService getTipoCambioCpeService() {
		return tipoCambioCpeService;
	}

	public void setTipoCambioCpeService(TipoCambioCpeService tipoCambioCpeService) {
		this.tipoCambioCpeService = tipoCambioCpeService;
	}

	public boolean isFlagPeriodo() {
		return flagPeriodo;
	}

	public void setFlagPeriodo(boolean flagPeriodo) {
		this.flagPeriodo = flagPeriodo;
	}
	public boolean isFlagExportar() {
		return flagExportar;
	}

	public void setFlagExportar(boolean flagExportar) {
		this.flagExportar = flagExportar;
	}
	
	public boolean isMostrarBoton() {
		return mostrarBoton;
	}

	public void setMostrarBoton(boolean mostrarBoton) {
		this.mostrarBoton = mostrarBoton;
	}
}
