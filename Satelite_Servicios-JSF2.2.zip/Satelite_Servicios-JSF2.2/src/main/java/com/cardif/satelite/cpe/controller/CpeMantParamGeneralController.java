
package com.cardif.satelite.cpe.controller;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.UsuarioBean;
import com.cardif.satelite.cpe.service.ParametroCpeService;
import com.cardif.satelite.cpe.service.UsuarioService;

@Controller("cpeMantParamGeneralController")
@Scope("session")
public class CpeMantParamGeneralController extends BaseController implements Serializable {
	private static final long serialVersionUID = 1L;
	private Date timeVersion;

	public static final Logger LOGGER = Logger.getLogger(CpeMantParamGeneralController.class);

	private String codUsuario;
	private String nomUsuario;
	private String correoUsuario;
	private String estadoUsuario;
	private String rutaCargaArchivoLayout;
	private String rutaGeneraTramaMasivaSeguros;
	private String rutaGeneraTramaMasivaServicios;
	private String rutaRespuestaTramaMasiva;
	private String separadorCamposTrama;
	private String prefijoLote;
	private String prefijoProceso;
	private String prefijoTipoProcesoMasivo;
	private String prefijoTipoProcesoOnline;
	private String prefijoFacturaElectronica;
	private String prefijoNotaCredito;
	private String prefijoBoletaElectrica;
	private String prefijoNotaDebito;
	private String tipoProceso;
	private String urlSwOnlineProd;
	private String usuarioProduccion;
	private String passwordProduccion;
	private String urlSwOnlineTest;
	private String usuarioTest;
	private String passwordTest;
	
	private String usuProdSeg;
	private String usuProdServ;
	private String usuTestSeg;
	private String usuTestServ;
	private String passProdSeg;
	private String passProdServ;
	private String passTestSeg;
	private String passTestServ;
	
	String usuarioDb;
	
	private List<UsuarioBean> listaUsuario;
	private int nroRegistros;
	private UsuarioBean usuarioSeleccionado; 

	@Autowired
	ParametroService parametroService;
	@Autowired
	private UsuarioService usuarioService;
	@Autowired
	private ParametroCpeService parametroCpeService;

	@Override
	@PostConstruct
	public String inicio() {
		try {
			if (tieneAcceso()) {
				timeVersion = new Date();
				usuarioDb = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
				inicializarVariables();
				listarParametros();
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	
	public void inicializarVariables(){
		listaUsuario = new ArrayList<UsuarioBean>();
		nroRegistros = listaUsuario.size();
		usuarioSeleccionado = new UsuarioBean();
		
		codUsuario = "";
		nomUsuario = "";
		correoUsuario = "";
		estadoUsuario = "";
	}
	
	public void cancelar(){
		inicializarVariables();
		listarParametros();
	}
	
	public void guardar(){
		try{
			validaRuta();
			validarCamposVacios();
			actualizarParametros();
			enviarMensaje(ErrorConstants.COD_ERROR_MANT_PARAM_GENER_INSERTAR);
			listarParametros();
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	private void validaRuta() throws SyncconException{
		try {
			
			String rutaLayout = rutaCargaArchivoLayout;
			String genTramaSeguro =rutaGeneraTramaMasivaSeguros; 
			String genTramaServicio = rutaGeneraTramaMasivaServicios;
			String resPTramaMasiva = rutaRespuestaTramaMasiva;
			
			File frutaLayout = new File(rutaLayout);
			File fgenTramaSeguro = new File(genTramaSeguro);
			File fgenTramaServicio = new File(genTramaServicio);
			File fresPTramaMasiva = new File(resPTramaMasiva);
			
			if(!frutaLayout.isDirectory())
				throw new SyncconException(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_RUTA_CARGA_ARCHIVOS, FacesMessage.SEVERITY_INFO);
			if(!fgenTramaSeguro.isDirectory())
				throw new SyncconException(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_RUTA_TRAMA_SEGUROS, FacesMessage.SEVERITY_INFO);
			if(!fgenTramaServicio.isDirectory())
				throw new SyncconException(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_RUTA_TRAMA_SERVICIO, FacesMessage.SEVERITY_INFO);
			if(!fresPTramaMasiva.isDirectory())
				throw new SyncconException(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_RUTA_TRAMA_RESPUESTA, FacesMessage.SEVERITY_INFO);
		
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		}
	}
	
	private void enviarMensaje(String codMensaje) {
		String mensaje = PropertiesErrorUtil.getProperty(codMensaje);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje, null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	}
	
	public void validarCamposVacios() throws SyncconException{
		if(rutaCargaArchivoLayout.trim().equals("") ||
			rutaGeneraTramaMasivaSeguros.trim().equals("") ||
			rutaGeneraTramaMasivaServicios.trim().equals("") ||
			rutaRespuestaTramaMasiva.trim().equals("") ||
			//separadorCamposTrama.trim().equals("") ||
			prefijoLote.trim().equals("") ||
			prefijoProceso.trim().equals("") ||
			prefijoTipoProcesoMasivo.trim().equals("") ||
			prefijoTipoProcesoOnline.trim().equals("") ||
			prefijoFacturaElectronica.trim().equals("") ||
			prefijoNotaCredito.trim().equals("") ||
			prefijoBoletaElectrica.trim().equals("") ||
			prefijoNotaDebito.trim().equals("") ||
			tipoProceso.trim().equals("") ||
			urlSwOnlineProd.trim().equals("") ||
			urlSwOnlineTest.trim().equals("") ||
			usuProdSeg.trim().equals("")||
			usuProdServ.trim().equals("")||
			usuTestSeg.trim().equals("")||
			usuTestServ.trim().equals("")||
			passProdSeg.trim().equals("")||
			passProdServ.trim().equals("")||
			passTestSeg.trim().equals("")||
			passTestServ.trim().equals("")){
				throw new SyncconException(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS, FacesMessage.SEVERITY_INFO);
		}
	}
	
	public void listarParametros(){
		obtenerParametrosRutaCargaArchivosLayout();
		obtenerParametrosGeneracionTramaMasiva();
		obtenerParametrosGeneracionNombreLote();
		obtenerParametrosPrefijosComprobantesElectronicos();
		obtenerParametrosConfiguracionServiciosEnvioProveedor();
	}
	
	public void actualizarParametros(){
		actualizarParametrosRutaCargaArchivosLayout();
		actualizarParametrosGeneracionTramaMasiva();
		actualizarParametrosGeneracionNombreLote();
		actualizarParametrosPrefijosComprobantesElectronicos();
		actualizarParametrosConfiguracionServiciosEnvioProveedor();
	}

	private void obtenerParametrosRutaCargaArchivosLayout(){
		rutaCargaArchivoLayout = listarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SIS_GENERAL_RUTA_CARGA);
	}
	
	private void obtenerParametrosGeneracionTramaMasiva(){
		rutaGeneraTramaMasivaSeguros = listarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SISRUTA_SEGUROS);
		rutaGeneraTramaMasivaServicios = listarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SISRUTA_SERVICIO);
		rutaRespuestaTramaMasiva = listarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SISRUTARESP);
		//separadorCamposTrama = listarParametro(Constantes.COD_PARAM_CPE_ESCONTRAMA_SPLT, Constantes.COD_PARAM_CPE_ESCONTRAMA_SPLT_ESCONTRAMA_SPLT);
	}
	
	private void obtenerParametrosGeneracionNombreLote(){
		prefijoLote = listarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_LT);
		prefijoProceso = listarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_PROC);
		prefijoTipoProcesoMasivo = listarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_TP_MAS);
		prefijoTipoProcesoOnline = listarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_TP_ONL);
	}
	
	private void obtenerParametrosPrefijosComprobantesElectronicos(){
		prefijoFacturaElectronica = listarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_FAC_ELEC);
		prefijoNotaCredito = listarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_NCF_ELEC);
		prefijoBoletaElectrica = listarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_BOL_ELEC);
		prefijoNotaDebito = listarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_NDF_ELEC);
	}
	
	private void obtenerParametrosConfiguracionServiciosEnvioProveedor(){
		tipoProceso = listarParametro(Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST, Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST_FLG_SW_PROD_TEST);
		urlSwOnlineProd = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_PARAM_ESCON_SW_PRD_URL_SW_PRD);
		urlSwOnlineTest = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_PARAM_ESCON_SW_TST_URL_SW_TST);
		
		usuProdSeg = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_USU_SW_PRD_SEG);
		passProdSeg = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_PASS_SW_PRD_SEG);
		usuProdServ = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_USU_SW_PRD_SERV);
		passProdServ = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_PASS_SW_PRD_SERV);
		
		usuTestSeg = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_USU_SW_TST_SEG);
		passTestSeg = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_PASS_SW_TST_SEG);
		usuTestServ = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_USU_SW_TST_SERV);
		passTestServ = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_PASS_SW_TST_SERV);
	}
	
	private void actualizarParametrosRutaCargaArchivosLayout(){
		actualizarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SIS_GENERAL_RUTA_CARGA, rutaCargaArchivoLayout);
	}
	
	private void actualizarParametrosGeneracionTramaMasiva(){
		actualizarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SISRUTA_SEGUROS, rutaGeneraTramaMasivaSeguros);
		actualizarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SISRUTA_SERVICIO, rutaGeneraTramaMasivaServicios);
		actualizarParametro(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG, Constantes.COD_VALOR_SISRUTARESP, rutaRespuestaTramaMasiva);
		//actualizarParametro(Constantes.COD_PARAM_CPE_ESCONTRAMA_SPLT, Constantes.COD_PARAM_CPE_ESCONTRAMA_SPLT_ESCONTRAMA_SPLT, separadorCamposTrama);
	}
	
	private void actualizarParametrosGeneracionNombreLote(){
		actualizarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_LT, prefijoLote);
		actualizarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_PROC, prefijoProceso);
		actualizarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_TP_MAS, prefijoTipoProcesoMasivo);
		actualizarParametro(Constantes.COD_PARAM_CPE_LOTE_CE, Constantes.COD_PARAM_CPE_LOTE_CE_PRF_TP_ONL, prefijoTipoProcesoOnline);
	}
	
	private void actualizarParametrosPrefijosComprobantesElectronicos(){
		actualizarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_FAC_ELEC, prefijoFacturaElectronica);
		actualizarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_NCF_ELEC, prefijoNotaCredito);
		actualizarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_BOL_ELEC, prefijoBoletaElectrica);
		actualizarParametro(Constantes.COD_PARAM_CPE_PREFIJO_CE, Constantes.COD_PARAM_CPE_PREFIJO_CE_NDF_ELEC, prefijoNotaDebito);
	}
	
	private void actualizarParametrosConfiguracionServiciosEnvioProveedor(){
		actualizarParametro(Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST, Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST_FLG_SW_PROD_TEST, tipoProceso);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_PARAM_ESCON_SW_PRD_URL_SW_PRD, urlSwOnlineProd);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_PARAM_ESCON_SW_TST_URL_SW_TST, urlSwOnlineTest);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_USU_SW_PRD_SEG, usuProdSeg);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_PASS_SW_PRD_SEG, passProdSeg);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_USU_SW_PRD_SERV, usuProdServ);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_PASS_SW_PRD_SERV, passProdServ);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_USU_SW_TST_SEG, usuTestSeg);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_PASS_SW_TST_SEG, passTestSeg);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_USU_SW_TST_SERV, usuTestServ);
		actualizarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_PASS_SW_TST_SERV, passTestServ);
	}
	
	private String listarParametro(String codParametro, String codValor){
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		parametroBean.setCodValor(codValor);
		parametroBean = parametroCpeService.listarParametro(parametroBean).get(0);
		return parametroBean.getNomValor();
	}
	
	private void actualizarParametro(String codParametro, String codValor, String nomValor){
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		parametroBean.setCodValor(codValor);
		parametroBean.setNomValor(nomValor);
		parametroBean.setUsuModifica(usuarioDb);
		parametroCpeService.actualizarParametro(parametroBean);
	}
	
	private void validacionCorreoUsuario() throws SyncconException
	{
 		String ValorFijo= "@cardif.com.pe";
		if(!correoUsuario.toUpperCase().contains(ValorFijo.toUpperCase())){
			throw new SyncconException(ErrorConstants.COD_ERROR_MANT_PARAM_GENER_CORREO_INVALIDO, FacesMessage.SEVERITY_INFO);
		}
	}
	
	public void buscarUsuario(){
		if(usuarioSeleccionado.getIdUsuario() != null){
			inicializarVariables();
		}
		UsuarioBean usuarioBean = new UsuarioBean();
		usuarioBean.setCodigoUsuario(codUsuario.trim().equals("") ? null : codUsuario);
		usuarioBean.setNombreUsuario(nomUsuario.trim().equals("") ? null : nomUsuario);
		usuarioBean.setCorreoUsuario(correoUsuario.trim().equals("") ? null : correoUsuario);
		usuarioBean.setEstado(estadoUsuario.trim().equals("") ? null : estadoUsuario.trim().equals("-1") ? null : estadoUsuario);
		listaUsuario = usuarioService.listarUsuario(usuarioBean);
		nroRegistros = listaUsuario.size();
	}
	
	public void obtenerUsuario(){
		if (usuarioSeleccionado != null) {
			setCodUsuario(usuarioSeleccionado.getCodigoUsuario());
			setNomUsuario(usuarioSeleccionado.getNombreUsuario());
			setCorreoUsuario(usuarioSeleccionado.getCorreoUsuario());
			setEstadoUsuario(usuarioSeleccionado.getEstado());
		}
	}
	
	public void agregarUsuario(){
		try{
			validarCamposUsuario();
			validacionCorreoUsuario();
			UsuarioBean usuarioBean = new UsuarioBean();
			usuarioBean.setCodigoUsuario(codUsuario);
			usuarioBean.setNombreUsuario(nomUsuario);
			usuarioBean.setCorreoUsuario(correoUsuario);
			usuarioBean.setEstado(estadoUsuario);
			if(usuarioSeleccionado.getIdUsuario() == null){
				usuarioBean.setUsuarioCreacion(usuarioDb);
				usuarioService.insertarUsuario(usuarioBean);
			}else {
				usuarioBean.setIdUsuario(usuarioSeleccionado.getIdUsuario());
				usuarioBean.setUsuarioModificacion(usuarioDb);
				usuarioService.actualizarUsuario(usuarioBean);
			}
			inicializarVariables();
			buscarUsuario();
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	private void validarCamposUsuario() throws SyncconException{
		if(codUsuario.trim().equals("") ||
				nomUsuario.trim().equals("") ||
				correoUsuario.trim().equals("") ||
				estadoUsuario.trim().equals("-1")){
			throw new SyncconException(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS, FacesMessage.SEVERITY_INFO);
		}
	}
	
	public void eliminarUsuario(){
		UsuarioBean usuarioBean = new UsuarioBean();
		usuarioBean.setIdUsuario(usuarioSeleccionado.getIdUsuario());
		usuarioBean.setUsuarioModificacion(usuarioDb);
		usuarioService.eliminarUsuario(usuarioBean);
		buscarUsuario();
	}

	public Date getTimeVersion() {
		return timeVersion;
	}

	public void setTimeVersion(Date timeVersion) {
		this.timeVersion = timeVersion;
	}

	public String getCorreoUsuario() {
		return correoUsuario;
	}

	public void setCorreoUsuario(String correoUsuario) {
		this.correoUsuario = correoUsuario;
	}

	public List<UsuarioBean> getListaUsuario() {
		return listaUsuario;
	}

	public void setListaUsuario(List<UsuarioBean> listaUsuario) {
		this.listaUsuario = listaUsuario;
	}

	public ParametroService getParametroService() {
		return parametroService;
	}

	public void setParametroService(ParametroService parametroService) {
		this.parametroService = parametroService;
	}

	public UsuarioService getUsuarioService() {
		return usuarioService;
	}

	public void setUsuarioService(UsuarioService usuarioService) {
		this.usuarioService = usuarioService;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getNomUsuario() {
		return nomUsuario;
	}

	public void setNomUsuario(String nomUsuario) {
		this.nomUsuario = nomUsuario;
	}

	public String getEstadoUsuario() {
		return estadoUsuario;
	}

	public void setEstadoUsuario(String estadoUsuario) {
		this.estadoUsuario = estadoUsuario;
	}

	public UsuarioBean getUsuarioSeleccionado() {
		return usuarioSeleccionado;
	}

	public void setUsuarioSeleccionado(UsuarioBean usuarioSeleccionado) {
		this.usuarioSeleccionado = usuarioSeleccionado;
	}

	public int getNroRegistros() {
		return nroRegistros;
	}

	public void setNroRegistros(int nroRegistros) {
		this.nroRegistros = nroRegistros;
	}

	public String getRutaCargaArchivoLayout() {
		return rutaCargaArchivoLayout;
	}

	public void setRutaCargaArchivoLayout(String rutaCargaArchivoLayout) {
		this.rutaCargaArchivoLayout = rutaCargaArchivoLayout;
	}

	public String getRutaRespuestaTramaMasiva() {
		return rutaRespuestaTramaMasiva;
	}

	public void setRutaRespuestaTramaMasiva(String rutaRespuestaTramaMasiva) {
		this.rutaRespuestaTramaMasiva = rutaRespuestaTramaMasiva;
	}

	public String getSeparadorCamposTrama() {
		return separadorCamposTrama;
	}

	public void setSeparadorCamposTrama(String separadorCamposTrama) {
		this.separadorCamposTrama = separadorCamposTrama;
	}

	public String getPrefijoLote() {
		return prefijoLote;
	}

	public void setPrefijoLote(String prefijoLote) {
		this.prefijoLote = prefijoLote;
	}

	public String getPrefijoProceso() {
		return prefijoProceso;
	}

	public void setPrefijoProceso(String prefijoProceso) {
		this.prefijoProceso = prefijoProceso;
	}

	public String getPrefijoTipoProcesoMasivo() {
		return prefijoTipoProcesoMasivo;
	}

	public void setPrefijoTipoProcesoMasivo(String prefijoTipoProcesoMasivo) {
		this.prefijoTipoProcesoMasivo = prefijoTipoProcesoMasivo;
	}

	public String getPrefijoTipoProcesoOnline() {
		return prefijoTipoProcesoOnline;
	}

	public void setPrefijoTipoProcesoOnline(String prefijoTipoProcesoOnline) {
		this.prefijoTipoProcesoOnline = prefijoTipoProcesoOnline;
	}

	public String getPrefijoFacturaElectronica() {
		return prefijoFacturaElectronica;
	}

	public void setPrefijoFacturaElectronica(String prefijoFacturaElectronica) {
		this.prefijoFacturaElectronica = prefijoFacturaElectronica;
	}

	public String getPrefijoNotaCredito() {
		return prefijoNotaCredito;
	}

	public void setPrefijoNotaCredito(String prefijoNotaCredito) {
		this.prefijoNotaCredito = prefijoNotaCredito;
	}

	public String getPrefijoBoletaElectrica() {
		return prefijoBoletaElectrica;
	}

	public void setPrefijoBoletaElectrica(String prefijoBoletaElectrica) {
		this.prefijoBoletaElectrica = prefijoBoletaElectrica;
	}

	public String getPrefijoNotaDebito() {
		return prefijoNotaDebito;
	}

	public void setPrefijoNotaDebito(String prefijoNotaDebito) {
		this.prefijoNotaDebito = prefijoNotaDebito;
	}

	public String getTipoProceso() {
		return tipoProceso;
	}

	public void setTipoProceso(String tipoProceso) {
		this.tipoProceso = tipoProceso;
	}

	public String getUrlSwOnlineProd() {
		return urlSwOnlineProd;
	}

	public void setUrlSwOnlineProd(String urlSwOnlineProd) {
		this.urlSwOnlineProd = urlSwOnlineProd;
	}

	public String getUsuarioProduccion() {
		return usuarioProduccion;
	}

	public void setUsuarioProduccion(String usuarioProduccion) {
		this.usuarioProduccion = usuarioProduccion;
	}

	public String getPasswordProduccion() {
		return passwordProduccion;
	}

	public void setPasswordProduccion(String passwordProduccion) {
		this.passwordProduccion = passwordProduccion;
	}

	public String getUrlSwOnlineTest() {
		return urlSwOnlineTest;
	}

	public void setUrlSwOnlineTest(String urlSwOnlineTest) {
		this.urlSwOnlineTest = urlSwOnlineTest;
	}

	public String getUsuarioTest() {
		return usuarioTest;
	}

	public void setUsuarioTest(String usuarioTest) {
		this.usuarioTest = usuarioTest;
	}

	public String getPasswordTest() {
		return passwordTest;
	}

	public void setPasswordTest(String passwordTest) {
		this.passwordTest = passwordTest;
	}

	public ParametroCpeService getParametroCpeService() {
		return parametroCpeService;
	}

	public void setParametroCpeService(ParametroCpeService parametroCpeService) {
		this.parametroCpeService = parametroCpeService;
	}
	
	public String getUsuProdSeg() {
		return usuProdSeg;
	}

	public void setUsuProdSeg(String usuProdSeg) {
		this.usuProdSeg = usuProdSeg;
	}

	public String getUsuProdServ() {
		return usuProdServ;
	}

	public void setUsuProdServ(String usuProdServ) {
		this.usuProdServ = usuProdServ;
	}

	public String getUsuTestSeg() {
		return usuTestSeg;
	}

	public void setUsuTestSeg(String usuTestSeg) {
		this.usuTestSeg = usuTestSeg;
	}

	public String getUsuTestServ() {
		return usuTestServ;
	}

	public void setUsuTestServ(String usuTestServ) {
		this.usuTestServ = usuTestServ;
	}

	public String getPassProdSeg() {
		return passProdSeg;
	}

	public void setPassProdSeg(String passProdSeg) {
		this.passProdSeg = passProdSeg;
	}

	public String getPassProdServ() {
		return passProdServ;
	}

	public void setPassProdServ(String passProdServ) {
		this.passProdServ = passProdServ;
	}

	public String getPassTestSeg() {
		return passTestSeg;
	}

	public void setPassTestSeg(String passTestSeg) {
		this.passTestSeg = passTestSeg;
	}

	public String getPassTestServ() {
		return passTestServ;
	}

	public void setPassTestServ(String passTestServ) {
		this.passTestServ = passTestServ;
	}

	public String getRutaGeneraTramaMasivaSeguros() {
		return rutaGeneraTramaMasivaSeguros;
	}

	public void setRutaGeneraTramaMasivaSeguros(String rutaGeneraTramaMasivaSeguros) {
		this.rutaGeneraTramaMasivaSeguros = rutaGeneraTramaMasivaSeguros;
	}

	public String getRutaGeneraTramaMasivaServicios() {
		return rutaGeneraTramaMasivaServicios;
	}

	public void setRutaGeneraTramaMasivaServicios(
			String rutaGeneraTramaMasivaServicios) {
		this.rutaGeneraTramaMasivaServicios = rutaGeneraTramaMasivaServicios;
	}
}

