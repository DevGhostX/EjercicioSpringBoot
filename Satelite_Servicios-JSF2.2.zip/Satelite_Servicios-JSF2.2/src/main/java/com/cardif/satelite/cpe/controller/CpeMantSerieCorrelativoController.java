
package com.cardif.satelite.cpe.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.ConfiguracionCpeBean;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.ProductoCpeBean;
import com.cardif.satelite.cpe.bean.SerieHistorialCpeBean;
import com.cardif.satelite.cpe.bean.SocioCpeBean;
import com.cardif.satelite.cpe.service.ConfiguracionCpeService;
import com.cardif.satelite.cpe.service.ParametroCpeService;
import com.cardif.satelite.cpe.service.ProductoCpeService;
import com.cardif.satelite.cpe.service.SerieHistorialCpeService;
import com.cardif.satelite.cpe.service.SocioCpeService;

@Controller("cpeMantSerieCorrelativoController")
@Scope("session")
public class CpeMantSerieCorrelativoController extends BaseController implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public static final Logger LOGGER = Logger.getLogger(CpeMantSerieCorrelativoController.class);
	
	private Date timeVersion;

	/****************** deshabilitados ******************/
	private boolean bloqueaEmpresaNew;
	private boolean bloqueaSocioNew;
	private boolean bloqueoProductoNew;
	private boolean bloqueaTipCompNew;
	private boolean bloqueaTipProductoNew;
	private boolean bloqueaAfectoNew;
	private boolean bloqueaIndicadorNew;
	private boolean bloqueaEstadoNew;
	private boolean bloqueaPrefijoNew;
	private boolean bloqueaSerieNew;
	private boolean bloqueaCorrelInicialNew;
	private boolean bloqueaCorrelFinalNew;
	
	private boolean puedeEliminar;
	
	private String empresaNew;
	private String socioNew;
	private String productoNew;
	private String tipCompNew;
	private String tipProductoNew;
	private String afectoNew;
	private String indicadorNew;
	private String estadoNew;
	private String prefijoNew;
	private String serieNew;
	private String correlInicialNew;
	private String correlFinalNew;
	
	//Lista combos y selección de combos
	private String empresaSelected;
	private List<SelectItem> empresaItems;
	private String socioSelected;
	private List<SelectItem> socioItems;
	private String productoSelected;
	private List<SelectItem> productoItems;
	private List<SelectItem> productoNewItems;
	private String tipoComprobanteSelected;
	private List<SelectItem> tipoComprobanteItems;
	private String tipoProductoSelected;
	private List<SelectItem> tipoProductoItems;
	private String estadoCfgSelected;
	private List<SelectItem> estadoCfgItems;
	
	private String afectoIGVSelected;
	private String indicadorPimsSelected;


	// Otras variables
	String usuarioDb;
	
	private List<ConfiguracionCpeBean> listaConfiguracion;
	private int nroRegistros;
	private ConfiguracionCpeBean confSeleccionada;

	// Variables de servicios
	@Autowired
	ParametroService parametroService;
	@Autowired
	private ParametroCpeService parametroCpeService;
	@Autowired
	private SocioCpeService socioCpeService;
	@Autowired
	private ProductoCpeService productoCpeService;
	@Autowired
	private ConfiguracionCpeService configuracionCpeService;
	@Autowired
	private SerieHistorialCpeService serieHistorialCpeService;

	@Override
	@PostConstruct
	public String inicio() {
		try {
			if (tieneAcceso()) {
				timeVersion = new Date();
				usuarioDb = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
				inicializarVariablesFiltros();
				inicializarVariablesNewFiltros();
				llenarCombos();
				//validarSiEsRedireccionamiento();
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	
	public void validarSiEsRedireccionamiento(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		FacesContext context = FacesContext.getCurrentInstance();
		bean = (ConfiguracionCpeBean)context.getExternalContext().getSessionMap().get("conf");
		
		if(bean != null){
			empresaSelected = bean.getIdEmpresa();
			socioSelected = String.valueOf(bean.getIdSocio());
			productoSelected = String.valueOf(bean.getIdProducto());
			tipoComprobanteSelected = bean.getIdTipoComp();
			tipoProductoSelected = bean.getTipoProducto();
			estadoCfgSelected = bean.getEstadoConfig();
			
			actualizarValoresProducto();
			buscar();
			
			context.getExternalContext().getSessionMap().remove("conf");
		}
	}
	
	public void actualizarConfiguracion(){
		//camposObligatorios();
		try{
	
			if (serieNew == null || serieNew.trim().length() <= 0){
				throw new SyncconException(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS, FacesMessage.SEVERITY_INFO);
			}
			else if (serieNew.trim().length() != Constantes.CPE_LONGITUD_SERIE){
				throw new SyncconException(ErrorConstants.COD_ERROR_MSJ_LONGITUD_SERIE, FacesMessage.SEVERITY_INFO);
			}
			
			ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
			bean.setIdEmpresa(empresaNew);
			bean.setIdTipoComp(tipCompNew);
			bean.setPrefijo(prefijoNew);
			bean.setSerie(serieNew);
			bean.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
			bean.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
			bean.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
			List<ConfiguracionCpeBean> listaConf = configuracionCpeService.listarConfiguracion(bean);
			if(!listaConf.isEmpty()){
				enviarMensaje(ErrorConstants.COD_ERROR_MANT_SERIE_CORRELATIVO_NUM_ASIGNADO);
				return;
			}else{
				/* Tabla CPE_SERIE_HISTORIAL Inicio */
				SerieHistorialCpeBean serieHistorialCpeBean = new SerieHistorialCpeBean();
				List<SerieHistorialCpeBean> listaSerieHistorialCpeBean = new ArrayList<SerieHistorialCpeBean>();
				serieHistorialCpeBean.setIdEmpresa(empresaNew);
				serieHistorialCpeBean.setIdTipoComp(tipCompNew);
				serieHistorialCpeBean.setPrefijo(prefijoNew);
				serieHistorialCpeBean.setSerie(serieNew);
				listaSerieHistorialCpeBean = serieHistorialCpeService.listarSerieHistorial(serieHistorialCpeBean);
				
				if(listaSerieHistorialCpeBean.isEmpty()){
					configuracionCpeService.actualizarConfiguracionSerieCorrelativo(setUpdate());
					
					serieHistorialCpeBean.setIdSocio(Integer.parseInt(socioNew));
					serieHistorialCpeBean.setIdProducto(Integer.parseInt(productoNew));
					serieHistorialCpeBean.setUsuCrea(usuarioDb);
					serieHistorialCpeService.insertarSerieHistorial(serieHistorialCpeBean);
					enviarMensaje(ErrorConstants.COD_ERROR_MANT_SERIE_CORRELATIVO_INSERTAR);
				}else{
					enviarMensaje(ErrorConstants.COD_ERROR_MANT_SERIE_CORRELATIVO_NUM_ASIGNADO);
					return;
				}
				/* Tabla CPE_SERIE_HISTORIAL Fin */
			}
			buscar();
		}catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}	
	
	public ConfiguracionCpeBean setUpdate(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		bean.setIdEmpresa(empresaNew);
		bean.setIdSocio(Integer.parseInt(socioNew));
		bean.setIdProducto(Integer.parseInt(productoNew));
		bean.setIdTipoComp(tipCompNew);
		bean.setPrefijo(prefijoNew == null ? "" : prefijoNew);
		bean.setSerie(serieNew);
		bean.setUsuModifica(usuarioDb);
		return bean;
	}
	
	private void inicializarVariablesFiltros(){
		
		listaConfiguracion = new ArrayList<ConfiguracionCpeBean>();
		nroRegistros = listaConfiguracion.size();
		
		empresaSelected = "";
		empresaItems = new ArrayList<SelectItem>();
		socioSelected = "";
		socioItems = new ArrayList<SelectItem>();
		productoSelected = "";
		productoItems = new ArrayList<SelectItem>();
		tipoComprobanteSelected = "";
		tipoComprobanteItems = new ArrayList<SelectItem>();
		tipoProductoSelected = "";
		tipoProductoItems = new ArrayList<SelectItem>();
		estadoCfgSelected = "";
		estadoCfgItems = new ArrayList<SelectItem>();
		
		puedeEliminar = false;
	}
	
	private void inicializarVariablesNewFiltros(){
		
		productoNewItems = new ArrayList<SelectItem>();
		
		empresaNew = "";
		socioNew = "";
		productoNew = "";
		tipCompNew = "";
		tipProductoNew = "";
		afectoNew = "";
		indicadorNew = "";
		estadoNew = "";
		prefijoNew = "";
		serieNew = "";
		correlInicialNew = "";
		correlFinalNew = "";

	}
	
	private void llenarCombos(){
		listarSocio();
		listarProducto();
		empresaItems = listarParametro(Constantes.COD_PARAM_CPE_EMPRESA, true);
		tipoComprobanteItems = listarParametro(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES, true);
		tipoProductoItems = listarParametro(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO, true);
		estadoCfgItems = listarParametro(Constantes.COD_PARAM_CPE_ESTADO_CFG, true);
	}
	
	public void buscar(){
		listaConfiguracion = configuracionCpeService.listarConfiguracion(setFiltrosBusqueda());
		nroRegistros = listaConfiguracion.size();
		if(listaConfiguracion.isEmpty()){
			enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_BUSQUEDA);
		}
	}
	
	private void enviarMensaje(String codMensaje) {
		String mensaje = PropertiesErrorUtil.getProperty(codMensaje);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje, null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	}
	
	public void limpiar(){
		inicializarVariablesFiltros();
		llenarCombos();
	}
	
	public void validarEliminacion(){
		puedeEliminar = false;
		if(confSeleccionada.getCorActual() == null || confSeleccionada.getCorActual() == 0){
			puedeEliminar = true;
		}else {
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_ELIMINAR_SERIE_CORRELATIVO_TIENE_COMPROBANTES_EMITIDOS);
		}
	}
	
	public void eliminar(){
		configuracionCpeService.inactivarConfiguracion(setDelete());
		buscar();
	}
	
	public ConfiguracionCpeBean setDelete(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		bean.setIdEmpresa(confSeleccionada.getIdEmpresa());
		bean.setIdSocio(confSeleccionada.getIdSocio());
		bean.setIdProducto(confSeleccionada.getIdProducto());
		bean.setIdTipoComp(confSeleccionada.getIdTipoComp());
		bean.setUsuModifica(usuarioDb);
		return bean;
	}
	
	public ConfiguracionCpeBean setFiltrosBusqueda(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		bean.setIdEmpresa(empresaSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : empresaSelected);
		bean.setIdSocio(socioSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : Integer.parseInt(socioSelected));
		bean.setIdProducto(productoSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : Integer.parseInt(productoSelected));
		bean.setIdTipoComp(tipoComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipoComprobanteSelected);
		bean.setTipoProducto(tipoProductoSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipoProductoSelected);
		bean.setEstadoConfig(estadoCfgSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : estadoCfgSelected);
		bean.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
		bean.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		bean.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
		return bean;
	}
	
	private void listarSocio(){
		SocioCpeBean socioCpeBean = new SocioCpeBean();
		List<SocioCpeBean> listaSocioBean = new ArrayList<SocioCpeBean>();
		listaSocioBean = socioCpeService.listarSocio(socioCpeBean);
		socioItems = new ArrayList<SelectItem>();
		socioItems.add(new SelectItem("-1", "- Seleccionar -"));

		for (Iterator<SocioCpeBean> iterator = listaSocioBean.iterator(); iterator.hasNext();) {
			SocioCpeBean listaOrigenDatos = (SocioCpeBean) iterator.next();
			socioItems.add(new SelectItem(String.valueOf(listaOrigenDatos.getIdSocio()), listaOrigenDatos.getNomSocio()));
		}
	}
	
	public void actualizarValoresProducto() {
		listarProducto();
	}
	
	private void listarProducto(){
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		List<ProductoCpeBean> listaProductoBean = new ArrayList<ProductoCpeBean>();
		if(!socioSelected.isEmpty()){
			productoCpeBean.setIdSocio(Integer.parseInt(socioSelected));
			listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
		}
		productoItems = new ArrayList<SelectItem>();
		productoItems.add(new SelectItem("-1", "- Seleccionar -"));

		for (Iterator<ProductoCpeBean> iterator = listaProductoBean.iterator(); iterator.hasNext();) {
			ProductoCpeBean producto = (ProductoCpeBean) iterator.next();
			productoItems.add(new SelectItem(String.valueOf(producto.getIdProducto()), producto.getNomProducto()));
		}
	}
	
	private List<SelectItem> listarParametro(String codParametro, boolean insertarSeleccionar){
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listaParametroBean = new ArrayList<ParametroCpeBean>();
		listaParametroBean = parametroCpeService.listarParametro(parametroBean);
		List<SelectItem> combo = new ArrayList<SelectItem>();
		if(insertarSeleccionar){
			combo.add(new SelectItem("-1", "- Seleccionar -"));
		}

		for (Iterator<ParametroCpeBean> iterator = listaParametroBean.iterator(); iterator.hasNext();) {
			ParametroCpeBean parametro = (ParametroCpeBean) iterator.next();
			combo.add(new SelectItem(parametro.getCodValor(), parametro.getNomValor()));
		}
		return combo;
	}

//	public void camposObligatorios() {
//		try{
//			boolean camposObligatorios;
//			camposObligatorios = false;
//	
//			if (prefijoNew == null || prefijoNew.trim().length() <= 0)
//				camposObligatorios = true;
//			else if (serieNew == null || serieNew.trim().length() <= 0)
//				camposObligatorios = true;
//	
//			if (camposObligatorios) {
//				throw new SyncconException(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS, FacesMessage.SEVERITY_INFO);
//			}
//		}catch (SyncconException ex) {
//			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
//			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
//			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
//		}
//		
//	}

	/** ABRE POPUP **/
	public void muestraPopUp() {
		camposbloqueados(true, true, true, true, true, true, true, true, false, false, true, true);
		setVerDetalle();
	}
	
	public void setVerDetalle(){
		setEmpresaNew(confSeleccionada.getIdEmpresa());
		setSocioNew(String.valueOf(confSeleccionada.getIdSocio()));
		setProductoNew(String.valueOf(confSeleccionada.getIdProducto()));
		setTipCompNew(confSeleccionada.getIdTipoComp());
		setTipProductoNew(confSeleccionada.getTipoProducto());
		setAfectoNew(String.valueOf(confSeleccionada.getAfectoIgv()));
		setIndicadorNew(confSeleccionada.getIndPims());
		setEstadoNew(confSeleccionada.getEstadoConfig());
		setPrefijoNew(confSeleccionada.getPrefijo());
		setSerieNew(confSeleccionada.getSerie());
		setCorrelInicialNew(String.valueOf(confSeleccionada.getCorInicial()));
		setCorrelFinalNew(confSeleccionada.getCorActual() == null ? "" : String.valueOf(confSeleccionada.getCorActual()));
		listarProductoNew();
	}
	
	private void listarProductoNew(){
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		List<ProductoCpeBean> listaProductoBean = new ArrayList<ProductoCpeBean>();
		if(!socioNew.isEmpty()){
			productoCpeBean.setIdSocio(Integer.parseInt(socioNew));
			listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
		}
		productoNewItems = new ArrayList<SelectItem>();
		productoNewItems.add(new SelectItem(Constantes.VALOR_DEFECTO_CBX, "- Seleccionar -"));

		for (Iterator<ProductoCpeBean> iterator = listaProductoBean.iterator(); iterator.hasNext();) {
			ProductoCpeBean producto = (ProductoCpeBean) iterator.next();
			productoNewItems.add(new SelectItem(String.valueOf(producto.getIdProducto()), producto.getNomProducto()));
		}
	}

	public void camposbloqueados(boolean empresaNew, boolean socioNew, boolean productoNew, boolean tipCompNew,
			boolean tipProductoNew, boolean afectoNew, boolean indicadorNew, boolean estadoNew, boolean prefijoNew,
			boolean serieNew, boolean correlInicialNew, boolean correlFinalNew) {
		bloqueaEmpresaNew = empresaNew;
		bloqueaSocioNew = socioNew;
		bloqueoProductoNew = productoNew;
		bloqueaTipCompNew = tipCompNew;
		bloqueaTipProductoNew = tipProductoNew;
		bloqueaAfectoNew = afectoNew;
		bloqueaIndicadorNew = indicadorNew;
		bloqueaEstadoNew = estadoNew;
		bloqueaPrefijoNew = prefijoNew;
		bloqueaSerieNew = serieNew;
		bloqueaCorrelInicialNew = correlInicialNew;
		bloqueaCorrelFinalNew = correlFinalNew;
	}
	
	public Date getTimeVersion() {
		return timeVersion;
	}

	public void setTimeVersion(Date timeVersion) {
		this.timeVersion = timeVersion;
	}

	public boolean isBloqueaEmpresaNew() {
		return bloqueaEmpresaNew;
	}

	public void setBloqueaEmpresaNew(boolean bloqueaEmpresaNew) {
		this.bloqueaEmpresaNew = bloqueaEmpresaNew;
	}

	public boolean isBloqueaSocioNew() {
		return bloqueaSocioNew;
	}

	public void setBloqueaSocioNew(boolean bloqueaSocioNew) {
		this.bloqueaSocioNew = bloqueaSocioNew;
	}

	public boolean isBloqueoProductoNew() {
		return bloqueoProductoNew;
	}

	public void setBloqueoProductoNew(boolean bloqueoProductoNew) {
		this.bloqueoProductoNew = bloqueoProductoNew;
	}

	public boolean isBloqueaTipCompNew() {
		return bloqueaTipCompNew;
	}

	public void setBloqueaTipCompNew(boolean bloqueaTipCompNew) {
		this.bloqueaTipCompNew = bloqueaTipCompNew;
	}

	public boolean isBloqueaTipProductoNew() {
		return bloqueaTipProductoNew;
	}

	public void setBloqueaTipProductoNew(boolean bloqueaTipProductoNew) {
		this.bloqueaTipProductoNew = bloqueaTipProductoNew;
	}

	public boolean isBloqueaAfectoNew() {
		return bloqueaAfectoNew;
	}

	public void setBloqueaAfectoNew(boolean bloqueaAfectoNew) {
		this.bloqueaAfectoNew = bloqueaAfectoNew;
	}

	public boolean isBloqueaIndicadorNew() {
		return bloqueaIndicadorNew;
	}

	public void setBloqueaIndicadorNew(boolean bloqueaIndicadorNew) {
		this.bloqueaIndicadorNew = bloqueaIndicadorNew;
	}

	public boolean isBloqueaEstadoNew() {
		return bloqueaEstadoNew;
	}

	public void setBloqueaEstadoNew(boolean bloqueaEstadoNew) {
		this.bloqueaEstadoNew = bloqueaEstadoNew;
	}

	public boolean isBloqueaPrefijoNew() {
		return bloqueaPrefijoNew;
	}

	public void setBloqueaPrefijoNew(boolean bloqueaPrefijoNew) {
		this.bloqueaPrefijoNew = bloqueaPrefijoNew;
	}

	public boolean isBloqueaSerieNew() {
		return bloqueaSerieNew;
	}

	public void setBloqueaSerieNew(boolean bloqueaSerieNew) {
		this.bloqueaSerieNew = bloqueaSerieNew;
	}

	public boolean isBloqueaCorrelInicialNew() {
		return bloqueaCorrelInicialNew;
	}

	public void setBloqueaCorrelInicialNew(boolean bloqueaCorrelInicialNew) {
		this.bloqueaCorrelInicialNew = bloqueaCorrelInicialNew;
	}

	public boolean isBloqueaCorrelFinalNew() {
		return bloqueaCorrelFinalNew;
	}

	public void setBloqueaCorrelFinalNew(boolean bloqueaCorrelFinalNew) {
		this.bloqueaCorrelFinalNew = bloqueaCorrelFinalNew;
	}

	public String getEmpresaNew() {
		return empresaNew;
	}

	public void setEmpresaNew(String empresaNew) {
		this.empresaNew = empresaNew;
	}

	public String getSocioNew() {
		return socioNew;
	}

	public void setSocioNew(String socioNew) {
		this.socioNew = socioNew;
	}

	public String getProductoNew() {
		return productoNew;
	}

	public void setProductoNew(String productoNew) {
		this.productoNew = productoNew;
	}

	public String getTipCompNew() {
		return tipCompNew;
	}

	public void setTipCompNew(String tipCompNew) {
		this.tipCompNew = tipCompNew;
	}

	public String getTipProductoNew() {
		return tipProductoNew;
	}

	public void setTipProductoNew(String tipProductoNew) {
		this.tipProductoNew = tipProductoNew;
	}

	public String getAfectoNew() {
		return afectoNew;
	}

	public void setAfectoNew(String afectoNew) {
		this.afectoNew = afectoNew;
	}

	public String getIndicadorNew() {
		return indicadorNew;
	}

	public void setIndicadorNew(String indicadorNew) {
		this.indicadorNew = indicadorNew;
	}

	public String getEstadoNew() {
		return estadoNew;
	}

	public void setEstadoNew(String estadoNew) {
		this.estadoNew = estadoNew;
	}

	public String getPrefijoNew() {
		return prefijoNew;
	}

	public void setPrefijoNew(String prefijoNew) {
		this.prefijoNew = prefijoNew;
	}

	public String getSerieNew() {
		return serieNew;
	}

	public void setSerieNew(String serieNew) {
		this.serieNew = serieNew;
	}

	public String getCorrelInicialNew() {
		return correlInicialNew;
	}

	public void setCorrelInicialNew(String correlInicialNew) {
		this.correlInicialNew = correlInicialNew;
	}

	public String getCorrelFinalNew() {
		return correlFinalNew;
	}

	public void setCorrelFinalNew(String correlFinalNew) {
		this.correlFinalNew = correlFinalNew;
	}

	public List<ConfiguracionCpeBean> getListaConfiguracion() {
		return listaConfiguracion;
	}

	public void setListaConfiguracion(List<ConfiguracionCpeBean> listaConfiguracion) {
		this.listaConfiguracion = listaConfiguracion;
	}

	public ParametroService getParametroService() {
		return parametroService;
	}

	public void setParametroService(ParametroService parametroService) {
		this.parametroService = parametroService;
	}

	public String getEmpresaSelected() {
		return empresaSelected;
	}

	public void setEmpresaSelected(String empresaSelected) {
		this.empresaSelected = empresaSelected;
	}

	public List<SelectItem> getEmpresaItems() {
		return empresaItems;
	}

	public void setEmpresaItems(List<SelectItem> empresaItems) {
		this.empresaItems = empresaItems;
	}

	public String getSocioSelected() {
		return socioSelected;
	}

	public void setSocioSelected(String socioSelected) {
		this.socioSelected = socioSelected;
	}

	public List<SelectItem> getSocioItems() {
		return socioItems;
	}

	public void setSocioItems(List<SelectItem> socioItems) {
		this.socioItems = socioItems;
	}

	public String getProductoSelected() {
		return productoSelected;
	}

	public void setProductoSelected(String productoSelected) {
		this.productoSelected = productoSelected;
	}

	public List<SelectItem> getProductoItems() {
		return productoItems;
	}

	public void setProductoItems(List<SelectItem> productoItems) {
		this.productoItems = productoItems;
	}

	public String getTipoComprobanteSelected() {
		return tipoComprobanteSelected;
	}

	public void setTipoComprobanteSelected(String tipoComprobanteSelected) {
		this.tipoComprobanteSelected = tipoComprobanteSelected;
	}

	public List<SelectItem> getTipoComprobanteItems() {
		return tipoComprobanteItems;
	}

	public void setTipoComprobanteItems(List<SelectItem> tipoComprobanteItems) {
		this.tipoComprobanteItems = tipoComprobanteItems;
	}

	public String getTipoProductoSelected() {
		return tipoProductoSelected;
	}

	public void setTipoProductoSelected(String tipoProductoSelected) {
		this.tipoProductoSelected = tipoProductoSelected;
	}

	public List<SelectItem> getTipoProductoItems() {
		return tipoProductoItems;
	}

	public void setTipoProductoItems(List<SelectItem> tipoProductoItems) {
		this.tipoProductoItems = tipoProductoItems;
	}

	public String getAfectoIGVSelected() {
		return afectoIGVSelected;
	}

	public void setAfectoIGVSelected(String afectoIGVSelected) {
		this.afectoIGVSelected = afectoIGVSelected;
	}

	public String getIndicadorPimsSelected() {
		return indicadorPimsSelected;
	}

	public void setIndicadorPimsSelected(String indicadorPimsSelected) {
		this.indicadorPimsSelected = indicadorPimsSelected;
	}

	public ParametroCpeService getParametroCpeService() {
		return parametroCpeService;
	}

	public void setParametroCpeService(ParametroCpeService parametroCpeService) {
		this.parametroCpeService = parametroCpeService;
	}

	public SocioCpeService getSocioCpeService() {
		return socioCpeService;
	}

	public void setSocioCpeService(SocioCpeService socioCpeService) {
		this.socioCpeService = socioCpeService;
	}

	public ProductoCpeService getProductoCpeService() {
		return productoCpeService;
	}

	public void setProductoCpeService(ProductoCpeService productoCpeService) {
		this.productoCpeService = productoCpeService;
	}

	public ConfiguracionCpeService getConfiguracionCpeService() {
		return configuracionCpeService;
	}

	public void setConfiguracionCpeService(
			ConfiguracionCpeService configuracionCpeService) {
		this.configuracionCpeService = configuracionCpeService;
	}

	public String getEstadoCfgSelected() {
		return estadoCfgSelected;
	}

	public void setEstadoCfgSelected(String estadoCfgSelected) {
		this.estadoCfgSelected = estadoCfgSelected;
	}

	public List<SelectItem> getEstadoCfgItems() {
		return estadoCfgItems;
	}

	public void setEstadoCfgItems(List<SelectItem> estadoCfgItems) {
		this.estadoCfgItems = estadoCfgItems;
	}

	public int getNroRegistros() {
		return nroRegistros;
	}

	public void setNroRegistros(int nroRegistros) {
		this.nroRegistros = nroRegistros;
	}

	public ConfiguracionCpeBean getConfSeleccionada() {
		return confSeleccionada;
	}

	public void setConfSeleccionada(ConfiguracionCpeBean confSeleccionada) {
		this.confSeleccionada = confSeleccionada;
	}

	public List<SelectItem> getProductoNewItems() {
		return productoNewItems;
	}

	public void setProductoNewItems(List<SelectItem> productoNewItems) {
		this.productoNewItems = productoNewItems;
	}

	public boolean isPuedeEliminar() {
		return puedeEliminar;
	}

	public void setPuedeEliminar(boolean puedeEliminar) {
		this.puedeEliminar = puedeEliminar;
	}
	
	public String getValidarRedireccionLoad(){
		validarSiEsRedireccionamiento();
		return "";
	}
	
}
