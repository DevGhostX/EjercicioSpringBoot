
package com.cardif.satelite.cpe.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.configuracion.service.ParametroService;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.ConfiguracionCpeBean;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.ProductoCpeBean;
import com.cardif.satelite.cpe.bean.SocioCpeBean;
import com.cardif.satelite.cpe.service.ConfiguracionCpeService;
import com.cardif.satelite.cpe.service.ParametroCpeService;
import com.cardif.satelite.cpe.service.ProductoCpeService;
import com.cardif.satelite.cpe.service.SocioCpeService;

@Controller("cpeMantSocioProdController")
@Scope("session")
public class CpeMantSocioProdController extends BaseController implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static final Logger LOGGER = Logger.getLogger(CpeMantSocioProdController.class);

	String usuarioDb;
	private Date timeVersion;
	private String empresaNew;
	private String socioNew;
	private String productoNew;
	private String tipCompNew;
	private String tipCompRef;
	private String tipProductoNew;
	private String afectoNew;
	private String indicadorNew;
	private String estadoNew;
	private String prefijosAltasNew;
	private String prefijosRecaudoNew;
	private String observacionNew;
	private Boolean esAgrupadoNew;
	
	//Lista combos y selección de combos
	private String empresaSelected;
	private List<SelectItem> empresaItems;
	private String socioSelected;
	private List<SelectItem> socioItems;
	private String productoSelected;
	private List<SelectItem> productoItems;
	private List<SelectItem> productoNewItems;
	private String tipoComprobanteSelected;
	private List<SelectItem> tipoComprobanteItems;
	private List<SelectItem> tipoComprobanteRefItems;	
	private String tipoProductoSelected;
	private List<SelectItem> tipoProductoItems;
	private String afectoIGVSelected;
	private String indicadorPimsSelected;
	
	/****************** deshabilitados ******************/
	private boolean bloqueaEmpresaNew;
	private boolean bloqueaSocioNew;
	private boolean bloqueoProductoNew;
	private boolean bloqueaTipCompNew;
	private boolean bloqueaTipCompRef;	
	private boolean bloqueaTipProductoNew;
	private boolean bloqueaAfectoNew;
	private boolean bloqueaIndicadorNew;
	private boolean bloqueaEstadoNew;
	private boolean bloqueaPrefijosAltasNew;
	private boolean bloqueaPrefijosRecaudoNew;
	private boolean bloqueaObservacionNew;
	private boolean bloqueabuttonNew;
	private boolean bloqueaCancelarNew;
	private boolean bloqueaLimpiarNew;
	private boolean bloqueaGrabarNew;
	private boolean bloquearEsAgrupado;
	
	private List<ConfiguracionCpeBean> listaConfiguracion;
	private ConfiguracionCpeBean confSeleccionada;
	private int nroRegistros;
	private boolean update;
	private boolean ver;
	
	private Boolean esAgrupado;
	private Boolean flagCerrarPopup;
	private boolean puedeEliminar;
	
	/*TIP_PER0100_CC09_13 INICIO 2019/05/17 - 13:35 - Se agrega los atributos flag de movimiento*/
	/**Atributo que almacena el flag que indica si se ha seleccionado el tipo de movimiento Alta*/
	private boolean flgTipoMovimientoAlta;
	/**Atributo que almacena el flag que indica si se ha seleccionado el tipo de movimiento Baja*/
	private boolean flgTipoMovimientoBaja;
	/**Atributo que almacena el flag que indica si se ha seleccionado el tipo de movimiento Recaudo*/
	private boolean flgTipoMovimientoRecaudo;
	/**Atributo que almacea el flag que indica si se habilita o no el tipo de movimiento Alta*/
	private boolean bloqueaFlgTipoMovimientoAlta;
	/**Atributo que almacea el flag que indica si se habilita o no el tipo de movimiento Baja*/
	private boolean bloqueaFlgTipoMovimientoBaja;
	/**Atributo que almacea el flag que indica si se habilita o no el tipo de movimiento Recaudo*/
	private boolean bloqueaFlgTipoMovimientoRecaudo;
	/*TIP_PER0100_CC09_13 FIN*/

	@Autowired
	ParametroService parametroService;
	@Autowired
	private ParametroCpeService parametroCpeService;
	@Autowired
	private SocioCpeService socioCpeService;
	@Autowired
	private ProductoCpeService productoCpeService;
	@Autowired
	private ConfiguracionCpeService configuracionCpeService;

	@Override
	@PostConstruct
	public String inicio() {
		try {
			if (tieneAcceso()) {
				timeVersion = new Date();
				usuarioDb = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
				
				inicializarVariablesFiltros();
				inicializarVariablesNewFiltros();
				llenarCombos();
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	
	private void inicializarVariablesFiltros(){
		
		listaConfiguracion = new ArrayList<ConfiguracionCpeBean>();
		nroRegistros = listaConfiguracion.size();
		
		empresaSelected = "";
		empresaItems = new ArrayList<SelectItem>();
		socioSelected = "";
		socioItems = new ArrayList<SelectItem>();
		productoSelected = "";
		productoItems = new ArrayList<SelectItem>();
		tipoComprobanteSelected = "";
		tipoComprobanteItems = new ArrayList<SelectItem>();
		tipoComprobanteRefItems = new ArrayList<SelectItem>();
		tipoProductoSelected = "";
		tipoProductoItems = new ArrayList<SelectItem>();
		afectoIGVSelected = "";
		indicadorPimsSelected = "";
		
		update = false;
		flagCerrarPopup = false;
	}
	
	private void inicializarVariablesNewFiltros(){
		
		productoNewItems = new ArrayList<SelectItem>();
		
		empresaNew = "";
		socioNew = "";
		productoNew = "";
		tipCompNew = "";
		tipCompRef = "";
		tipProductoNew = "";
		afectoNew = "";
		indicadorNew = "";
		estadoNew = "";
		prefijosAltasNew = "";
		prefijosRecaudoNew = "";
		observacionNew = "";
		esAgrupadoNew = false;
		
		/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 09:48 - Se inicializa las variables flgTipoMovimientoAlta, flgTipoMovimientoBaja
		 * 												  flgTipoMovimientoRecaudo a false*/
		flgTipoMovimientoAlta = false;
		flgTipoMovimientoBaja = false;
		flgTipoMovimientoRecaudo = false;
		bloqueaFlgTipoMovimientoAlta = true;
		bloqueaFlgTipoMovimientoBaja = true;
		bloqueaFlgTipoMovimientoRecaudo = true;
		/*TIP_PER0100_CC09_13 FIN*/
	}
	
	private void llenarCombos(){
		listarSocio();
		listarProducto();
		empresaItems = listarParametro(Constantes.COD_PARAM_CPE_EMPRESA, true);
		tipoComprobanteItems = listarParametro(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES, true);
		tipoComprobanteRefItems = listarParametro(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTE_REF, true);
		tipoProductoItems = listarParametro(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO, true);
	}
	
	private void listarSocio(){
		SocioCpeBean socioCpeBean = new SocioCpeBean();
		List<SocioCpeBean> listaSocioBean = new ArrayList<SocioCpeBean>();
		listaSocioBean = socioCpeService.listarSocio(socioCpeBean);
		socioItems = new ArrayList<SelectItem>();
		socioItems.add(new SelectItem(Constantes.VALOR_DEFECTO_CBX, "- Seleccionar -"));

		for (Iterator<SocioCpeBean> iterator = listaSocioBean.iterator(); iterator.hasNext();) {
			SocioCpeBean listaOrigenDatos = (SocioCpeBean) iterator.next();
			socioItems.add(new SelectItem(String.valueOf(listaOrigenDatos.getIdSocio()), listaOrigenDatos.getNomSocio()));
		}
	}
	
	public void actualizarValoresProducto() {
		listarProducto();
	}
	
	private void listarProducto(){
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		List<ProductoCpeBean> listaProductoBean = new ArrayList<ProductoCpeBean>();
		if(!socioSelected.isEmpty()){
			productoCpeBean.setIdSocio(Integer.parseInt(socioSelected));
			listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
		}
		productoItems = new ArrayList<SelectItem>();
		productoItems.add(new SelectItem(Constantes.VALOR_DEFECTO_CBX, "- Seleccionar -"));

		for (Iterator<ProductoCpeBean> iterator = listaProductoBean.iterator(); iterator.hasNext();) {
			ProductoCpeBean producto = (ProductoCpeBean) iterator.next();
			productoItems.add(new SelectItem(producto.getIdProducto(), producto.getNomProducto()));
		}
	}
	
	public void actualizarValoresProductoNew() {
		listarProductoNew();
		actualizarValoresProductoDetalleNew();
	}

	public void actualizarValoresProductoDetalleNew(){
		if(!socioNew.trim().isEmpty() && !productoNew.trim().isEmpty() && !socioNew.trim().equals(Constantes.VALOR_DEFECTO_CBX) && !productoNew.trim().equals(Constantes.VALOR_DEFECTO_CBX)){
			ProductoCpeBean productoCpeBean = new ProductoCpeBean();
			List<ProductoCpeBean> listaProductoCpeBean = new ArrayList<ProductoCpeBean>();
			productoCpeBean.setIdSocio(Integer.parseInt(socioNew));
			productoCpeBean.setIdProducto(Integer.parseInt(productoNew));
			listaProductoCpeBean = productoCpeService.listarProducto(productoCpeBean);
			
			if(!listaProductoCpeBean.isEmpty()){
				tipProductoNew = listaProductoCpeBean.get(0).getTipoProducto();
				prefijosAltasNew = listaProductoCpeBean.get(0).getPrefijoAlta();
				prefijosRecaudoNew = listaProductoCpeBean.get(0).getPrefijoRecaudo();
				
				/*TIP_PER0100_CC09_13 INICIO 2019/05/29 - 16:39 - Se actualiza el valor de los flag de movimientos(Alta, Baja, Recaudo)*/
				setFlagMovimientos(listaProductoCpeBean.get(0).getTipoMovimiento());
				/*TIP_PER0100_CC09_13 FIN*/
				
				
				if(tipProductoNew.equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO))
				{
					afectoNew = Constantes.CANTIDAD_DEFAULT;
					indicadorNew = Constantes.CANTIDAD_DEFAULT;
					bloqueaIndicadorNew = bloqueaAfectoNew = true;
				}else{				
					if (ver && !update){
//						afectoNew = Constantes.VALOR_DEFECTO_CBX;
//						indicadorNew = Constantes.VALOR_DEFECTO_CBX;
						bloqueaIndicadorNew = bloqueaAfectoNew = true;
					}else{
						bloqueaIndicadorNew = bloqueaAfectoNew = false;
					}
						
				}
			}
		}else{
			tipProductoNew = "";
			prefijosAltasNew = "";
			prefijosRecaudoNew = "";
		}
	}
	
	private void listarProductoNew(){
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		List<ProductoCpeBean> listaProductoBean = new ArrayList<ProductoCpeBean>();
		if(!socioNew.isEmpty()){
			productoCpeBean.setIdSocio(Integer.parseInt(socioNew));
			listaProductoBean = productoCpeService.listarProducto(productoCpeBean);
		}
		productoNewItems = new ArrayList<SelectItem>();
		productoNewItems.add(new SelectItem(Constantes.VALOR_DEFECTO_CBX, "- Seleccionar -"));

		for (Iterator<ProductoCpeBean> iterator = listaProductoBean.iterator(); iterator.hasNext();) {
			ProductoCpeBean producto = (ProductoCpeBean) iterator.next();
			productoNewItems.add(new SelectItem(String.valueOf(producto.getIdProducto()), producto.getNomProducto()));
		}
	}
	
	private List<SelectItem> listarParametro(String codParametro, boolean insertarSeleccionar){
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listaParametroBean = new ArrayList<ParametroCpeBean>();
		listaParametroBean = parametroCpeService.listarParametro(parametroBean);
		List<SelectItem> combo = new ArrayList<SelectItem>();
		if(insertarSeleccionar){
			combo.add(new SelectItem(Constantes.VALOR_DEFECTO_CBX, "- Seleccionar -"));
		}

		for (Iterator<ParametroCpeBean> iterator = listaParametroBean.iterator(); iterator.hasNext();) {
			ParametroCpeBean parametro = (ParametroCpeBean) iterator.next();
			combo.add(new SelectItem(parametro.getCodValor(), parametro.getNomValor()));
		}
		return combo;
	}
	
	public void buscar(){
		try{
			listaConfiguracion = configuracionCpeService.listarConfiguracion(setFiltrosBusqueda());
			nroRegistros = listaConfiguracion.size();
			
			if(listaConfiguracion.isEmpty()){
				throw new SyncconException(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_BUSQUEDA, FacesMessage.SEVERITY_INFO);
			}
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void limpiar(){
		inicializarVariablesFiltros();
		llenarCombos();
	}
	
	public ConfiguracionCpeBean setFiltrosBusqueda(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		bean.setIdEmpresa(empresaSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : empresaSelected);
		bean.setIdSocio(socioSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : Integer.parseInt(socioSelected));
		bean.setIdProducto(productoSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : Integer.parseInt(productoSelected));
		bean.setIdTipoComp(tipoComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipoComprobanteSelected);
		bean.setTipoProducto(tipoProductoSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipoProductoSelected);
		bean.setAfectoIgv(afectoIGVSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : Integer.parseInt(afectoIGVSelected));
		bean.setIndPims(indicadorPimsSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ? null : indicadorPimsSelected);
		bean.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
		bean.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		bean.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
		return bean;
	}

	public String GrabaSocioProd() {
		try {
			flagCerrarPopup = false;
			CamposObligatorios();
			if(update){
				configuracionCpeService.actualizarConfiguracion(setUpdate());
				enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_ACTUALIZAR);
				flagCerrarPopup = true;
			}else{
				ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
				bean.setIdEmpresa(empresaNew);
				bean.setIdSocio(Integer.parseInt(socioNew));
				bean.setIdProducto(Integer.parseInt(productoNew));
				bean.setIdTipoComp(tipCompNew);
				bean.setPrefijo(setearPrefijo(tipCompNew,tipCompRef));
				bean.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
				bean.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
				bean.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
				List<ConfiguracionCpeBean> listaConf = configuracionCpeService.listarConfiguracion(bean);
				LOGGER.error(listaConf.size());
				if(!listaConf.isEmpty()){
					enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CONF_EXISTENTE);
					return null;
				}else{
					configuracionCpeService.insertarConfiguracion(setInsert());
					enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_INSERTAR);
					flagCerrarPopup = true;
				}
			}
			buscar();
		} catch (SyncconException ex) {
			LOGGER.error("ERROR SYNCCO N: " + ex.getMessageComplete());
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		return null;
	}
	
	private String setearPrefijo(String tipCompNew, String tipCompRef){
		String prefijo = "";
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(Constantes.COD_PARAM_CPE_PREFIJO_CE);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		if(tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
			parametroBean.setCodValor(Constantes.COD_PARAM_CPE_PREFIJO_CE_BOL_ELEC);
			prefijo = parametroCpeService.listarParametro(parametroBean).get(0).getNomValor();
		}else if(tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)){
			parametroBean.setCodValor(Constantes.COD_PARAM_CPE_PREFIJO_CE_FAC_ELEC);
			prefijo = parametroCpeService.listarParametro(parametroBean).get(0).getNomValor();
		}else if(tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO)){
			if (tipCompRef.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_REF_FACTURA)){
				parametroBean.setCodValor(Constantes.COD_PARAM_CPE_PREFIJO_CE_NCF_ELEC);
				prefijo = parametroCpeService.listarParametro(parametroBean).get(0).getNomValor();
			}else if (tipCompRef.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_REF_BOLETA)){
				parametroBean.setCodValor(Constantes.COD_PARAM_CPE_PREFIJO_CE_NCB_ELEC);
				prefijo = parametroCpeService.listarParametro(parametroBean).get(0).getNomValor();
			}			
		}else if(tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO)){
			if (tipCompRef.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_REF_FACTURA)){
				parametroBean.setCodValor(Constantes.COD_PARAM_CPE_PREFIJO_CE_NDF_ELEC);
				prefijo = parametroCpeService.listarParametro(parametroBean).get(0).getNomValor();
			}else if (tipCompRef.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_REF_BOLETA)){
				parametroBean.setCodValor(Constantes.COD_PARAM_CPE_PREFIJO_CE_NDB_ELEC);
				prefijo = parametroCpeService.listarParametro(parametroBean).get(0).getNomValor();
			}			
		}
		return prefijo;
	}
	
	private void enviarMensaje(String codMensaje) {
		String mensaje = PropertiesErrorUtil.getProperty(codMensaje);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje, null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	}
	
	public void validarEliminacion(){
		puedeEliminar = false;
		if(confSeleccionada.getCorActual() == null || confSeleccionada.getCorActual() == 0){
			puedeEliminar = true;
		}else {
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_ELIMINAR_SOCIO_PRODUCTO_TIENE_COMPROBANTES_EMITIDOS);
		}
	}
	
	public void eliminar() throws SyncconException{
		configuracionCpeService.eliminarConfiguracion(setDelete());
		buscar();
	}
	
	public ConfiguracionCpeBean setDelete(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		bean.setIdEmpresa(confSeleccionada.getIdEmpresa());
		bean.setIdSocio(confSeleccionada.getIdSocio());
		bean.setIdProducto(confSeleccionada.getIdProducto());
		bean.setIdTipoComp(confSeleccionada.getIdTipoComp());
		
		return bean;
	}
	
	public ConfiguracionCpeBean setInsert(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		bean.setIdEmpresa(empresaNew);
		bean.setIdSocio(Integer.parseInt(socioNew));
		bean.setIdProducto(Integer.parseInt(productoNew));
		bean.setIdTipoComp(tipCompNew);
		bean.setAfectoIgv(Integer.parseInt(afectoNew));
		bean.setIndPims(indicadorNew);
		bean.setEstadoConfig(estadoNew);
		bean.setCorInicial(1);
		bean.setSerie("");
		bean.setPrefijo(setearPrefijo(tipCompNew,tipCompRef));
		bean.setUsuCrea(usuarioDb);
		bean.setObservaciones(observacionNew);
		bean.setFlgAgrupado(esAgrupadoNew == true ? Constantes.ACTIVO : Constantes.INACTIVO);
		return bean;
	}
	
	public ConfiguracionCpeBean setUpdate(){
		ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
		bean.setIdEmpresa(empresaNew);
		bean.setIdSocio(Integer.parseInt(socioNew));
		bean.setIdProducto(Integer.parseInt(productoNew));
		bean.setIdTipoComp(tipCompNew);
		bean.setAfectoIgv(Integer.parseInt(afectoNew));
		bean.setIndPims(indicadorNew);
		bean.setEstadoConfig(estadoNew);
//		bean.setPrefijo("");
//		bean.setSerie("");
		bean.setUsuModifica(usuarioDb);
		bean.setObservaciones(observacionNew);
		bean.setFlgAgrupado(esAgrupado == true ? Constantes.ACTIVO : Constantes.INACTIVO);
		return bean;
	}

	public void editaSocio() {
		update = true;
		camposbloqueados(true, true, true, true, true, false, false, false, false, true, true, false, false, false, false, false, false);
		setVerDetalle();
	}

	public void nuevoSocio() {
		update = false;
		ver = false;
		camposbloqueados(false, false, false, false, true, false, false, false, false, true, true, false, true, false, false, false, false);
		inicializarVariablesNewFiltros();
		listarProductoNew();
	}
	
	public void limpiarNuevoSocio(){
		if(update){
			setVerDetalle();
		}else{
			inicializarVariablesNewFiltros();
			listarProductoNew();
		}
	}

	public void verSocio() {
		update = false;
		ver = true;
		//camposbloqueados(true, true, true, true, true, false, true, true, true, true, true, true, true, true, false, true, true);
		camposbloqueados(true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);
		setVerDetalle();
	}
	
	public void setVerDetalle(){
		setEmpresaNew(confSeleccionada.getIdEmpresa());
		setSocioNew(String.valueOf(confSeleccionada.getIdSocio()));
		setProductoNew(String.valueOf(confSeleccionada.getIdProducto()));
		setTipCompNew(confSeleccionada.getIdTipoComp());
		setTipCompRef(confSeleccionada.getPrefijo());
		setTipProductoNew(confSeleccionada.getTipoProducto());
		setAfectoNew(String.valueOf(confSeleccionada.getAfectoIgv()));
		setIndicadorNew(confSeleccionada.getIndPims());
		setEstadoNew(confSeleccionada.getEstadoConfig());
		setObservacionNew(confSeleccionada.getObservaciones());
		setEsAgrupado(confSeleccionada.getFlgAgrupado().equals(Constantes.ACTIVO) ? true : false);
		/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 10:13 - Se actualiza el valor de los flag de movimientos(Alta, Baja, Recaudo)*/
		setFlagMovimientos(confSeleccionada.getTipoMovimiento());
		/*TIP_PER0100_CC09_13 FIN*/
		actualizarValoresProductoNew();
	}
	
	/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 10:13 - Se actualiza el valor de los flag de movimientos(Alta, Baja, Recaudo)*/
	private void setFlagMovimientos(String movimientos){
		flgTipoMovimientoAlta=false;
		flgTipoMovimientoBaja=false;
		flgTipoMovimientoRecaudo=false;
		if(movimientos != null){
			String[] MovimientosArray = movimientos.split(",");
			
			for(String str : MovimientosArray){
				if(str.trim().toUpperCase().equals("A")){
					flgTipoMovimientoAlta=true;
				}
				if(str.trim().toUpperCase().equals("B")){
					flgTipoMovimientoBaja=true;
				}
				if(str.trim().toUpperCase().equals("R")){
					flgTipoMovimientoRecaudo=true;
				}
			}
		}
	}
	/*TIP_PER0100_CC09_13 FIN*/
	
	public String redireccionarMantSerieCorrelativo(){
		FacesContext context = FacesContext.getCurrentInstance();
		context.getExternalContext().getSessionMap().put("conf", confSeleccionada);
		return "toMantSerieCorrelativo";
	}

	public void CamposObligatorios() throws SyncconException {

		boolean camposObligatorios;
		camposObligatorios = false;

		if (empresaNew == null || empresaNew.trim().length() <= 0 || empresaNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (socioNew == null || socioNew.trim().length() <= 0 || socioNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (productoNew == null || productoNew.trim().length() <= 0 || productoNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (tipCompNew == null || tipCompNew.trim().length() <= 0 || tipCompNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if ((tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO)||
				tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO))&&
				tipCompRef.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (tipProductoNew == null || tipProductoNew.trim().length() <= 0  || tipProductoNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (afectoNew == null || afectoNew.trim().length() <= 0 || afectoNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (indicadorNew == null || indicadorNew.trim().length() <= 0 || indicadorNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (estadoNew == null || estadoNew.trim().length() <= 0 || estadoNew.trim().equals(Constantes.VALOR_DEFECTO_CBX))
			camposObligatorios = true;
		else if (prefijosAltasNew == null || prefijosAltasNew.trim().length() <= 0)
			camposObligatorios = true;
		else if (prefijosRecaudoNew == null || prefijosRecaudoNew.trim().length() <= 0)
			camposObligatorios = true;

		if (camposObligatorios) {
			throw new SyncconException(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS, FacesMessage.SEVERITY_INFO);
		}
	}

	public void camposbloqueados(boolean empresaNew, boolean socioNew, boolean productoNew, boolean tipCompNew,
			boolean tipCompRef, boolean tipProductoNew, boolean afectoNew, boolean indicadorNew, boolean estadoNew,
			boolean prefijosAltasNew, boolean prefijosRecaudoNew, boolean observacionNew, boolean buttonNew,
			boolean limpiarNew, boolean cancelarNew, boolean grabarNew, boolean esAgrupado) {
		bloqueaEmpresaNew = empresaNew;
		bloqueaSocioNew = socioNew;
		bloqueoProductoNew = productoNew;
		bloqueaTipCompNew = tipCompNew;
		bloqueaTipCompRef = tipCompRef;
		bloqueaTipProductoNew = tipProductoNew;
		bloqueaAfectoNew = afectoNew;
		bloqueaIndicadorNew = indicadorNew;
		bloqueaEstadoNew = estadoNew;
		bloqueaPrefijosAltasNew = prefijosAltasNew;
		bloqueaPrefijosRecaudoNew = prefijosRecaudoNew;
		bloqueaObservacionNew = observacionNew;
		bloqueabuttonNew = buttonNew;
		bloqueaLimpiarNew = limpiarNew;
		bloqueaCancelarNew = cancelarNew;
		bloqueaGrabarNew = grabarNew;
		bloquearEsAgrupado = esAgrupado;
	}
	
	public void actTipoCompRef(){
		if(tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) ||
				tipCompNew.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO)){
			bloqueaTipCompRef = false;
		}else{
			bloqueaTipCompRef = true;
		}
	}

	public Date getTimeVersion() {
		return timeVersion;
	}

	public void setTimeVersion(Date timeVersion) {
		this.timeVersion = timeVersion;
	}

	public String getEmpresaNew() {
		return empresaNew;
	}

	public void setEmpresaNew(String empresaNew) {
		this.empresaNew = empresaNew;
	}

	public String getSocioNew() {
		return socioNew;
	}

	public void setSocioNew(String socioNew) {
		this.socioNew = socioNew;
	}

	public String getProductoNew() {
		return productoNew;
	}

	public void setProductoNew(String productoNew) {
		this.productoNew = productoNew;
	}

	public String getTipCompNew() {
		return tipCompNew;
	}

	public void setTipCompNew(String tipCompNew) {
		this.tipCompNew = tipCompNew;
	}
	
	public String getTipCompRef() {
		return tipCompRef;
	}

	public void setTipCompRef(String tipCompRef) {
		this.tipCompRef = tipCompRef;
	}

	public String getTipProductoNew() {
		return tipProductoNew;
	}

	public void setTipProductoNew(String tipProductoNew) {
		this.tipProductoNew = tipProductoNew;
	}

	public String getAfectoNew() {
		return afectoNew;
	}

	public void setAfectoNew(String afectoNew) {
		this.afectoNew = afectoNew;
	}

	public String getIndicadorNew() {
		return indicadorNew;
	}

	public void setIndicadorNew(String indicadorNew) {
		this.indicadorNew = indicadorNew;
	}

	public String getEstadoNew() {
		return estadoNew;
	}

	public void setEstadoNew(String estadoNew) {
		this.estadoNew = estadoNew;
	}

	public String getPrefijosAltasNew() {
		return prefijosAltasNew;
	}

	public void setPrefijosAltasNew(String prefijosAltasNew) {
		this.prefijosAltasNew = prefijosAltasNew;
	}

	public String getPrefijosRecaudoNew() {
		return prefijosRecaudoNew;
	}

	public void setPrefijosRecaudoNew(String prefijosRecaudoNew) {
		this.prefijosRecaudoNew = prefijosRecaudoNew;
	}

	public String getObservacionNew() {
		return observacionNew;
	}

	public void setObservacionNew(String observacionNew) {
		this.observacionNew = observacionNew;
	}

	public boolean isBloqueaEmpresaNew() {
		return bloqueaEmpresaNew;
	}

	public void setBloqueaEmpresaNew(boolean bloqueaEmpresaNew) {
		this.bloqueaEmpresaNew = bloqueaEmpresaNew;
	}

	public boolean isBloqueaSocioNew() {
		return bloqueaSocioNew;
	}

	public void setBloqueaSocioNew(boolean bloqueaSocioNew) {
		this.bloqueaSocioNew = bloqueaSocioNew;
	}

	public boolean isBloqueoProductoNew() {
		return bloqueoProductoNew;
	}

	public void setBloqueoProductoNew(boolean bloqueoProductoNew) {
		this.bloqueoProductoNew = bloqueoProductoNew;
	}

	public boolean isBloqueaTipCompNew() {
		return bloqueaTipCompNew;
	}

	public void setBloqueaTipCompNew(boolean bloqueaTipCompNew) {
		this.bloqueaTipCompNew = bloqueaTipCompNew;
	}
	
	public boolean isBloqueaTipCompRef() {
		return bloqueaTipCompRef;
	}

	public void setBloqueaTipCompRef(boolean bloqueaTipCompRef) {
		this.bloqueaTipCompRef = bloqueaTipCompRef;
	}

	public boolean isBloqueaTipProductoNew() {
		return bloqueaTipProductoNew;
	}

	public void setBloqueaTipProductoNew(boolean bloqueaTipProductoNew) {
		this.bloqueaTipProductoNew = bloqueaTipProductoNew;
	}

	public boolean isBloqueaAfectoNew() {
		return bloqueaAfectoNew;
	}

	public void setBloqueaAfectoNew(boolean bloqueaAfectoNew) {
		this.bloqueaAfectoNew = bloqueaAfectoNew;
	}

	public boolean isBloqueaIndicadorNew() {
		return bloqueaIndicadorNew;
	}

	public void setBloqueaIndicadorNew(boolean bloqueaIndicadorNew) {
		this.bloqueaIndicadorNew = bloqueaIndicadorNew;
	}

	public boolean isBloqueaEstadoNew() {
		return bloqueaEstadoNew;
	}

	public void setBloqueaEstadoNew(boolean bloqueaEstadoNew) {
		this.bloqueaEstadoNew = bloqueaEstadoNew;
	}

	public boolean isBloqueaPrefijosAltasNew() {
		return bloqueaPrefijosAltasNew;
	}

	public void setBloqueaPrefijosAltasNew(boolean bloqueaPrefijosAltasNew) {
		this.bloqueaPrefijosAltasNew = bloqueaPrefijosAltasNew;
	}

	public boolean isBloqueaPrefijosRecaudoNew() {
		return bloqueaPrefijosRecaudoNew;
	}

	public void setBloqueaPrefijosRecaudoNew(boolean bloqueaPrefijosRecaudoNew) {
		this.bloqueaPrefijosRecaudoNew = bloqueaPrefijosRecaudoNew;
	}

	public boolean isBloqueaObservacionNew() {
		return bloqueaObservacionNew;
	}

	public void setBloqueaObservacionNew(boolean bloqueaObservacionNew) {
		this.bloqueaObservacionNew = bloqueaObservacionNew;
	}

	public boolean isBloqueabuttonNew() {
		return bloqueabuttonNew;
	}

	public void setBloqueabuttonNew(boolean bloqueabuttonNew) {
		this.bloqueabuttonNew = bloqueabuttonNew;
	}

	public boolean isBloqueaCancelarNew() {
		return bloqueaCancelarNew;
	}

	public void setBloqueaCancelarNew(boolean bloqueaCancelarNew) {
		this.bloqueaCancelarNew = bloqueaCancelarNew;
	}

	public boolean isBloqueaLimpiarNew() {
		return bloqueaLimpiarNew;
	}

	public void setBloqueaLimpiarNew(boolean bloqueaLimpiarNew) {
		this.bloqueaLimpiarNew = bloqueaLimpiarNew;
	}

	public boolean isBloqueaGrabarNew() {
		return bloqueaGrabarNew;
	}

	public void setBloqueaGrabarNew(boolean bloqueaGrabarNew) {
		this.bloqueaGrabarNew = bloqueaGrabarNew;
	}

	public String getEmpresaSelected() {
		return empresaSelected;
	}

	public void setEmpresaSelected(String empresaSelected) {
		this.empresaSelected = empresaSelected;
	}

	public List<SelectItem> getEmpresaItems() {
		return empresaItems;
	}

	public void setEmpresaItems(List<SelectItem> empresaItems) {
		this.empresaItems = empresaItems;
	}

	public ParametroService getParametroService() {
		return parametroService;
	}

	public void setParametroService(ParametroService parametroService) {
		this.parametroService = parametroService;
	}

	public ParametroCpeService getParametroCpeService() {
		return parametroCpeService;
	}

	public void setParametroCpeService(ParametroCpeService parametroCpeService) {
		this.parametroCpeService = parametroCpeService;
	}

	public String getSocioSelected() {
		return socioSelected;
	}

	public void setSocioSelected(String socioSelected) {
		this.socioSelected = socioSelected;
	}

	public List<SelectItem> getSocioItems() {
		return socioItems;
	}

	public void setSocioItems(List<SelectItem> socioItems) {
		this.socioItems = socioItems;
	}

	public String getProductoSelected() {
		return productoSelected;
	}

	public void setProductoSelected(String productoSelected) {
		this.productoSelected = productoSelected;
	}

	public List<SelectItem> getProductoItems() {
		return productoItems;
	}

	public void setProductoItems(List<SelectItem> productoItems) {
		this.productoItems = productoItems;
	}

	public String getTipoComprobanteSelected() {
		return tipoComprobanteSelected;
	}

	public void setTipoComprobanteSelected(String tipoComprobanteSelected) {
		this.tipoComprobanteSelected = tipoComprobanteSelected;
	}

	public List<SelectItem> getTipoComprobanteItems() {
		return tipoComprobanteItems;
	}

	public void setTipoComprobanteItems(List<SelectItem> tipoComprobanteItems) {
		this.tipoComprobanteItems = tipoComprobanteItems;
	}
	
	public List<SelectItem> getTipoComprobanteRefItems() {
		return tipoComprobanteRefItems;
	}

	public void setTipoComprobanteRefItems(List<SelectItem> tipoComprobanteRefItems) {
		this.tipoComprobanteRefItems = tipoComprobanteRefItems;
	}

	public String getTipoProductoSelected() {
		return tipoProductoSelected;
	}

	public void setTipoProductoSelected(String tipoProductoSelected) {
		this.tipoProductoSelected = tipoProductoSelected;
	}

	public List<SelectItem> getTipoProductoItems() {
		return tipoProductoItems;
	}

	public void setTipoProductoItems(List<SelectItem> tipoProductoItems) {
		this.tipoProductoItems = tipoProductoItems;
	}

	public SocioCpeService getSocioCpeService() {
		return socioCpeService;
	}

	public void setSocioCpeService(SocioCpeService socioCpeService) {
		this.socioCpeService = socioCpeService;
	}

	public ProductoCpeService getProductoCpeService() {
		return productoCpeService;
	}

	public void setProductoCpeService(ProductoCpeService productoCpeService) {
		this.productoCpeService = productoCpeService;
	}

	public String getAfectoIGVSelected() {
		return afectoIGVSelected;
	}

	public void setAfectoIGVSelected(String afectoIGVSelected) {
		this.afectoIGVSelected = afectoIGVSelected;
	}

	public String getIndicadorPimsSelected() {
		return indicadorPimsSelected;
	}

	public void setIndicadorPimsSelected(String indicadorPimsSelected) {
		this.indicadorPimsSelected = indicadorPimsSelected;
	}

	public ConfiguracionCpeService getConfiguracionCpeService() {
		return configuracionCpeService;
	}

	public void setConfiguracionCpeService(
			ConfiguracionCpeService configuracionCpeService) {
		this.configuracionCpeService = configuracionCpeService;
	}

	public List<ConfiguracionCpeBean> getListaConfiguracion() {
		return listaConfiguracion;
	}

	public void setListaConfiguracion(List<ConfiguracionCpeBean> listaConfiguracion) {
		this.listaConfiguracion = listaConfiguracion;
	}

	public int getNroRegistros() {
		return nroRegistros;
	}

	public void setNroRegistros(int nroRegistros) {
		this.nroRegistros = nroRegistros;
	}

	public List<SelectItem> getProductoNewItems() {
		return productoNewItems;
	}

	public void setProductoNewItems(List<SelectItem> productoNewItems) {
		this.productoNewItems = productoNewItems;
	}

	public ConfiguracionCpeBean getConfSeleccionada() {
		return confSeleccionada;
	}

	public void setConfSeleccionada(ConfiguracionCpeBean confSeleccionada) {
		this.confSeleccionada = confSeleccionada;
	}

	public Boolean getEsAgrupado() {
		return esAgrupado;
	}

	public void setEsAgrupado(Boolean esAgrupado) {
		this.esAgrupado = esAgrupado;
	}

	public Boolean getEsAgrupadoNew() {
		return esAgrupadoNew;
	}

	public void setEsAgrupadoNew(Boolean esAgrupadoNew) {
		this.esAgrupadoNew = esAgrupadoNew;
	}

	public boolean isBloquearEsAgrupado() {
		return bloquearEsAgrupado;
	}

	public void setBloquearEsAgrupado(boolean bloquearEsAgrupado) {
		this.bloquearEsAgrupado = bloquearEsAgrupado;
	}

	public Boolean getFlagCerrarPopup() {
		return flagCerrarPopup;
	}

	public void setFlagCerrarPopup(Boolean flagCerrarPopup) {
		this.flagCerrarPopup = flagCerrarPopup;
	}

	public boolean isPuedeEliminar() {
		return puedeEliminar;
	}

	public void setPuedeEliminar(boolean puedeEliminar) {
		this.puedeEliminar = puedeEliminar;
	}

	/*TIP_PER0100_CC09_13 INICIO 2019/05/10 - 13:40 - Se agrega los métodos get y set de los atributos flag de movimientos*/
	
	/**
	 * Método que permite obtener el flag que indica si se ha seleccionado el tipo de movimiento Alta.
	 * @return flgTipoMovimientoAlta Flag que indica si se ha seleccionado el tipo de movimiento Alta, tipo boolean.
	 */
	public boolean isFlgTipoMovimientoAlta() {
		return flgTipoMovimientoAlta;
	}

	/**
	 * Método que permite actualizar el flag que indica si se ha seleccionado el tipo de movimiento Alta.
	 * @param flgTipoMovimientoAlta Flag que indica si se ha seleccionado el tipo de movimiento Alta, tipo boolean.
	 */
	public void setFlgTipoMovimientoAlta(boolean flgTipoMovimientoAlta) {
		this.flgTipoMovimientoAlta = flgTipoMovimientoAlta;
	}

	
	/**
	 * Método que permite obtener el flag que indica si se ha seleccionado el tipo de movimiento Baja. 
	 * @return flgTipoMovimientoBaja Flag que indica si se ha seleccionado el tipo de movimiento Baja, tipo boolean.
	 */
	public boolean isFlgTipoMovimientoBaja() {
		return flgTipoMovimientoBaja;
	}

	/**
	 * Método que permite actualizar el flag que indica si se ha seleccionado el tipo de movimiento Baja. 
	 * @param flgTipoMovimientoBaja Flag que indica si se ha seleccionado el tipo de movimiento Baja, tipo boolean.
	 */
	public void setFlgTipoMovimientoBaja(boolean flgTipoMovimientoBaja) {
		this.flgTipoMovimientoBaja = flgTipoMovimientoBaja;
	}

	/**
	 * Método que permite obtener el flag que indica si se ha seleccionado el tipo de movimiento Recaudo.
	 * @return flgTipoMovimientoRecaudo Flag que indica si se ha seleccionado el tipo de movimiento Recaudo, tipo boolean.
	 */
	public boolean isFlgTipoMovimientoRecaudo() {
		return flgTipoMovimientoRecaudo;
	}

	/**
	 * Método que permite actualizar el flag que indica si se ha seleccionado el tipo de movimiento Recaudo. 
	 * @param flgTipoMovimientoRecaudo Flag que indica si se ha seleccionado el tipo de movimiento Recaudo, tipo boolean.
	 */
	public void setFlgTipoMovimientoRecaudo(boolean flgTipoMovimientoRecaudo) {
		this.flgTipoMovimientoRecaudo = flgTipoMovimientoRecaudo;
	}

	/**
	 * Método que permite obtener el flag que indica si se habilita o no el tipo de movimiento Alta.
	 * @return bloqueaFlgTipoMovimientoAlta Flag que indica si se habilita o no el tipo de movimiento Alta, tipo boolean.
	 */
	public boolean isBloqueaFlgTipoMovimientoAlta() {
		return bloqueaFlgTipoMovimientoAlta;
	}

	/**
	 * Método que permite actualizar el flag que indica si se habilita o no el tipo de movimiento Alta.
	 * @param bloqueaFlgTipoMovimientoAlta Flag que indica si se habilita o no el tipo de movimiento Alta, tipo boolean.
	 */
	public void setBloqueaFlgTipoMovimientoAlta(boolean bloqueaFlgTipoMovimientoAlta) {
		this.bloqueaFlgTipoMovimientoAlta = bloqueaFlgTipoMovimientoAlta;
	}

	/**
	 * Método que permite obtener el flag que indica si se habilita o no el tipo de movimiento Baja.
	 * @return bloqueaFlgTipoMovimientoBaja Flag que indica si se habilita o no el tipo de movimiento Baja, tipo boolean.
	 */
	public boolean isBloqueaFlgTipoMovimientoBaja() {
		return bloqueaFlgTipoMovimientoBaja;
	}

	/**
	 * Método que permite actualizar el flag que indica si se habilita o no el tipo de movimiento Baja.
	 * @param bloqueaFlgTipoMovimientoBaja Flag que indica si se habilita o no el tipo de movimiento Baja, tipo boolean.
	 */
	public void setBloqueaFlgTipoMovimientoBaja(boolean bloqueaFlgTipoMovimientoBaja) {
		this.bloqueaFlgTipoMovimientoBaja = bloqueaFlgTipoMovimientoBaja;
	}

	/**
	 * Método que permite obtener el flag que indica si se habilita o no el tipo de movimiento Recaudo.
	 * @return bloqueaFlgTipoMovimientoRecaudo Flag que indica si se habilita o no el tipo de movimiento Recaudo, tipo boolean.
	 */
	public boolean isBloqueaFlgTipoMovimientoRecaudo() {
		return bloqueaFlgTipoMovimientoRecaudo;
	}

	/**
	 * Método que permite actualizar el flag que indica si se habilita o no el tipo de movimiento Recaudo.
	 * @param bloqueaFlgTipoMovimientoRecaudo Flag que indica si se habilita o no el tipo de movimiento Recaudo, tipo boolean.
	 */
	public void setBloqueaFlgTipoMovimientoRecaudo(boolean bloqueaFlgTipoMovimientoRecaudo) {
		this.bloqueaFlgTipoMovimientoRecaudo = bloqueaFlgTipoMovimientoRecaudo;
	}
	
	
	/*TIP_PER0100_CC09_13 FIN*/
}
