package com.cardif.satelite.cpe.controller;

import static com.cardif.satelite.constantes.ErrorConstants.MSJ_ERROR_GENERAL;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.cardif.framework.controller.BaseController;
import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.framework.excepcion.SyncconException;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.CargaVentaCabCpeBean;
import com.cardif.satelite.cpe.bean.CargaVentaItemCpeBean;
import com.cardif.satelite.cpe.bean.ComprobanteCpeBean;
import com.cardif.satelite.cpe.bean.ConfiguracionCpeBean;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoEstadoCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoMasivoCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoVentaCpeBean;
import com.cardif.satelite.cpe.bean.ProductoCpeBean;
import com.cardif.satelite.cpe.bean.SocioCpeBean;
import com.cardif.satelite.cpe.bean.UbigeoCpeBean;
import com.cardif.satelite.cpe.bean.UpdateVentaCpeBean;
import com.cardif.satelite.cpe.bean.UsuarioBean;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.bean.VentaEstadoCpeBean;
import com.cardif.satelite.cpe.bean.VentaPimsCpeBean;
import com.cardif.satelite.cpe.bean.VentaUploadCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonADICpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonADINCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonCABCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonCABNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonCustomerCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonDETCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonDETNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonDRFNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonEMICpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonEMINCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonExoneradasCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonExoneradasNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonExportadasCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonFCBLCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonGratuitasCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonGratuitasNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonGravadasCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonGravadasNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonIDECpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonIDENCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonInafectasCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonInafectasNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonLeyendaCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonLeyendaNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonRECCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonRECNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonRequestCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonResponseCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonRootCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonTotalImpuestosCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonTotalImpuestosDetCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonTotalImpuestosDetNCNDCpeBean;
import com.cardif.satelite.cpe.bean.structureJson.StructureJsonTotalImpuestosNCNDCpeBean;
import com.cardif.satelite.cpe.service.CampoLayoutCpeService;
import com.cardif.satelite.cpe.service.CargaVentaCabCpeService;
import com.cardif.satelite.cpe.service.ComprobanteCpeService;
import com.cardif.satelite.cpe.service.ConfiguracionCpeService;
import com.cardif.satelite.cpe.service.ParametroCpeService;
import com.cardif.satelite.cpe.service.ParametroSUNATCpeService;
import com.cardif.satelite.cpe.service.ProcesoCpeService;
import com.cardif.satelite.cpe.service.ProductoCpeService;
import com.cardif.satelite.cpe.service.RegistroVentasSuscripcionService;
import com.cardif.satelite.cpe.service.SocioCpeService;
import com.cardif.satelite.cpe.service.UbigeoCpeService;
import com.cardif.satelite.cpe.service.UsuarioService;
import com.cardif.satelite.cpe.service.VentaDataMartCpeService;
import com.cardif.satelite.cpe.service.VentaPimsCpeService;
import com.cardif.satelite.cpe.service.VentaUploadCpeService;
import com.cardif.satelite.cpe.util.DataSourceSatelite;
import com.cardif.satelite.cpe.util.JerseyClientCpe;
import com.cardif.satelite.cpe.util.NumeroToLetra;
import com.cardif.satelite.model.TstVentas;
import com.cardif.satelite.ssis.service.SsisService;
import com.cardif.satelite.util.SateliteUtil;
import com.cardif.satelite.util.Utilitarios;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Controller("emisionCEController")
@Scope("session")
public class EmisionCEController extends BaseController{
	
	public static final Logger logger = Logger.getLogger(EmisionCEController.class);
	
	@Autowired
	private UsuarioService usuarioService;
	
	@Autowired
	private ParametroCpeService parametroCpeService;
	
	@Autowired
	private ParametroSUNATCpeService parametroSUNATCpeService;
	
	@Autowired
	private ProcesoCpeService procesoCpeService;

	@Autowired
	private CargaVentaCabCpeService CargaVentaCabCpeService;
	
	@Autowired
	private SocioCpeService socioCpeService;
	
	@Autowired
	private ProductoCpeService productoCpeService;
	
	@Autowired
	private UbigeoCpeService ubigeoCpeService;
	
	@Autowired
	private ConfiguracionCpeService configuracionCpeService;
	
	@Autowired
	private ComprobanteCpeService comprobanteCpeService;
	
	@Autowired
	private SsisService ssisService;
	
	@Autowired
	private VentaUploadCpeService ventaUploadCpeService;
	
	@Autowired
	private VentaPimsCpeService ventaPimsCpeService;
	
	@Autowired
	private RegistroVentasSuscripcionService registroVentasSuscripcionService;
	
	@Autowired
	private CampoLayoutCpeService campoLayoutCpeService;
	
	/**TIP_PER0100_CC14 INICIO 2019/06/20 - 14:31 - Se agrega atributo que hace referencia a la interfaz de servicios de DataMart*/
	/**Atributo que almacena la referencia  la interfaz de servicios de DataMart*/
	@Autowired
	private VentaDataMartCpeService ventaDataMartCpeService;
	/**TIP_PER0100_CC14 FIN*/
	
	/** Variables de Pantalla Emisión de Comprobantes **/
	
	private List<SelectItem> usuarioItems;
	private List<SelectItem> estadoItems;
	private List<ProcesoCpeBean> listProcesoCpe;

	private String usuarioSelected;
	private String estadoSelected;
	private Date fechaDesde;
	private Date fechaHasta;
	private String conReg;
	private int nroRegistros;
	private String usuarioSesion;
	
	private String usuarioTransaction;
	private String nombreProcesoTransaction;
	private String estadoTransaction;
	private Long idProcesoTransaction;
	private boolean flg_valida;
	private boolean existe_cab;
	
	/** Variables de Pantalla Pre Proceso **/
	
	private ProcesoCpeBean proceso;
	private String socioErrorSelected;
	private Date fecEmisionError;
	private String productoErrorSelected;
	private String conceptoError;
	private String clienteError;
	private String tipCompErrorSelected;
	private String numCompError;
	private String tipDocErrorSelected;
	private String monedaErrorSelected;
	private String montoError;
	private String certificadoError;
	private String numDocError;
	private List<VentaCpeBean> listVentaError;
	private int nroRegistrosError;

	private String socioProcesarSelected;
	private Date fecEmisionProcesar;
	private String productoProcesarSelected;
	private String conceptoProcesar;
	private String clienteProcesar;
	private String tipCompProcesarSelected;
	private String numCompProcesar;
	private String tipDocProcesarSelected;
	private String monedaProcesarSelected;
	private String montoProcesar;
	private String certificadoProcesar;
	private String numDocProcesar;
	private List<VentaCpeBean> listVentaProcesar;
	private int nroRegistrosProcesar;
	private BigDecimal montoTotalProcesar;
	private String labelMonedaProcesar;

	private List<SelectItem> socioRegistrosErrorItems;
	private List<SelectItem> tipCompRegistrosErrorItems;
	private List<SelectItem> monedaRegistrosErrorItems;
	private List<SelectItem> tipDocRegistrosErrosItems;
	private List<SelectItem> productoRegistrosErrorItems;
	
	private List<SelectItem> socioRegistrosProcesarItems;
	private List<SelectItem> tipCompRegistrosProcesarItems;
	private List<SelectItem> monedaRegistrosProcesarItems;
	private List<SelectItem> tipDocRegistrosProcesarItems;
	private List<SelectItem> productoRegistrosProcesarItems;
	
	private SimpleDateFormat formatoddMMaaaa;
	
	/** Variables de Pantalla Nuevo Comprobante **/
	
	private List<SelectItem> socioComprobanteItems;
	private List<SelectItem> tipCompComprobanteItems;
	private List<SelectItem> productoComprobanteItems;
	private List<SelectItem> estadoComprobanteItems;
	private List<SelectItem> tipDocComprobanteItems;
	private List<SelectItem> departamentoComprobanteItems;
	private List<SelectItem> provinciaComprobanteItems;
	private List<SelectItem> distritoComprobanteItems;
	private List<SelectItem> tipCompRefComprobanteItems;
	private List<SelectItem> monedaComprobanteItems;
	private List<SelectItem> empresaComprobanteItems;

	private String socioComprobanteSelected;
	private String productoComprobanteSelected;
	private String referenciaComprobanteSelected;
	private boolean referenciaBoolean;
	private String tipDocComprobanteSelected;
	private String tipCompComprobanteSelected;
	private String estadoComprobanteSelected;
	private Date fechaRegistroComprobante;
	private Date fechaVencimientoComprobante;
	private String numDocComprobante;
	private String clienteComprobante;
	private String direccionComprobante;
	private String departamentoComprobante;
	private String provinciaComprobante;
	private String distritoComprobante;
	private String codProdSunat;
	private boolean disabledCodProdSunat;
	private String conceptoComprobante;
	private String numeroSerieComprobante;
	private String numeroCorrelativoComprobante;
	private String tipCompRefComprobanteSelected;
	private Date fechaEmisionComprobante;
	private String valFactExportComprobante;
	private String baseImponibleComprobante;
	private String impInafectoComprobante;
	private String impExoneradoComprobante;
	private String iscComprobante;
	private String igvComprobante;
	private String otrosImportesComprobante;
	private String importeTotalComprobante;
	private String monedaComprobanteSelected;
	private String empresaComprobanteSelected;
	private String telefonoComprobante;
	private String correoComprobante;
	private String numPolizaComprobante;
	private String tipoProductoComprobante;
	private boolean disabledPoliza;

	private String action;
	private Long idVentaEdicion;
	private Date timeVersion;
	
	/** Variables de Pantalla Busqueda de Ventas **/
	private List<SelectItem> socioBusquedaItems;
	private List<SelectItem> monedaBusquedaItems;
	private List<SelectItem> tipCompBusquedaItems;
	private List<SelectItem> estadoBusquedaItems;
	private List<SelectItem> origenBusquedaItems;
	private List<SelectItem> tipDocBusquedaItems;
	private List<SelectItem> productoBusquedaItems;

	private String socioBusquedaSelected;
	private String productoBusquedaSelected;
	private String estadoBusquedaSelected;
	private boolean disabledUpload;
	private boolean disabledUploadSelected;
	private String origenBusquedaSelected;
	private String tipBusqueda;
	private String clienteBusqueda;
	private String tipDocBusqueda;
	private String numDocBusqueda;
	private Date fechaDesdeBusqueda;
	private Date fechaHastaBusqueda;
	private String certificadoBusqueda;
	private String monedaBusquedaSelected;
	private String codUploadBusqueda;
	private String tipCompBusquedaSelected;
	private String numCompBusqueda;
	private String loteBusqueda;
	
	private boolean agrupado;
	private boolean detallado;
	
	private List<VentaCpeBean> listDetallada;
	private List<CargaVentaCabCpeBean> listAgrupada;
	private int nroRegistrosDetallado;
	private int nroRegistrosAgrupado;
	private boolean allSelectedDet;
	private List<VentaCpeBean> listRegProcesar;
	private int nroRegistrosBusVenProcesar;
	private boolean allSelectedAgrup;
	private boolean allSelectedRegProc;
	private String tipoProcesoCe;
	
	private boolean disabledOnline;
	private boolean disabledMasivo;
	
	private List<VentaCpeBean> listVentaCpe;
	private String mensajeValidacionArchivo;
	private String nomArchivo;
	// TODO BSC 12/09/2019 Con RichFaces 4.x no se puede obtener el objeto java.io.File durante la carga. En lugar de ello, se usa arreglo de byte
	private UploadedFile archivo;
	private boolean disabledCargar;
	private String idFileUploadComponent;
	private boolean mostrarImportarDatos;

	private Boolean seleccionarTodosError;
	private Boolean seleccionarTodosProcesar;
	
	/** Variables de Pantalla Proceso Masivo **/
	private List<SelectItem> socioProcesoMasivoItems;
	private List<SelectItem> productoProcesoMasivoItems;
	private List<SelectItem> tipCompProcesoMasivoItems;
	private List<SelectItem> tipDocProcesoMasivoItems;
	private List<SelectItem> monedaProcesoMasivoItems;
	
	private String socioProcesoMasivoSelected;
	private String productoProcesoMasivoSelected;
	private String tipCompProcesoMasivoSelected;
	private String tipDocProcesoMasivoSelected;
	private String monedaProcesoMasivoSelected;
	private String conceptoProcesoMasivo;
	private String clienteProcesoMasivo;
	private String numCompProcesoMasivo;
	private Date fecEmisionProcesoMasivo;
	private String montoProcesoMasivo;
	private String certificadoProcesoMasivo;
	private String numDocProcesoMasivo;
	
	List<ProcesoMasivoCpeBean> listaProcesoMasivo;
	private Integer regSeleccionados;
	private BigDecimal montoSeleccionados;
	private String fechaProcesoMasivo;
	private String loteProcesoMasivo;
	
	/** Variables de pantalla Procesados Online**/
	private List<SelectItem> socioProcesadosErrorOnlineItems;
	private List<SelectItem> productoProcesadosErrorOnlineItems;
	private List<SelectItem> tipComprobanteProcesadosErrorOnlineItems;
	private List<SelectItem> tipDocProcesadosErrorOnlineItems;
	private List<SelectItem> monedaProcesadosErrorOnlineItems;
	private String socioProcesadosErrorOnlineSelected;
	private String productoProcesadosErrorOnlineSelected;
	private String conceptoProcesadosErrorOnline;
	private String clienteProcesadosErrorOnline;
	private String tipComprobanteProcesadosErrorOnlineSelected;
	private String numCompProcesadosErrorOnline;
	private Date fechaEmisionProcesadosErrorOnline;
	private String tipDocProcesadosOnlineErrorSelected;
	private String monedaProcesadosErrorOnlineSelected;
	private String montoProcesadosErrorOnline;
	private String certificadoProcesadosErrorOnline;
	private String numDocProcesadosErrorOnline;
	
	private List<ProcesoMasivoCpeBean> listProcesadosErrorOnline;
	private int nroRegistrosProcesadosErrorOnline;
	private BigDecimal montoTotalProcesadosErrorOnline;
	
	private List<SelectItem> socioProcesadosCorrectosOnlineItems;
	private List<SelectItem> productoProcesadosCorrectosOnlineItems;
	private List<SelectItem> tipComprobanteProcesadosCorrectosOnlineItems;
	private List<SelectItem> tipDocProcesadosCorrectosOnlineItems;
	private List<SelectItem> monedaProcesadosCorrectosOnlineItems;
	private String socioProcesadosCorrectosOnlineSelected;
	private String productoProcesadosCorrectosOnlineSelected;
	private String conceptoProcesadosCorrectosOnline;
	private String clienteProcesadosCorrectosOnline;
	private String tipComprobanteProcesadosCorrectosOnlineSelected;
	private String numCompProcesadosCorrectosOnline;
	private Date fechaEmisionProcesadosCorrectosOnline;
	private String tipDocProcesadosOnlineCorrectosSelected;
	private String monedaProcesadosCorrectosOnlineSelected;
	private String montoProcesadosCorrectosOnline;
	private String certificadoProcesadosCorrectosOnline;
	private String numDocProcesadosCorrectosOnline;
	
	private List<ProcesoMasivoCpeBean> listProcesadosCorrectosOnline;
	private int nroRegistrosProcesadosCorrectosOnline;
	private BigDecimal montoTotalProcesadosCorrectosOnline;
	
	private String fechaProcesoOnline;
	
	private ProcesoMasivoCpeBean ventaSeleccionada;
	
	/**Variables de Comprobante Ref**/
	private List<SelectItem> socioRefItems;
	private List<SelectItem> productoRefItems;
	private List<SelectItem> tipComprobanteRefItems;
	private List<SelectItem> tipDocRefItems;
	private List<SelectItem> monedaRefItems;
	private String socioRefSelected;
	private String productoRefSelected;
	private String clienteRef;
	private String tipComprobanteRefSelected;
	private String numCompRef;
	private Date fechaEmisionRef;
	private String tipDocRefSelected;
	private String monedaRefSelected;
	private String montoRef;
	private String certificadoRef;
	private String numDocRef;
	
	private List<ComprobanteCpeBean> listRef;
	private int regSeleccionadosRef;
	private BigDecimal montoTotalSeleccionadosRef;
	
	/** Variables det **/
	private CargaVentaCabCpeBean cabBusquedaAgrupDet;
	private VentaCpeBean detBusquedaDetallado;
	private VentaCpeBean detBusquedaDetalladoProc;
	private VentaCpeBean detPreProcError;
	private VentaCpeBean detPreProcOk;
	
	private String msjProcesoEliminar;
	
	private int numMaximoOnline;
	
	private boolean flagComprobanteCorrecto;
	
	private boolean bloqAgrup;

	private String repoSelected;
	
	private String loteOnline;
	
	List<UbigeoCpeBean> listUbigeo;
	
	
	/**TIP_PER0100_CC14 INICIO 2019/06/17 - 09:20 - Se agrega atributos para edición de detalle de item de comprobante*/
	/**Atributo que almacena la lista de detalle item perteneciente a un comprobante*/
	private List<CargaVentaItemCpeBean> listDetalleItemComprobante;
	/**Atributo que almacena el concepto del detalle item perteneciente a un comprobante.*/
	private String conceptoItem;
	/**Atributo que almacena la cantidad de item.*/
	private int cantidadItem;
	/**Atributo que almacena el precio de venta de detalle de Item de un comprobante.*/
	private BigDecimal precioVentaItem;
	/**Atributo que almacena el valor de la venta total, monto que no considera el IGV.*/
	private BigDecimal valorVentaTotal;
	/**Atributo que almacena el valor de operaciones gratuitas.*/
	private BigDecimal impValOpGratuitas;
	/**Atributo que almacena indicador de aplica IGV para un registro de venta */
	private boolean ventaAplicaIGV;
	/**TIP_PER0100_CC14 FIN*/
	
	/**TIP_PER0100_FASE02 INICIO 2019/11/22 - 12:39 - Se agrega atributo que permite habilitar la opción de Resumen.*/
	private boolean disabledResumen;
	/**TIP_PER0100_FASE02 FIN 2019/11/22 - 12:39 - Se agrega atributo que permite habilitar la opción de Resumen.*/
	
	@Autowired
	private DataSourceSatelite dataSourceSatelite;

	@Override
	@PostConstruct
	public String inicio() {
		
		if (!tieneAcceso()) {
			logger.info("No cuenta con los accesos necesarios.");
			return "accesoDenegado";
		}
		
		usuarioSesion = (FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString().length() > 1) ? FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("UID").toString() : SecurityContextHolder.getContext().getAuthentication().getName();
		
		formatoddMMaaaa = new SimpleDateFormat("dd/MM/yyyy");
		
		inicializarFiltros();
		
		inicializarResultados();
		
		inicializarTransaction();
		
		inicializarOtros();
		
		cargarCbx();
		
		
		inicializarFiltrosRegistrosError();
		
		inicializarResultadosRegistrosError();
		
		inicializarFiltrosRegistrosProcesar();
		
		inicializarResultadosRegistrosProcesar();
		
		//inicializarOtrosPreProceso();
		
		inicializarVariablesComprobante();
		
		
		inicializarFiltrosBusquedaVenta();
		
		disabledCargar = true;
		mostrarImportarDatos = false;
		
		seleccionarTodosError = false;
		
		flagComprobanteCorrecto = false;
		
		
		inicializarFiltrosProcesadosErrorOnline();
		
		inicializarResultadosProcesadosErrorOnline();
		
		inicializarFiltrosProcesadosCorrectosOnline();
		
		inicializarResultadosProcesadosCorrectosOnline();
		
		fechaProcesoOnline = "";
		
		inicializarFiltrosRef();
		inicializarResultadosRef();
		
		cabBusquedaAgrupDet = new CargaVentaCabCpeBean();
		detBusquedaDetallado = new VentaCpeBean();
		detBusquedaDetalladoProc = new VentaCpeBean();
		detPreProcError = new VentaCpeBean();
		detPreProcOk = new VentaCpeBean();
		msjProcesoEliminar = "";
		numMaximoOnline = 0;
		bloqAgrup = false;
		timeVersion = new Date();
		disabledPoliza = true;
		
		/**TIP_PER0100_CC14 INICIO 2019/06/20 - 09:42 - Se actualiza el valor por defecto de repoSelected de Pims a DataMart*/
//		repoSelected = "Pims";
		repoSelected = "DataMart";
		/**TIP_PER0100_CC14 INICIO*/
		loteOnline = "";
		
		listUbigeo = ubigeoCpeService.listarUbigeo();
		
		return null;
	}
	
	private void inicializarFiltros(){
		usuarioItems = new ArrayList<SelectItem>();
		estadoItems = new ArrayList<SelectItem>();
		usuarioSelected = "-1";
		estadoSelected = "-1";
		fechaDesde = primerDiaMesActual();
		fechaHasta = new Date();
		conReg = "2";
	}
	
	private void inicializarResultados(){
		listProcesoCpe = new ArrayList<ProcesoCpeBean>();
		nroRegistros = 0;
	}
	
	private void inicializarTransaction(){
		usuarioTransaction = "";
		nombreProcesoTransaction = "";
		estadoTransaction = "";
		idProcesoTransaction = null;
	}
	
	private void inicializarOtros(){
		proceso = new ProcesoCpeBean();
		action = "";
		idVentaEdicion = null;
	}
	
	private void inicializarFiltrosRegistrosError(){
		socioRegistrosErrorItems = new ArrayList<SelectItem>();
		tipCompRegistrosErrorItems = new ArrayList<SelectItem>();
		monedaRegistrosErrorItems = new ArrayList<SelectItem>();
		tipDocRegistrosErrosItems = new ArrayList<SelectItem>();
		productoRegistrosErrorItems = new ArrayList<SelectItem>();
		socioErrorSelected = Constantes.VALOR_DEFECTO_CBX;
		fecEmisionError = null;
		productoErrorSelected = Constantes.VALOR_DEFECTO_CBX;
		conceptoError = "";
		clienteError = "";
		tipCompErrorSelected = Constantes.VALOR_DEFECTO_CBX;
		numCompError = "";
		tipDocErrorSelected = Constantes.VALOR_DEFECTO_CBX;
		monedaErrorSelected = Constantes.VALOR_DEFECTO_CBX;
		montoError = "";
		certificadoError = "";
		numDocError = "";
	}
	
	private void inicializarResultadosRegistrosError(){
		listVentaError = new ArrayList<VentaCpeBean>();
		nroRegistrosError = 0;
		setMostrarImportarDatos();
	}
	
	private void setMostrarImportarDatos(){
		if(listVentaError.size() > 0){
			mostrarImportarDatos = true;
		}else {
			mostrarImportarDatos = false;
		}
	}
	
	private void inicializarFiltrosRegistrosProcesar(){
		socioRegistrosProcesarItems = new ArrayList<SelectItem>();
		tipCompRegistrosProcesarItems = new ArrayList<SelectItem>();
		monedaRegistrosProcesarItems = new ArrayList<SelectItem>();
		tipDocRegistrosProcesarItems = new ArrayList<SelectItem>();
		productoRegistrosProcesarItems = new ArrayList<SelectItem>();
		socioProcesarSelected = Constantes.VALOR_DEFECTO_CBX;
		fecEmisionProcesar = null;
		productoProcesarSelected = Constantes.VALOR_DEFECTO_CBX;
		conceptoProcesar = "";
		clienteProcesar = "";
		tipCompProcesarSelected = Constantes.VALOR_DEFECTO_CBX;
		numCompProcesar = "";
		tipDocProcesarSelected = Constantes.VALOR_DEFECTO_CBX;
		monedaProcesarSelected = Constantes.VALOR_DEFECTO_CBX;
		montoProcesar = "";
		certificadoProcesar = "";
		numDocProcesar = "";
	}
	
	private void inicializarResultadosRegistrosProcesar(){
		listVentaProcesar = new ArrayList<VentaCpeBean>();
		nroRegistrosProcesar = 0;
		montoTotalProcesar = BigDecimal.ZERO;
		labelMonedaProcesar = "";
	}
	
	private void inicializarResultadosProcesadosErrorOnline(){
		listProcesadosErrorOnline = new ArrayList<ProcesoMasivoCpeBean>();
		nroRegistrosProcesadosErrorOnline = 0;
		montoTotalProcesadosErrorOnline = BigDecimal.ZERO;
	}
	
	private void inicializarResultadosProcesadosCorrectosOnline(){
		listProcesadosCorrectosOnline = new ArrayList<ProcesoMasivoCpeBean>();
		nroRegistrosProcesadosCorrectosOnline = 0;
		montoTotalProcesadosCorrectosOnline = BigDecimal.ZERO;
	}
	
	private void inicializarVariablesComprobante(){
		socioComprobanteItems = new ArrayList<SelectItem>();
		tipCompComprobanteItems = new ArrayList<SelectItem>();
		productoComprobanteItems = new ArrayList<SelectItem>();
		estadoComprobanteItems = new ArrayList<SelectItem>();
		tipDocComprobanteItems = new ArrayList<SelectItem>();
		departamentoComprobanteItems = new ArrayList<SelectItem>();
		provinciaComprobanteItems = new ArrayList<SelectItem>();
		distritoComprobanteItems = new ArrayList<SelectItem>();
		tipCompRefComprobanteItems = new ArrayList<SelectItem>();
		monedaComprobanteItems = new ArrayList<SelectItem>();
		empresaComprobanteItems = new ArrayList<SelectItem>();
		
		socioComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		productoComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		referenciaComprobanteSelected = "0";
		referenciaBoolean = true;
		tipDocComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		tipCompComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		estadoComprobanteSelected = Constantes.COD_VALOR_ESTADO_PROCESO_PENDIENTE;
		fechaRegistroComprobante = new Date();
		//fechaVencimientoComprobante = new Date();
		numDocComprobante = "";
		clienteComprobante = "";
		direccionComprobante = "";
		departamentoComprobante = Constantes.VALOR_DEFECTO_CBX;
		provinciaComprobante = Constantes.VALOR_DEFECTO_CBX;
		distritoComprobante = Constantes.VALOR_DEFECTO_CBX;
		codProdSunat = "";
		disabledCodProdSunat = true;
		conceptoComprobante = "";
		numeroSerieComprobante = "";
		numeroCorrelativoComprobante = "";
		tipCompRefComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		fechaEmisionComprobante = null;
		valFactExportComprobante = "";
		baseImponibleComprobante = "";
		impInafectoComprobante = "";
		impExoneradoComprobante = "";
		iscComprobante = "";
		igvComprobante = "";
		otrosImportesComprobante = "";
		importeTotalComprobante = "";
		monedaComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		empresaComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		telefonoComprobante = "";
		correoComprobante = "";
		numPolizaComprobante = "";
	}
	
	//private void inicializarOtrosPreProceso(){
		//tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
	//}
	
	private void inicializarFiltrosBusquedaVenta(){
		socioBusquedaItems = new ArrayList<SelectItem>();
		monedaBusquedaItems = new ArrayList<SelectItem>();
		tipCompBusquedaItems = new ArrayList<SelectItem>();
		estadoBusquedaItems = new ArrayList<SelectItem>();
		origenBusquedaItems = new ArrayList<SelectItem>();
		tipDocBusquedaItems = new ArrayList<SelectItem>();
		productoBusquedaItems = new ArrayList<SelectItem>();
		
		socioBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		productoBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		estadoBusquedaSelected = Constantes.COD_VALOR_ESTADO_PROCESO_PENDIENTE;
		disabledUpload = true;
		disabledUploadSelected = false;
		origenBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		tipBusqueda = "0";
		clienteBusqueda = "";
		tipDocBusqueda = Constantes.VALOR_DEFECTO_CBX;
		numDocBusqueda = "";
		fechaDesdeBusqueda = primerDiaMesActual();
		fechaHastaBusqueda = new Date();
		certificadoBusqueda = "";
		monedaBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		codUploadBusqueda = "";
		tipCompBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		numCompBusqueda = "";
		loteBusqueda = "";
		
		agrupado = true;
		detallado = false;
		
		listAgrupada = new ArrayList<CargaVentaCabCpeBean>();
		listDetallada = new ArrayList<VentaCpeBean>();
		nroRegistrosDetallado = 0;
		nroRegistrosAgrupado = 0;
		allSelectedDet = false;
		listRegProcesar = new ArrayList<VentaCpeBean>();
		nroRegistrosBusVenProcesar = 0;
		allSelectedAgrup = false;
		allSelectedRegProc = false;
	}
	
	private void inicializarLimpiarBusquedaBusVenta(){
		socioBusquedaItems = new ArrayList<SelectItem>();
		monedaBusquedaItems = new ArrayList<SelectItem>();
		tipCompBusquedaItems = new ArrayList<SelectItem>();
		estadoBusquedaItems = new ArrayList<SelectItem>();
		origenBusquedaItems = new ArrayList<SelectItem>();
		tipDocBusquedaItems = new ArrayList<SelectItem>();
		productoBusquedaItems = new ArrayList<SelectItem>();
		
		socioBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		productoBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		estadoBusquedaSelected = Constantes.COD_VALOR_ESTADO_PROCESO_PENDIENTE;
		disabledUpload = true;
		disabledUploadSelected = false;
		origenBusquedaSelected = Constantes.COD_ORIGEN_ARCHIVO;
		tipBusqueda = "0";
		clienteBusqueda = "";
		tipDocBusqueda = Constantes.VALOR_DEFECTO_CBX;
		numDocBusqueda = "";
		fechaDesdeBusqueda = primerDiaMesActual();
		fechaHastaBusqueda = new Date();
		certificadoBusqueda = "";
		monedaBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		codUploadBusqueda = "";
		tipCompBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		numCompBusqueda = "";
		loteBusqueda = "";
		bloqAgrup = false;
		
		agrupado = true;
		detallado = false;
		
		listAgrupada = new ArrayList<CargaVentaCabCpeBean>();
		listDetallada = new ArrayList<VentaCpeBean>();
		nroRegistrosDetallado = 0;
		nroRegistrosAgrupado = 0;
		allSelectedDet = false;
		allSelectedAgrup = false;
	}
	
	public void inicializarFiltrosProcesoMasivo(){
		socioProcesoMasivoSelected = Constantes.VALOR_DEFECTO_CBX;;
		productoProcesoMasivoSelected = Constantes.VALOR_DEFECTO_CBX;;
		tipCompProcesoMasivoSelected = Constantes.VALOR_DEFECTO_CBX;;
		tipDocProcesoMasivoSelected = Constantes.VALOR_DEFECTO_CBX;;
		monedaProcesoMasivoSelected = Constantes.VALOR_DEFECTO_CBX;
		
		socioProcesoMasivoItems = listarSocioCbx();
		productoProcesoMasivoItems = listarProductoCbx(socioProcesoMasivoSelected);
		tipCompProcesoMasivoItems = listarTipCompCbx();
		tipDocProcesoMasivoItems = listarTipDocCbx();
		monedaProcesoMasivoItems = listarMonedaCbx();
		
		conceptoProcesoMasivo = "";
		clienteProcesoMasivo = "";
		numCompProcesoMasivo = "";
		fecEmisionProcesoMasivo = null;
		montoProcesoMasivo = "";
		certificadoProcesoMasivo = "";
		numDocProcesoMasivo = "";
		
		listaProcesoMasivo = new ArrayList<ProcesoMasivoCpeBean>();
		regSeleccionados = listaProcesoMasivo.size();
		montoSeleccionados = BigDecimal.ZERO;
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		fechaProcesoMasivo = fmt.format(proceso.getFechaCreacion());
		loteProcesoMasivo = armarLote(Constantes.TIPO_PROCESO_CE_MASIVO);
	}
	
	private String armarLote(String tipoProceso){
		String lote = "CE";
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		String fecha = fmt.format(new Date());
		lote = lote.concat(fecha.substring(0, 4)).concat(fecha.substring(4,6)).concat(fecha.substring(6, 8)).concat("-P");
		if(tipoProceso.equals(Constantes.TIPO_PROCESO_CE_MASIVO)){
			lote = lote.concat("M");
		}else if(tipoProceso.equals(Constantes.TIPO_PROCESO_CE_ONLINE)){//Online
			lote = lote.concat("O");
		}
		/**TIP_PER0100_FASE02 INICIO 2019/12/26 - 11:58 - Se agrega bifurcación para la generación del número de lote de Resumen de comprobante.*/
		else{//Resumen
			lote = lote.concat("R");
		}
		/**TIP_PER0100_FASE02 FIN 2019/12/26 - 11:58 - Se agrega bifurcación para la generación del número de lote de Resumen de comprobante.*/
		
		int count = Integer.parseInt(listarParametro(Constantes.COD_PARAM_CORRELATIVO_LOTE, Constantes.COD_VALOR_CORRELATIVO_LOTE));
		count = count + 1;
		actualizarParametro(Constantes.COD_PARAM_CORRELATIVO_LOTE, Constantes.COD_VALOR_CORRELATIVO_LOTE, String.valueOf(count));
		lote = lote.concat(String.valueOf(count));
		
		ProcesoCpeBean procesoCpeBean = new ProcesoCpeBean();
		procesoCpeBean.setIdProceso(proceso.getIdProceso());
		procesoCpeBean.setNumeroLote(lote);
		procesoCpeService.actualizarProcesoLoteCpe(procesoCpeBean);
		
		return lote;
	}
	
	private void actualizarParametro(String codParametro, String codValor, String nomValor){
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		parametroBean.setCodValor(codValor);
		parametroBean.setNomValor(nomValor);
		parametroBean.setUsuModifica(usuarioSesion);
		parametroCpeService.actualizarParametro(parametroBean);
	}
	
	private void inicializarLimpiarTodoBusVent(){
		inicializarLimpiarBusquedaBusVenta();
		
		listRegProcesar = new ArrayList<VentaCpeBean>();
		nroRegistrosBusVenProcesar = 0;
		allSelectedRegProc = false;
	}
	
	private void inicializarFiltrosProcesadosErrorOnline(){
		socioProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
		productoProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
		tipComprobanteProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
		tipDocProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
		monedaProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
		socioProcesadosErrorOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		productoProcesadosErrorOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		conceptoProcesadosErrorOnline = "";
		clienteProcesadosErrorOnline = "";
		tipComprobanteProcesadosErrorOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		numCompProcesadosErrorOnline = "";
		fechaEmisionProcesadosErrorOnline = null;
		tipDocProcesadosOnlineErrorSelected = Constantes.VALOR_DEFECTO_CBX;
		monedaProcesadosErrorOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		montoProcesadosErrorOnline = "";
		certificadoProcesadosErrorOnline = "";
		numDocProcesadosErrorOnline = "";
	}
	
	private void inicializarFiltrosProcesadosCorrectosOnline(){
		socioProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
		productoProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
		tipComprobanteProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
		tipDocProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
		monedaProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
		socioProcesadosCorrectosOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		productoProcesadosCorrectosOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		conceptoProcesadosCorrectosOnline = "";
		clienteProcesadosCorrectosOnline = "";
		tipComprobanteProcesadosCorrectosOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		numCompProcesadosCorrectosOnline = "";
		fechaEmisionProcesadosCorrectosOnline = null;
		tipDocProcesadosOnlineCorrectosSelected = Constantes.VALOR_DEFECTO_CBX;
		monedaProcesadosCorrectosOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		montoProcesadosCorrectosOnline = "";
		certificadoProcesadosCorrectosOnline = "";
		numDocProcesadosCorrectosOnline = "";
	}
	
	private void inicializarFiltrosRef(){
		socioRefItems = new ArrayList<SelectItem>();
		productoRefItems = new ArrayList<SelectItem>();
		tipComprobanteRefItems = new ArrayList<SelectItem>();
		tipDocRefItems = new ArrayList<SelectItem>();
		monedaRefItems = new ArrayList<SelectItem>();
		socioRefSelected = Constantes.VALOR_DEFECTO_CBX;
		productoRefSelected = Constantes.VALOR_DEFECTO_CBX;
		clienteRef = "";
		tipComprobanteRefSelected = Constantes.VALOR_DEFECTO_CBX;
		numCompRef = "";
		fechaEmisionRef = null;
		tipDocRefSelected = Constantes.VALOR_DEFECTO_CBX;
		monedaRefSelected = Constantes.VALOR_DEFECTO_CBX;
		montoRef = "";
		certificadoRef = "";
		numDocRef = "";
	}
	
	private void inicializarResultadosRef(){
		listRef = new ArrayList<ComprobanteCpeBean>();
		regSeleccionadosRef = 0;
		montoTotalSeleccionadosRef = BigDecimal.ZERO;
	}
	
	private void cargarCbx(){
		try {
			listarUsuarioCbx();
			listarEstadosCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void cargarCbxRegistrosError(){
		try {
			listarSocioRegistrosError();
			listarTipCompRegistrosError();
			listarMonedaRegistrosError();
			listarTipDocRegistrosError();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void cargarCbxRegistrosProcesar(){
		try {
			listarSocioRegistrosProcesar();
			listarTipCompRegistrosProcesar();
			listarMonedaRegistrosProcesar();
			listarTipDocRegistrosProcesar();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void cargarCbxComprobante(){
		try {
			listarSocioComprobante();
			listarTipCompComprobante();
			listarEstadoComprobante();
			listarTipDocComprobante();
			listarTipCompRefComprobante();
			listarMonedaComprobante();
			listarEmpresaComprobante();
			listarDepartamentoComprobante();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void cargarCbxBusquedaVenta(){
		try {
			listarSocioBusqueda();
			listarMonedaBusqueda();
			listarTipCompBusqueda();
			listarEstadoBusqueda();
			listarOrigenBusqueda();
			listarTipDocBusqueda();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void cargarCbxProcesadosErrorOnline(){
		try {
			listarSocioProcesadosErrorOnline();
			listarTipCompProcesadosErrorOnline();
			listarTipDocProcesadosErrorOnline();
			listarMonedaProcesadosErrorOnline();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void cargarCbxProcesadosCorrectosOnline(){
		try {
			listarSocioProcesadosCorrectosOnline();
			listarTipCompProcesadosCorrectosOnline();
			listarTipDocProcesadosCorrectosOnline();
			listarMonedaProcesadosCorrectosOnline();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void cargarCbxRef(){
		try {
			listarSocioRef();
			listarTipCompRef();
			listarTipDocRef();
			listarMonedaRef();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarUsuarioCbx(){
		try {
			UsuarioBean usuarioBean = new UsuarioBean();
			usuarioBean.setEstado(Constantes.ACTIVO);
			
			List<UsuarioBean> listUsuario = usuarioService.listarUsuario(usuarioBean);
			
			usuarioItems = new ArrayList<SelectItem>();
			
			for(UsuarioBean usu : listUsuario){
				usuarioItems.add(new SelectItem(usu.getCodigoUsuario(), usu.getCodigoUsuario()));
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarEstadosCbx(){
		try {
			ParametroCpeBean parametroCpeBean = new ParametroCpeBean();
			parametroCpeBean.setCodParam(Constantes.COD_PARAM_CPE_ESTADO_PROCESO);
			parametroCpeBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
			List<ParametroCpeBean> listParametroCpe = new ArrayList<ParametroCpeBean>();
			listParametroCpe = parametroCpeService.listarParametro(parametroCpeBean);
			
			estadoItems = new ArrayList<SelectItem>();
			
			for(ParametroCpeBean param : listParametroCpe){
				estadoItems.add(new SelectItem(param.getCodValor(), param.getNomValor()));
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarSocioRegistrosError(){
		try {
			socioRegistrosErrorItems = new ArrayList<SelectItem>();
			socioRegistrosErrorItems = listarSocioCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarSocioRegistrosProcesar(){
		try {
			socioRegistrosProcesarItems = new ArrayList<SelectItem>();
			socioRegistrosProcesarItems = listarSocioCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarSocioComprobante(){
		try {
			socioComprobanteItems = new ArrayList<SelectItem>();
			socioComprobanteItems = listarSocioCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarSocioBusqueda(){
		try {
			socioBusquedaItems = new ArrayList<SelectItem>();
			socioBusquedaItems = listarSocioCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarSocioProcesadosErrorOnline(){
		try {
			socioProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
			socioProcesadosErrorOnlineItems = listarSocioCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarSocioProcesadosCorrectosOnline(){
		try {
			socioProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
			socioProcesadosCorrectosOnlineItems = listarSocioCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarSocioRef(){
		try {
			socioRefItems = new ArrayList<SelectItem>();
			socioRefItems = listarSocioCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompComprobante(){
		try {
			tipCompComprobanteItems = new ArrayList<SelectItem>();
			if(referenciaComprobanteSelected.equals(Constantes.INACTIVO)){
				tipCompComprobanteItems = listarTipCompCbx();
			}else{
				List<SelectItem> listaTmp = listarTipCompCbx();
				if(action.equals("N")){
					for(SelectItem bean : listaTmp){
						if(bean.getValue().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) ||
								bean.getValue().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO)){
							tipCompComprobanteItems.add(bean);
						}
					}
				}else {
					tipCompComprobanteItems.addAll(listaTmp);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompBusqueda(){
		try {
			tipCompBusquedaItems = new ArrayList<SelectItem>();
			tipCompBusquedaItems = listarTipCompCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompProcesadosErrorOnline(){
		try {
			tipComprobanteProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
			tipComprobanteProcesadosErrorOnlineItems = listarTipCompCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompProcesadosCorrectosOnline(){
		try {
			tipComprobanteProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
			tipComprobanteProcesadosCorrectosOnlineItems = listarTipCompCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompRef(){
		try {
			tipComprobanteRefItems = new ArrayList<SelectItem>();
			tipComprobanteRefItems = listarTipCompCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarEstadoComprobante(){
		try {
			estadoComprobanteItems = new ArrayList<SelectItem>();
			estadoComprobanteItems = listarEstadoVentaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarEstadoBusqueda(){
		try {
			estadoBusquedaItems = new ArrayList<SelectItem>();
			estadoBusquedaItems = listarEstadoVentaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarOrigenBusqueda(){
		try {
			origenBusquedaItems = new ArrayList<SelectItem>();
			origenBusquedaItems = listarOrigenCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompRegistrosError(){
		try {
			tipCompRegistrosErrorItems = new ArrayList<SelectItem>();
			tipCompRegistrosErrorItems = listarTipCompCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompRegistrosProcesar(){
		try {
			tipCompRegistrosProcesarItems = new ArrayList<SelectItem>();
			tipCompRegistrosProcesarItems = listarTipCompCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarMonedaRegistrosError(){
		try {
			monedaRegistrosErrorItems = new ArrayList<SelectItem>();
			monedaRegistrosErrorItems = listarMonedaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarMonedaRegistrosProcesar(){
		try {
			monedaRegistrosProcesarItems = new ArrayList<SelectItem>();
			monedaRegistrosProcesarItems = listarMonedaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipDocRegistrosError(){
		try {
			tipDocRegistrosErrosItems = new ArrayList<SelectItem>();
			tipDocRegistrosErrosItems = listarTipDocCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipDocRegistrosProcesar(){
		try {
			tipDocRegistrosProcesarItems = new ArrayList<SelectItem>();
			tipDocRegistrosProcesarItems = listarTipDocCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipDocComprobante(){
		try {
			tipDocComprobanteItems = new ArrayList<SelectItem>();
			tipDocComprobanteItems = listarTipDocCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipDocBusqueda(){
		try {
			tipDocBusquedaItems = new ArrayList<SelectItem>();
			tipDocBusquedaItems = listarTipDocCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipDocProcesadosErrorOnline(){
		try {
			tipDocProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
			tipDocProcesadosErrorOnlineItems = listarTipDocCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipDocProcesadosCorrectosOnline(){
		try {
			tipDocProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
			tipDocProcesadosCorrectosOnlineItems = listarTipDocCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipDocRef(){
		try {
			tipDocRefItems = new ArrayList<SelectItem>();
			tipDocRefItems = listarTipDocCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarTipCompRefComprobante(){
		try {
			tipCompRefComprobanteItems = new ArrayList<SelectItem>();
			List<SelectItem> listaTmp = listarTipCompCbx();
			for(SelectItem bean : listaTmp){
				if(bean.getValue().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA) ||
						bean.getValue().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
					tipCompRefComprobanteItems.add(bean);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarMonedaComprobante(){
		try {
			monedaComprobanteItems = new ArrayList<SelectItem>();
			monedaComprobanteItems = listarMonedaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarMonedaBusqueda(){
		try {
			monedaBusquedaItems = new ArrayList<SelectItem>();
			monedaBusquedaItems = listarMonedaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarMonedaProcesadosErrorOnline(){
		try {
			monedaProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
			monedaProcesadosErrorOnlineItems = listarMonedaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarMonedaProcesadosCorrectosOnline(){
		try {
			monedaProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
			monedaProcesadosCorrectosOnlineItems = listarMonedaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarMonedaRef(){
		try {
			monedaRefItems = new ArrayList<SelectItem>();
			monedaRefItems = listarMonedaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarEmpresaComprobante(){
		try {
			empresaComprobanteItems = new ArrayList<SelectItem>();
			empresaComprobanteItems = listarEmpresaCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarDepartamentoComprobante(){
		try {
			departamentoComprobanteItems = new ArrayList<SelectItem>();
			departamentoComprobanteItems = listarDepartamentoCbx();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoRegistrosError(){
		try {
			productoRegistrosErrorItems = new ArrayList<SelectItem>();
			productoRegistrosErrorItems = listarProductoCbx(socioErrorSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoProcesadosErrorOnline(){
		try {
			productoProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
			productoProcesadosErrorOnlineItems = listarProductoCbx(socioProcesadosErrorOnlineSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoRef(){
		try {
			productoRefItems = new ArrayList<SelectItem>();
			productoRefItems = listarProductoCbx(socioRefSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoProcesadosCorrectosOnline(){
		try {
			productoProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
			productoProcesadosCorrectosOnlineItems = listarProductoCbx(socioProcesadosCorrectosOnlineSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoProcesoMasivo(){
		try {
			productoProcesoMasivoItems = new ArrayList<SelectItem>();
			productoProcesoMasivoItems = listarProductoCbx(socioProcesoMasivoSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoComprobante(){
		try {
			productoComprobanteItems = new ArrayList<SelectItem>();
			productoComprobanteItems = listarProductoCbx(socioComprobanteSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProvinciaComprobante(){
		try {
			provinciaComprobanteItems = new ArrayList<SelectItem>();
			provinciaComprobanteItems = listarProvinciaCbx(departamentoComprobante);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarDistritoComprobante(){
		try {
			distritoComprobanteItems = new ArrayList<SelectItem>();
			distritoComprobanteItems = listarDistritoCbx(provinciaComprobante, departamentoComprobante);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoRegistrosProcesar(){
		try {
			productoRegistrosProcesarItems = new ArrayList<SelectItem>();
			productoRegistrosProcesarItems = listarProductoCbx(socioProcesarSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private void listarProductoBusquedaVenta(){
		try {
			productoBusquedaItems = new ArrayList<SelectItem>();
			productoBusquedaItems = listarProductoCbx(socioBusquedaSelected);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	
	private List<SelectItem> listarSocioCbx(){
		
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			List<SocioCpeBean> listSocio = new ArrayList<SocioCpeBean>();
			listSocio = socioCpeService.listarSocio(new SocioCpeBean());
			
			for(SocioCpeBean socio : listSocio){
				list.add(new SelectItem(String.valueOf(socio.getIdSocio()), socio.getNomSocio()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarTipCompCbx(){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			ParametroCpeBean parametroRequest = new ParametroCpeBean();
			parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
			parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
			
			List<ParametroCpeBean> listTipComp = new ArrayList<ParametroCpeBean>();
			listTipComp = parametroCpeService.listarParametro(parametroRequest);
			
			for(ParametroCpeBean param : listTipComp){
				list.add(new SelectItem(param.getCodValor(), param.getNomValor()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarEstadoVentaCbx(){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			ParametroCpeBean parametroRequest = new ParametroCpeBean();
			parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
			parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
			
			List<ParametroCpeBean> listTipComp = new ArrayList<ParametroCpeBean>();
			listTipComp = parametroCpeService.listarParametro(parametroRequest);
			
			for(ParametroCpeBean param : listTipComp){
				list.add(new SelectItem(param.getCodValor(), param.getNomValor()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarOrigenCbx(){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			ParametroCpeBean parametroRequest = new ParametroCpeBean();
			parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_ORIGEN_DATOS);
			parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
			
			List<ParametroCpeBean> listOrigen = new ArrayList<ParametroCpeBean>();
			listOrigen = parametroCpeService.listarParametro(parametroRequest);
			
			for(ParametroCpeBean param : listOrigen){
				list.add(new SelectItem(param.getCodValor(), param.getNomValor()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarMonedaCbx(){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			ParametroCpeBean parametroRequest = new ParametroCpeBean();
			parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
			parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
			
			List<ParametroCpeBean> listMoneda = new ArrayList<ParametroCpeBean>();
			listMoneda = parametroCpeService.listarParametro(parametroRequest);
			
			for(ParametroCpeBean param : listMoneda){
				list.add(new SelectItem(param.getCodValor(), param.getNomValor()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarEmpresaCbx(){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			ParametroCpeBean parametroRequest = new ParametroCpeBean();
			parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_EMPRESA);
			parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
			
			List<ParametroCpeBean> listEmpresa = new ArrayList<ParametroCpeBean>();
			listEmpresa = parametroCpeService.listarParametro(parametroRequest);
			
			for(ParametroCpeBean param : listEmpresa){
				list.add(new SelectItem(param.getCodValor(), param.getNomValor()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarDepartamentoCbx(){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			
			List<UbigeoCpeBean> listDepartamento = new ArrayList<UbigeoCpeBean>();
			listDepartamento = ubigeoCpeService.listarDepartamento();
			
			for(UbigeoCpeBean depart : listDepartamento){
				list.add(new SelectItem(depart.getCodigoUbigeo(), depart.getNombreUbigeo()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarTipDocCbx(){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			ParametroCpeBean parametroRequest = new ParametroCpeBean();
			parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
			parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
			
			List<ParametroCpeBean> listTipDoc = new ArrayList<ParametroCpeBean>();
			listTipDoc = parametroCpeService.listarParametro(parametroRequest);
			
			for(ParametroCpeBean tipDoc : listTipDoc){
				list.add(new SelectItem(tipDoc.getCodValor(), tipDoc.getNomValor()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarProductoCbx(String socio){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			ProductoCpeBean productoRequest = new ProductoCpeBean();
			productoRequest.setIdSocio(Integer.parseInt(socio));
			
			List<ProductoCpeBean> listProducto = new ArrayList<ProductoCpeBean>();
			listProducto = productoCpeService.listarProducto(productoRequest);
			
			for(ProductoCpeBean producto : listProducto){
				list.add(new SelectItem(producto.getIdProducto().toString(), producto.getNomProducto()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarProvinciaCbx(String departamentoComprobante){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			UbigeoCpeBean ubigeoCpeBean = new UbigeoCpeBean();
			ubigeoCpeBean.setIdDepartamento(departamentoComprobante.substring(0, 2));
			
			List<UbigeoCpeBean> listProvincia = new ArrayList<UbigeoCpeBean>();
			listProvincia = ubigeoCpeService.listarProvincia(ubigeoCpeBean);
			
			for(UbigeoCpeBean prov : listProvincia){
				list.add(new SelectItem(prov.getCodigoUbigeo(), prov.getNombreUbigeo()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	private List<SelectItem> listarDistritoCbx(String provinciaComprobante, String departamentoComprobante){
		List<SelectItem> list = new ArrayList<SelectItem>();
		
		try {
			UbigeoCpeBean ubigeoCpeBean = new UbigeoCpeBean();
			ubigeoCpeBean.setIdProvincia(provinciaComprobante.substring(2, 4));
			ubigeoCpeBean.setIdDepartamento(departamentoComprobante.substring(0, 2));
			
			List<UbigeoCpeBean> listDistrito = new ArrayList<UbigeoCpeBean>();
			listDistrito = ubigeoCpeService.listarDistrito(ubigeoCpeBean);
			
			for(UbigeoCpeBean dist : listDistrito){
				list.add(new SelectItem(dist.getCodigoUbigeo(), dist.getNombreUbigeo()));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return list;
	}
	
	public void buscarProceso(){
		try {
			// Validar valores de los filtros
			validarFiltrosBusqueda();
			ProcesoCpeBean proceso = new ProcesoCpeBean();
			proceso.setCodUsuarioParam(usuarioSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : usuarioSelected);
			proceso.setCodEstado(estadoSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : estadoSelected);
			proceso.setFechaDesde(fechaDesde);
			proceso.setFechaHasta(fechaHasta);
			proceso.setConRegParam(conReg);
			
			proceso.setCodigoParametro(Constantes.COD_PARAM_CPE_ESTADO_PROCESO);
			proceso.setTipoParametro(Constantes.TIP_PARAM_DETALLE);
			
			listProcesoCpe = new ArrayList<ProcesoCpeBean>();
			listProcesoCpe = procesoCpeService.buscarProcesoCpe(proceso);
			
			nroRegistros = listProcesoCpe.size();
		} catch (SyncconException ex) {
			FacesMessage facesMsg = new FacesMessage(ex.getSeveridad(), ex.getMessage(), null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		} catch (Exception e) {
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/** Valida los valores de los filtros de busqueda propuesta **/
	private void validarFiltrosBusqueda() throws SyncconException {
		// Validar fechas de Registro
		if (fechaDesde != null && fechaHasta != null && fechaDesde.after(fechaHasta))
			throw new SyncconException(ErrorConstants.COD_ERROR_RANGO_FECHAS, FacesMessage.SEVERITY_INFO);

		if (fechaDesde != null && fechaHasta == null)
			throw new SyncconException(ErrorConstants.COD_ERROR_FECHA_HASTA, FacesMessage.SEVERITY_INFO);

		if (fechaDesde == null && fechaHasta != null)
			throw new SyncconException(ErrorConstants.COD_ERROR_FECHA_DESDE, FacesMessage.SEVERITY_INFO);

	}
	
	private boolean existeUsuarioRegistro(String codUsu){
		boolean flg = false;
		
		UsuarioBean usu = new UsuarioBean();
		usu.setCodigoUsuario(codUsu);
		List<UsuarioBean> listUsu = usuarioService.listarUsuario(usu);
		
		if(listUsu != null && !listUsu.isEmpty() && listUsu.size() > 0){
			flg = true;
		}
		return flg;
	}
	
	private Date primerDiaMesActual(){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		return calendar.getTime();
	}
	
	public void limpiar(){
		inicializarFiltros();
		inicializarResultados();
		cargarCbx();
	}
	
	public void abrirNuevoProceso(){
		usuarioTransaction = usuarioSesion;
		listarEstadosCbx();
		estadoTransaction = Constantes.COD_VALOR_ESTADO_PROCESO_PENDIENTE;
	}
	
	public void guardarProceso(){
		
		if(nombreProcesoTransaction.trim().length() == 0 ){
			enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS);
			flg_valida = false;
			return;
		}
		
		if(!existeUsuarioRegistro(usuarioSesion)){
			enviarMensaje(ErrorConstants.COD_ERROR_USUARIO_NO_REGISTRA);
			flg_valida = false;
			return;
		}
		
		if((nombreProcesoTransaction + "_" + usuarioTransaction).length() > 50){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NOMBRE_PROCESO_LARGO);
			nombreProcesoTransaction = "";
			flg_valida = false;
			return;
		}
		flg_valida = true;
		ProcesoCpeBean procesoCpeBean = new ProcesoCpeBean();
		procesoCpeBean.setNombreProceso(nombreProcesoTransaction + "_" + usuarioTransaction);
		procesoCpeBean.setCodUsuarioCreacion(usuarioTransaction);
		
		procesoCpeService.guardarProcesoCpe(procesoCpeBean);
		
		ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
		procesoEstadoCpeBean.setIdProceso(procesoCpeBean.getIdProceso());
		procesoEstadoCpeBean.setEstadoProceso(estadoTransaction);
		procesoEstadoCpeBean.setUsuModifica(usuarioTransaction);
		
		procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
		
		inicializarTransaction();
		
		buscarProceso();
		
		String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_REGISTRO_EXISTOSO_PROCESO);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje + procesoCpeBean.getIdProceso().toString(), null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		
	}
	
	public void abrirEliminar(){
		ProcesoCpeBean procesoCpeBean = (ProcesoCpeBean) FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_proceso}", ProcesoCpeBean.class);
		
		idProcesoTransaction = procesoCpeBean.getIdProceso();
		
	}
	
	public void eliminarProceso(){
		
		ProcesoCpeBean proc = new ProcesoCpeBean();
		
		for(ProcesoCpeBean bean : listProcesoCpe){
			if(bean.getIdProceso().equals(idProcesoTransaction)){
				proc = bean;
				break;
			}
		}
		
		if(proc.getCodEstado().trim().equals(Constantes.COD_VALOR_ESTADO_PROCESO_PROCESADO) 
				|| proc.getCodEstado().trim().equals(Constantes.COD_VALOR_ESTADO_PROCESO_PROCESADO_ERRORES) ){
			msjProcesoEliminar = getNoEliminarProcesoConfirmacion();
			return;
		}
		
		ProcesoCpeBean procesoCpeBean = new ProcesoCpeBean();
		procesoCpeBean.setIdProceso(idProcesoTransaction);
		
		ProcesoVentaCpeBean procesoVentaCpeBean = new ProcesoVentaCpeBean();
		procesoVentaCpeBean.setIdProceso(idProcesoTransaction);
		
		procesoCpeService.eliminarProcesoVentaProcesoCpe(procesoVentaCpeBean);
		procesoCpeService.eliminarProcesoEstadoCpe(procesoCpeBean);
		procesoCpeService.eliminarProcesoCpe(procesoCpeBean);
		
		msjProcesoEliminar = getEliminarProcesoConfirmacion();
		
		inicializarTransaction();
		
		buscarProceso();
	}
	
	public String goToPreProceso(){
		
		proceso = (ProcesoCpeBean) FacesContext.getCurrentInstance().getApplication()
						.evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_proceso}", ProcesoCpeBean.class);
		
		inicializarFiltrosRegistrosError();
		
		cargarCbxRegistrosError();
		
		inicializarResultadosRegistrosError();
		
		inicializarFiltrosRegistrosProcesar();
		
		cargarCbxRegistrosProcesar();
		
		inicializarResultadosRegistrosProcesar();
		
		//inicializarOtrosPreProceso();
		
		//filtrarError();
		
		//filtrarProcesar();
		
		if (nroRegistros > 0){
			filtrarErrorYProcesar();
		}
		
		ParametroCpeBean prmCpe = new ParametroCpeBean();
		prmCpe.setCodParam(Constantes.COD_PARAM_NUM_MAXIMO_ONLINE);
		prmCpe.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listPrm = new ArrayList<ParametroCpeBean>();
		listPrm = parametroCpeService.listarParametro(prmCpe);
		numMaximoOnline = Integer.parseInt(listPrm.get(0).getNomValor());
		
		return "toPreProceso";
	}
	
	public void filtrarErrorYProcesar(){
		
		VentaCpeBean ventaRequest = new VentaCpeBean();
		ventaRequest.setIdProceso(proceso.getIdProceso());
		
		ventaRequest.setParamEmpresa(Constantes.COD_PARAM_CPE_EMPRESA);
		ventaRequest.setParamTipParam(Constantes.TIP_PARAM_DETALLE);
		ventaRequest.setParamMoneda(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		ventaRequest.setParamEstadoVenta(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		ventaRequest.setParamTipDoc(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
		
		List<VentaCpeBean> listventa = procesoCpeService.buscarVentaCpe(ventaRequest);
		setUbigeoCodADesc(listventa);
		
		/*Validar Tipo Proceso por Empresa*/
		if (listventa.size() > 0)
		{
			String empresa;
			String cod_valor = null;
			empresa = listventa.get(0).getIdEmpresa().toString();
			ParametroCpeBean param = new ParametroCpeBean();
			param.setCodParam(Constantes.COD_PARAM_TIPO_PROCESO_POR_EMPRESA);
			param.setTipParam(Constantes.TIP_PARAM_DETALLE);
	
			if (empresa.equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS))
			{
				cod_valor = Constantes.COD_VALOR_PROCESO_ONLINE_SEGUROS;
				param.setCodValor(cod_valor);
				List<ParametroCpeBean> lstParam1 = new ArrayList<ParametroCpeBean>();
				lstParam1 = parametroCpeService.listarParametro(param);
				if (Integer.parseInt(lstParam1.get(0).getNomValor().toString()) == 0)
					setDisabledOnline(true);
				else
					setDisabledOnline(false);
				
				cod_valor = Constantes.COD_VALOR_PROCESO_MASIVO_SEGUROS;
				param.setCodValor(cod_valor);
				List<ParametroCpeBean> lstParam2 = new ArrayList<ParametroCpeBean>();
				lstParam2 = parametroCpeService.listarParametro(param);
				if (Integer.parseInt(lstParam2.get(0).getNomValor().toString()) == 0)
					setDisabledMasivo(true);
				else
					setDisabledMasivo(false);
				
				/**TIP_PER0100_FASE02 INICIO 2019/11/26 - 17:55 - Se agrega Lógica que permite habilitar la opción de Resumen.*/
				cod_valor = Constantes.COD_VALOR_PROCESO_RESUMEN_SEGUROS;
				param.setCodValor(cod_valor);
				List<ParametroCpeBean> lstParam3 = new ArrayList<ParametroCpeBean>();
				lstParam3 = parametroCpeService.listarParametro(param);
				if (Integer.parseInt(lstParam3.get(0).getNomValor().toString()) == 0)
					setDisabledResumen(true);
				else
					setDisabledResumen(false);
				/**TIP_PER0100_FASE02 FIN 2019/11/26 - 17:55 - Se agrega Lógica que permite habilitar la opción de Resumen.*/
				
				
				/**TIP_PER0100_FASE02 INICIO 2019/11/26 - 18:01 - Se reajusta lógica de habilitar opciones de tipos de procesos.*/
//				if (disabledOnline == false && disabledMasivo == false)
//					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
//				else if (disabledOnline == false  && disabledMasivo == true)
//					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
//				else if (disabledOnline == true && disabledMasivo == false)
//					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_MASIVO;
				
				if (disabledOnline == false && disabledMasivo == false  && disabledResumen == false)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
				else if (disabledOnline == false  && disabledMasivo == true && disabledResumen == true)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
				else if (disabledOnline == true && disabledMasivo == false && disabledResumen == true)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_MASIVO;
				else if (disabledOnline == true && disabledMasivo == true && disabledResumen == false)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE_RESUMEN;
				
				/**TIP_PER0100_FASE02 FIN 2019/11/26 - 18:01 - Se reajusta lógica de habilitar opciones de tipos de procesos.*/
			}
			else 
			{
				cod_valor = Constantes.COD_VALOR_PROCESO_ONLINE_SERVICIOS;
				param.setCodValor(cod_valor);
				List<ParametroCpeBean> lstParam1 = new ArrayList<ParametroCpeBean>();
				lstParam1 = parametroCpeService.listarParametro(param);
				if (Integer.parseInt(lstParam1.get(0).getNomValor().toString()) == 0)
					setDisabledOnline(true);
				else
					setDisabledOnline(false);
				
				cod_valor = Constantes.COD_VALOR_PROCESO_MASIVO_SERVICIOS;
				param.setCodValor(cod_valor);
				List<ParametroCpeBean> lstParam2 = new ArrayList<ParametroCpeBean>();
				lstParam2 = parametroCpeService.listarParametro(param);
				if (Integer.parseInt(lstParam2.get(0).getNomValor().toString()) == 0)
					setDisabledMasivo(true);
				else
					setDisabledMasivo(false);

				/**TIP_PER0100_FASE02 INICIO 2019/11/26 - 17:55 - Se agrega Lógica que permite habilitar la opción de Resumen.*/
				cod_valor = Constantes.COD_VALOR_PROCESO_RESUMEN_SEGUROS;
				param.setCodValor(cod_valor);
				List<ParametroCpeBean> lstParam3 = new ArrayList<ParametroCpeBean>();
				lstParam3 = parametroCpeService.listarParametro(param);
				if (Integer.parseInt(lstParam3.get(0).getNomValor().toString()) == 0)
					setDisabledResumen(true);
				else
					setDisabledResumen(false);
				/**TIP_PER0100_FASE02 FIN 2019/11/26 - 17:55 - Se agrega Lógica que permite habilitar la opción de Resumen.*/
				
				/**TIP_PER0100_FASE02 INICIO 2019/11/26 - 18:01 - Se reajusta lógica de habilitar opciones de tipos de procesos.*/
//				if (disabledOnline == false && disabledMasivo == false)
//					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
//				else if (disabledOnline == false  && disabledMasivo == true)
//					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
//				else if (disabledOnline == true && disabledMasivo == false)
//					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_MASIVO;
				
				if (disabledOnline == false && disabledMasivo == false  && disabledResumen == false)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
				else if (disabledOnline == false  && disabledMasivo == true && disabledResumen == true)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
				else if (disabledOnline == true && disabledMasivo == false && disabledResumen == true)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_MASIVO;
				else if (disabledOnline == true && disabledMasivo == true && disabledResumen == false)
					tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE_RESUMEN;
				
				/**TIP_PER0100_FASE02 FIN 2019/11/26 - 18:01 - Se reajusta lógica de habilitar opciones de tipos de procesos.*/
			}
		}
		else
		{
			setDisabledOnline(false);
			setDisabledMasivo(false);
			setDisabledResumen(false);/**TIP_PER0100_FASE02 INICIO-FIN 2019/11/26 - 18:05 - Se habilita opción resumen.*/
			tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
		}
		
		listVentaError = new ArrayList<VentaCpeBean>();
		listVentaProcesar = new ArrayList<VentaCpeBean>();
		
		for(VentaCpeBean venta : listventa){
			if(requiereCompletarDatos(venta)){
				listVentaError.add(venta);
			}else{
				listVentaProcesar.add(venta);
			}
		}
		
		/* Error Inicio */
		nroRegistrosError = listVentaError.size();
		setMostrarImportarDatos();
		/* Error Fin */
		
		/* Proceso Inicio */
		nroRegistrosProcesar = listVentaProcesar.size();
		
		if(nroRegistrosProcesar == 0){
			labelMonedaProcesar = "";
		}else{
			if(monedaProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
				labelMonedaProcesar = Constantes.LABEL_ALL_CBX;
			}else{
				for(SelectItem item : monedaRegistrosProcesarItems){
					if(item.getValue().toString().equals(monedaProcesarSelected)){
						labelMonedaProcesar = item.getLabel().toString();
						break;
					}
				}
			}
		}
		
		montoTotalProcesar = BigDecimal.ZERO;
		for(VentaCpeBean venta : listVentaProcesar){
			montoTotalProcesar = montoTotalProcesar.add(venta.getImpTotal() == null ? BigDecimal.ZERO : venta.getImpTotal());
		}
		/* Proceso Fin */
		

	}
	
	public void obtenerProductoRegistrosError(){
		if(!socioErrorSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoRegistrosError();
		}else{
			productoRegistrosErrorItems = new ArrayList<SelectItem>();
			productoErrorSelected = Constantes.VALOR_DEFECTO_CBX;
		}
	}

	public void obtenerProductoProcesoMasivo(){
		if(!socioProcesoMasivoSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoProcesoMasivo();
		}else{
			productoProcesoMasivoItems = new ArrayList<SelectItem>();
			socioProcesoMasivoSelected = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void obtenerProductoRegistrosProcesar(){
		if(!socioProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoRegistrosProcesar();
		}else{
			productoRegistrosProcesarItems = new ArrayList<SelectItem>();
			productoProcesarSelected = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void obtenerProductoComprobante(){
		if(!socioComprobanteSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoComprobante();
		}else{
			productoComprobanteItems = new ArrayList<SelectItem>();
			productoComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		}
		actualizarImportes();
	}
	
	public void ValidarProductoAdministrativo()
	{
		if(!productoComprobanteSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			//Traemos Cod Prod SUNAT del Producto seleccionado
			ProductoCpeBean productoRequest = new ProductoCpeBean();
			productoRequest.setIdSocio(Integer.parseInt(socioComprobanteSelected));
			productoRequest.setIdProducto(Integer.parseInt(productoComprobanteSelected));
			
			List<ProductoCpeBean> listProducto = new ArrayList<ProductoCpeBean>();
			listProducto = productoCpeService.listarProducto(productoRequest);
			
			if (listProducto.size() > 0)
			{
				if (listProducto.get(0).getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO))
				{
					codProdSunat = "";
				}
				else {
					codProdSunat = String.valueOf(listProducto.get(0).getCodProdSunat());
				}
			}
			else {
				codProdSunat = "";
			}
		}
	}
	
	public void actualizarImportes(){
		if(action.equals("N")){
			importeTotalComprobante = "";
			valFactExportComprobante = "0";
			impInafectoComprobante = "0";
			iscComprobante = "0";
			otrosImportesComprobante = "0";
			baseImponibleComprobante = "0";
			impExoneradoComprobante = "0";
			igvComprobante = "0";
			
			ValidarProductoAdministrativo();
		}
		
		if(empresaComprobanteSelected.equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
			disabledPoliza = false;
		}else{
			disabledPoliza = true;
		}
		
		numPolizaComprobante = "";
		
//		if(action.equals("E")){
//			disabledPoliza = true;
//		}
	}

	public void obtenerProductoProcesadosErrorOnline(){
		if(!socioProcesadosErrorOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoProcesadosErrorOnline();
		}else{
			productoProcesadosErrorOnlineItems = new ArrayList<SelectItem>();
			productoProcesadosErrorOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void obtenerProductoProcesadosCorrectosOnline(){
		if(!socioProcesadosCorrectosOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoProcesadosCorrectosOnline();
		}else{
			productoProcesadosCorrectosOnlineItems = new ArrayList<SelectItem>();
			productoProcesadosCorrectosOnlineSelected = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void obtenerProductoRef(){
		if(!socioRefSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoRef();
		}else{
			productoRefItems = new ArrayList<SelectItem>();
			productoRefSelected = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void obtenerProvinciaComprobante(){
		if(!departamentoComprobante.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProvinciaComprobante();
			distritoComprobanteItems = new ArrayList<SelectItem>();
			distritoComprobante = Constantes.VALOR_DEFECTO_CBX;
		}else{
			provinciaComprobanteItems = new ArrayList<SelectItem>();
			provinciaComprobante = Constantes.VALOR_DEFECTO_CBX;
			distritoComprobanteItems = new ArrayList<SelectItem>();
			distritoComprobante = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void obtenerDistritoComprobante(){
		if(!provinciaComprobante.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarDistritoComprobante();
		}else{
			distritoComprobanteItems = new ArrayList<SelectItem>();
			distritoComprobante = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void filtrarProcesar(){
		
		VentaCpeBean ventaRequest = new VentaCpeBean();
		ventaRequest.setIdProceso(proceso.getIdProceso());
		//ventaRequest.setFlgCompletado(Constantes.FLG_COMPLETADO_SI);
		ventaRequest.setIdSocio(socioProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX) ?  null : Long.parseLong(socioProcesarSelected));
		ventaRequest.setIdProducto(productoProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.parseLong(productoProcesarSelected));
		ventaRequest.setConcepto(conceptoProcesar == null ? null : conceptoProcesar.trim().length() == 0 ?  null : "%" + conceptoProcesar + "%");
		ventaRequest.setNomCliRazSoc(clienteProcesar == null ? null : clienteProcesar.trim().length() == 0 ? null : "%" + clienteProcesar + "%");
		ventaRequest.setIdTipoComp(tipCompProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipCompProcesarSelected);
		ventaRequest.setFechaEmisionDate(fecEmisionProcesar);
		ventaRequest.setIdTipoDocCli(tipDocProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipDocProcesarSelected);
		ventaRequest.setTipoMoneda(monedaProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : monedaProcesarSelected);
		ventaRequest.setImpTotal(montoProcesar == null ? null : montoProcesar.trim().length() == 0 ? null : new BigDecimal(montoProcesar));
		ventaRequest.setNumDocCli(numDocProcesar == null ? null : numDocProcesar.trim().length() == 0 ? null : numDocProcesar);
		ventaRequest.setNumeroComprobante(numCompProcesar == null ? null : numCompProcesar.trim().length() == 0 ? null : Long.parseLong(numCompProcesar));
		ventaRequest.setNumPoliza(certificadoProcesar == null ? null : certificadoProcesar.trim().length() == 0 ? null : certificadoProcesar);
		
		ventaRequest.setParamEmpresa(Constantes.COD_PARAM_CPE_EMPRESA);
		ventaRequest.setParamTipParam(Constantes.TIP_PARAM_DETALLE);
		ventaRequest.setParamMoneda(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		ventaRequest.setParamEstadoVenta(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		ventaRequest.setParamTipDoc(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
		
		List<VentaCpeBean> listVenta = procesoCpeService.buscarVentaCpe(ventaRequest);
		setUbigeoCodADesc(listVenta);
		listVentaProcesar = new ArrayList<VentaCpeBean>();
		
		for(VentaCpeBean venta : listVenta){
			if(!requiereCompletarDatos(venta)){
				listVentaProcesar.add(venta);
			}
		}
		
		nroRegistrosProcesar = listVentaProcesar.size();
		
		if(nroRegistrosProcesar == 0){
			labelMonedaProcesar = "";
		}else{
			if(monedaProcesarSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
				labelMonedaProcesar = Constantes.LABEL_ALL_CBX;
			}else{
				for(SelectItem item : monedaRegistrosProcesarItems){
					if(item.getValue().toString().equals(monedaProcesarSelected)){
						labelMonedaProcesar = item.getLabel().toString();
						break;
					}
				}
			}
		}
		
		montoTotalProcesar = BigDecimal.ZERO;
		for(VentaCpeBean venta : listVentaProcesar){
			montoTotalProcesar = montoTotalProcesar.add(venta.getImpTotal() == null ? BigDecimal.ZERO : venta.getImpTotal());
		}
		
	}
	
	public void exportarTablaRegistrosProcesar(){
		
		SXSSFWorkbook book = new SXSSFWorkbook();
		Sheet sheet = null;
		
		try {
			
			sheet = book.createSheet("Ventas por Procesar");
			sheet.setColumnWidth(0, 6000);
			sheet.setColumnWidth(1, 6000);
			sheet.setColumnWidth(2, 6000);
			sheet.setColumnWidth(3, 6000);
			sheet.setColumnWidth(4, 6000);
			sheet.setColumnWidth(5, 6000);
			sheet.setColumnWidth(6, 6000);
			sheet.setColumnWidth(7, 6000);
			sheet.setColumnWidth(8, 6000);
			sheet.setColumnWidth(9, 6000);
			sheet.setColumnWidth(10, 8000);
			
			// Estilos para cabecera del documento
			CellStyle headStyle = book.createCellStyle();

			Font headFont = book.createFont();
			headFont.setFontHeightInPoints((short) 9);
			headFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			headFont.setColor(HSSFColor.BLACK.index);

			headStyle.setAlignment(CellStyle.ALIGN_CENTER);
			headStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
			headStyle.setBorderTop(CellStyle.BORDER_THIN);
			headStyle.setBorderLeft(CellStyle.BORDER_THIN);
			headStyle.setBorderRight(CellStyle.BORDER_THIN);
			headStyle.setBorderBottom(CellStyle.BORDER_THIN);
			headStyle.setFont(headFont);
			
			// Estilos para el cuerpo del documento
			CellStyle bodyStyle = book.createCellStyle();

			Font bodyFont = book.createFont();
			bodyFont.setFontHeightInPoints((short) 9);
			bodyFont.setColor(HSSFColor.BLACK.index);

			bodyStyle.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyle.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyle.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyle.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyle.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyle.setFont(bodyFont);
			
			// Construyendo cuerpo
			int rowPosition = 0;
			int columnPosition = 0;
			
			Row row = sheet.createRow(rowPosition);

			Cell cell = row.createCell(columnPosition);
			RichTextString val = new XSSFRichTextString("Empresa");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);

			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Socio");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Producto");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Cliente");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Moneda");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Monto");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IGV");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Estado");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Origen");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Fecha Carga");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Motivo Rechazo");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			// DATA
			for (int i = 0; i < listVentaProcesar.size(); i++) {
				rowPosition++;
				row = sheet.createRow(rowPosition);
				for (int j = 0; j <= 10; j++) {
					cell = row.createCell(j);
					if (j == 0) {
						cell.setCellValue(listVentaProcesar.get(i).getNombreEmpresa());
					} else if (j == 1) {
						cell.setCellValue(listVentaProcesar.get(i).getNomSocio());
					} else if (j == 2) {
						cell.setCellValue(listVentaProcesar.get(i).getNomProducto());
					} else if (j == 3) {
						cell.setCellValue(listVentaProcesar.get(i).getNomCliRazSoc());
					} else if (j == 4) {
						cell.setCellValue(listVentaProcesar.get(i).getNombreMoneda());
					} else if (j == 5) {
						cell.setCellValue(listVentaProcesar.get(i).getImpTotal().doubleValue());
					} else if (j == 6) {
						cell.setCellValue(listVentaProcesar.get(i).getIgv().doubleValue());
					} else if (j == 7) {
						cell.setCellValue(listVentaProcesar.get(i).getNombreEstado());
					} else if (j == 8) {
						cell.setCellValue(listVentaProcesar.get(i).getOrigen());
					} else if (j == 9) {
						cell.setCellValue(formatoddMMaaaa.format(listVentaProcesar.get(i).getFechaCarga()));
					}else if (j == 10) {
						cell.setCellValue(listVentaProcesar.get(i).getMotivoRechazo());
					}
					cell.setCellStyle(bodyStyle);
				}
			}
			
			String fileName = "RegistrosProcesar_Ventas.xlsx";

			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			response.addHeader("Content-Disposition", "attachment; filename=" + fileName);
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			OutputStream out = response.getOutputStream();
			book.write(out);
			out.close();

			FacesContext.getCurrentInstance().responseComplete();
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		
	}
	
	public void limpiarFiltrosError(){
		inicializarFiltrosRegistrosError();
		inicializarResultadosRegistrosError();
		cargarCbxRegistrosError();		
		seleccionarTodosError = false;
	}
	
	public void filtrarError(){
		
		VentaCpeBean ventaRequest = new VentaCpeBean();
		ventaRequest.setIdProceso(proceso.getIdProceso());
		//ventaRequest.setFlgCompletado(Constantes.FLG_COMPLETADO_NO);
		ventaRequest.setIdSocio(socioErrorSelected.equals(Constantes.VALOR_DEFECTO_CBX) ?  null : Long.parseLong(socioErrorSelected));
		ventaRequest.setIdProducto(productoErrorSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.parseLong(productoErrorSelected));
		ventaRequest.setConcepto(conceptoError == null ? null : conceptoError.trim().length() == 0 ?  null : "%" + conceptoError + "%");
		ventaRequest.setNomCliRazSoc(clienteError == null ? null : clienteError.trim().length() == 0 ? null : "%" + clienteError + "%");
		ventaRequest.setIdTipoComp(tipCompErrorSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipCompErrorSelected);
		ventaRequest.setFechaEmisionDate(fecEmisionError);
		ventaRequest.setIdTipoDocCli(tipDocErrorSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipDocErrorSelected);
		ventaRequest.setTipoMoneda(monedaErrorSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : monedaErrorSelected);
		ventaRequest.setImpTotal(montoError == null ? null : montoError.trim().length() == 0 ? null : new BigDecimal(montoError));
		ventaRequest.setNumDocCli(numDocError == null ? null : numDocError.trim().length() == 0 ? null : numDocError);
		ventaRequest.setNumeroComprobante(numCompError == null ? null : numCompError.trim().length() == 0 ? null : Long.parseLong(numCompError));
		
		ventaRequest.setParamEmpresa(Constantes.COD_PARAM_CPE_EMPRESA);
		ventaRequest.setParamTipParam(Constantes.TIP_PARAM_DETALLE);
		ventaRequest.setParamMoneda(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		ventaRequest.setParamEstadoVenta(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		ventaRequest.setParamTipDoc(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
		
		List<VentaCpeBean> listventa = procesoCpeService.buscarVentaCpe(ventaRequest);
		setUbigeoCodADesc(listventa);
		listVentaError = new ArrayList<VentaCpeBean>();
		
		for(VentaCpeBean venta : listventa){
			if(requiereCompletarDatos(venta)){
				listVentaError.add(venta);
			}
		}
		
		nroRegistrosError = listVentaError.size();
		setMostrarImportarDatos();
		
	}
	
	public void onchangeCheckboxRegProcesar(){
		VentaCpeBean bean = (VentaCpeBean)FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaProcesar}", VentaCpeBean.class);
		if(!bean.isSeleccionado()){
			seleccionarTodosProcesar = false;
		}
	}
	
	private void setUbigeoDescACod(VentaCpeBean venta){
		if(venta.getDepartamento() != null && !venta.getDepartamento().equals("")){
			obtenerDepartamento(venta);
			if(venta.getProvincia() != null && !venta.getProvincia().equals("")){
				obtenerProvincia(venta);
				if(venta.getDistrito() != null && !venta.getDistrito().equals("")){
					obtenerDistrito(venta);
				}else{
					venta.setDistrito("");
				}
			}
			else{
				venta.setProvincia("");
				venta.setDistrito("");
			}
		}else{
			venta.setDepartamento("");
			venta.setProvincia("");
			venta.setDistrito("");
		}
	}
	
	public void exportarTablaRegistrosError(){
		
		SXSSFWorkbook book = new SXSSFWorkbook();
		Sheet sheet = null;
		
		
		try {
			
			sheet = book.createSheet("Ventas con Error");
			sheet.protectSheet("password");
			
			for(int i=0; i<=42; i++){
				sheet.setColumnWidth(i, 6000);
			}
			
			// Estilos para cabecera del documento
			CellStyle headStyle = book.createCellStyle();

			Font headFont = book.createFont();
			headFont.setFontHeightInPoints((short) 9);
			headFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			headFont.setColor(HSSFColor.BLACK.index);

			headStyle.setAlignment(CellStyle.ALIGN_CENTER);
			headStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
			headStyle.setBorderTop(CellStyle.BORDER_THIN);
			headStyle.setBorderLeft(CellStyle.BORDER_THIN);
			headStyle.setBorderRight(CellStyle.BORDER_THIN);
			headStyle.setBorderBottom(CellStyle.BORDER_THIN);
			headStyle.setFont(headFont);
			
			// Estilos para cabecera del documento obligatorios
			CellStyle headStyleObl = book.createCellStyle();

			headStyleObl.setAlignment(CellStyle.ALIGN_CENTER);
			headStyleObl.setVerticalAlignment(CellStyle.ALIGN_FILL);
			headStyleObl.setBorderTop(CellStyle.BORDER_THIN);
			headStyleObl.setBorderLeft(CellStyle.BORDER_THIN);
			headStyleObl.setBorderRight(CellStyle.BORDER_THIN);
			headStyleObl.setBorderBottom(CellStyle.BORDER_THIN);
			headStyleObl.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			headStyleObl.setFillPattern(CellStyle.SOLID_FOREGROUND);
			headStyleObl.setFont(headFont);
			
			// Estilos para el cuerpo del documento
			CellStyle bodyStyle = book.createCellStyle();

			Font bodyFont = book.createFont();
			bodyFont.setFontHeightInPoints((short) 9);
			bodyFont.setColor(HSSFColor.BLACK.index);

			bodyStyle.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyle.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyle.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyle.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyle.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyle.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyle.setFont(bodyFont);
			
			// Estilos para el cuerpo del documento obligatorios
			CellStyle bodyStyleReq = book.createCellStyle();

			bodyStyleReq.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyleReq.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyleReq.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyleReq.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyleReq.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyleReq.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyleReq.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			bodyStyleReq.setFillPattern(CellStyle.SOLID_FOREGROUND);
			bodyStyleReq.setFont(bodyFont);
			bodyStyleReq.setLocked(false);
			
			// Estilos para el cuerpo del documento obligatorios
			CellStyle bodyStyleComple = book.createCellStyle();

			bodyStyleComple.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyleComple.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyleComple.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyleComple.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyleComple.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyleComple.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyleComple.setFont(bodyFont);
			bodyStyleComple.setLocked(false);
			
			// Estilos para el cuerpo del documento (solo pintar sin desbloquear)
			CellStyle bodyStyleSoloPintar = book.createCellStyle();
			
			bodyStyleSoloPintar.setAlignment(CellStyle.ALIGN_CENTER);
			bodyStyleSoloPintar.setVerticalAlignment(CellStyle.ALIGN_FILL);
			bodyStyleSoloPintar.setBorderTop(CellStyle.BORDER_THIN);
			bodyStyleSoloPintar.setBorderLeft(CellStyle.BORDER_THIN);
			bodyStyleSoloPintar.setBorderRight(CellStyle.BORDER_THIN);
			bodyStyleSoloPintar.setBorderBottom(CellStyle.BORDER_THIN);
			bodyStyleSoloPintar.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			bodyStyleSoloPintar.setFillPattern(CellStyle.SOLID_FOREGROUND);
			bodyStyleSoloPintar.setFont(bodyFont);
			
			// Construyendo cuerpo
			int rowPosition = 0;
			int columnPosition = 0;
			
			Row row = sheet.createRow(rowPosition);

			Cell cell = row.createCell(columnPosition);
			RichTextString val = new XSSFRichTextString("EmpresaEmisora");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);

			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Socio");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Producto");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FechaEmision");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 16:13 - Se agrega a la estructura Orden de compra*/
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OrdenCompra");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			/*TIP_PER0100_CC09_13 FIN*/
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoComprobante");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ConceptoNC/ND");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoMoneda");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FechaVencimiento");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoDocCliente");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NumDocCliente");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Nombres-RazonSocial");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Direccion");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Departamento");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Provincia");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Distrito");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Telefono");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Correo");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoComprobanteRef");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("FechaEmisionRef");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("SerieComprobanteRef");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("CorrelativoSerieOrig");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Concepto");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ProductoSunat");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);

			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("NumeroPoliza");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 16:15 - Se agrega a la estructura Aplica Detracción y PorcDetracción*/
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("AplicaDetraccion");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("PorcDetraccion");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			/*TIP_PER0100_CC09_13 FIN*/
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ValorFactExport");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("BaseImponible");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ImporteExonerado");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ImporteInafecto");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ValorOpGratuitas");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ISC");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("IGV");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Otros Importes");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Importe Total");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
//			columnPosition++;
//			cell = row.createCell(columnPosition);
//			val = new XSSFRichTextString("TipoCambio");
//			cell.setCellValue(val);
//			cell.setCellStyle(headStyle);
//			
//			columnPosition++;
//			cell = row.createCell(columnPosition);
//			val = new XSSFRichTextString("Estado");
//			cell.setCellValue(val);
//			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OpenItem");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("OpenItemRef");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Area");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Observaciones");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
//			columnPosition++;
//			cell = row.createCell(columnPosition);
//			val = new XSSFRichTextString("Monto USD");
//			cell.setCellValue(val);
//			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Colect_indiv");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Linea");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TipoAfectacion");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			
			/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 16:16 - Se agrega a la estructura Título Adicional y Valor Adicional*/
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("TituloAdicional");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("ValorAdicional");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			/*TIP_PER0100_CC09_13 FIN*/
			
			columnPosition++;
			cell = row.createCell(columnPosition);
			val = new XSSFRichTextString("Id Venta");
			cell.setCellValue(val);
			cell.setCellStyle(headStyle);
			
			// DATA
			for (int i = 0; i < listVentaError.size(); i++) {
				rowPosition++;
				row = sheet.createRow(rowPosition);
				for (int j = 0; j <= 45; j++) {
					cell = row.createCell(j);
					if (j == 0) {
						// EmpresaEmisora
						cell.setCellValue(listVentaError.get(i).getIdEmpresa() == null ? "" : listVentaError.get(i).getIdEmpresa());
						cell.setCellStyle(bodyStyle);
					} else if (j == 1) {
						// Socio
						cell.setCellValue(listVentaError.get(i).getIdSocio() == null ? 0 : listVentaError.get(i).getIdSocio().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 2) {
						// Producto
						cell.setCellValue(listVentaError.get(i).getIdProducto() == null ? 0 : listVentaError.get(i).getIdProducto().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 3) {
						// FechaEmision
						cell.setCellValue(listVentaError.get(i).getFechaEmision() == null ? "" : listVentaError.get(i).getFechaEmision());
						cell.setCellStyle(bodyStyle);
					} else if (j == 4) {
						/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 16:19 - Se agrega el dato de error para Orden de compra*/
						// OrdenCompra
						cell.setCellValue(listVentaError.get(i).getOrdenCompra() == null ? "" : listVentaError.get(i).getOrdenCompra());
						cell.setCellStyle(bodyStyle);
						/*TIP_PER0100_CC09_13 FIN*/
						
					}else if (j == 5) {
						// TipoComprobante
						cell.setCellValue(listVentaError.get(i).getIdTipoComp() == null ? "" : listVentaError.get(i).getIdTipoComp());
						cell.setCellStyle(bodyStyle);
					}else if (j == 6) {
						// ConceptoND
						cell.setCellValue(listVentaError.get(i).getConcepNd() == null ? "" : listVentaError.get(i).getConcepNd());
						cell.setCellStyle(bodyStyle);
					} else if (j == 7) {
						// TipoMoneda
						cell.setCellValue(listVentaError.get(i).getTipoMoneda() == null ? "" : listVentaError.get(i).getTipoMoneda());
						if(listVentaError.get(i).getTipoMoneda() != null && listVentaError.get(i).getTipoMoneda().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleReq);
						}
					} else if (j == 8) {
						// FechaVencimiento
						cell.setCellValue(listVentaError.get(i).getFechaVenc() == null ? "" : listVentaError.get(i).getFechaVenc());
						cell.setCellStyle(bodyStyle);
					} else if (j == 9) {
						// TipoDocCliente
						cell.setCellValue(listVentaError.get(i).getIdTipoDocCli() == null ? "" : listVentaError.get(i).getIdTipoDocCli());
						if(listVentaError.get(i).getIdTipoDocCli() != null && listVentaError.get(i).getIdTipoDocCli().trim().length() > 0){
							if(validarTipoComprobanteConTipoDocumento(listVentaError.get(i).getIdTipoComp(), listVentaError.get(i).getIdTipoDocCli(), listVentaError.get(i).getTipoProducto())){
								//cell.setCellStyle(bodyStyleSoloPintar);
								cell.setCellStyle(bodyStyleReq);
							}else{
								cell.setCellStyle(bodyStyle);
							}
						}else{
							cell.setCellStyle(bodyStyleReq);
						}
					} else if (j == 10) {
						// NumDocCliente
						cell.setCellValue(listVentaError.get(i).getNumDocCli() == null ? "" : listVentaError.get(i).getNumDocCli());
						if(listVentaError.get(i).getNumDocCli() != null && listVentaError.get(i).getNumDocCli().trim().length() > 0){
							if((listVentaError.get(i).getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DNI) 
									|| listVentaError.get(i).getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC))
									? !esNumDocvalido(listVentaError.get(i).getNumDocCli(), getNumeroDigitosTipDoc(listVentaError.get(i).getIdTipoDocCli())) : false){
								cell.setCellStyle(bodyStyleReq);
							}else{
								cell.setCellStyle(bodyStyle);
							}
						}else{
							cell.setCellStyle(bodyStyleReq);
						}
					} else if (j == 11) {
						// Nombres-RazonSocial
						cell.setCellValue(listVentaError.get(i).getNomCliRazSoc() == null ? "" : listVentaError.get(i).getNomCliRazSoc());
						if(listVentaError.get(i).getNomCliRazSoc() != null && listVentaError.get(i).getNomCliRazSoc().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleReq);
						}
					} else if (j == 12) {
						// Direccion
						cell.setCellValue(listVentaError.get(i).getDirCliente() == null ? "" : listVentaError.get(i).getDirCliente());
						if(listVentaError.get(i).getDirCliente() != null && listVentaError.get(i).getDirCliente().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleComple);
						}
					} else if (j == 13) {
						// Departamento
						cell.setCellValue(listVentaError.get(i).getDepartamento() == null ? "" : listVentaError.get(i).getDepartamento());
						if(listVentaError.get(i).getDepartamento() != null && listVentaError.get(i).getDepartamento().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleComple);
						}
					} else if (j == 14) {
						// Provincia
						cell.setCellValue(listVentaError.get(i).getProvincia() == null ? "" : listVentaError.get(i).getProvincia());
						if(listVentaError.get(i).getProvincia() != null && listVentaError.get(i).getProvincia().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleComple);
						}
					} else if (j == 15) {
						// Distrito
						cell.setCellValue(listVentaError.get(i).getDistrito() == null ? "" : listVentaError.get(i).getDistrito());
						if(listVentaError.get(i).getDistrito() != null && listVentaError.get(i).getDistrito().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleComple);
						}
					} else if (j == 16) {
						// Telefono
						cell.setCellValue(listVentaError.get(i).getTelefCliente() == null ? "" : listVentaError.get(i).getTelefCliente());
						if(listVentaError.get(i).getTelefCliente() != null && listVentaError.get(i).getTelefCliente().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleComple);
						}
					} else if (j == 17) {
						// Correo
						cell.setCellValue(listVentaError.get(i).getMailCliente() == null ? "" : listVentaError.get(i).getMailCliente());
						if(listVentaError.get(i).getMailCliente() != null && listVentaError.get(i).getMailCliente().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							cell.setCellStyle(bodyStyleComple);
						}
					} else if (j == 18) {
						// TipoComprobanteRef
						cell.setCellValue(listVentaError.get(i).getIdTipoCompRef() == null ? "" : listVentaError.get(i).getIdTipoCompRef());
						cell.setCellStyle(bodyStyle);
					} else if (j == 19) {
						// FechaEmisionRef
						cell.setCellValue(listVentaError.get(i).getFechaEmisionRef() == null ? "" : listVentaError.get(i).getFechaEmisionRef());
						cell.setCellStyle(bodyStyle);
					} else if (j == 20) {
						// SerieComprobanteRef
						cell.setCellValue(listVentaError.get(i).getNumSerieRef() == null ? "" : listVentaError.get(i).getNumSerieRef().toString());
						cell.setCellStyle(bodyStyle);
					} else if (j == 21) {
						// CorrelativoSerieOrig
						cell.setCellValue(listVentaError.get(i).getNumCorRef() == null ? "" : listVentaError.get(i).getNumCorRef().toString());
						cell.setCellStyle(bodyStyle);
					} else if (j == 22) {
						// Concepto
						cell.setCellValue(listVentaError.get(i).getConcepto() == null ? "" : listVentaError.get(i).getConcepto());
						if(listVentaError.get(i).getConcepto() != null && listVentaError.get(i).getConcepto().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							if(listVentaError.get(i).getIdEmpresa().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
								cell.setCellStyle(bodyStyleReq);
							}else{
								cell.setCellStyle(bodyStyle);
							}
						}
					} else if (j == 23) {
						// ProductoSunat
						cell.setCellValue(listVentaError.get(i).getCodProdSunat() == null ? 0 : listVentaError.get(i).getCodProdSunat());
						cell.setCellStyle(bodyStyle);
					} else if (j == 24) {
						// NumeroPoliza
						cell.setCellValue(listVentaError.get(i).getNumPoliza() == null ? "" : listVentaError.get(i).getNumPoliza());
						if(listVentaError.get(i).getNumPoliza() != null && listVentaError.get(i).getNumPoliza().trim().length() > 0){
							cell.setCellStyle(bodyStyle);
						}else{
							if(listVentaError.get(i).getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
								cell.setCellStyle(bodyStyle);
							}else {
								cell.setCellStyle(bodyStyleReq);
							}
						}
					} else if (j == 25) {
						/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 16:19 - Se agrega el dato de error para AplicaDetracción y PorcDetracción*/
						// AplicaDetraccion
						cell.setCellValue(listVentaError.get(i).getAplicaDetraccion()== null ? "" : listVentaError.get(i).getAplicaDetraccion());
						cell.setCellStyle(bodyStyle);
					} else if (j == 26) {
						// PorcDetraccion
						cell.setCellValue(listVentaError.get(i).getPorcDetraccion() == null ? 0 : listVentaError.get(i).getPorcDetraccion().doubleValue());
						cell.setCellStyle(bodyStyle);
						/*TIP_PER0100_CC09_13 FIN*/
					} else if (j == 27) {
						// ValorFactExport
						cell.setCellValue(listVentaError.get(i).getValFactExport() == null ? 0 : listVentaError.get(i).getValFactExport().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 28) {
						// BaseImponible
						cell.setCellValue(listVentaError.get(i).getBaseImponible() == null ? 0 : listVentaError.get(i).getBaseImponible().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 29) {
						// ImporteExonerado
						cell.setCellValue(listVentaError.get(i).getImpExonerado() == null ? 0 : listVentaError.get(i).getImpExonerado().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 30) {
						// ImporteInafecto
						cell.setCellValue(listVentaError.get(i).getImpInafecto() == null ? 0 : listVentaError.get(i).getImpInafecto().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 31) {
						// ValorOpGratuitas
						cell.setCellValue(listVentaError.get(i).getValOpGratuitas() == null ? 0 : listVentaError.get(i).getValOpGratuitas().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 32) {
						// ISC
						cell.setCellValue(listVentaError.get(i).getIsc() == null ? 0 : listVentaError.get(i).getIsc().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 33) {
						// IGV
						cell.setCellValue(listVentaError.get(i).getIgv() == null ? 0 : listVentaError.get(i).getIgv().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 34) {
						// Otros Importes
						cell.setCellValue(listVentaError.get(i).getImpOtros() == null ? 0 : listVentaError.get(i).getImpOtros().doubleValue());
						cell.setCellStyle(bodyStyle);
					} else if (j == 35) {
						// Importe Total
						cell.setCellValue(listVentaError.get(i).getImpTotal() == null ? 0 : listVentaError.get(i).getImpTotal().doubleValue());
						cell.setCellStyle(bodyStyle);
//					} else if (j == 33) {
//						// TipoCambio
//						cell.setCellValue(listVentaError.get(i).getTipoCambio() == null ? 0 : listVentaError.get(i).getTipoCambio().doubleValue());
//						cell.setCellStyle(bodyStyle);
//					} else if (j == 34) {
//						// Estado
//						cell.setCellValue(listVentaError.get(i).getEstado() == null ? "" : listVentaError.get(i).getEstado());
//						cell.setCellStyle(bodyStyle);
					} else if (j == 36) {
						// OpenItem
						cell.setCellValue(listVentaError.get(i).getOpenItem() == null ? "" : listVentaError.get(i).getOpenItem());
						cell.setCellStyle(bodyStyle);
					} else if (j == 37) {
						// OpenItemRef
						cell.setCellValue(listVentaError.get(i).getOpenItemRef() == null ? "" : listVentaError.get(i).getOpenItemRef());
						cell.setCellStyle(bodyStyle);
					} else if (j == 38) {
						// Area
						cell.setCellValue(listVentaError.get(i).getArea() == null ? "" : listVentaError.get(i).getArea());
						cell.setCellStyle(bodyStyle);
					} else if (j == 39) {
						//Observaciones
						cell.setCellValue(listVentaError.get(i).getObservacion() == null ? "" : listVentaError.get(i).getObservacion());
						cell.setCellStyle(bodyStyle);
//					} else if (j == 39) {
//						// Monto USD
//						cell.setCellValue(listVentaError.get(i).getMontoUsd() == null ? 0 : listVentaError.get(i).getMontoUsd().doubleValue());
//						cell.setCellStyle(bodyStyle);
					} else if (j == 40) {
						// Colect_indiv
						cell.setCellValue(listVentaError.get(i).getColectIndiv() == null ? "" : listVentaError.get(i).getColectIndiv());
						cell.setCellStyle(bodyStyle);
					} else if (j == 41) {
						// Linea
						cell.setCellValue(listVentaError.get(i).getLinea() == null ? "" : listVentaError.get(i).getLinea());
						cell.setCellStyle(bodyStyle);
					} else if (j == 42) {
						// Periodo
						cell.setCellValue(listVentaError.get(i).getTipoAfectacion() == null ? "" : listVentaError.get(i).getTipoAfectacion());
						cell.setCellStyle(bodyStyle);
					} else if (j == 43) {
						/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 16:30 - Se agrega el dato de error para TituloAdicional y ValorAdicional*/
						// TituloAdicional
						cell.setCellValue(listVentaError.get(i).getTituloAdicional() == null ? "" : listVentaError.get(i).getTituloAdicional());
						cell.setCellStyle(bodyStyle);
					} else if (j == 44) {
						// ValorAdicional
						cell.setCellValue(listVentaError.get(i).getValorAdicional() == null ? "" : listVentaError.get(i).getValorAdicional());
						cell.setCellStyle(bodyStyle);
						/*TIP_PER0100_CC09_13 FIN*/
					}  else if (j == 45) {
						// Id Venta
						cell.setCellValue(listVentaError.get(i).getIdVenta());
						cell.setCellStyle(bodyStyle);
					}
				}
				setUbigeoDescACod(listVentaError.get(i));
			}
			
			setUbigeoCodADesc(listVentaError);
			
			String fileName = "RegistrosError_Ventas.xlsx";

			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			response.addHeader("Content-Disposition", "attachment; filename=" + fileName);
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			OutputStream out = response.getOutputStream();
			book.write(out);
			out.close();

			FacesContext.getCurrentInstance().responseComplete();
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		
	}
	
//	public void setUbigeoCodADesc(List<VentaCpeBean> listaVenta){
//		for(VentaCpeBean venta : listaVenta){
//			String departamentoRec = "";
//			String provinciaRec = "";
//			String distritoRec = "";
//			
//			if((venta.getDepartamento() != null && !venta.getDepartamento().equals("")) 
//					&& (venta.getProvincia() != null && !venta.getProvincia().equals(""))
//					&& (venta.getDistrito() != null && !venta.getDistrito().equals(""))){
//				
//				UbigeoCpeBean ubigeoDepRec = new UbigeoCpeBean();
//				ubigeoDepRec.setCodigoUbigeo(venta.getDepartamento());
//				List<UbigeoCpeBean> listDepRec = ubigeoCpeService.obtenerUbigeo(ubigeoDepRec);
//				
//				if(listDepRec != null && !listDepRec.isEmpty()){
//					departamentoRec = listDepRec.get(0).getNombreUbigeo();
//					
//					UbigeoCpeBean ubigeoProvRec = new UbigeoCpeBean();
//					ubigeoProvRec.setCodigoUbigeo(venta.getProvincia());
//					List<UbigeoCpeBean> listProvRec = ubigeoCpeService.obtenerUbigeo(ubigeoProvRec);
//					
//					if(listProvRec != null && !listProvRec.isEmpty()){
//						provinciaRec = listProvRec.get(0).getNombreUbigeo();
//						
//						UbigeoCpeBean ubigeoDistRec = new UbigeoCpeBean();
//						ubigeoDistRec.setCodigoUbigeo(venta.getDistrito());
//						List<UbigeoCpeBean> listDistRec = ubigeoCpeService.obtenerUbigeo(ubigeoDistRec);
//						
//						if(listDistRec != null && !listDistRec.isEmpty()){
//							distritoRec = listDistRec.get(0).getNombreUbigeo();
//						}else{
//							//departamentoRec = "";
//							//provinciaRec = "";
//							distritoRec = "";
//						}
//					}else{
//						//departamentoRec = "";
//						provinciaRec = "";
//						distritoRec = "";
//					}
//				}else{
//					departamentoRec = "";
//					provinciaRec = "";
//					distritoRec = "";
//				}
//			}else{
//				departamentoRec = "";
//				provinciaRec = "";
//				distritoRec = "";
//			}
//			
//			venta.setDepartamento(departamentoRec);
//			venta.setProvincia(provinciaRec);
//			venta.setDistrito(distritoRec);
//		}
//	}
	
	public void setUbigeoCodADesc(List<VentaCpeBean> listaVenta){
		
		//List<UbigeoCpeBean> listUbigeo = new ArrayList<UbigeoCpeBean>();
		//listUbigeo = ubigeoCpeService.listarUbigeo();
		
		for(VentaCpeBean venta : listaVenta){
			String departamentoRec = "";
			String provinciaRec = "";
			String distritoRec = "";
			
			if((venta.getDepartamento() != null && !venta.getDepartamento().equals("")) 
					&& (venta.getProvincia() != null && !venta.getProvincia().equals(""))
					&& (venta.getDistrito() != null && !venta.getDistrito().equals(""))){
				
				List<UbigeoCpeBean> listDepRec = new ArrayList<UbigeoCpeBean>();
				
				for(UbigeoCpeBean ubig : listUbigeo){
					if((ubig.getIdDepartamento() 
							+ ubig.getIdProvincia() 
							+ ubig.getIdDistrito()).equalsIgnoreCase(venta.getDepartamento())){
						listDepRec.add(ubig);
						break;
					}
				}

				if(listDepRec != null && !listDepRec.isEmpty()){
					departamentoRec = listDepRec.get(0).getNombreUbigeo();
					
					List<UbigeoCpeBean> listProvRec = new ArrayList<UbigeoCpeBean>();
					
					for(UbigeoCpeBean ubig : listUbigeo){
						if((ubig.getIdDepartamento() 
								+ ubig.getIdProvincia() 
								+ ubig.getIdDistrito()).equalsIgnoreCase(venta.getProvincia())){
							listProvRec.add(ubig);
							break;
						}
					}
					
					if(listProvRec != null && !listProvRec.isEmpty()){
						provinciaRec = listProvRec.get(0).getNombreUbigeo();
						
						List<UbigeoCpeBean> listDistRec = new ArrayList<UbigeoCpeBean>();
						
						for(UbigeoCpeBean ubig : listUbigeo){
							if((ubig.getIdDepartamento() 
									+ ubig.getIdProvincia() 
									+ ubig.getIdDistrito()).equalsIgnoreCase(venta.getDistrito())){
								listDistRec.add(ubig);
								break;
							}
						}
						
						if(listDistRec != null && !listDistRec.isEmpty()){
							distritoRec = listDistRec.get(0).getNombreUbigeo();
						}else{
							distritoRec = "";
						}
					}else{
						provinciaRec = "";
						distritoRec = "";
					}
				}else{
					departamentoRec = "";
					provinciaRec = "";
					distritoRec = "";
				}
			}else{
				departamentoRec = "";
				provinciaRec = "";
				distritoRec = "";
			}
			
			venta.setDepartamento(departamentoRec);
			venta.setProvincia(provinciaRec);
			venta.setDistrito(distritoRec);
		}
	}
	
	public void limpiarFiltrosProcesar(){
		inicializarFiltrosRegistrosProcesar();
		inicializarResultadosRegistrosProcesar();
		cargarCbxRegistrosProcesar();
	}
	
	public String goToNuevoComprobante(){
		
		inicializarVariablesComprobante();
		
		cargarCbxComprobante();
		
		action = "N";
		
		return "toNuevoComprobante";
	}
	
	public String goToPreviousPreProceso(){
		
		filtrarError();
		filtrarProcesar();
		/**TIP_PER0100_CC14 INICIO 2019/06/17 - 16:53 - Se llama al metodo limpiar limpiarCamposDetalleItem*/
		limpiarCamposDetalleItem();
		/**TIP_PER0100_CC14 INICIO */
		return "toPreProceso";
	}
	
	public String goToPreviousEmiProceso(){
		buscarProceso();
		return "toEmiProceso";
	}
	
	public String goToEditarComprobante(){
		
		inicializarVariablesComprobante();
		
		
		cargarCbxComprobante();
		action = "E";
		
		VentaCpeBean ventaCpeBean = (VentaCpeBean) FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaProcesar}", VentaCpeBean.class);
		
		idVentaEdicion = ventaCpeBean.getIdVenta();
		
		socioComprobanteSelected = ventaCpeBean.getIdSocio() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdSocio().toString();
		fechaRegistroComprobante = ventaCpeBean.getFechaEmision() == null ? null : ventaCpeBean.getFechaEmision().trim().length() == 0 ? null : getStringToDate(ventaCpeBean.getFechaEmision());
		productoComprobanteSelected = ventaCpeBean.getIdProducto() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdProducto().toString();
		estadoComprobanteSelected = ventaCpeBean.getEstado() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getEstado().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getEstado();
		fechaVencimientoComprobante = null;
		tipDocComprobanteSelected = ventaCpeBean.getIdTipoDocCli() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoDocCli().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoDocCli();
		tipCompComprobanteSelected = ventaCpeBean.getIdTipoComp() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoComp().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoComp();
		numDocComprobante = ventaCpeBean.getNumDocCli();
		monedaComprobanteSelected = ventaCpeBean.getTipoMoneda() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getTipoMoneda().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getTipoMoneda();
		empresaComprobanteSelected = ventaCpeBean.getIdEmpresa() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdEmpresa().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdEmpresa();
		clienteComprobante = ventaCpeBean.getNomCliRazSoc();
		telefonoComprobante = ventaCpeBean.getTelefCliente();
		direccionComprobante = ventaCpeBean.getDirCliente();
		correoComprobante = ventaCpeBean.getMailCliente();
		setUbigeoDescACod(ventaCpeBean);
		departamentoComprobante = ventaCpeBean.getDepartamento() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDepartamento().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDepartamento();
		obtenerProvinciaComprobante();
		provinciaComprobante = ventaCpeBean.getProvincia() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getProvincia().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getProvincia();
		obtenerDistritoComprobante();
		distritoComprobante = ventaCpeBean.getDistrito() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDistrito().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDistrito();
		codProdSunat = ventaCpeBean.getCodProdSunat() == null ? "" : ventaCpeBean.getCodProdSunat().toString();
		conceptoComprobante = ventaCpeBean.getConcepto();
		referenciaComprobanteSelected = (ventaCpeBean.getNumSerieRef() != null 
											|| ventaCpeBean.getNumCorRef() != null 
											|| ventaCpeBean.getIdTipoCompRef()!= null 
											|| ventaCpeBean.getFechaEmisionRef() != null) ? "1" : "0";
		numeroSerieComprobante = ventaCpeBean.getNumSerieRef() == null ? null : ventaCpeBean.getNumSerieRef().toString();
		numeroCorrelativoComprobante = ventaCpeBean.getNumCorRef() == null ? null : ventaCpeBean.getNumCorRef().toString();
		tipCompRefComprobanteSelected = ventaCpeBean.getIdTipoCompRef() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoCompRef().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoCompRef();
		fechaEmisionComprobante = ventaCpeBean.getFechaEmisionRef() == null ? null : ventaCpeBean.getFechaEmisionRef().trim().length() == 0 ? null : getStringToDate(ventaCpeBean.getFechaEmisionRef());
		valFactExportComprobante = ventaCpeBean.getValFactExport() == null ? null : ventaCpeBean.getValFactExport().toString();
		impInafectoComprobante = ventaCpeBean.getImpInafecto() == null ? null : ventaCpeBean.getImpInafecto().toString();
		iscComprobante = ventaCpeBean.getIsc() == null ? null : ventaCpeBean.getIsc().toString();
		otrosImportesComprobante = ventaCpeBean.getImpOtros() == null ? null : ventaCpeBean.getImpOtros().toString();
		baseImponibleComprobante = ventaCpeBean.getBaseImponible() == null ? null : ventaCpeBean.getBaseImponible().toString();
		impExoneradoComprobante = ventaCpeBean.getImpExonerado() == null ? null : ventaCpeBean.getImpExonerado().toString();
		igvComprobante = ventaCpeBean.getIgv() == null ? null : ventaCpeBean.getIgv().toString();
		importeTotalComprobante = ventaCpeBean.getImpTotal() == null ? null : ventaCpeBean.getImpTotal().toString();
		
		tipoProductoComprobante = ventaCpeBean.getTipoProducto() == null ? null : ventaCpeBean.getTipoProducto().trim(); 
		
		obtenerProductoComprobante();
		
		visualizarSeccionReferencia();
		
		numPolizaComprobante = ventaCpeBean.getNumPoliza();
		
		if(ventaCpeBean.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO))
		{
			disabledCodProdSunat = false;
		}
		else 
		{
			disabledCodProdSunat = true;
		}
		
		referenciaBoolean = true;
		
		return "toNuevoComprobante";
	}
	
	public String goToEditarComprobanteError(){
		
		inicializarVariablesComprobante();
		
		cargarCbxComprobante();
		
		action = "E";
		
		VentaCpeBean ventaCpeBean = (VentaCpeBean) FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaError}", VentaCpeBean.class);
		
		idVentaEdicion = ventaCpeBean.getIdVenta();
		
		socioComprobanteSelected = ventaCpeBean.getIdSocio() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdSocio().toString();
		fechaRegistroComprobante = ventaCpeBean.getFechaEmision() == null ? null : ventaCpeBean.getFechaEmision().trim().length() == 0 ? null : getStringToDate(ventaCpeBean.getFechaEmision());
		productoComprobanteSelected = ventaCpeBean.getIdProducto() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdProducto().toString();
		estadoComprobanteSelected = ventaCpeBean.getEstado() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getEstado().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getEstado();
		fechaVencimientoComprobante = null;
		tipDocComprobanteSelected = ventaCpeBean.getIdTipoDocCli() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoDocCli().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoDocCli();
		tipCompComprobanteSelected = ventaCpeBean.getIdTipoComp() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoComp().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoComp();
		numDocComprobante = ventaCpeBean.getNumDocCli();
		monedaComprobanteSelected = ventaCpeBean.getTipoMoneda() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getTipoMoneda().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getTipoMoneda();
		empresaComprobanteSelected = ventaCpeBean.getIdEmpresa() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdEmpresa().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdEmpresa();
		clienteComprobante = ventaCpeBean.getNomCliRazSoc();
		telefonoComprobante = ventaCpeBean.getTelefCliente();
		direccionComprobante = ventaCpeBean.getDirCliente();
		correoComprobante = ventaCpeBean.getMailCliente();
		setUbigeoDescACod(ventaCpeBean);
		departamentoComprobante = ventaCpeBean.getDepartamento() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDepartamento().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDepartamento();
		obtenerProvinciaComprobante();
		provinciaComprobante = ventaCpeBean.getProvincia() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getProvincia().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getProvincia();
		obtenerDistritoComprobante();
		distritoComprobante = ventaCpeBean.getDistrito() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDistrito().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDistrito();
		codProdSunat = ventaCpeBean.getCodProdSunat() == null ? "" : ventaCpeBean.getCodProdSunat().toString();
		conceptoComprobante = ventaCpeBean.getConcepto();
		referenciaComprobanteSelected = (ventaCpeBean.getNumSerieRef() != null 
											|| ventaCpeBean.getNumCorRef() != null 
											|| ventaCpeBean.getIdTipoCompRef()!= null 
											|| ventaCpeBean.getFechaEmisionRef() != null) ? "1" : "0";
		numeroSerieComprobante = ventaCpeBean.getNumSerieRef() == null ? null : ventaCpeBean.getNumSerieRef().toString();
		numeroCorrelativoComprobante = ventaCpeBean.getNumCorRef() == null ? null : ventaCpeBean.getNumCorRef().toString();
		tipCompRefComprobanteSelected = ventaCpeBean.getIdTipoCompRef() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoCompRef().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoCompRef();
		fechaEmisionComprobante = ventaCpeBean.getFechaEmisionRef() == null ? null : ventaCpeBean.getFechaEmisionRef().trim().length() == 0 ? null : getStringToDate(ventaCpeBean.getFechaEmisionRef());
		valFactExportComprobante = ventaCpeBean.getValFactExport() == null ? null : ventaCpeBean.getValFactExport().toString();
		impInafectoComprobante = ventaCpeBean.getImpInafecto() == null ? null : ventaCpeBean.getImpInafecto().toString();
		iscComprobante = ventaCpeBean.getIsc() == null ? null : ventaCpeBean.getIsc().toString();
		otrosImportesComprobante = ventaCpeBean.getImpOtros() == null ? null : ventaCpeBean.getImpOtros().toString();
		baseImponibleComprobante = ventaCpeBean.getBaseImponible() == null ? null : ventaCpeBean.getBaseImponible().toString();
		impExoneradoComprobante = ventaCpeBean.getImpExonerado() == null ? null : ventaCpeBean.getImpExonerado().toString();
		igvComprobante = ventaCpeBean.getIgv() == null ? null : ventaCpeBean.getIgv().toString();
		importeTotalComprobante = ventaCpeBean.getImpTotal() == null ? null : ventaCpeBean.getImpTotal().toString();
		
		tipoProductoComprobante = ventaCpeBean.getTipoProducto() == null ? null : ventaCpeBean.getTipoProducto().trim();
		
		obtenerProductoComprobante();
		
		visualizarSeccionReferencia();
		
		numPolizaComprobante = ventaCpeBean.getNumPoliza();
		
		if(ventaCpeBean.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO))
		{
			disabledCodProdSunat = false;
		}
		else 
		{
			disabledCodProdSunat = true;
		}
		
		return "toNuevoComprobante";
	}

	/**TIP_PER0100_CC14 INICIO 2019/06/14 - 11:04 - Se agrega el método goToEditarDetalle, adicionarDetalle*/
	public String goToEditarDetalleComprobante(){
		limpiarCamposDetalleItem();
		inicializarVariablesComprobante();
		
		cargarCbxComprobante();
		
		action = "E";
		
		VentaCpeBean ventaCpeBean = (VentaCpeBean) FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaProcesar}", VentaCpeBean.class);
		
		idVentaEdicion = ventaCpeBean.getIdVenta();
		
		socioComprobanteSelected = ventaCpeBean.getIdSocio() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdSocio().toString();
		fechaRegistroComprobante = ventaCpeBean.getFechaEmision() == null ? null : ventaCpeBean.getFechaEmision().trim().length() == 0 ? null : getStringToDate(ventaCpeBean.getFechaEmision());
		productoComprobanteSelected = ventaCpeBean.getIdProducto() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdProducto().toString();
		estadoComprobanteSelected = ventaCpeBean.getEstado() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getEstado().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getEstado();
		fechaVencimientoComprobante = null;
		tipDocComprobanteSelected = ventaCpeBean.getIdTipoDocCli() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoDocCli().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoDocCli();
		tipCompComprobanteSelected = ventaCpeBean.getIdTipoComp() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoComp().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdTipoComp();
		numDocComprobante = ventaCpeBean.getNumDocCli();
		monedaComprobanteSelected = ventaCpeBean.getTipoMoneda() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getTipoMoneda().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getTipoMoneda();
		empresaComprobanteSelected = ventaCpeBean.getIdEmpresa() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdEmpresa().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getIdEmpresa();
		clienteComprobante = ventaCpeBean.getNomCliRazSoc();
		telefonoComprobante = ventaCpeBean.getTelefCliente();
		direccionComprobante = ventaCpeBean.getDirCliente();
		correoComprobante = ventaCpeBean.getMailCliente();
		setUbigeoDescACod(ventaCpeBean);
		departamentoComprobante = ventaCpeBean.getDepartamento() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDepartamento().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDepartamento();
		obtenerProvinciaComprobante();
		provinciaComprobante = ventaCpeBean.getProvincia() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getProvincia().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getProvincia();
		obtenerDistritoComprobante();
		distritoComprobante = ventaCpeBean.getDistrito() == null ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDistrito().trim().length() == 0 ? Constantes.VALOR_DEFECTO_CBX : ventaCpeBean.getDistrito();
		codProdSunat = ventaCpeBean.getCodProdSunat() == null ? "" : ventaCpeBean.getCodProdSunat().toString();
		conceptoComprobante = ventaCpeBean.getConcepto();
		referenciaComprobanteSelected = (ventaCpeBean.getNumSerieRef() != null 
											|| ventaCpeBean.getNumCorRef() != null 
											|| ventaCpeBean.getIdTipoCompRef()!= null 
											|| ventaCpeBean.getFechaEmisionRef() != null) ? "1" : "0";
		valFactExportComprobante = ventaCpeBean.getValFactExport() == null ? null : ventaCpeBean.getValFactExport().toString();
		impInafectoComprobante = ventaCpeBean.getImpInafecto() == null ? null : ventaCpeBean.getImpInafecto().toString();
		iscComprobante = ventaCpeBean.getIsc() == null ? null : ventaCpeBean.getIsc().toString();
		otrosImportesComprobante = ventaCpeBean.getImpOtros() == null ? null : ventaCpeBean.getImpOtros().toString();
		baseImponibleComprobante = ventaCpeBean.getBaseImponible() == null ? null : ventaCpeBean.getBaseImponible().toString();
		impExoneradoComprobante = ventaCpeBean.getImpExonerado() == null ? null : ventaCpeBean.getImpExonerado().toString();
		igvComprobante = ventaCpeBean.getIgv() == null ? null : ventaCpeBean.getIgv().toString();
		importeTotalComprobante = ventaCpeBean.getImpTotal() == null ? null : ventaCpeBean.getImpTotal().toString();
		
		tipoProductoComprobante = ventaCpeBean.getTipoProducto() == null ? null : ventaCpeBean.getTipoProducto().trim(); 
		
		obtenerProductoComprobante();
		
		numPolizaComprobante = ventaCpeBean.getNumPoliza();
		
		valorVentaTotal = new BigDecimal(0);
		impValOpGratuitas = new BigDecimal(0);
		BigDecimal baseImponibleTemp;
		BigDecimal impInafectoComprobante;
		BigDecimal impExoneradoComprobanteTemp;
		
		baseImponibleTemp = ventaCpeBean.getBaseImponible() == null ? new BigDecimal(0) : ventaCpeBean.getBaseImponible();
		impInafectoComprobante = ventaCpeBean.getImpInafecto() == null ? new BigDecimal(0) : ventaCpeBean.getImpInafecto();
		impExoneradoComprobanteTemp = ventaCpeBean.getImpExonerado() == null ? new BigDecimal(0) : ventaCpeBean.getImpExonerado();
		impValOpGratuitas = ventaCpeBean.getValOpGratuitas() == null ? new BigDecimal(0) : ventaCpeBean.getValOpGratuitas();
		
		valorVentaTotal = baseImponibleTemp.add(impInafectoComprobante);
		valorVentaTotal = valorVentaTotal.add(impExoneradoComprobanteTemp);
		valorVentaTotal = valorVentaTotal.add(impValOpGratuitas);
		
		ventaAplicaIGV = true;
		if(ventaCpeBean.getValFactExport().compareTo(BigDecimal.ZERO) > 0
			|| ventaCpeBean.getImpExonerado().compareTo(BigDecimal.ZERO) > 0
			|| ventaCpeBean.getImpInafecto().compareTo(BigDecimal.ZERO) > 0
			|| ventaCpeBean.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
			ventaAplicaIGV = false;
		}
		
		CargaVentaItemCpeBean cargaVentaItemCpeBean = new CargaVentaItemCpeBean();
		cargaVentaItemCpeBean.setIdVenta(ventaCpeBean.getIdVenta());
		listDetalleItemComprobante = procesoCpeService.listarProcesoVentaDetalleItemCpeBean(cargaVentaItemCpeBean);
		
		
		return "toEditarDetalleComprobante";
	
	}

	public void adicionarDetalleItem(){
		
		if(conceptoItem==null || conceptoItem.trim().equals("")){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_CONCEPTO_ITEM_DETALLE_OBLIGATORIO);
			return;
		}
		
		if(cantidadItem<1){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_MINIMA_CANTIDAD_Y_SOLO_ENTEROS);
			return;
		}
		
		if(precioVentaItem ==null || precioVentaItem.compareTo(BigDecimal.ONE)<=0){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_VALOR_VENTA_DETALLE_NO_MENOR_IGUAL_A_CERO);
			return;
		}
		
		if(listDetalleItemComprobante==null){
			listDetalleItemComprobante = new ArrayList<CargaVentaItemCpeBean>();
		}
		
		BigDecimal valorTotalparcial = new BigDecimal(0);
		
		for(CargaVentaItemCpeBean item : listDetalleItemComprobante){
			valorTotalparcial = valorTotalparcial.add(item.getValorVenta());
		}
		valorTotalparcial = valorTotalparcial.add(precioVentaItem);
		
		if(valorVentaTotal.compareTo(valorTotalparcial)<0){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_SUMA_VALORES_PRECIO_VENTA_SUPERA_VALOR_VENTA_TOTAL);
			return;
		}
		
		CargaVentaItemCpeBean itemNuevo = new CargaVentaItemCpeBean();
		
		itemNuevo.setConcepto(conceptoItem);
		itemNuevo.setCantidad(cantidadItem);
		itemNuevo.setValorVenta(precioVentaItem);
		
		BigDecimal igv = new BigDecimal(0);
		try {
			ParametroCpeBean param = new ParametroCpeBean();
			param.setTipParam(Constantes.TIP_PARAM_DETALLE);
			param.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
			param.setCodValor(Constantes.COD_VALOR_GENERAL_IGV);
			igv = new BigDecimal(parametroCpeService.listarParametro(param).get(0).getNomValor());
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
	
		BigDecimal igvPrecioVenta = new BigDecimal(0);
		BigDecimal valorTotal = new BigDecimal(0);
		valorTotal = precioVentaItem;
		
		if(ventaAplicaIGV){
			igvPrecioVenta = precioVentaItem.multiply(igv).setScale(2, RoundingMode.HALF_UP);
			valorTotal = precioVentaItem.add(igvPrecioVenta);
		}
		
		itemNuevo.setIgv(igvPrecioVenta);
		itemNuevo.setValorTotal(valorTotal);
		itemNuevo.setIdVenta(idVentaEdicion);
		Long maxId = new Long(0);
		
		for(CargaVentaItemCpeBean itemD : listDetalleItemComprobante){
			if(itemD.getIdItemDetalleVenta()!=null){
				if(itemD.getIdItemDetalleVenta().compareTo(maxId)>0){
					maxId = new Long(itemD.getIdItemDetalleVenta().longValue());
				}
			}
		}
		maxId = maxId + new Long(1);
		itemNuevo.setIdItemDetalleVenta(maxId);
		itemNuevo.setEstadoMantenimiento("NUEVO");
		itemNuevo.setUsuarioCreacion(usuarioSesion);
		listDetalleItemComprobante.add(itemNuevo);
		limpiarCamposDetalleItem();

	}
	
	public void eliminarVentaDetalleItem(){
		
		CargaVentaItemCpeBean item = (CargaVentaItemCpeBean) FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_detalleItem}", CargaVentaItemCpeBean.class);
		
		for(int i=0; i <listDetalleItemComprobante.size();i++){
			if(String.valueOf(listDetalleItemComprobante.get(i).getIdItemDetalleVenta().intValue()).equals(String.valueOf(item.getIdItemDetalleVenta().intValue()))){
				listDetalleItemComprobante.remove(i);
				break;
			}
		}
	}

	public void limpiarCamposDetalleItem(){
		conceptoItem = null;
		cantidadItem = 0;
		precioVentaItem = null;
	}
	
	public void limpiarItemDetalleComprobante(){
		limpiarCamposDetalleItem();
		listDetalleItemComprobante=null;
	}

	public String guardarItemDetalleComprobante(){
		String resultado = null;
		boolean procesoExitoso = false;
		try{
			

			CargaVentaItemCpeBean cargaVentaItemCpeBean = new CargaVentaItemCpeBean();
			List<CargaVentaItemCpeBean> listaDetalleDB = new ArrayList<CargaVentaItemCpeBean>();
			
			cargaVentaItemCpeBean.setIdVenta(idVentaEdicion);
			listaDetalleDB = procesoCpeService.listarProcesoVentaDetalleItemCpeBean(cargaVentaItemCpeBean);
			
			if(listaDetalleDB!=null && listaDetalleDB.size()>0){
				if(listDetalleItemComprobante!=null && listDetalleItemComprobante.size()>0){
					
					BigDecimal valorTotalparcial = new BigDecimal(0);
					
					for(CargaVentaItemCpeBean item : listDetalleItemComprobante){
						valorTotalparcial = valorTotalparcial.add(item.getValorVenta());
					}
					
					if(valorVentaTotal.compareTo(valorTotalparcial)!=0){
						enviarMensaje(ErrorConstants.COD_ERROR_MSJ_SUMA_VALORES_PRECIO_VENTA_NO_COINCIDE_VALOR_VENTA_TOTAL);
						return resultado;
					}
					
					for(CargaVentaItemCpeBean itemBD : listaDetalleDB){
						boolean encontrado = false;
						for(CargaVentaItemCpeBean itemD : listDetalleItemComprobante){
							if(itemD.getEstadoMantenimiento()==null || !itemD.getEstadoMantenimiento().equals("NUEVO")){
								if(String.valueOf(itemBD.getIdItemDetalleVenta().longValue()).equals(String.valueOf(itemD.getIdItemDetalleVenta().longValue()))){
									encontrado = true;
								}
							}
						}
						if(!encontrado){
							procesoCpeService.eliminarProcesoVentaDetalleItemCpeBean(itemBD);
						}
					}
					
					for(CargaVentaItemCpeBean itemD : listDetalleItemComprobante){
						if(itemD.getEstadoMantenimiento()!=null && itemD.getEstadoMantenimiento().equals("NUEVO")){
							procesoCpeService.insertarProcesoVentaDetalleItemCpeBean(itemD);
						}
					}
					
					procesoExitoso = true;
				}else{
					
					for(CargaVentaItemCpeBean itemBD : listaDetalleDB){
						procesoCpeService.eliminarProcesoVentaDetalleItemCpeBean(itemBD);
					}
					procesoExitoso = true;
				}
			}else{
				if(listDetalleItemComprobante!=null && listDetalleItemComprobante.size()>0){
					
					BigDecimal valorTotalparcial = new BigDecimal(0);
					
					for(CargaVentaItemCpeBean item : listDetalleItemComprobante){
						valorTotalparcial = valorTotalparcial.add(item.getValorVenta());
					}
					
					if(valorVentaTotal.compareTo(valorTotalparcial)!=0){
						enviarMensaje(ErrorConstants.COD_ERROR_MSJ_SUMA_VALORES_PRECIO_VENTA_NO_COINCIDE_VALOR_VENTA_TOTAL);
						return resultado;
					}
					
					for(CargaVentaItemCpeBean itemD : listDetalleItemComprobante){
						if(itemD.getEstadoMantenimiento()!=null && itemD.getEstadoMantenimiento().equals("NUEVO")){
							procesoCpeService.insertarProcesoVentaDetalleItemCpeBean(itemD);
						}
					}
					
					procesoExitoso = true;
					
				}else{
					enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_SE_HAN_INGRESADO_ITEMS_ASOCIADOS_A_LA_VENTA);
					resultado = "toPreProceso";
				}
			}
			
			if(procesoExitoso){
				resultado = "toPreProceso";
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_PROCESO_DE_REGISTROS_ITEM_DE_DETALLE_DE_COMPROBANTE_EXITOSO);
			}
			
		}catch(Exception e){
			e.printStackTrace();
			logger.error(e.getMessage());
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_PROBLEMAS_AL_REGISTRAR_LOS_ITEM_DE_DETALLE_DE_COMPROBANTE);
		}
		
		return resultado;
	}
	
	/**TIP_PER0100_CC14 FIN*/
	public void calcularMontosNuevoComprobante(){
		
		if(empresaComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				socioComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				productoComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				tipCompComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX)){
			importeTotalComprobante = "";
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_FALTA_SELECCIONAR_EMPRESA_SOCIO_PRODUCTO_TIPOCOMP);
			return;
		}
		
		if(importeTotalComprobante.trim().length() > 0){
			ConfiguracionCpeBean conf = new ConfiguracionCpeBean();
			List<ConfiguracionCpeBean> listaConf = new ArrayList<ConfiguracionCpeBean>();
			conf.setIdEmpresa(empresaComprobanteSelected);
			conf.setIdSocio(Integer.parseInt(socioComprobanteSelected));
			conf.setIdProducto(Integer.parseInt(productoComprobanteSelected));
			conf.setIdTipoComp(tipCompComprobanteSelected);
			conf.setCodParam1(Constantes.COD_PARAM_CPE_EMPRESA);
			conf.setCodParam2(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
			conf.setCodParam3(Constantes.COD_PARAM_CPE_TIPO_PRODUCTO);
			conf.setEstadoConfig(Constantes.ACTIVO);
			listaConf = configuracionCpeService.listarConfiguracion(conf);
			
			if(!listaConf.isEmpty()){
				if(listaConf.get(0).getSerie() == null || listaConf.get(0).getSerie().trim().equals("")){
					importeTotalComprobante = "";
					enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_CONFIGURACION_SOCIO_PRODUCTO);
					return;
				}else{
					BigDecimal importeTotal = new BigDecimal(importeTotalComprobante);
					if(listaConf.get(0).getAfectoIgv() == 1){
						BigDecimal igv = new BigDecimal(0);
						try {
							ParametroCpeBean param = new ParametroCpeBean();
							param.setTipParam(Constantes.TIP_PARAM_DETALLE);
							param.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
							param.setCodValor(Constantes.COD_VALOR_GENERAL_IGV);
							igv = new BigDecimal(parametroCpeService.listarParametro(param).get(0).getNomValor());
							igv = igv.add(new BigDecimal(1));
						} catch (NumberFormatException e) {
							e.printStackTrace();
						}
						BigDecimal baseImponible = importeTotal.divide(igv, 2, RoundingMode.HALF_UP);
						BigDecimal igvVenta = importeTotal.subtract(baseImponible);
						
						baseImponibleComprobante = String.valueOf(baseImponible);
						igvComprobante = String.valueOf(igvVenta);
						impInafectoComprobante = "0";
					}else{
						baseImponibleComprobante = "0";
						igvComprobante = "0";
						impInafectoComprobante = String.valueOf(importeTotal);
					}
					
					
					valFactExportComprobante = "0";
					impExoneradoComprobante = "0";
					iscComprobante = "0";
					otrosImportesComprobante = "0";
					//ValOpGratuitas
					enviarMensaje(ErrorConstants.COD_ERROR_MSJ_MONTOS_VALIDADOS);
				}
			}else {
				importeTotalComprobante = "";
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_CONFIGURACION_SOCIO_PRODUCTO);
				return;
			}
		}else{
			importeTotalComprobante = "";
			valFactExportComprobante = "0";
			impInafectoComprobante = "0";
			iscComprobante = "0";
			otrosImportesComprobante = "0";
			baseImponibleComprobante = "0";
			impExoneradoComprobante = "0";
			igvComprobante = "0";
		}
	}
	
	private Date getStringToDate(String dateStr){
		Date date = null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	        date = formatter.parse(dateStr);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
        return date;
	}
	
	public void visualizarSeccionReferencia(){
		listarTipCompComprobante();
		if(action.equals("A")){
			onChangeCbxTipComp();
		}
		if(referenciaComprobanteSelected.equals("0")){
			referenciaBoolean = true;
		}else{
			referenciaBoolean = false;
		}
	}
	
	public void onChangeCbxTipComp(){
		if(tipDocComprobanteSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			tipCompComprobanteSelected = Constantes.VALOR_DEFECTO_CBX;
		}else if(tipDocComprobanteSelected.equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC)){
			tipCompComprobanteSelected = Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA;
		}else{
			tipCompComprobanteSelected = Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA;
		}
		actualizarImportes();
	}
	
	private boolean formatoCorrectoCorreo(String email){
        Pattern pattern = Pattern
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

        Matcher mather = pattern.matcher(email);

        if (mather.find() == true) {
            return true;
        } else {
            return false;
        }
	}
	
	public boolean esNumero(String cadena) {

        boolean esNumero;

        try {
            Long.parseLong(cadena);
            esNumero = true;
        } catch (NumberFormatException excepcion) {
        	esNumero = false;
        }

        return esNumero;
    }
	
	public void guardarComprobante(){
		
		if(socioComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 1
				tipCompComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				//fechaRegistroComprobante == null ||
				productoComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 2
				estadoBusquedaSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				//fechaVencimientoComprobante == null ||
				tipDocComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 3
				numDocComprobante.trim().length() == 0 ||
				monedaComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				empresaComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				clienteComprobante.trim().length() == 0 ||//linea 4
				//telefonoComprobante.trim().length() == 0 ||
				//direccionComprobante.trim().length() == 0 ||//linea 5
				//correoComprobante.trim().length() == 0 ||
				//departamentoComprobante.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 6
				//provinciaComprobante.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				//distritoComprobante.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				//conceptoComprobante.trim().length() == 0 ||//linea 7
				(empresaComprobanteSelected.equals(Constantes.COD_CARDIF_SERVICIOS) ? conceptoComprobante.trim().length() == 0 : false) ||
				valFactExportComprobante.trim().length() == 0 ||//Importes
				impInafectoComprobante.trim().length() == 0 ||
				iscComprobante.trim().length() == 0 ||
				otrosImportesComprobante.trim().length() == 0 ||
				baseImponibleComprobante.trim().length() == 0 ||
				impExoneradoComprobante.trim().length() == 0 ||
				igvComprobante.trim().length() == 0 ||
				importeTotalComprobante.trim().length() == 0 ||
				(empresaComprobanteSelected.equals(Constantes.COD_CARDIF_SEGUROS) ? numPolizaComprobante.trim().length() == 0 : false)
				){
			enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS);
			return;
		}
		
		if(!productoComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) )
		{
			if(codProdSunat.trim().length() == 0)
			{
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_PRODUCTO_SUNAT);
				return;	
			}
		}
		
		if(!tipDocComprobanteSelected.equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_CARNET_EXTRANJERIA)){
			if(!esNumero(numDocComprobante)){
				enviarMensaje(ErrorConstants.COD_ERROR_NUM_DOC_INCORRECTO);
				return;
			}
		}
		
		if(tipDocComprobanteSelected.equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DNI)){
			if(numDocComprobante.trim().length() != 8){
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_LONGITUD_INCORRECTA_NUM_DOC);
				return;
			}
		}else if(tipDocComprobanteSelected.equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC)) {
			if(numDocComprobante.trim().length() != 11){
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_LONGITUD_INCORRECTA_NUM_DOC);
				return;
			}
		}
		
		if(!formatoCorrectoCorreo(correoComprobante) && correoComprobante.trim().length() != 0){
			enviarMensaje(ErrorConstants.COD_ERROR_FORMATO_CORREO_INCORRECTO);
			return;
		}
		
		if(referenciaComprobanteSelected.equals(Constantes.ACTIVO)){
			if(numeroSerieComprobante.trim().length() == 0 ||
					numeroCorrelativoComprobante.trim().length() == 0 ||
					tipCompRefComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
					fechaEmisionComprobante == null){
				enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS);
				return;
			}
		}
		
		CargaVentaCabCpeBean cabBean = new CargaVentaCabCpeBean();
		CargaVentaCabCpeBean ventacab = new CargaVentaCabCpeBean();
		cabBean.setFechaCarga(new Date());
		cabBean.setIdOrigen(Constantes.COD_ORIGEN_MANUAL);
		List<CargaVentaCabCpeBean> listCab = CargaVentaCabCpeService.listarCargaVentaCab(cabBean);
		
 		if (listCab.size() == 0)
		{
			ventacab.setIdOrigen(Constantes.COD_ORIGEN_MANUAL);
			ventacab.setIdTipoCarga(Constantes.ID_TIPO_CARGA_ONLINE);
			ventacab.setNomArchivo("Ingreso Manual");
			ventacab.setNumRegistro(Long.parseLong("0"));
			ventacab.setEstadoCarga("2");
			ventacab.setUsuarioCarga(usuarioSesion);
			ventacab.setPesoArchivo("");
			
			CargaVentaCabCpeService.insertarCargaVentaCab(ventacab);
			existe_cab = false;
		}
		else 
		{
			existe_cab = true;
		}
		
		VentaCpeBean venta = new VentaCpeBean();
		if (existe_cab)
		{
			//venta.setIdCarga(Long.parseLong(Constantes.ID_CARGA_COMPROBANTES_MANUAL));
			venta.setIdCarga(listCab.get(0).getIdCarga());
		}else {
			venta.setIdCarga(ventacab.getIdCarga());
		}
		venta.setIdTramaUpload(null);
		venta.setLlaveUpload(null);
		venta.setLlavePims(null);
		venta.setIdEmpresa(empresaComprobanteSelected);
		venta.setIdSocio(Long.parseLong(socioComprobanteSelected));
		venta.setNomSocio(getLabelItems(socioComprobanteItems, socioComprobanteSelected));
		venta.setIdProducto(Long.parseLong(productoComprobanteSelected));
		venta.setNomProducto(getLabelItems(productoComprobanteItems, productoComprobanteSelected));
		venta.setFechaEmision(getDateToString(fechaRegistroComprobante));
		venta.setIdTipoComp(tipCompComprobanteSelected);
		venta.setConcepNd(null);
		venta.setTipoMoneda(monedaComprobanteSelected);
		venta.setFechaVenc(null);
		venta.setIdTipoDocCli(tipDocComprobanteSelected);
		venta.setNumDocCli(numDocComprobante.trim());
		venta.setNomCliRazSoc(clienteComprobante.trim());
		venta.setDirCliente(direccionComprobante.trim());
		venta.setDepartamento(departamentoComprobante.equals(Constantes.VALOR_DEFECTO_CBX) ? null :departamentoComprobante);
		venta.setProvincia(provinciaComprobante.equals(Constantes.VALOR_DEFECTO_CBX) ? null :provinciaComprobante);
		venta.setDistrito(distritoComprobante.equals(Constantes.VALOR_DEFECTO_CBX) ? null :distritoComprobante);
		venta.setTelefCliente(telefonoComprobante);
		venta.setMailCliente(correoComprobante.trim());
		venta.setIdTipoCompRef(tipCompRefComprobanteSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipCompRefComprobanteSelected);
		venta.setNumSerieRef(numeroSerieComprobante == null ? null : numeroSerieComprobante.trim().length() == 0 ? null : Long.parseLong(numeroSerieComprobante.trim()));
		venta.setNumCorRef(numeroCorrelativoComprobante == null ? null : numeroCorrelativoComprobante.trim().length() == 0 ? null : Long.parseLong(numeroCorrelativoComprobante.trim()));
		venta.setFechaEmisionRef(getDateToString(fechaEmisionComprobante));
		venta.setConcepto(conceptoComprobante.trim());
		venta.setCodProdSunat(Long.parseLong(codProdSunat.trim().toString()));
		venta.setNumPoliza(numPolizaComprobante.trim());
		venta.setFechaVenta(null);
		venta.setValFactExport(new BigDecimal(valFactExportComprobante));
		venta.setBaseImponible(new BigDecimal(baseImponibleComprobante));
		venta.setImpExonerado(new BigDecimal(impExoneradoComprobante));
		venta.setImpInafecto(new BigDecimal(impInafectoComprobante));
		venta.setValOpGratuitas(BigDecimal.ZERO);//Cero
		venta.setIsc(new BigDecimal(iscComprobante));
		venta.setIgv(new BigDecimal(igvComprobante));
		venta.setImpOtros(new BigDecimal(otrosImportesComprobante));
		venta.setImpTotal(new BigDecimal(importeTotalComprobante));
		venta.setTipoCambio(null);
		venta.setEstado(estadoComprobanteSelected);//Referencial
		venta.setOpenItem(null);
		venta.setOpenItemRef(null);
		venta.setArea(null);
		venta.setObservacion(null);
		venta.setMontoUsd(null);
		venta.setColectIndiv(getProductoPorIdSocioProducto(Integer.parseInt(productoComprobanteSelected.toString()), 
							Integer.parseInt(socioComprobanteSelected.toString())).getTipoProducto());
		venta.setLinea(null);
		venta.setPeriodo(getPeriodoActual());
		venta.setFlgPims("0");
		venta.setFlgUpload("0");
		venta.setFlgRv("0");
		venta.setFlgDetraccion("0");
		venta.setFlgCompletado(Constantes.FLG_COMPLETADO_SI);
		venta.setIdPle(Long.parseLong("0"));//Cero
		
		procesoCpeService.guardarVentaCpe(venta);
		
		VentaEstadoCpeBean ventaEstadoCpeBean = new VentaEstadoCpeBean();
		ventaEstadoCpeBean.setIdVenta(venta.getIdVenta());
		ventaEstadoCpeBean.setEstadoVenta(estadoComprobanteSelected);
		ventaEstadoCpeBean.setUsuarioCreacion(usuarioSesion);
		
		procesoCpeService.guardarVentaEstadoCpe(ventaEstadoCpeBean);
		
		ProcesoVentaCpeBean procesoVentaCpeBean = new ProcesoVentaCpeBean();
		procesoVentaCpeBean.setIdProceso(proceso.getIdProceso());
		procesoVentaCpeBean.setIdVenta(venta.getIdVenta());
		procesoVentaCpeBean.setEstado(Constantes.ACTIVO);
		
		procesoCpeService.guardarProcesoVentaCpe(procesoVentaCpeBean);
		
		ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
		procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
		procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
		procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
		
		procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
		
		flagComprobanteCorrecto = true;
		//limpiarComprobante();
	}
	
	public void limpiarComprobante(){
		if(action.equals("E")){
			clienteComprobante = "";
			direccionComprobante = "";
			departamentoComprobante = Constantes.VALOR_DEFECTO_CBX;
			provinciaComprobante = Constantes.VALOR_DEFECTO_CBX;
			distritoComprobante = Constantes.VALOR_DEFECTO_CBX;
			fechaVencimientoComprobante = null;
		}else{
			inicializarVariablesComprobante();
			cargarCbxComprobante();
		}
	}
	
	public void limpiarBusquedaBusVenta(){
		inicializarLimpiarBusquedaBusVenta();
		cargarCbxBusquedaVenta();
	}
	
	public void limpiarTodoBusVenta(){
		inicializarLimpiarTodoBusVent();
		cargarCbxBusquedaVenta();
	}
	
	private String getLabelItems(List<SelectItem> listSelectItem, String value){
		String label = null;
		
		try {
			for(SelectItem item : listSelectItem){
				if(item.getValue().toString().equals(value)){
					label = item.getLabel().toString();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return label;
		
	}
	
	private String getDateToString(Date date){
		String strDate = "";
		
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		
		strDate = date == null ? null : dateFormat.format(date);
		
		return strDate;
	}
	
	private String getPeriodoActual(){
		String periodo = "";
		DateFormat dateFormat = new SimpleDateFormat("MMyyyy");
		
		periodo = dateFormat.format(new Date());
		
		return periodo;
	}
	
	private ProductoCpeBean getProductoPorIdSocioProducto(Integer idProducto, Integer idSocio){
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		productoCpeBean.setIdSocio(idSocio);
		productoCpeBean.setIdProducto(idProducto);
		
		List<ProductoCpeBean> listProducto = productoCpeService.listarProducto(productoCpeBean);
		
		return listProducto.get(0);
	}
	
	public void actionForm(){
		flagComprobanteCorrecto = false;
		
		if(action.equals("N")){
			guardarComprobante();
		}else{
			editarComprobante();
		}
	}
	
	private void editarComprobante(){
		
		if(/*socioComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 1*/
				tipCompComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				/*fechaRegistroComprobante == null ||
				productoComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 2
				estadoBusquedaSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) || */
				//fechaVencimientoComprobante == null ||
				/*tipDocComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 3
				monedaComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				empresaComprobanteSelected.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||*/
				numDocComprobante.trim().length() == 0 ||
				clienteComprobante.trim().length() == 0 ||//linea 4
				/*telefonoComprobante.trim().length() == 0 ||*/
				//direccionComprobante.trim().length() == 0 ||//linea 5
				/*correoComprobante.trim().length() == 0 ||*/
				//departamentoComprobante.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||//linea 6
				//provinciaComprobante.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				//distritoComprobante.trim().equals(Constantes.VALOR_DEFECTO_CBX) ||
				/*conceptoComprobante.trim().length() == 0 ||//linea 7
				valFactExportComprobante.trim().length() == 0 ||//Importes
				impInafectoComprobante.trim().length() == 0 ||
				iscComprobante.trim().length() == 0 ||
				otrosImportesComprobante.trim().length() == 0 ||
				baseImponibleComprobante.trim().length() == 0 ||
				impExoneradoComprobante.trim().length() == 0 ||
				igvComprobante.trim().length() == 0 ||
				importeTotalComprobante.trim().length() == 0*/
				(empresaComprobanteSelected.equals(Constantes.COD_CARDIF_SEGUROS) && !tipoProductoComprobante.equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO) ? numPolizaComprobante.trim().length() == 0 : false)
				){
			enviarMensaje(ErrorConstants.COD_ERROR_MANT_SOCIO_PRODUCTO_CAMPOS_OBLIGATORIOS);
			return;
		}
		
		ProcesoVentaCpeBean procesoVentaCpeBean = new ProcesoVentaCpeBean();
		procesoVentaCpeBean.setIdProceso(proceso.getIdProceso());
		procesoVentaCpeBean.setIdVenta(idVentaEdicion);
		procesoVentaCpeBean.setEstado(Constantes.ACTIVO);
		
		List<ProcesoVentaCpeBean> listProcesoVenta = procesoCpeService.listarProcesoVentaCpeBean(procesoVentaCpeBean);
		Long idProcesoVenta = listProcesoVenta.get(0).getIdVentaProceso();
		
		UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
		updateVentaCpeBean.setIdVentaProceso(idProcesoVenta);
		
		List<UpdateVentaCpeBean> listUpdateVenta = procesoCpeService.listarUpdateVentaCpe(updateVentaCpeBean);
		
		UpdateVentaCpeBean updateVenta = new UpdateVentaCpeBean();
		updateVenta.setIdVentaProceso(idProcesoVenta);
		updateVenta.setFechaVencimiento(null);
		updateVenta.setRazSocCli(clienteComprobante.trim());
		updateVenta.setDirCli(direccionComprobante.trim());
		updateVenta.setDepartamento(departamentoComprobante);
		updateVenta.setProvincia(provinciaComprobante);
		updateVenta.setDistrito(distritoComprobante);
		
		
		if(listUpdateVenta == null || listUpdateVenta.isEmpty()){
			//Insertar
			updateVenta.setUsuarioCreacion(usuarioSesion);
			procesoCpeService.guardarUpdateVenta(updateVenta);
		}else{
			//Update
			updateVenta.setUsuarioModificacion(usuarioSesion);
			procesoCpeService.actualizarUpdateVenta(updateVenta);
		}
		
		ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
		procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
		procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
		procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
		
		procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
		
		VentaCpeBean vnt = new VentaCpeBean();
		vnt.setIdVenta(idVentaEdicion);
		vnt.setNumDocCli(numDocComprobante);
		vnt.setNumPoliza(numPolizaComprobante);
		procesoCpeService.actualizarNumDocCliVenta(vnt);
		
		flagComprobanteCorrecto = true;
		//limpiarComprobante();
	}
	
	public String goToBusquedaVentas(){
		
		inicializarFiltrosBusquedaVenta();
		cargarCbxBusquedaVenta();
		
		return "toBusquedaVentas";
	}
	
	public void obtenerProductoBusquedaVenta(){
		if(!socioBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX)){
			listarProductoBusquedaVenta();
		}else{
			productoBusquedaItems = new ArrayList<SelectItem>();
			productoBusquedaSelected = Constantes.VALOR_DEFECTO_CBX;
		}
	}
	
	public void onChangeOrigenCbx(){
		if(origenBusquedaSelected.equals(Constantes.COD_ORIGEN_UPLOAD)){
			disabledUpload = false;
			disabledUploadSelected = true;
		}else{
			disabledUpload = true;
			disabledUploadSelected = false;
		}
		
		if(origenBusquedaSelected.equals(Constantes.COD_ORIGEN_PIMS) || origenBusquedaSelected.equals("9") ){
			tipBusqueda = "1";
			bloqAgrup = true;
		}else if(origenBusquedaSelected.equals(Constantes.COD_ORIGEN_UPLOAD)){
			bloqAgrup = true;
			tipBusqueda = "0";
		}else{
			bloqAgrup = false;
		}
		
		onChangeTipoBusqueda();
	}
	
	public void onChangeTipoBusqueda(){
		if(tipBusqueda.equals("0")){
			agrupado = true;
			detallado = false;
		}else if(tipBusqueda.equals("1")){
			detallado = true;
			agrupado = false;
		}
	}
	
	public void buscarVentasOrigenes(){
		
		if (fechaDesdeBusqueda == null && fechaHastaBusqueda == null){
			enviarMensaje(ErrorConstants.COD_ERROR_FEC_NO_INGRESADA);
			return;
		}
		
		if (fechaDesdeBusqueda != null && fechaHastaBusqueda != null && fechaDesdeBusqueda.after(fechaHastaBusqueda)){
			enviarMensaje(ErrorConstants.COD_ERROR_RANGO_FECHAS);
			return;
		}
		if (fechaDesdeBusqueda != null && fechaHastaBusqueda == null){
			enviarMensaje(ErrorConstants.COD_ERROR_FECHA_HASTA);
			return;
		}
		if (fechaDesdeBusqueda == null && fechaHastaBusqueda != null){
			enviarMensaje(ErrorConstants.COD_ERROR_FECHA_DESDE);
			return;
		}
		
		listDetallada = new ArrayList<VentaCpeBean>();
		listAgrupada = new ArrayList<CargaVentaCabCpeBean>();
		
		VentaCpeBean ventaCpeBean = new VentaCpeBean();
		ventaCpeBean.setIdSocio(socioBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.parseLong(socioBusquedaSelected));
		ventaCpeBean.setIdProducto(productoBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.parseLong(productoBusquedaSelected));
		ventaCpeBean.setNomCliRazSoc(clienteBusqueda == null ? null : clienteBusqueda.trim().length() == 0 ? null : "%" + clienteBusqueda + "%");
		ventaCpeBean.setIdTipoDocCli(tipDocBusqueda.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipDocBusqueda);
		ventaCpeBean.setFechaDesde(fechaDesdeBusqueda);
		ventaCpeBean.setFechaHasta(sumarDia(fechaHastaBusqueda));
		ventaCpeBean.setOrigen(origenBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : origenBusquedaSelected);
		ventaCpeBean.setNumDocCli(numDocBusqueda == null ? null : numDocBusqueda.trim().length() == 0 ? null : numDocBusqueda);
		ventaCpeBean.setTipoMoneda(monedaBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : monedaBusquedaSelected);
		ventaCpeBean.setEstadoVenta(estadoBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : estadoBusquedaSelected);
		ventaCpeBean.setNumPoliza(certificadoBusqueda == null ? null : certificadoBusqueda.trim().length() == 0 ? null : certificadoBusqueda);
		ventaCpeBean.setIdTipoComp(tipCompBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipCompBusquedaSelected);
		ventaCpeBean.setNumeroComprobante(numCompBusqueda == null ? null : numCompBusqueda.trim().length() == 0 ? null : Long.parseLong(numCompBusqueda));
		ventaCpeBean.setIdTramaUpload(codUploadBusqueda == null ? null : codUploadBusqueda.trim().length() == 0 ? null : Long.valueOf(codUploadBusqueda));
		
		ventaCpeBean.setParamEmpresa(Constantes.COD_PARAM_CPE_EMPRESA);
		ventaCpeBean.setParamTipParam(Constantes.TIP_PARAM_DETALLE);
		ventaCpeBean.setParamMoneda(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		ventaCpeBean.setParamEstadoVenta(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		ventaCpeBean.setParamTipDoc(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
		
		if(detallado){
			
			listDetallada = procesoCpeService.buscarVentaDetalladoCpe(ventaCpeBean);
			
			List<VentaCpeBean> listRemove = new ArrayList<VentaCpeBean>();
			
			for(VentaCpeBean proc : listRegProcesar){
				for(VentaCpeBean venta : listDetallada){
					if(venta.getIdVenta().equals(proc.getIdVenta())){
						listRemove.add(proc);
					}
				}
			}
			
			for(VentaCpeBean bean : listRemove){
				for(int i = 0 ; i<listDetallada.size(); i++){
					if(listDetallada.get(i).getIdVenta().equals(bean.getIdVenta())){
						listDetallada.remove(i);
						break;
					}
				}
			}
			
			nroRegistrosDetallado = listDetallada.size();
			
			listAgrupada = new ArrayList<CargaVentaCabCpeBean>();
			nroRegistrosAgrupado = 0;
			
		}else if(agrupado){
			
			if(!origenBusquedaSelected.equals(Constantes.COD_ORIGEN_UPLOAD)){
				List<VentaCpeBean> listDet = procesoCpeService.buscarVentaDetalladoCpe(ventaCpeBean);
				for(Long idCarga : getIdCargaArray(listDet)){
					CargaVentaCabCpeBean cabBean = new CargaVentaCabCpeBean();
					cabBean.setIdCarga(idCarga);
					List<CargaVentaCabCpeBean> listCab = procesoCpeService.listarCargaVentaCab(cabBean);
					CargaVentaCabCpeBean cab = listCab.get(0);
					insertIntoListCabVenta(listDet, cab);
					cab.setNumRegistro(Long.parseLong(String.valueOf(cab.getListDet().size())));
					listAgrupada.add(cab);
				}
				
				List<VentaCpeBean> listRemove = new ArrayList<VentaCpeBean>();
				
				for(VentaCpeBean proc : listRegProcesar){
					for(CargaVentaCabCpeBean cab : listAgrupada){
						for(VentaCpeBean venta : cab.getListDet()){
							if(venta.getIdVenta().equals(proc.getIdVenta())){
								listRemove.add(proc);
							}
						}
					}
				}
				
				for(VentaCpeBean bean : listRemove){
					for(CargaVentaCabCpeBean cab : listAgrupada){
						for(int i = 0 ; i<cab.getListDet().size(); i++){
							if(cab.getListDet().get(i).getIdVenta().equals(bean.getIdVenta())){
								cab.getListDet().remove(i);
								break;
							}
						}
					}
				}
				
				for(CargaVentaCabCpeBean cab : listAgrupada){
					cab.setNumRegistro(Long.parseLong(String.valueOf(cab.getListDet().size())));
				}
				
				eliminarRegListaVacia(listAgrupada);
				
				List<CargaVentaCabCpeBean> listCarga = new ArrayList<CargaVentaCabCpeBean>(); 
				
				for(CargaVentaCabCpeBean carga : listAgrupada){
					if(carga.getIdOrigen().equals(Constantes.COD_ORIGEN_UPLOAD)){
						listCarga.add(carga);
					}
				}
				
				for(CargaVentaCabCpeBean temp : listCarga){
					listAgrupada.remove(temp);
				}
				
				agruparNombreTrama(listCarga);
			}else{
				listAgrupada = new ArrayList<CargaVentaCabCpeBean>();
				listAgrupada = procesoCpeService.listarAgrupadoUpload(ventaCpeBean);

				for(CargaVentaCabCpeBean crg : listAgrupada){
					crg.setListDet(new ArrayList<VentaCpeBean>());
				}
			}
			
			nroRegistrosAgrupado = listAgrupada.size();
			
			listDetallada = new ArrayList<VentaCpeBean>();
			nroRegistrosDetallado = 0;
			
		}
	}
	
	private void agruparNombreTrama(List<CargaVentaCabCpeBean> listCarga){
		List<CargaVentaCabCpeBean> listCabNuevo = new ArrayList<CargaVentaCabCpeBean>();
		
		for(CargaVentaCabCpeBean bean : listCarga){
			for(VentaCpeBean venta : bean.getListDet()){
				boolean existe = false;
				
				for(CargaVentaCabCpeBean cab : listCabNuevo){
					
					if(venta.getNombreTramaUpload() == null){
						venta.setNombreTramaUpload("");
					}
					
					if(venta.getNombreTramaUpload().equals(cab.getNomArchivo())){
						cab.getListDet().add(venta);
						existe = true;
						break;
					}
				}
				
				if(!existe){
					CargaVentaCabCpeBean cabBean = new CargaVentaCabCpeBean();
					cabBean.setIdCarga(venta.getIdCarga());
					List<CargaVentaCabCpeBean> listCab = procesoCpeService.listarCargaVentaCab(cabBean);
					CargaVentaCabCpeBean cabe = listCab.get(0);
					cabe.setNomArchivo(venta.getNombreTramaUpload());
					cabe.setListDet(new ArrayList<VentaCpeBean>());
					cabe.getListDet().add(venta);
					listCabNuevo.add(cabe);
				}
			}
		}
		
		
		for(CargaVentaCabCpeBean temp : listCabNuevo){
			temp.setNumRegistro(Long.parseLong(String.valueOf(temp.getListDet().size())));
		}
		
		listAgrupada.addAll(listCabNuevo);
	}
	
	private List<Long> getIdCargaArray(List<VentaCpeBean> listDet){
		List<Long> cargaArray = new ArrayList<Long>();
		for(VentaCpeBean det : listDet){
			boolean indInsertar = true;
			for(Long idCarga : cargaArray){
				if(det.getIdCarga().equals(idCarga)){
					indInsertar = false;
					break;
				}
			}
			
			if(indInsertar){
				cargaArray.add(det.getIdCarga());
			}
		}
		
		return cargaArray;
	}
	
	private void insertIntoListCabVenta(List<VentaCpeBean> listDet, CargaVentaCabCpeBean cab){
		cab.setListDet(new ArrayList<VentaCpeBean>());
		for(VentaCpeBean venta : listDet){
			if(venta.getIdCarga().equals(cab.getIdCarga())){
				cab.getListDet().add(venta);
			}
		}
	}
	
	public void onChangeSelectedDet(){
		if(allSelectedDet){
			for(VentaCpeBean bean : listDetallada){
				bean.setSeleccionado(true);
			}
		}else{
			for(VentaCpeBean bean : listDetallada){
				bean.setSeleccionado(false);
			}
		}
	}
	
	public void onChangeSelectedAgrup(){
		if(allSelectedAgrup){
			for(CargaVentaCabCpeBean bean : listAgrupada){
				bean.setSeleccionado(true);
			}
		}else{
			for(CargaVentaCabCpeBean bean : listAgrupada){
				bean.setSeleccionado(false);
			}
		}
	}
	
	public void onChangeSelectedRegProc(){
		if(allSelectedRegProc){
			for(VentaCpeBean bean : listRegProcesar){
				bean.setSeleccionado(true);
			}
		}else{
			for(VentaCpeBean bean : listRegProcesar){
				bean.setSeleccionado(false);
			}
		}
	}
	
	public void agregarDetToProcesar(){
		boolean regSeleccionados = false;
		for(VentaCpeBean bean : listDetallada){
			if(bean.isSeleccionado()){
				listRegProcesar.add(bean);
				regSeleccionados = true;
			}
		}
		if(regSeleccionados){
			for(VentaCpeBean bean : listRegProcesar){
				listDetallada.remove(bean);
			}
			nroRegistrosDetallado = listDetallada.size();
			nroRegistrosBusVenProcesar = listRegProcesar.size();
		}else{
			enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
		}
		allSelectedDet = false;
	}
	
	public void agregarAgrupToProcesar(){
		boolean regSeleccionados = false;
		
		for(CargaVentaCabCpeBean cab : listAgrupada){
			if(cab.isSeleccionado()){
				
				if(origenBusquedaSelected.equals(Constantes.COD_ORIGEN_UPLOAD)){
					VentaCpeBean ventaRequest = new VentaCpeBean();
					ventaRequest.setIdCarga(cab.getIdCarga());
					ventaRequest.setIdTramaUpload(cab.getIdTramaUpload());
					ventaRequest.setIdSocio(socioBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.parseLong(socioBusquedaSelected));
					ventaRequest.setIdProducto(productoBusquedaSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.parseLong(productoBusquedaSelected));
					ventaRequest.setParamEmpresa(Constantes.COD_PARAM_CPE_EMPRESA);
					ventaRequest.setParamTipParam(Constantes.TIP_PARAM_DETALLE);
					ventaRequest.setParamMoneda(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
					ventaRequest.setParamEstadoVenta(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
					ventaRequest.setParamTipDoc(Constantes.COD_PARAM_CPE_TIPO_DOCUMENTO);
					
					List<VentaCpeBean> listDet = procesoCpeService.buscarVentaDetalladoCpe(ventaRequest);
					cab.setListDet(new ArrayList<VentaCpeBean>());
					cab.setListDet(listDet);
				}
				
				for(VentaCpeBean det : cab.getListDet()){
					det.setSeleccionado(true);
					listRegProcesar.add(det);
					regSeleccionados = true;
				}
			}
		}
		
		if(regSeleccionados){
			if(!origenBusquedaSelected.equals(Constantes.COD_ORIGEN_UPLOAD)){
				for(VentaCpeBean bean : listRegProcesar){
					for(CargaVentaCabCpeBean cab : listAgrupada){
						cab.getListDet().remove(bean);
						cab.setNumRegistro(Long.parseLong(String.valueOf(cab.getListDet().size())));
					}
				}
				eliminarRegListaVacia(listAgrupada);
			}else{
				eliminarRegListaVaciaUpload(listAgrupada);
			}
			
			nroRegistrosAgrupado = listAgrupada.size();
			nroRegistrosBusVenProcesar = listRegProcesar.size();
			allSelectedRegProc = true;
		}else{
			enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
		}
		
		allSelectedAgrup = false;
	}
	
	private void eliminarRegListaVaciaUpload(List<CargaVentaCabCpeBean> listCab){
		List<CargaVentaCabCpeBean> listRemove = new ArrayList<CargaVentaCabCpeBean>();
		
		for(CargaVentaCabCpeBean cab : listCab){
			if(cab.isSeleccionado()){
				listRemove.add(cab);
			}
		}
		
		for(CargaVentaCabCpeBean bean : listRemove){
			listCab.remove(bean);
		}
	}
	
	private void eliminarRegListaVacia(List<CargaVentaCabCpeBean> listCab){
		List<CargaVentaCabCpeBean> listRemove = new ArrayList<CargaVentaCabCpeBean>();
		
		for(CargaVentaCabCpeBean cab : listCab){
			if(cab.getListDet().size() == 0){
				listRemove.add(cab);
			}
		}
		
		for(CargaVentaCabCpeBean bean : listRemove){
			listCab.remove(bean);
		}
	}
	
	public String guardarVentasProcesoVenta(){
		try{		
		
			boolean regSeleccionado = false;
			List<VentaCpeBean> listVenta = new ArrayList<VentaCpeBean>();
			for(VentaCpeBean det : listRegProcesar){
				if(det.isSeleccionado()){
					regSeleccionado = true;
					det.setIdProceso(proceso.getIdProceso());
					listVenta.add(det);
				}
			}
			
			if (listVenta.size()>0){
				
				insertProcesoVentaPLSQL(listVenta, Integer.parseInt(Constantes.ACTIVO));
				procesoCpeService.limpiarCaracterExtrano(listVenta.get(0).getIdCarga());
				ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
				procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
				procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
				procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
				
				procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
			}else{
				enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
				return "toPreProceso";
			}

			/*Validar Tipo Proceso por Empresa*/
			if (listVenta.size() > 0)
			{
				String empresa;
				String cod_valor = null;
				empresa = listVenta.get(0).getIdEmpresa().toString();
				ParametroCpeBean param = new ParametroCpeBean();
				param.setCodParam(Constantes.COD_PARAM_TIPO_PROCESO_POR_EMPRESA);
				param.setTipParam(Constantes.TIP_PARAM_DETALLE);
		
				if (empresa.equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS))
				{
					cod_valor = Constantes.COD_VALOR_PROCESO_ONLINE_SEGUROS;
					param.setCodValor(cod_valor);
					List<ParametroCpeBean> lstParam1 = new ArrayList<ParametroCpeBean>();
					lstParam1 = parametroCpeService.listarParametro(param);
					if (Integer.parseInt(lstParam1.get(0).getNomValor().toString()) == 0)
						setDisabledOnline(true);
					else
						setDisabledOnline(false);
					
					cod_valor = Constantes.COD_VALOR_PROCESO_MASIVO_SEGUROS;
					param.setCodValor(cod_valor);
					List<ParametroCpeBean> lstParam2 = new ArrayList<ParametroCpeBean>();
					lstParam2 = parametroCpeService.listarParametro(param);
					if (Integer.parseInt(lstParam2.get(0).getNomValor().toString()) == 0)
						setDisabledMasivo(true);
					else
						setDisabledMasivo(false);
					
					if (disabledOnline == false && disabledMasivo == false)
						tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
					else if (disabledOnline == false  && disabledMasivo == true)
						tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
					else if (disabledOnline == true && disabledMasivo == false)
						tipoProcesoCe = Constantes.TIPO_PROCESO_CE_MASIVO;
				}
				else 
				{
					cod_valor = Constantes.COD_VALOR_PROCESO_ONLINE_SERVICIOS;
					param.setCodValor(cod_valor);
					List<ParametroCpeBean> lstParam1 = new ArrayList<ParametroCpeBean>();
					lstParam1 = parametroCpeService.listarParametro(param);
					if (Integer.parseInt(lstParam1.get(0).getNomValor().toString()) == 0)
						setDisabledOnline(true);
					else
						setDisabledOnline(false);
					
					cod_valor = Constantes.COD_VALOR_PROCESO_MASIVO_SERVICIOS;
					param.setCodValor(cod_valor);
					List<ParametroCpeBean> lstParam2 = new ArrayList<ParametroCpeBean>();
					lstParam2 = parametroCpeService.listarParametro(param);
					if (Integer.parseInt(lstParam2.get(0).getNomValor().toString()) == 0)
						setDisabledMasivo(true);
					else
						setDisabledMasivo(false);
					
					if (disabledOnline == false && disabledMasivo == false)
						tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
					else if (disabledOnline == false  && disabledMasivo == true)
						tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
					else if (disabledOnline == true && disabledMasivo == false)
						tipoProcesoCe = Constantes.TIPO_PROCESO_CE_MASIVO;
				}
			}
			else
			{
				setDisabledOnline(false);
				setDisabledMasivo(false);
				tipoProcesoCe = Constantes.TIPO_PROCESO_CE_ONLINE;
			}
			
			filtrarError();
			filtrarProcesar();
			
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
		
		return "toPreProceso";
	}
	
	private void enviarMensaje(String codMensaje) {
		String mensaje = PropertiesErrorUtil.getProperty(codMensaje);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje, null);
		FacesContext.getCurrentInstance().addMessage(null, facesMsg);
	}
	
	public String procesar(){
		String redirect = "";
		
		//Test de Conexión
		if(tipoProcesoCe.equals(Constantes.TIPO_PROCESO_CE_ONLINE)){
			
			String flg = listarParametro(Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST
											, Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST_FLG_SW_PROD_TEST);
			String urlConnection = "";
			
			if(flg.equals(Constantes.CPE_CODIGO_PROD)){
				urlConnection = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_PARAM_ESCON_SW_PRD_URL_SW_PRD);
			}else if(flg.equals(Constantes.CPE_CODIGO_TEST)){
				urlConnection = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_PARAM_ESCON_SW_TST_URL_SW_TST);
			}
			
			StructureJsonRequestCpeBean requestBean = new StructureJsonRequestCpeBean();
	        StructureJsonCustomerCpeBean customer = new StructureJsonCustomerCpeBean();
	        customer.setUsername("");
	        customer.setPassword("");
	        requestBean.setCustomer(customer);
	        requestBean.setFileName("");
	        requestBean.setFileContent("");
	        
	        Gson gsonRequest = new GsonBuilder().disableHtmlEscaping().create();
	        String jsonRequest = gsonRequest.toJson(requestBean);
	        
	        JerseyClientCpe restClient = new JerseyClientCpe();
	        
	        int output = restClient.testConnection(jsonRequest, urlConnection);
	        
	        if(output != Integer.parseInt(Constantes.CPE_CODIGO_WS_STATUS_OK)){
	        	enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_EXISTE_CONEXION_ESCON);
	        	return null;
	        }
	        
		}
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat fmtYYYYmmDD = new SimpleDateFormat("yyyy-MM-dd");
		DecimalFormat decimal = new DecimalFormat("0.00",  new DecimalFormatSymbols(Locale.US));
		String jsonGenerated = "";
		boolean flgErrores = false;
		
		////////////////////////////////
		StringBuilder responseJson = new StringBuilder();
		///////////////////////////////
		
		List<VentaCpeBean> listaProcesarVentas = new ArrayList<VentaCpeBean>();
		for(VentaCpeBean temp : listVentaProcesar){
			if(!temp.getEstadoCodigo().equals(Constantes.COD_ESTADO_VENTA_VALIDADO)){
				listaProcesarVentas.add(temp);
			}
		}
		
		if(listaProcesarVentas.isEmpty()){
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_EXISTEN_REGISTROS_POR_PROCESAR);
			return null;
		}
		
		if(tipoProcesoCe.equals(Constantes.TIPO_PROCESO_CE_ONLINE)){
			if(listaProcesarVentas.size() > numMaximoOnline){
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_MAXIMO_ONLINE);
				return null;
			}
		}
		
		if(tipoProcesoCe.equals(Constantes.TIPO_PROCESO_CE_ONLINE)){
		
			List<List<VentaCpeBean>> listAgrupado = new ArrayList<List<VentaCpeBean>>();
			
			for(VentaCpeBean cpe : listaProcesarVentas){
				if((cpe.getIdEmpresa() != null && cpe.getIdEmpresa().trim().length() != 0) 
						&& (cpe.getIdSocio() != null)
						&& (cpe.getIdProducto() != null)
						&& (cpe.getIdTipoComp() != null && cpe.getIdTipoComp().trim().length() != 0)){
					
					ConfiguracionCpeBean config = new ConfiguracionCpeBean();
					config.setIdEmpresa(cpe.getIdEmpresa());
					config.setIdSocio(Integer.parseInt(cpe.getIdSocio().toString()));
					config.setIdProducto(Integer.parseInt(cpe.getIdProducto().toString()));
					config.setIdTipoComp(cpe.getIdTipoComp());
					config.setFlgAgrupado(Constantes.CPE_FLG_AGRUPADO);
					config.setEstadoConfig(Constantes.ACTIVO);
					
					List<ConfiguracionCpeBean> listConfiguracion = configuracionCpeService.listarConfiguracionCpe(config);
					
					boolean flg = false;
					
					if(listConfiguracion != null && !listConfiguracion.isEmpty() && listConfiguracion.size() > 0){
						for(List<VentaCpeBean> list : listAgrupado){
							if(list.get(0).getIdEmpresa().equals(cpe.getIdEmpresa()) 
									&& list.get(0).getIdSocio().equals(cpe.getIdSocio())
									&& list.get(0).getIdProducto().equals(cpe.getIdProducto())
									&& list.get(0).getIdTipoComp().equals(cpe.getIdTipoComp())){
								list.add(cpe);
								flg=true;
								break;
							}
						}
						
						if(!flg){
							List<VentaCpeBean> lista = new ArrayList<VentaCpeBean>();
							lista.add(cpe);
							listAgrupado.add(lista);
						}
					}
				}
			}
			
			for(List<VentaCpeBean> listVenta : listAgrupado){
				for(VentaCpeBean vent : listVenta){
					listaProcesarVentas.remove(vent);
				}
			}
			
			for(List<VentaCpeBean> listVenta : listAgrupado){
				
				BigDecimal valFactExportSum = BigDecimal.ZERO;
				BigDecimal baseImponibleSum = BigDecimal.ZERO;
				BigDecimal impExoneradoSum = BigDecimal.ZERO;
				BigDecimal impInafectoSum = BigDecimal.ZERO;
				BigDecimal valOpGratuitasSum = BigDecimal.ZERO;
				BigDecimal iscSum = BigDecimal.ZERO;
				BigDecimal igvSum = BigDecimal.ZERO;
				BigDecimal impOtrosSum = BigDecimal.ZERO;
				BigDecimal ImpTotalSum = BigDecimal.ZERO;
				
				for(VentaCpeBean vent : listVenta){
					valFactExportSum = valFactExportSum.add(vent.getValFactExport());
					baseImponibleSum = baseImponibleSum.add(vent.getBaseImponible());
					impExoneradoSum = impExoneradoSum.add(vent.getImpExonerado());
					impInafectoSum = impInafectoSum.add(vent.getImpInafecto());
					valOpGratuitasSum = valOpGratuitasSum.add(vent.getValOpGratuitas());
					iscSum = iscSum.add(vent.getIsc());
					igvSum = igvSum.add(vent.getIgv());
					impOtrosSum = impOtrosSum.add(vent.getImpOtros());
					ImpTotalSum = ImpTotalSum.add(vent.getImpTotal());
				}
				
				VentaCpeBean vTemp = (VentaCpeBean) listVenta.get(0).clone();
				vTemp.setValFactExport(valFactExportSum);
				vTemp.setBaseImponible(baseImponibleSum);
				vTemp.setImpExonerado(impExoneradoSum);
				vTemp.setImpInafecto(impInafectoSum);
				vTemp.setValOpGratuitas(valOpGratuitasSum);
				vTemp.setIsc(iscSum);
				vTemp.setIgv(igvSum);
				vTemp.setImpOtros(impOtrosSum);
				vTemp.setImpTotal(ImpTotalSum);
				vTemp.setFlgAgrupado(Constantes.ACTIVO);
				vTemp.setIdAgrupado(null);
				setUbigeos(vTemp);
				listaProcesarVentas.add(vTemp);
				
				procesoCpeService.guardarVentaCpe(vTemp);
				
				VentaEstadoCpeBean ventaEstadoCpeBean = new VentaEstadoCpeBean();
				ventaEstadoCpeBean.setIdVenta(vTemp.getIdVenta());
				ventaEstadoCpeBean.setEstadoVenta(Constantes.COD_ESTADO_VENTA_PENDIENTE);
				ventaEstadoCpeBean.setUsuarioCreacion(usuarioSesion);
				
				procesoCpeService.guardarVentaEstadoCpe(ventaEstadoCpeBean);
				
				ProcesoVentaCpeBean procesoVentaCpeBean = new ProcesoVentaCpeBean();
				procesoVentaCpeBean.setIdProceso(proceso.getIdProceso());
				procesoVentaCpeBean.setIdVenta(vTemp.getIdVenta());
				procesoVentaCpeBean.setEstado(Constantes.ACTIVO);
				
				procesoCpeService.guardarProcesoVentaCpe(procesoVentaCpeBean);
				
				for(VentaCpeBean vent : listVenta){
					VentaCpeBean bean = new VentaCpeBean();
					bean.setIdVenta(vent.getIdVenta());
					bean.setIdAgrupado(vTemp.getIdVenta());
					procesoCpeService.actualizarVentaIdAgrupado(bean);
				}
				
			}
		}

		if(tipoProcesoCe.equals(Constantes.TIPO_PROCESO_CE_ONLINE)){
			
			redirect = "toProcesoOnline";
			
			List<VentaCpeBean> ventasFacturar = new ArrayList<VentaCpeBean>();
			List<VentaCpeBean> ventasNoFacturar = new ArrayList<VentaCpeBean>();
			
			ParametroCpeBean parametroDetrac = new ParametroCpeBean();
			parametroDetrac.setCodParam(Constantes.COD_PARAM_DETRACCION_ESCON);
			parametroDetrac.setTipParam(Constantes.TIP_PARAM_DETALLE);
			
			List<ParametroCpeBean> listParamDetrac = parametroCpeService.listarParametro(parametroDetrac);
			
			/*Traemos Lista de Tipo Tributo*/
//			ParametroSUNATCpeBean paramTipoTributo = new ParametroSUNATCpeBean();
//			paramTipoTributo.setCodParam(Constantes.COD_PARAM_SUNAT_TIPO_TRIBUTO);
//			paramTipoTributo.setTipParam(Constantes.TIP_PARAM_DETALLE);
//			
//			List<ParametroSUNATCpeBean> listParamTipoTributo = parametroSUNATCpeService.listarParametro(paramTipoTributo);
			
			/*Traemos Lista de Tipo Afectacion*/
//			ParametroSUNATCpeBean paramTipoAfectacion = new ParametroSUNATCpeBean();
//			paramTipoAfectacion.setCodParam(Constantes.COD_PARAM_SUNAT_TIPO_AFECTACION);
//			paramTipoAfectacion.setTipParam(Constantes.TIP_PARAM_DETALLE);
//			
//			List<ParametroSUNATCpeBean> listParamTipoAfectacion = parametroSUNATCpeService.listarParametro(paramTipoAfectacion);
			
			for(VentaCpeBean venta : listaProcesarVentas){
				setUbigeoDescACod(venta);
				if((venta.getIdEmpresa() != null && venta.getIdEmpresa().trim().length() != 0) 
						&& (venta.getIdSocio() != null)
						&& (venta.getIdProducto() != null)
						&& (venta.getIdTipoComp() != null && venta.getIdTipoComp().trim().length() != 0))
					{
					if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA) 
							&& !venta.getIdTipoDocCli().trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC)
							&& venta.getNumDocCli().trim().length() != 11){
						ventasNoFacturar.add(venta);
					}else{
						ConfiguracionCpeBean config = new ConfiguracionCpeBean();
						config.setIdEmpresa(venta.getIdEmpresa());
						config.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
						config.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
						config.setIdTipoComp(venta.getIdTipoComp());
						if (venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA))
						{
							config.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
						}
						else if (venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA))
						{
							config.setPrefijo(Constantes.CPE_PREFIJO_BOLETA);
						}
						else if (venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) 
								|| venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO))
						{
							/**TIP_PER0100_CC15 INICIO 2019/06/21 - 10:14 - Se agrega validación de tipo de comprobante con código de referencia 13*/
							if(venta.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO)){
								config.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
							}else
							/**TIP_PER0100_CC15 FIN*/
							if (venta.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC) )
								config.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
							else if (venta.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC) )
								config.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
							else
								config.setPrefijo(Constantes.CPE_PREFIJO_BOLETA);
						}
						else
						{
							if (venta.getIdTipoDocCli().trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC))
								config.setPrefijo(Constantes.CPE_PREFIJO_FACTURA);
							else
								config.setPrefijo(Constantes.CPE_PREFIJO_BOLETA);
						}
						config.setEstadoConfig(Constantes.ACTIVO);
						
						List<ConfiguracionCpeBean> listConfiguracion = configuracionCpeService.listarConfiguracionCpe(config);
						
						if(listConfiguracion != null && !listConfiguracion.isEmpty()){
							ConfiguracionCpeBean conf = listConfiguracion.get(0);
							String prefijo = "";
							String serie = "";
							int corrInt = 0;
							String corrStr = "";
							String numComprobante="";
							Date fechaEmision = null;
							
							ComprobanteCpeBean compCpeBeanRequest = new ComprobanteCpeBean();
							compCpeBeanRequest.setIdVenta(venta.getIdVenta());
							List<ComprobanteCpeBean> listCompCpeBeanRequest = comprobanteCpeService.obtenerComprobante(compCpeBeanRequest);
							
							if(listCompCpeBeanRequest == null || listCompCpeBeanRequest.isEmpty() || listCompCpeBeanRequest.size() == 0){
								
//								if(venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) 
//										|| venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO)){
//									prefijo = venta.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC) 
//											? Constantes.CPE_PREFIJO_BOLETA : venta.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA) 
//													? Constantes.CPE_PREFIJO_FACTURA : "";
//								}else{
									prefijo = conf.getPrefijo() == null ? "" : conf.getPrefijo();
//								}
								
								serie = conf.getSerie().trim();
								
								corrInt = conf.getCorActual() == null ? conf.getCorInicial() : conf.getCorActual() + 1;
								
								corrStr = String.format("%08d", corrInt);
								
								numComprobante = prefijo + serie + "-" + corrStr;
								
								ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
								bean.setIdEmpresa(venta.getIdEmpresa());
								bean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
								bean.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
								bean.setIdTipoComp(venta.getIdTipoComp());
								bean.setPrefijo(prefijo);
								bean.setSerie(serie);
								bean.setEstadoConfig(Constantes.ACTIVO);
								bean.setCorActual(corrInt);
								bean.setUsuModifica(usuarioSesion);
								
								configuracionCpeService.actualizarCorrelativo(bean);
								
								ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
								comprobante.setIdVenta(venta.getIdVenta());
								comprobante.setIdTipoComp(venta.getIdTipoComp());
								
								ProcesoVentaCpeBean procesoVentaCpeBean = new ProcesoVentaCpeBean();
								procesoVentaCpeBean.setIdProceso(proceso.getIdProceso());
								procesoVentaCpeBean.setIdVenta(venta.getIdVenta());
								procesoVentaCpeBean.setEstado(Constantes.ACTIVO);
								List<ProcesoVentaCpeBean> listProcesoVenta = procesoCpeService.listarProcesoVentaCpeBean(procesoVentaCpeBean);
								ProcesoVentaCpeBean procesoVentaCpeBeanResponse = listProcesoVenta.get(0);
								
								comprobante.setIdVentaProceso(procesoVentaCpeBeanResponse.getIdVentaProceso());
								comprobante.setIdEmpresa(venta.getIdEmpresa());
								comprobante.setIdSocio(venta.getIdSocio());
								comprobante.setIdProducto(venta.getIdProducto());
								comprobante.setSerieComp(serie);
								comprobante.setCorrComp(corrStr);
								
								CargaVentaCabCpeBean cargaBean = new CargaVentaCabCpeBean();
								cargaBean.setIdCarga(venta.getIdCarga());
								List<CargaVentaCabCpeBean> listCarga = procesoCpeService.listarCargaVentaCab(cargaBean);
								CargaVentaCabCpeBean cargaVentaCabCpeBeanResponseBean = listCarga.get(0);
								if(cargaVentaCabCpeBeanResponseBean.getIdOrigen().trim().equals(Constantes.COD_ORIGEN_ARCHIVO)){
									
									ParametroCpeBean parametroCpeBean = new ParametroCpeBean();
									parametroCpeBean.setCodParam(Constantes.COD_PARAM_CONTA_AUTH);
									parametroCpeBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
									List<ParametroCpeBean> listAuth = new ArrayList<ParametroCpeBean>();
									listAuth = parametroCpeService.listarParametro(parametroCpeBean);
									
									ParametroCpeBean paramAuth = new ParametroCpeBean();
									for(ParametroCpeBean auth : listAuth){
										if(auth.getCodValor().trim().equalsIgnoreCase(Constantes.COD_PARAM_CONTA_AUTH_CONTA_AUTH)){
											paramAuth = auth;
										}
									}
									
									String[] authArray = paramAuth.getNomValor().split("\\|");
									boolean indAuth = false;
									for(int i=0 ; i<authArray.length; i++){
										if(authArray[i].trim().equalsIgnoreCase(cargaVentaCabCpeBeanResponseBean.getUsuarioCarga().trim())){
											indAuth = true;
											break;
										}
									}
									
									if(indAuth){
										fechaEmision = getStringToDate(venta.getFechaEmision());
									}else{
										fechaEmision = new Date();
									}
									
								}else{
									fechaEmision = new Date();
								}
								
								comprobante.setFecEmision(fmt.format(fechaEmision));
								comprobante.setEstadoComp(Constantes.COD_ESTADO_VENTA_PENDIENTE);
								comprobante.setUsuCrea(usuarioSesion);
								comprobante.setNumComprobante(numComprobante);
								
								comprobanteCpeService.insertarComprobanteCpe(comprobante);
							}else{
								ComprobanteCpeBean comp = listCompCpeBeanRequest.get(0);
								numComprobante = comp.getNumComprobante();
								fechaEmision = comp.getFechaEmisionDate();
							}
							
							if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)
									|| venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
								
								StructureJsonFCBLCpeBean structureJson = new StructureJsonFCBLCpeBean();
								
								StructureJsonIDECpeBean ide = new StructureJsonIDECpeBean();
								ide.setNumeracion(numComprobante);
								ide.setFechaEmision(fmtYYYYmmDD.format(fechaEmision));
								//ide.setHoraEmision();
								ide.setCodTipoDocumento(venta.getIdTipoComp());
								ide.setTipoMoneda(venta.getTipoMoneda());
								/*TIP_PER0100_CC09_13 INICIO 2019/05/06 - 11:13 - Se inserta en la estructura JSON el dato de la orden de compra*/
								ide.setNumeroOrdenCompra(venta.getOrdenCompra());
								/*TIP_PER0100_CC09_13 FIN*/
								//ide.setNumeroOrdenCompra();
								ide.setFechaVencimiento(venta.getFechaVenc() == null ? null : venta.getFechaVenc().trim().length() == 0 
															? null : fmtYYYYmmDD.format(getStringToDate(venta.getFechaVenc())));
								
								structureJson.setIDE(ide);
								
								String tipDocId = "";
								String numDocId = "";
								String nombreComercial = "";
								String razonSocial = "";
								String ubigeo = "";
								String direccion = "";
								String urbanizacion = "";
								String provincia = "";
								String departamento = "";
								String distrito = "";
								String codigoPais = "";
								String telefono = "";
								String mail = "";
								
								if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
									//Seguros
									ParametroCpeBean parametro = new ParametroCpeBean();
									parametro.setCodParam(Constantes.COD_PARAM_CPE_CARDIF_SEGUROS);
									parametro.setTipParam(Constantes.TIP_PARAM_DETALLE);
									
									List<ParametroCpeBean> listParam = parametroCpeService.listarParametro(parametro);
									
									for(ParametroCpeBean param : listParam){
										if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_DIR)){
											direccion = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_ID_TIP_DOC)){
											tipDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_MAIL)){
											mail = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RAS_SOC)){
											razonSocial = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RUC)){
											numDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_TEL)){
											telefono = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_UBIGEO)){
											ubigeo = param.getNomValor().trim();
										}
									}
									
								}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
									//Servicios
									ParametroCpeBean parametro = new ParametroCpeBean();
									parametro.setCodParam(Constantes.COD_PARAM_CPE_CARDIF_SERVICIOS);
									parametro.setTipParam(Constantes.TIP_PARAM_DETALLE);
									
									List<ParametroCpeBean> listParam = parametroCpeService.listarParametro(parametro);
									
									for(ParametroCpeBean param : listParam){
										if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_DIR)){
											direccion = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_ID_TIP_DOC)){
											tipDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_MAIL)){
											mail = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RAS_SOC)){
											razonSocial = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RUC)){
											numDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_TEL)){
											telefono = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_UBIGEO)){
											ubigeo = param.getNomValor().trim();
										}
									}
									
								}
								
								if(ubigeo != null && ubigeo.trim().length() != 0){
									
									UbigeoCpeBean ubigeoDep = new UbigeoCpeBean();
									ubigeoDep.setCodigoUbigeo(ubigeo.substring(0, 2) + "0000");
									List<UbigeoCpeBean> listDepartamento = ubigeoCpeService.obtenerUbigeo(ubigeoDep);
									
									if(listDepartamento != null && !listDepartamento.isEmpty()){
										departamento = listDepartamento.get(0).getNombreUbigeo();
										
										UbigeoCpeBean ubigeoProv = new UbigeoCpeBean();
										ubigeoProv.setCodigoUbigeo(ubigeo.substring(0,4) + "00");
										List<UbigeoCpeBean> listProvincia = ubigeoCpeService.obtenerUbigeo(ubigeoProv);
										
										if(listProvincia != null && !listProvincia.isEmpty()){
											provincia = listProvincia.get(0).getNombreUbigeo();
											
											UbigeoCpeBean ubigeoDist = new UbigeoCpeBean();
											ubigeoDist.setCodigoUbigeo(ubigeo);
											List<UbigeoCpeBean> listDistrito = ubigeoCpeService.obtenerUbigeo(ubigeoDist);
											
											if(listDistrito != null && !listDistrito.isEmpty()){
												distrito = listDistrito.get(0).getNombreUbigeo();
											}else{
												ubigeo = null;
												provincia = null;
												departamento = null;
												distrito = null;
											}
										}else{
											ubigeo = null;
											provincia = null;
											departamento = null;
											distrito = null;
										}
									}else{
										ubigeo = null;
										provincia = null;
										departamento = null;
										distrito = null;
									}
								}else{
									ubigeo = null;
									provincia = null;
									departamento = null;
									distrito = null;
								}
								
								nombreComercial = null;
								urbanizacion = null;
								codigoPais = "PE";
								
								StructureJsonEMICpeBean emi = new StructureJsonEMICpeBean();
								emi.setTipoDocId(tipDocId.substring(1, 2));
								emi.setNumeroDocId(numDocId);
								emi.setNombreComercial(nombreComercial == null ? null : nombreComercial.trim().length() == 0 ? null : nombreComercial.toUpperCase());
								emi.setRazonSocial(razonSocial.toUpperCase());
								emi.setUbigeo(ubigeo == null ? null : ubigeo.trim().length() == 0 ? null : ubigeo);
								emi.setDireccion(direccion.toUpperCase());
								emi.setUrbanizacion(urbanizacion == null ? null : urbanizacion.trim().length() == 0 ? null : urbanizacion.toUpperCase());
								emi.setProvincia(provincia == null ? null : provincia.trim().length() == 0 ? null : provincia.toUpperCase());
								emi.setDepartamento(departamento == null ? null : departamento.trim().length() == 0 ? null : departamento.toUpperCase());
								emi.setDistrito(distrito == null ? null : distrito.trim().length() == 0 ? null : distrito.toUpperCase());
								emi.setCodigoPais(codigoPais == null ? null : codigoPais.trim().length() == 0 ? null : codigoPais);
								emi.setTelefono(telefono == null ? null : telefono.trim().length() == 0 ? null : telefono);
								emi.setCorreoElectronico(mail == null ? null : mail.trim().length() == 0 ? null : mail.toUpperCase());
								emi.setCodigoAsigSUNAT(Constantes.CPE_CODIGO_ASIG_SUNAT);
								
								structureJson.setEMI(emi);
								
								String departamentoRec = "";
								String provinciaRec = "";
								String distritoRec = "";
								
								if((venta.getDepartamento() != null && !venta.getDepartamento().equals("")) 
										&& (venta.getProvincia() != null && !venta.getProvincia().equals(""))
										&& (venta.getDistrito() != null && !venta.getDistrito().equals(""))){
									
									UbigeoCpeBean ubigeoDepRec = new UbigeoCpeBean();
									ubigeoDepRec.setCodigoUbigeo(venta.getDepartamento());
									List<UbigeoCpeBean> listDepRec = ubigeoCpeService.obtenerUbigeo(ubigeoDepRec);
									
									if(listDepRec != null && !listDepRec.isEmpty()){
										departamentoRec = listDepRec.get(0).getNombreUbigeo();
										
										UbigeoCpeBean ubigeoProvRec = new UbigeoCpeBean();
										ubigeoProvRec.setCodigoUbigeo(venta.getProvincia());
										List<UbigeoCpeBean> listProvRec = ubigeoCpeService.obtenerUbigeo(ubigeoProvRec);
										
										if(listProvRec != null && !listProvRec.isEmpty()){
											provinciaRec = listProvRec.get(0).getNombreUbigeo();
											
											UbigeoCpeBean ubigeoDistRec = new UbigeoCpeBean();
											ubigeoDistRec.setCodigoUbigeo(venta.getDistrito());
											List<UbigeoCpeBean> listDistRec = ubigeoCpeService.obtenerUbigeo(ubigeoDistRec);
											
											if(listDistRec != null && !listDistRec.isEmpty()){
												distritoRec = listDistRec.get(0).getNombreUbigeo();
											}else{
												departamentoRec = null;
												provinciaRec = null;
												distritoRec = null;
											}
										}else{
											departamentoRec = null;
											provinciaRec = null;
											distritoRec = null;
										}
									}else{
										departamentoRec = null;
										provinciaRec = null;
										distritoRec = null;
									}
								}else{
									departamentoRec = null;
									provinciaRec = null;
									distritoRec = null;
								}
								
								StructureJsonRECCpeBean rec = new StructureJsonRECCpeBean();
								/*Validación Comprobante No Domiciliado*/
								
								rec.setTipoDocId(venta.getIdTipoDocCli().substring(1, 2));
								rec.setNumeroDocId(venta.getNumDocCli());
								rec.setRazonSocial(venta.getNomCliRazSoc().toUpperCase());
								rec.setDireccion(venta.getDirCliente() == null ? null : venta.getDirCliente().trim().length() == 0 ? null : venta.getDirCliente().toUpperCase());
								rec.setDepartamento(departamentoRec == null ? null : departamentoRec.trim().length() == 0 ? null : departamentoRec.toUpperCase());
								rec.setProvincia(provinciaRec == null ? null : provinciaRec.trim().length() == 0 ? null : provinciaRec.toUpperCase());
								rec.setDistrito(distritoRec == null ? null : distritoRec.trim().length() == 0 ? null : distritoRec.toUpperCase());
								rec.setCodigoPais("PE");
								rec.setTelefono(venta.getTelefCliente() == null ? null : venta.getTelefCliente().trim().length() == 0 ? null : venta.getTelefCliente());
								rec.setCorreoElectronico(venta.getMailCliente() == null ? null : venta.getMailCliente().trim().length() == 0 ? null : venta.getMailCliente().toUpperCase());
								
								structureJson.setREC(rec);
								
								StructureJsonCABCpeBean cab = new StructureJsonCABCpeBean();
								
								StructureJsonGravadasCpeBean gravadas = new StructureJsonGravadasCpeBean();
								gravadas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_GRAVADAS);
								gravadas.setTotalVentas(decimal.format(venta.getBaseImponible()));
								
								if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) == 0){
									cab.setGravadas(null);
								}else{
									cab.setGravadas(gravadas);
								}
								
								StructureJsonInafectasCpeBean inafectas = new StructureJsonInafectasCpeBean();
								inafectas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_INAFECTAS);
								inafectas.setTotalVentas(decimal.format(venta.getImpInafecto()));
								
								if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) == 0){
									cab.setInafectas(null);
								}else{
									cab.setInafectas(inafectas);
								}
								
								StructureJsonExoneradasCpeBean exoneradas = new StructureJsonExoneradasCpeBean();
								exoneradas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_EXONERADAS);
								exoneradas.setTotalVentas(decimal.format(venta.getImpExonerado()));
								
								if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) == 0){
									cab.setExoneradas(null);
								}else{
									cab.setExoneradas(exoneradas);
								}
								
								StructureJsonGratuitasCpeBean gratuitas = new StructureJsonGratuitasCpeBean();
								gratuitas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_GRATUITAS);
								gratuitas.setTotalVentas(decimal.format(venta.getValOpGratuitas()));
								
								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0){
									cab.setGratuitas(null);
								}else{
									cab.setGratuitas(gratuitas);
								}
								
								StructureJsonExportadasCpeBean exportadas = new StructureJsonExportadasCpeBean();
								exportadas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_EXPORTACIONES);
								exportadas.setTotalVentas(decimal.format(venta.getValFactExport()));
								
								if(venta.getValFactExport().compareTo(BigDecimal.ZERO) == 0){
									cab.setExportadas(null);
								}else{
									cab.setExportadas(exportadas);
								}
								
								//StructureJsonPercepcionesCpeBean percepciones = new StructureJsonPercepcionesCpeBean();
								//percepciones.setIndicadorPercepcion();
								//percepciones.setCodRegimenPercepcion();
								//percepciones.setBaseImpPercepcion(decimal.format(venta.getBaseImponible()));
								//percepciones.setMontoPercepcion();
								//percepciones.setFactorPercepcion();
								
								//cab.setPercepciones(percepciones);
								
								String codTipTributo = "";
								
								if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_EXPORTACION;
								}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_IGV;
								}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_EXONERADO;
								}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_INAFECTO;
								}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_GRATUITO;
								}
								
								StructureJsonTotalImpuestosCpeBean totalImpuestosCab = new StructureJsonTotalImpuestosCpeBean();
								totalImpuestosCab.setIdImpuesto(codTipTributo);
								totalImpuestosCab.setMontoImpuesto(decimal.format(venta.getIgv()));
								
								List<StructureJsonTotalImpuestosCpeBean> listTotalImpCab = new ArrayList<StructureJsonTotalImpuestosCpeBean>();
								listTotalImpCab.add(totalImpuestosCab);
								
								cab.setTotalImpuestos(listTotalImpCab);
								cab.setSumOtrosCargos(venta.getImpOtros() == null ? null : (venta.getImpOtros().compareTo(BigDecimal.ZERO) == 0) ? null : decimal.format(venta.getImpOtros()));
								
								//StructureJsonTotalDescuentosCpeBean totalDescuentos = new StructureJsonTotalDescuentosCpeBean();
								//totalDescuentos.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_TOTAL_DESCUENTOS);
								//totalDescuentos.setTotalDescuentos("0.00");
								
								//cab.setTotalDescuentos(totalDescuentos);
								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0){
									cab.setImporteTotal(decimal.format(venta.getImpTotal()));
								}
								else {
									cab.setImporteTotal(decimal.format(BigDecimal.ZERO));
								}
								//cab.setTotalAnticipos(Constantes.TOTAL_ANTICIPO_CPE);
								
								//Validamos Tipo Operación de Venta con o sin detraccion
 								if (venta.getFlgDetraccion().equals(Constantes.FLG_DETRACCION_NO))
									if (venta.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC))
										cab.setTipoOperacion(Constantes.COD_VALOR_TIPO_OPERACION_VENTA_NO_DOMICILIADO);
									else
										cab.setTipoOperacion(Constantes.COD_VALOR_TIPO_OPERACION_VENTA_SIN_DETRACCION);
								else
									cab.setTipoOperacion(Constantes.COD_VALOR_TIPO_OPERACION_VENTA_CON_DETRACCION);
								
								StructureJsonLeyendaCpeBean leyenda = new StructureJsonLeyendaCpeBean();
								leyenda.setCodigo(Constantes.CODIGO_LEYENDA_CPE);
								
								if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0) // Gratuitas se envia monto cero en letras
									leyenda.setDescripcion(new NumeroToLetra().convertir(decimal.format(BigDecimal.ZERO), true, venta.getNombreMoneda()));
								else
									leyenda.setDescripcion(new NumeroToLetra().convertir(decimal.format(venta.getImpTotal()), true, venta.getNombreMoneda()));
								
								List<StructureJsonLeyendaCpeBean> listLeyenda = new ArrayList<StructureJsonLeyendaCpeBean>();
								listLeyenda.add(leyenda);
								
								if (venta.getFlgDetraccion().equals(Constantes.FLG_DETRACCION_SI)) // Agregamos leyenda de Detracción
								{
									StructureJsonLeyendaCpeBean leyendaDetrac = new StructureJsonLeyendaCpeBean();
									leyendaDetrac.setCodigo(Constantes.CODIGO_LEYENDA_DETRACCION_CPE);
									leyendaDetrac.setDescripcion(Constantes.COD_VALOR_MSJE_DETRACCION_ESCON);
									listLeyenda.add(leyendaDetrac);
								}
								if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0) // Agregamos leyenda de Gratuitas
								{
									StructureJsonLeyendaCpeBean leyendaGratuitas = new StructureJsonLeyendaCpeBean();
									leyendaGratuitas.setCodigo(Constantes.CODIGO_LEYENDA_GRATUITAS_CPE);
									leyendaGratuitas.setDescripcion(Constantes.COD_VALOR_MSJE_GRATUITAS_ESCON);
									listLeyenda.add(leyendaGratuitas);
								}
								
								cab.setLeyenda(listLeyenda);
								
								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0){
									cab.setMontoTotalImpuestos(decimal.format(venta.getIgv()));
								}else {
									cab.setMontoTotalImpuestos(decimal.format(BigDecimal.ZERO));
								}
								
								structureJson.setCAB(cab);

/**TIP_PER0100_CC14 INICIO 2019/06/18 - 14:00 - Se comenta generación de detalle de estructura Json*/

//								SocioCpeBean socioBean = new SocioCpeBean();
//								socioBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
//								List<SocioCpeBean> listSocio = new ArrayList<SocioCpeBean>();
//								listSocio = socioCpeService.listarSocio(socioBean);
//								SocioCpeBean socioResponse = listSocio.get(0);
//								
//								ProductoCpeBean productoBean = new ProductoCpeBean();
//								productoBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
//								productoBean.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
//								List<ProductoCpeBean> listProducto = new ArrayList<ProductoCpeBean>();
//								listProducto = productoCpeService.listarProducto(productoBean);
//								ProductoCpeBean productoResponse = listProducto.get(0);
//								
//								String valorUnitario = "";
//								BigDecimal igv = BigDecimal.ZERO;
//								BigDecimal dividendo = BigDecimal.ONE;
//								
//								ParametroCpeBean parametroRequest = new ParametroCpeBean();
//								parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
//								parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
//								List<ParametroCpeBean> listPrm = parametroCpeService.listarParametro(parametroRequest);
//								for(ParametroCpeBean prm : listPrm){
//									if(prm.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_GENERAL_IGV)){
//										igv = new BigDecimal(prm.getNomValor());
//									}
//								}
//								
//								dividendo = dividendo.add(igv);
//
//								if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
//									if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0)
//										valorUnitario = decimal.format(venta.getImpTotal());
//									else
//										valorUnitario = decimal.format(venta.getBaseImponible());
//								}else{
//									if(conf.getAfectoIgv() == 0)
//										valorUnitario = decimal.format(venta.getImpTotal());
//									else
//										valorUnitario = decimal.format(venta.getBaseImponible());
//								}
//
//								String montoImpuesto = "";
//								
//								if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(venta.getImpTotal().divide(dividendo, 2, RoundingMode.HALF_UP));
//								}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(venta.getImpTotal().divide(dividendo, 2, RoundingMode.HALF_UP));
//								}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(BigDecimal.ZERO);
//								}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(BigDecimal.ZERO);
//								}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(BigDecimal.ZERO);
//								}
//								
//								String tipoAfectacion = "";
//								
//								if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_FACT_EXPORT;
//								}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_BASE_IMPONIBLE;
//								}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_IMP_EXONERADO;
//								}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_INAFECTO;
//								}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = venta.getTipoAfectacion().toString();
//								}
								
//								StructureJsonDETCpeBean det = new StructureJsonDETCpeBean();
//								
//								det.setNumeroItem("1");
//								//det.setCodigoProducto();
//								
//								
////								if(venta.getIdOrigen().trim().equals(Constantes.COD_ORIGEN_UPLOAD)){
////									//Seguros
////									det.setDescripcionProducto("PRIMA DE SEGUROS - " + socioResponse.getNomSocio().trim().toUpperCase() + " / " + productoResponse.getNomProducto().trim().toUpperCase());
////								}else{
////									//archivo
////									det.setDescripcionProducto(venta.getConcepto().toUpperCase());
////								}
//								
//								// Antigua validacion para el concepto de item del comprobnate
//								if(venta.getTipoProducto().trim().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
//									//Administrativo
//									det.setDescripcionProducto(venta.getConcepto().toUpperCase());
//								}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
//									//Seguros
//									det.setDescripcionProducto("PRIMA DE SEGUROS - " + socioResponse.getNomSocio().trim().toUpperCase() + " / " + productoResponse.getNomProducto().trim().toUpperCase());
//								}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
//									//Servicios
//									det.setDescripcionProducto(venta.getConcepto().toUpperCase());
//								}
//								
//								det.setCantidadItems("1.00");
//								det.setUnidad(Constantes.COD_NUMBER_OF_INTERNATIONAL_UNITS);
//								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0)
//								{
//									det.setValorUnitario(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
//									det.setPrecioVentaUnitario(decimal.format(venta.getImpTotal()));
//								}
//								else
//								{
//									det.setValorUnitario(decimal.format(BigDecimal.ZERO));
//									det.setPrecioVentaUnitario(decimal.format(BigDecimal.ZERO));
//								}
//								
//								StructureJsonTotalImpuestosDetCpeBean totalImpuestos = new StructureJsonTotalImpuestosDetCpeBean();
//								totalImpuestos.setIdImpuesto(codTipTributo);
//								totalImpuestos.setMontoImpuesto(decimal.format(venta.getIgv()));
//								totalImpuestos.setTipoAfectacion(tipoAfectacion);
//								
//								String montoBase = "";
//								
//								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									montoBase = decimal.format(venta.getValOpGratuitas());
//								}else{
//									montoBase = valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario;
//								}
//								
//								totalImpuestos.setMontoBase(montoBase);
//								
//								if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
//									if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0){
//										igv = new BigDecimal(0.00);
//									}
//								}else{
//									if(conf.getAfectoIgv() == 0){
//										igv = new BigDecimal(0.00);
//									}
//								}
//								
//								totalImpuestos.setPorcentaje(decimal.format(igv.multiply(new BigDecimal(100.00))));
//								
//								List<StructureJsonTotalImpuestosDetCpeBean> listTlimp = new ArrayList<StructureJsonTotalImpuestosDetCpeBean>();
//								listTlimp.add(totalImpuestos);
//								
//								det.setTotalImpuestos(listTlimp);
//								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
//									det.setValorVenta(decimal.format(venta.getValOpGratuitas()));
//								else
//									det.setValorVenta(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
//								
//								String onerosas = "";
//								
//								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									onerosas = decimal.format(venta.getValOpGratuitas());
//								}else{
//									onerosas = null;
//								}
//								
//								det.setValorRefOpOnerosas(onerosas);
//								det.setCodProductoSunat(venta.getCodProdSunat() == null ? "" :String.valueOf(venta.getCodProdSunat()));
//								
//								//det.setNumeroPlaca(); det.setCodNumeroContrato(); det.setNumeroContrato();
//								//det.setCodFechaOtorgCredito(); det.setFechaOtorgCredito(); det.setCodTipoPrestamo(); det.setTipoPrestamo();
//								//det.setCodPartidaRegistral(); det.setPartidaRegistral(); det.setCodIndicadorPrimViv(); det.setIndicadorPrimViv();
//								//det.setCodDireccionPredio(); det.setDireccionPredio(); det.setCodCodigoUbigeo(); det.setCodigoUbigeo();
//								//det.setCodUrbanizacion(); det.setUrbanizacion(); det.setCodDepartamento(); det.setDepartamento();
//								//det.setCodProvincia(); det.setProvincia(); det.setCodDistrito(); det.setDistrito();
//								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
//									det.setMontoTotalImpuestos(decimal.format(BigDecimal.ZERO));
//								else
//									det.setMontoTotalImpuestos(decimal.format(venta.getIgv().add(venta.getIsc()).add(venta.getImpOtros())));
//								
//								List<StructureJsonDETCpeBean> listDet = new ArrayList<StructureJsonDETCpeBean>();
//								listDet.add(det);
/**TIP_PER0100_CC14 FIN*/
								/**TIP_PER0100_CC14 INICIO 2019/06/18 - 10:34 - Se llama al método que permite generar la lista de detalles de la escructura Json*/
								List<StructureJsonDETCpeBean> listDet = new ArrayList<StructureJsonDETCpeBean>();
								listDet = obtenerDETFCBLStructuraJson(venta, conf,codTipTributo);
								structureJson.setDET(listDet);
								/**TIP_PER0100_CC14 FIN*/
								// Agregamos parte ADI de Detracción
								if (venta.getFlgDetraccion().equals(Constantes.FLG_DETRACCION_SI))
								{
									String nro_cuenta = null;
									Double imp_detraccion = null;
									Double porcentaje = null;
									String mensaje = null;
									List<StructureJsonADICpeBean> listAdicional = new ArrayList<StructureJsonADICpeBean>();
									StructureJsonADICpeBean valor1  = new StructureJsonADICpeBean();

									valor1.setTituloAdicional(listParamDetrac.get(0).getCodValor().toString());
									valor1.setValorAdicional(listParamDetrac.get(0).getNomValor().toString());
									listAdicional.add(valor1);
									
									StructureJsonADICpeBean valor2  = new StructureJsonADICpeBean();
									valor2.setTituloAdicional(listParamDetrac.get(1).getCodValor().toString());
									nro_cuenta = listParamDetrac.get(1).getNomValor().toString();
									valor2.setValorAdicional(listParamDetrac.get(1).getNomValor().toString());
									listAdicional.add(valor2);
									
									StructureJsonADICpeBean valor3  = new StructureJsonADICpeBean();
									valor3.setTituloAdicional(listParamDetrac.get(2).getCodValor().toString());
									valor3.setValorAdicional(listParamDetrac.get(2).getNomValor().toString());
									listAdicional.add(valor3);
									
									StructureJsonADICpeBean valor4  = new StructureJsonADICpeBean();
									valor4.setTituloAdicional(listParamDetrac.get(3).getCodValor().toString());
									imp_detraccion = Double.parseDouble(venta.getImpDetraccion().toString());
									valor4.setValorAdicional(Utilitarios.formateoMonto(imp_detraccion));
									
									listAdicional.add(valor4);

									StructureJsonADICpeBean valor5  = new StructureJsonADICpeBean();
									valor5.setTituloAdicional(Constantes.COD_VALOR_MSJE_DETRACCION_ESCON);
									mensaje = listParamDetrac.get(4).getNomValor().toString();
									/*TIP_PER0100_CC09_13 INICIO 2019/05/16 - 11:09 - Se comenta obtención del valor del porcentaje anterior y se agrega la nueva forma de obtener el porcentaje*/
//									porcentaje = Double.parseDouble(listParamDetrac.get(5).getNomValor().toString());
									porcentaje = Double.parseDouble(venta.getPorcDetraccion().toString());
									/*TIP_PER0100_CC09_13 FIN*/
									
									mensaje = mensaje.replace("XXXXXXXXX", nro_cuenta).replace("YYY.YY", Utilitarios.formateoMonto(imp_detraccion)).replace("ZZZ.ZZ", Utilitarios.formateoMonto(porcentaje));
									mensaje = mensaje.replace("\\n", "\n");
									valor5.setValorAdicional(mensaje);
									listAdicional.add(valor5);
									
									structureJson.setADI(listAdicional);
								}
								
								/*TIP_PER0100_CC09_13 INICIO 2019/05/06 - 17:02 - Se inserta en la estructura JSON los datos adicionales de titulo y valor*/
								List<StructureJsonADICpeBean> listAdicional = new ArrayList<StructureJsonADICpeBean>();
								listAdicional = structureJson.getADI();
								if(listAdicional==null){
									if(venta.getTituloAdicional()!=null && venta.getValorAdicional()!=null
											&& !venta.getTituloAdicional().trim().equals("") && !venta.getValorAdicional().trim().equals("")){
										listAdicional = new ArrayList<StructureJsonADICpeBean>();
										StructureJsonADICpeBean tituloValor  = new StructureJsonADICpeBean();
										tituloValor.setTituloAdicional(venta.getTituloAdicional());
										tituloValor.setValorAdicional(venta.getValorAdicional());
										listAdicional.add(tituloValor);
										structureJson.setADI(listAdicional);
									}
								}else{
									if(venta.getTituloAdicional()!=null && venta.getValorAdicional()!=null
											&& !venta.getTituloAdicional().trim().equals("") && !venta.getValorAdicional().trim().equals("")){
										StructureJsonADICpeBean tituloValor  = new StructureJsonADICpeBean();
										tituloValor.setTituloAdicional(venta.getTituloAdicional());
										tituloValor.setValorAdicional(venta.getValorAdicional());
										listAdicional.add(tituloValor);
										structureJson.setADI(listAdicional);
									}
								}
								/*TIP_PER0100_CC09_13 FIN*/
								
								StructureJsonRootCpeBean root = new StructureJsonRootCpeBean();
								
								if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)){
									root.setFactura(structureJson);
								}else if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
									root.setBoleta(structureJson);
								}
								
								Gson gson = new Gson();
								jsonGenerated = gson.toJson(root);
								
							}else if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO)
									|| venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO)){
								
								StructureJsonNCNDCpeBean structureJson = new StructureJsonNCNDCpeBean();
								
								StructureJsonIDENCNDCpeBean ide = new StructureJsonIDENCNDCpeBean();
								ide.setNumeracion(numComprobante);
								ide.setFechaEmision(fmtYYYYmmDD.format(fechaEmision));
								//ide.setHoraEmision();
								ide.setTipoMoneda(venta.getTipoMoneda());
								
								structureJson.setIDE(ide);
								
								String tipDocId = "";
								String numDocId = "";
								String nombreComercial = "";
								String razonSocial = "";
								String ubigeo = "";
								String direccion = "";
								String urbanizacion = "";
								String provincia = "";
								String departamento = "";
								String distrito = "";
								String codigoPais = "";
								String telefono = "";
								String mail = "";
								
								if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
									//Seguros
									ParametroCpeBean parametro = new ParametroCpeBean();
									parametro.setCodParam(Constantes.COD_PARAM_CPE_CARDIF_SEGUROS);
									parametro.setTipParam(Constantes.TIP_PARAM_DETALLE);
									
									List<ParametroCpeBean> listParam = parametroCpeService.listarParametro(parametro);
									
									for(ParametroCpeBean param : listParam){
										if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_DIR)){
											direccion = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_ID_TIP_DOC)){
											tipDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_MAIL)){
											mail = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RAS_SOC)){
											razonSocial = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RUC)){
											numDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_TEL)){
											telefono = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_UBIGEO)){
											ubigeo = param.getNomValor().trim();
										}
									}
									
								}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
									//Servicios
									ParametroCpeBean parametro = new ParametroCpeBean();
									parametro.setCodParam(Constantes.COD_PARAM_CPE_CARDIF_SERVICIOS);
									parametro.setTipParam(Constantes.TIP_PARAM_DETALLE);
									
									List<ParametroCpeBean> listParam = parametroCpeService.listarParametro(parametro);
									
									for(ParametroCpeBean param : listParam){
										if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_DIR)){
											direccion = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_ID_TIP_DOC)){
											tipDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_MAIL)){
											mail = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RAS_SOC)){
											razonSocial = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RUC)){
											numDocId = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_TEL)){
											telefono = param.getNomValor().trim();
										}else if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_UBIGEO)){
											ubigeo = param.getNomValor().trim();
										}
									}
									
								}
								
								if(ubigeo != null && ubigeo.trim().length() != 0){
									
									UbigeoCpeBean ubigeoDep = new UbigeoCpeBean();
									ubigeoDep.setCodigoUbigeo(ubigeo.substring(0, 2) + "0000");
									List<UbigeoCpeBean> listDepartamento = ubigeoCpeService.obtenerUbigeo(ubigeoDep);
									
									if(listDepartamento != null && !listDepartamento.isEmpty()){
										departamento = listDepartamento.get(0).getNombreUbigeo();
										
										UbigeoCpeBean ubigeoProv = new UbigeoCpeBean();
										ubigeoProv.setCodigoUbigeo(ubigeo.substring(0,4) + "00");
										List<UbigeoCpeBean> listProvincia = ubigeoCpeService.obtenerUbigeo(ubigeoProv);
										
										if(listProvincia != null && !listProvincia.isEmpty()){
											provincia = listProvincia.get(0).getNombreUbigeo();
											
											UbigeoCpeBean ubigeoDist = new UbigeoCpeBean();
											ubigeoDist.setCodigoUbigeo(ubigeo);
											List<UbigeoCpeBean> listDistrito = ubigeoCpeService.obtenerUbigeo(ubigeoDist);
											
											if(listDistrito != null && !listDistrito.isEmpty()){
												distrito = listDistrito.get(0).getNombreUbigeo();
											}else{
												ubigeo = null;
												provincia = null;
												departamento = null;
												distrito = null;
											}
										}else{
											ubigeo = null;
											provincia = null;
											departamento = null;
											distrito = null;
										}
									}else{
										ubigeo = null;
										provincia = null;
										departamento = null;
										distrito = null;
									}
								}else{
									ubigeo = null;
									provincia = null;
									departamento = null;
									distrito = null;
								}
								
								nombreComercial = null;
								urbanizacion = null;
								codigoPais = "PE";
								
								StructureJsonEMINCNDCpeBean emi = new StructureJsonEMINCNDCpeBean();
								emi.setTipoDocId(tipDocId.substring(1, 2));
								emi.setNumeroDocId(numDocId);
								emi.setNombreComercial(nombreComercial == null ? null : nombreComercial.trim().length() == 0 ? null : nombreComercial.toUpperCase());
								emi.setRazonSocial(razonSocial.toUpperCase());
								emi.setUbigeo(ubigeo == null ? null : ubigeo.trim().length() == 0 ? null : ubigeo);
								emi.setDireccion(direccion.toUpperCase());
								emi.setUrbanizacion(urbanizacion == null ? null : urbanizacion.trim().length() == 0 ? null : urbanizacion.toUpperCase());
								emi.setProvincia(provincia == null ? null : provincia.trim().length() == 0 ? null : provincia.toUpperCase());
								emi.setDepartamento(departamento == null ? null : departamento.trim().length() == 0 ? null : departamento.toUpperCase());
								emi.setDistrito(distrito == null ? null : distrito.trim().length() == 0 ? null : distrito.toUpperCase());
								emi.setCodigoPais(codigoPais == null ? null : codigoPais.trim().length() == 0 ? null : codigoPais);
								emi.setTelefono(telefono == null ? null : telefono.trim().length() == 0 ? null : telefono);
								emi.setCorreoElectronico(mail == null ? null : mail.trim().length() == 0 ? null : mail.toUpperCase());
								emi.setCodigoAsigSUNAT(Constantes.CPE_CODIGO_ASIG_SUNAT);
								
								structureJson.setEMI(emi);
								
								String departamentoRec = "";
								String provinciaRec = "";
								String distritoRec = "";
								
								if((venta.getDepartamento() != null && !venta.getDepartamento().equals("")) 
										&& (venta.getProvincia() != null && !venta.getProvincia().equals(""))
										&& (venta.getDistrito() != null && !venta.getDistrito().equals(""))){
									
									UbigeoCpeBean ubigeoDepRec = new UbigeoCpeBean();
									ubigeoDepRec.setCodigoUbigeo(venta.getDepartamento());
									List<UbigeoCpeBean> listDepRec = ubigeoCpeService.obtenerUbigeo(ubigeoDepRec);
									
									if(listDepRec != null && !listDepRec.isEmpty()){
										departamentoRec = listDepRec.get(0).getNombreUbigeo();
										
										UbigeoCpeBean ubigeoProvRec = new UbigeoCpeBean();
										ubigeoProvRec.setCodigoUbigeo(venta.getProvincia());
										List<UbigeoCpeBean> listProvRec = ubigeoCpeService.obtenerUbigeo(ubigeoProvRec);
										
										if(listProvRec != null && !listProvRec.isEmpty()){
											provinciaRec = listProvRec.get(0).getNombreUbigeo();
											
											UbigeoCpeBean ubigeoDistRec = new UbigeoCpeBean();
											ubigeoDistRec.setCodigoUbigeo(venta.getDistrito());
											List<UbigeoCpeBean> listDistRec = ubigeoCpeService.obtenerUbigeo(ubigeoDistRec);
											
											if(listDistRec != null && !listDistRec.isEmpty()){
												distritoRec = listDistRec.get(0).getNombreUbigeo();
											}else{
												departamentoRec = null;
												provinciaRec = null;
												distritoRec = null;
											}
										}else{
											departamentoRec = null;
											provinciaRec = null;
											distritoRec = null;
										}
									}else{
										departamentoRec = null;
										provinciaRec = null;
										distritoRec = null;
									}
								}else{
									departamentoRec = null;
									provinciaRec = null;
									distritoRec = null;
								}
								
								StructureJsonRECNCNDCpeBean rec = new StructureJsonRECNCNDCpeBean();
								rec.setTipoDocId(venta.getIdTipoDocCli().substring(1, 2));
								rec.setNumeroDocId(venta.getNumDocCli());
								rec.setRazonSocial(venta.getNomCliRazSoc().toUpperCase());
								rec.setDireccion(venta.getDirCliente() == null ? null : venta.getDirCliente().trim().length() == 0 ? null : venta.getDirCliente().toUpperCase());
								rec.setDepartamento(departamentoRec == null ? null : departamentoRec.trim().length() == 0 ? null : departamentoRec.toUpperCase());
								rec.setProvincia(provinciaRec == null ? null : provinciaRec.trim().length() == 0 ? null : provinciaRec.toUpperCase());
								rec.setDistrito(distritoRec == null ? null : distritoRec.trim().length() == 0 ? null : distritoRec.toUpperCase());
								rec.setCodigoPais("PE");
								rec.setTelefono(venta.getTelefCliente() == null ? null : venta.getTelefCliente().trim().length() == 0 ? null : venta.getTelefCliente());
								rec.setCorreoElectronico(venta.getMailCliente() == null ? null : venta.getMailCliente().trim().length() == 0 ? null : venta.getMailCliente().toUpperCase());
								
								structureJson.setREC(rec);
								
								String prefijoRef = "";
								String numeroDocRef = "";
								String descMotivo = "-";
								
								if(venta.getNumSerieRef() != null || venta.getNumCorRef() != null){
								
									if(venta.getIdTipoCompRef().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA)){
										prefijoRef = Constantes.CPE_PREFIJO_FACTURA;
									}else if(venta.getIdTipoCompRef().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
										prefijoRef = Constantes.CPE_PREFIJO_BOLETA;
									}
								
									/**TIP_PER0100_CC15 INICIO 2019/06/21 - 13:32 - Se agrega validación para armar el número de documento de referencia para ND y NC con código de referencia 13*/
									if(venta.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_AUTORIZADO)){
										numeroDocRef = (venta.getStrNumSerieRef() == null ? "" 
												: venta.getStrNumSerieRef().trim())
												+ "-" + (venta.getStrNumCorRef() == null ? "" 
												: venta.getStrNumCorRef().trim());
									}else{
									/**TIP_PER0100_CC15 FIN*/
									numeroDocRef = prefijoRef + (venta.getNumSerieRef() == null ? "" 
													: String.format("%03d", Integer.parseInt(venta.getNumSerieRef().toString()))) 
													+ "-" + (venta.getNumCorRef() == null ? "" 
													: String.format("%08d", Integer.parseInt(venta.getNumCorRef().toString())));
									}
								}
								
								ParametroCpeBean prmMtv = new ParametroCpeBean();
								if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO)){
									prmMtv.setCodParam(Constantes.COD_PARAM_MOTIVO_REF_NC);
								}else{
									prmMtv.setCodParam(Constantes.COD_PARAM_MOTIVO_REF_ND);
								}								
								prmMtv.setTipParam(Constantes.TIP_PARAM_DETALLE);
//								List<ParametroCpeBean> listMtv = new ArrayList<ParametroCpeBean>();
//								listMtv = parametroCpeService.listarParametro(prmMtv);
								
								// si comenta para evitar la doble descripcion en el pdf
//								for(ParametroCpeBean mtv : listMtv){
//									if(mtv.getCodValor().trim().equals(String.format("%02d", Integer.parseInt(venta.getConcepNd().trim())))){
//										descMotivo = mtv.getNomValor();
//										break;
//									}
//								}
								
								StructureJsonDRFNCNDCpeBean drf = new StructureJsonDRFNCNDCpeBean();
								drf.setTipoDocRelacionado(venta.getIdTipoCompRef());
								drf.setNumeroDocRelacionado(numeroDocRef);
								drf.setCodigoMotivo(String.format("%02d", Integer.parseInt(venta.getConcepNd().trim())));
								drf.setDescripcionMotivo(descMotivo.toUpperCase());
								
								List<StructureJsonDRFNCNDCpeBean> listDrfNCND = new ArrayList<StructureJsonDRFNCNDCpeBean>();
								listDrfNCND.add(drf);
								
								structureJson.setDRF(listDrfNCND);
								
								StructureJsonCABNCNDCpeBean cab = new StructureJsonCABNCNDCpeBean();
								
								StructureJsonGravadasNCNDCpeBean gravadas = new StructureJsonGravadasNCNDCpeBean();
								gravadas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_GRAVADAS);
								gravadas.setTotalVentas(decimal.format(venta.getBaseImponible()));
								
								if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) == 0){
									cab.setGravadas(null);
								}else{
									cab.setGravadas(gravadas);
								}
								
								StructureJsonInafectasNCNDCpeBean inafectas = new StructureJsonInafectasNCNDCpeBean();
								inafectas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_INAFECTAS);
								inafectas.setTotalVentas(decimal.format(venta.getImpInafecto()));
								
								if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) == 0){
									cab.setInafectas(null);
								}else{
									cab.setInafectas(inafectas);
								}
								
								StructureJsonExoneradasNCNDCpeBean exoneradas = new StructureJsonExoneradasNCNDCpeBean();
								exoneradas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_EXONERADAS);
								exoneradas.setTotalVentas(decimal.format(venta.getImpExonerado()));
								
								if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) == 0){
									cab.setExoneradas(null);
								}else{
									cab.setExoneradas(exoneradas);
								}
								
								StructureJsonGratuitasNCNDCpeBean gratuitas = new StructureJsonGratuitasNCNDCpeBean();
								gratuitas.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_GRATUITAS);
								//gratuitas.setTotalVentas(decimal.format(venta.getImpTotal()));
								gratuitas.setTotalVentas(decimal.format(venta.getValOpGratuitas()));
								
								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0){
									cab.setGratuitas(null);
								}else{
									cab.setGratuitas(gratuitas);
								}
								
								String codTipTributo = "";
								
								if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_EXPORTACION;
								}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_IGV;
								}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_EXONERADO;
								}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_INAFECTO;
								}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
									codTipTributo = Constantes.COD_VALOR_TIPO_TRIBUTO_GRATUITO;
								}
								
								StructureJsonTotalImpuestosNCNDCpeBean totalImpuestosCab = new StructureJsonTotalImpuestosNCNDCpeBean();
								totalImpuestosCab.setIdImpuesto(codTipTributo);
								totalImpuestosCab.setMontoImpuesto(decimal.format(venta.getIgv()));
								
								List<StructureJsonTotalImpuestosNCNDCpeBean> listTotalImpCab = new ArrayList<StructureJsonTotalImpuestosNCNDCpeBean>();
								listTotalImpCab.add(totalImpuestosCab);
								
								cab.setTotalImpuestos(listTotalImpCab);
								cab.setSumOtrosCargos(venta.getImpOtros() == null ? null : (venta.getImpOtros().compareTo(BigDecimal.ZERO) == 0) ? null : decimal.format(venta.getImpOtros()));
								
								//StructureJsonTotalDescuentosNCNDCpeBean totalDescuentos = new StructureJsonTotalDescuentosNCNDCpeBean();
								//totalDescuentos.setCodigo(Constantes.COD_VALOR_CONCEPTO_TRIB_TOTAL_DESCUENTOS);
								//totalDescuentos.setTotalDescuentos("0.00");
								
								if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
								{
									cab.setImporteTotal(decimal.format(BigDecimal.ZERO));
									cab.setTipoOperacion(Constantes.COD_VALOR_TIPO_OPERACION_VENTA_SIN_DETRACCION);
								}
								else {
									cab.setImporteTotal(decimal.format(venta.getImpTotal()));
								}
								
								StructureJsonLeyendaNCNDCpeBean leyenda = new StructureJsonLeyendaNCNDCpeBean();
								leyenda.setCodigo(Constantes.CODIGO_LEYENDA_CPE);
								
								if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0) // Gratuitas se envia monto cero en letras
									leyenda.setDescripcion(new NumeroToLetra().convertir(decimal.format(BigDecimal.ZERO), true, venta.getNombreMoneda()));
								else
									leyenda.setDescripcion(new NumeroToLetra().convertir(decimal.format(venta.getImpTotal()), true, venta.getNombreMoneda()));
								
								List<StructureJsonLeyendaNCNDCpeBean> listLeyenda = new ArrayList<StructureJsonLeyendaNCNDCpeBean>();
								listLeyenda.add(leyenda);
								
								if (venta.getFlgDetraccion().equals(Constantes.FLG_DETRACCION_SI)) // Agregamos leyenda de Detracción
								{
									StructureJsonLeyendaNCNDCpeBean leyendaDetrac = new StructureJsonLeyendaNCNDCpeBean();
									leyendaDetrac.setCodigo(Constantes.CODIGO_LEYENDA_DETRACCION_CPE);
									leyendaDetrac.setDescripcion(Constantes.COD_VALOR_MSJE_DETRACCION_ESCON);
									
									listLeyenda.add(leyendaDetrac);
								}
								
								if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0) // Agregamos leyenda de Gratuitas
								{
									StructureJsonLeyendaNCNDCpeBean leyendaGratuitas = new StructureJsonLeyendaNCNDCpeBean();
									leyendaGratuitas.setCodigo(Constantes.CODIGO_LEYENDA_GRATUITAS_CPE);
									leyendaGratuitas.setDescripcion(Constantes.COD_VALOR_MSJE_GRATUITAS_ESCON);
									
									listLeyenda.add(leyendaGratuitas);
								}
								
								cab.setLeyenda(listLeyenda);
								
								if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
								{
									cab.setMontoTotalImpuestos(decimal.format(BigDecimal.ZERO));
								}
								else
								{
									cab.setMontoTotalImpuestos(decimal.format(venta.getIgv()));
								}
								
								structureJson.setCAB(cab);
								
/**TIP_PER0100_CC14 INICIO 2019/06/18 - 19:18 - Se comenta el código que permite generar la lista de detalles de la escructura Json para Nota de Crédito y Débito*/
//								SocioCpeBean socioBean = new SocioCpeBean();
//								socioBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
//								List<SocioCpeBean> listSocio = new ArrayList<SocioCpeBean>();
//								listSocio = socioCpeService.listarSocio(socioBean);
//								SocioCpeBean socioResponse = listSocio.get(0);
//								
//								ProductoCpeBean productoBean = new ProductoCpeBean();
//								productoBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
//								productoBean.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
//								List<ProductoCpeBean> listProducto = new ArrayList<ProductoCpeBean>();
//								listProducto = productoCpeService.listarProducto(productoBean);
//								ProductoCpeBean productoResponse = listProducto.get(0);
//								
//								String valorUnitario = "";
//								BigDecimal igv = BigDecimal.ZERO;
//								BigDecimal dividendo = BigDecimal.ONE;
//								
//								ParametroCpeBean parametroRequest = new ParametroCpeBean();
//								parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
//								parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
//								List<ParametroCpeBean> listPrm = parametroCpeService.listarParametro(parametroRequest);
//								for(ParametroCpeBean prm : listPrm){
//									if(prm.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_GENERAL_IGV)){
//										igv = new BigDecimal(prm.getNomValor());
//									}
//								}
//								
//								dividendo = dividendo.add(igv);
//								
//								if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
//									if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0 ){
//										valorUnitario = decimal.format(venta.getImpTotal());
//									}else{
//										valorUnitario = decimal.format(venta.getBaseImponible());
//									}
//								}else{
//									if(conf.getAfectoIgv() == 0){
//										valorUnitario = decimal.format(venta.getImpTotal());
//									}else{
//										valorUnitario = decimal.format(venta.getBaseImponible());
//									}
//								}
//								
//								String montoImpuesto = "";
//								
//								if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(venta.getImpTotal().divide(dividendo, 2, RoundingMode.HALF_UP));
//								}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(venta.getImpTotal().divide(dividendo, 2, RoundingMode.HALF_UP));
//								}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(BigDecimal.ZERO);
//								}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(BigDecimal.ZERO);
//								}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									montoImpuesto = decimal.format(BigDecimal.ZERO);
//								}
//								
//								String tipoAfectacion = "";
//								
//								if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_FACT_EXPORT;
//								}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_BASE_IMPONIBLE;
//								}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_IMP_EXONERADO;
//								}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_INAFECTO;
//								}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									tipoAfectacion = venta.getTipoAfectacion().toString();
//								}
//								
//								StructureJsonDETNCNDCpeBean det = new StructureJsonDETNCNDCpeBean();
//								det.setNumeroItem("1");
//								//det.setCodigoProducto();
//								
////								if(venta.getIdOrigen().trim().equals(Constantes.COD_ORIGEN_UPLOAD)){
////									//Seguros
////									det.setDescripcionProducto("PRIMA DE SEGUROS - " + socioResponse.getNomSocio().trim().toUpperCase() + " / " + productoResponse.getNomProducto().trim().toUpperCase());
////								}else{
////									//archivo
////									det.setDescripcionProducto(venta.getConcepto().toUpperCase());
////								}
//								
//								if(venta.getTipoProducto().trim().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)
//									/*TIP_PER0100_CC09_13 INICIO 2019/06/03 - 16:44 - Se valida concepto tipo ND/NC igual a 10*/
//									|| venta.getConcepNd().equals(Constantes.COD_MOTIVO_SUNAT_OTROS)
//									/*TIP_PER0100_CC09_13 FIN */
//										){
//									//Administrativo
//									det.setDescripcionProducto(venta.getConcepto().toUpperCase());
//								}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
//									//Seguros
//									det.setDescripcionProducto("PRIMA DE SEGUROS - " + socioResponse.getNomSocio().trim().toUpperCase() + " / " + productoResponse.getNomProducto().trim().toUpperCase());
//								}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
//									//Servicios
//									det.setDescripcionProducto(venta.getConcepto().toUpperCase());
//								}
//								
//								det.setCantidadItems("1.00");
//								det.setUnidad(Constantes.COD_NUMBER_OF_INTERNATIONAL_UNITS);
//								if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
//								{
//									det.setValorUnitario(decimal.format(BigDecimal.ZERO));
//									det.setPrecioVentaUnitario(decimal.format(BigDecimal.ZERO));
//								}else {
//									det.setValorUnitario(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
//									det.setPrecioVentaUnitario(decimal.format(venta.getImpTotal()));
//								}
//								
//								StructureJsonTotalImpuestosDetNCNDCpeBean totalImpuestos = new StructureJsonTotalImpuestosDetNCNDCpeBean();
//								totalImpuestos.setIdImpuesto(codTipTributo);
//								totalImpuestos.setMontoImpuesto(decimal.format(venta.getIgv()));
//								totalImpuestos.setTipoAfectacion(tipoAfectacion);
//								
//								String montoBase = "";
//								
//								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									montoBase = decimal.format(venta.getValOpGratuitas());
//								}else{
//									montoBase = valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario;
//								}
//								
//								totalImpuestos.setMontoBase(montoBase);
//								
//								if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
//									if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0){
//										igv = new BigDecimal(0.00);
//									}
//								}else{
//									if(conf.getAfectoIgv() == 0){
//										igv = new BigDecimal(0.00);
//									}
//								}
//								
//								totalImpuestos.setPorcentaje(decimal.format(igv.multiply(new BigDecimal(100.00))));
//								
//								List<StructureJsonTotalImpuestosDetNCNDCpeBean> listTlimp = new ArrayList<StructureJsonTotalImpuestosDetNCNDCpeBean>();
//								listTlimp.add(totalImpuestos);
//								
//								det.setTotalImpuestos(listTlimp);
//								det.setValorVenta(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
//								
//								String onerosas = "";
//								
//								if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
//									onerosas = decimal.format(venta.getValOpGratuitas());
//								}else{
//									onerosas = null;
//								}
//								
//								det.setValorRefOpOnerosas(onerosas);
//								det.setCodProductoSunat(venta.getCodProdSunat() == null ? "" :String.valueOf(venta.getCodProdSunat()));
//								
//								//det.setCodProductoSunat(); det.setCodNumeroContrato(); det.setNumeroContrato();
//								//det.setCodFechaOtorgCredito(); det.setFechaOtorgCredito(); det.setCodTipoPrestamo(); det.setTipoPrestamo();
//								//det.setCodPartidaRegistral(); det.setPartidaRegistral(); det.setCodIndicadorPrimViv(); det.setIndicadorPrimViv();
//								//det.setCodDireccionPredio(); det.setDireccionPredio(); det.setCodCodigoUbigeo(); det.setCodigoUbigeo();
//								//det.setCodUrbanizacion(); det.setUrbanizacion(); det.setCodDepartamento(); det.setDepartamento();
//								//det.setCodProvincia(); det.setProvincia(); det.setCodDistrito(); det.setDistrito();
//								det.setMontoTotalImpuestos(decimal.format(venta.getIgv().add(venta.getIsc()).add(venta.getImpOtros())));
//								
//								List<StructureJsonDETNCNDCpeBean> listDet = new ArrayList<StructureJsonDETNCNDCpeBean>();
//								listDet.add(det);
//								
//								structureJson.setDET(listDet);
/**TIP_PER0100_CC14 FIN*/								
								
								/**TIP_PER0100_CC14 INICIO 2019/06/18 - 19:11 - Se llama al método que permite generar la lista de detalles de la escructura Json para Nota de Crédito y Débito*/
								List<StructureJsonDETNCNDCpeBean> listDet = new ArrayList<StructureJsonDETNCNDCpeBean>();
								listDet = obtenerDETNCNDStructuraJson(venta, conf,codTipTributo);
								structureJson.setDET(listDet);
								/**TIP_PER0100_CC14 FIN*/
								
								
								// Agregamos parte ADI de Detracción
								if (venta.getFlgDetraccion().equals(Constantes.FLG_DETRACCION_SI))
								{
									String nro_cuenta = null;
									Double imp_detraccion = null;
									Double porcentaje = null;
									String mensaje = null;
									
									List<StructureJsonADINCNDCpeBean> listAdicional = new ArrayList<StructureJsonADINCNDCpeBean>();
									StructureJsonADINCNDCpeBean valor1  = new StructureJsonADINCNDCpeBean();

									valor1.setTituloAdicional(listParamDetrac.get(0).getCodValor().toString());
									valor1.setValorAdicional(listParamDetrac.get(0).getNomValor().toString());
//									listAdicional.add(valor1);
									
									StructureJsonADINCNDCpeBean valor2  = new StructureJsonADINCNDCpeBean();
									valor2.setTituloAdicional(listParamDetrac.get(1).getCodValor().toString());
									nro_cuenta = listParamDetrac.get(1).getNomValor().toString();
									valor2.setValorAdicional(listParamDetrac.get(1).getNomValor().toString());
//									listAdicional.add(valor2);
									
									StructureJsonADINCNDCpeBean valor3  = new StructureJsonADINCNDCpeBean();
									valor3.setTituloAdicional(listParamDetrac.get(2).getCodValor().toString());
									valor3.setValorAdicional(listParamDetrac.get(2).getNomValor().toString());
//									listAdicional.add(valor3);
									
									StructureJsonADINCNDCpeBean valor4  = new StructureJsonADINCNDCpeBean();
									valor4.setTituloAdicional(listParamDetrac.get(3).getCodValor().toString());
									imp_detraccion = Double.parseDouble(venta.getImpDetraccion().toString());
									valor4.setValorAdicional(Utilitarios.formateoMonto(imp_detraccion));
//									listAdicional.add(valor4);

									StructureJsonADINCNDCpeBean valor5  = new StructureJsonADINCNDCpeBean();
									valor5.setTituloAdicional(Constantes.COD_VALOR_MSJE_DETRACCION_ESCON);
									mensaje = listParamDetrac.get(4).getNomValor().toString();
									/*TIP_PER0100_CC09_13 INICIO 2019/05/16 - 11:05 - Se comenta obtención del valor del porcentaje anterior y se agrega la nueva forma de obtener el porcentaje*/
//									porcentaje = Double.parseDouble(listParamDetrac.get(5).getNomValor().toString());
									porcentaje = Double.parseDouble(venta.getPorcDetraccion().toString());
									/*TIP_PER0100_CC09_13 FIN*/
									mensaje = mensaje.replace("XXXXXXXXX", nro_cuenta).replace("YYY.YY", Utilitarios.formateoMonto(imp_detraccion)).replace("ZZZ.ZZ", Utilitarios.formateoMonto(porcentaje));
									mensaje = mensaje.replace("\\n", "\n");
									valor5.setValorAdicional(mensaje);
									listAdicional.add(valor5);
									
									structureJson.setADI(listAdicional);
								}
								
								/*TIP_PER0100_CC09_13 INICIO 2019/05/06 - 17:15 - Se inserta en la estructura JSON los datos adicionales de titulo y valor*/
								List<StructureJsonADINCNDCpeBean> listAdicional = new ArrayList<StructureJsonADINCNDCpeBean>();
								listAdicional = structureJson.getADI();
								if(listAdicional==null){
									if(venta.getTituloAdicional()!=null && venta.getValorAdicional()!=null
											&& !venta.getTituloAdicional().trim().equals("") && !venta.getValorAdicional().trim().equals("")){
										listAdicional = new ArrayList<StructureJsonADINCNDCpeBean>();
										StructureJsonADINCNDCpeBean tituloValor  = new StructureJsonADINCNDCpeBean();
										tituloValor.setTituloAdicional(venta.getTituloAdicional());
										tituloValor.setValorAdicional(venta.getValorAdicional());
										listAdicional.add(tituloValor);
										structureJson.setADI(listAdicional);
									}
								}else{
									if(venta.getTituloAdicional()!=null && venta.getValorAdicional()!=null
											&& !venta.getTituloAdicional().trim().equals("") && !venta.getValorAdicional().trim().equals("")){
										StructureJsonADINCNDCpeBean tituloValor  = new StructureJsonADINCNDCpeBean();
										tituloValor.setTituloAdicional(venta.getTituloAdicional());
										tituloValor.setValorAdicional(venta.getValorAdicional());
										listAdicional.add(tituloValor);
										structureJson.setADI(listAdicional);
									}
								}
								/*TIP_PER0100_CC09_13 FIN*/
								
								StructureJsonRootCpeBean root = new StructureJsonRootCpeBean();
								
								if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO)){
									root.setNotaCredito(structureJson);
								}else if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO)){
									root.setNotaDebito(structureJson);
								}
								
								Gson gson = new Gson();
								jsonGenerated = gson.toJson(root);
							}
							
							String flg_prod_test = listarParametro(Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST
													, Constantes.COD_PARAM_CPE_FLG_SW_PROD_TEST_FLG_SW_PROD_TEST);
							
							String URL = "";
							if(flg_prod_test.equals(Constantes.CPE_CODIGO_PROD)){
								URL = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_PARAM_ESCON_SW_PRD_URL_SW_PRD);
							}else if(flg_prod_test.equals(Constantes.CPE_CODIGO_TEST)){
								URL = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_PARAM_ESCON_SW_TST_URL_SW_TST);
							}
							
							String username = "";
							String password = "";
							
							String rucEmisor = "";
							
							if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
								//Seguros
								ParametroCpeBean parametro = new ParametroCpeBean();
								parametro.setCodParam(Constantes.COD_PARAM_CPE_CARDIF_SEGUROS);
								parametro.setTipParam(Constantes.TIP_PARAM_DETALLE);
								
								List<ParametroCpeBean> listParam = parametroCpeService.listarParametro(parametro);
								
								for(ParametroCpeBean param : listParam){
									if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RUC)){
										rucEmisor = param.getNomValor().trim();
									}
								}
								
								if(flg_prod_test.equals(Constantes.CPE_CODIGO_PROD)){
									username = rucEmisor + listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_USU_SW_PRD_SEG);
									password = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_PASS_SW_PRD_SEG);
								}else if(flg_prod_test.equals(Constantes.CPE_CODIGO_TEST)){
									username = rucEmisor + listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_USU_SW_TST_SEG);
									password = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_PASS_SW_TST_SEG);
								}
								
							}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
								//Servicios
								ParametroCpeBean parametro = new ParametroCpeBean();
								parametro.setCodParam(Constantes.COD_PARAM_CPE_CARDIF_SERVICIOS);
								parametro.setTipParam(Constantes.TIP_PARAM_DETALLE);
								
								List<ParametroCpeBean> listParam = parametroCpeService.listarParametro(parametro);
								
								for(ParametroCpeBean param : listParam){
									if(param.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_EMPRESA_RUC)){
										rucEmisor = param.getNomValor().trim();
									}
								}
								
								if(flg_prod_test.equals(Constantes.CPE_CODIGO_PROD)){
									username = rucEmisor + listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_USU_SW_PRD_SERV);
									password = listarParametro(Constantes.COD_PARAM_ESCON_SW_PRD, Constantes.COD_VALOR_PASS_SW_PRD_SERV);
								}else if(flg_prod_test.equals(Constantes.CPE_CODIGO_TEST)){
									username = rucEmisor + listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_USU_SW_TST_SERV);
									password = listarParametro(Constantes.COD_PARAM_ESCON_SW_TST, Constantes.COD_VALOR_PASS_SW_TST_SERV);
								}

							}
							
							String filename = rucEmisor + "-" + venta.getIdTipoComp().trim() + "-" + numComprobante + ".json";
							String fileContent = "";
							
							try {
								String ruta = filename;
							    File archivo = new File(ruta);
							    BufferedWriter bw;
							    if(archivo.exists()) {
							    	bw = new BufferedWriter(new PrintWriter(archivo, "UTF8"));
							        bw.write(jsonGenerated);
							    } else {
							        bw = new BufferedWriter(new PrintWriter(archivo, "UTF8"));
							        bw.write(jsonGenerated);
							    }
							    bw.close();
							    
						        FileInputStream fis = new FileInputStream(archivo);
						        ByteArrayOutputStream bos = new ByteArrayOutputStream();
						        byte[] buf = new byte[1024];
					            for (int readNum; (readNum = fis.read(buf)) != -1;) {
					                bos.write(buf, 0, readNum);
					            }
						        byte[] bytes = bos.toByteArray();
						        
						        Base64 codec = new Base64();
						        byte[] encoded = codec.encode(bytes);
//						        fileContent = new String(encoded, "UTF-8");
						        fileContent = new String(encoded);
						        
						        StructureJsonRequestCpeBean requestBean = new StructureJsonRequestCpeBean();
						        StructureJsonCustomerCpeBean customer = new StructureJsonCustomerCpeBean();
						        customer.setUsername(username);
						        customer.setPassword(password);
						        requestBean.setCustomer(customer);
						        requestBean.setFileName(filename);
						        requestBean.setFileContent(fileContent);
						        
						        Gson gsonRequest = new GsonBuilder().disableHtmlEscaping().create();
						        String jsonRequest = gsonRequest.toJson(requestBean);
						        
						        JerseyClientCpe restClient = new JerseyClientCpe();
						        
						        String output = restClient.sendCEPost(jsonRequest, URL);
						        
						        Gson gsonResponse = new GsonBuilder().disableHtmlEscaping().create();
						        StructureJsonResponseCpeBean response = gsonResponse.fromJson(output, StructureJsonResponseCpeBean.class);
						        
						        if(!response.getResponseCode().equals(Constantes.COD_SCON_RESPONSE_OK)){
						        	flgErrores = true;
						        }
						        
						        ComprobanteCpeBean comprobanteCpeBean = new ComprobanteCpeBean();
						        comprobanteCpeBean.setEstadoComp(response.getResponseCode().equals(Constantes.COD_SCON_RESPONSE_OK) ? Constantes.COD_ESTADO_VENTA_VALIDADO : response.getResponseCode().equals(Constantes.COD_SCON_RESPONSE_ERROR_ENVIO) ? Constantes.COD_ESTADO_VENTA_ERROR_ENVIO : response.getResponseCode().equals(Constantes.COD_SCON_RESPONSE_MAYOR_7_DIAS_EMISION) ? Constantes.COD_ESTADO_VENTA_ANULADO : Constantes.COD_ESTADO_VENTA_RECHAZADO);
						        comprobanteCpeBean.setNumComprobante(numComprobante);
						        comprobanteCpeBean.setDescError(response.getResponseContent());
						        comprobanteCpeBean.setIdTipoComp(venta.getIdTipoComp().trim());
						        comprobanteCpeService.actualizarEstadoComprobanteCpe(comprobanteCpeBean);
						        
						        VentaEstadoCpeBean ventaEstadoCpeBean = new VentaEstadoCpeBean();
						        ventaEstadoCpeBean.setIdVenta(venta.getIdVenta());
						        ventaEstadoCpeBean.setEstadoVenta(comprobanteCpeBean.getEstadoComp().equals(Constantes.COD_ESTADO_VENTA_ANULADO) ? Constantes.COD_ESTADO_VENTA_PENDIENTE : comprobanteCpeBean.getEstadoComp());
						        ventaEstadoCpeBean.setUsuarioCreacion(usuarioSesion);
						        procesoCpeService.guardarVentaEstadoCpe(ventaEstadoCpeBean);
						        
						        if(comprobanteCpeBean.getEstadoComp().equals(Constantes.COD_ESTADO_VENTA_ANULADO)){
						        	ProcesoVentaCpeBean procesoVentaCpeBean = new ProcesoVentaCpeBean();
						        	procesoVentaCpeBean.setIdProceso(proceso.getIdProceso());
						        	procesoVentaCpeBean.setIdVenta(venta.getIdVenta());
						        	procesoVentaCpeBean.setEstado(Constantes.INACTIVO);
						        	procesoCpeService.actualizarProcesoVentaCpe(procesoVentaCpeBean);;
						        }
						        
						        if((venta.getFlgAgrupado() == null ? "" : venta.getFlgAgrupado()).equalsIgnoreCase(Constantes.CPE_FLG_AGRUPADO)){
						        	VentaCpeBean ventaPadreRequest = new VentaCpeBean();
						        	ventaPadreRequest.setIdVenta(venta.getIdVenta());
						        	
						        	List<VentaCpeBean> listChild = procesoCpeService.listarAgrupadoChild(ventaPadreRequest);
						        	
						        	for(VentaCpeBean child : listChild){
						        		VentaEstadoCpeBean ventaEstadoBean = new VentaEstadoCpeBean();
						        		ventaEstadoBean.setIdVenta(child.getIdVenta());
						        		ventaEstadoBean.setEstadoVenta(comprobanteCpeBean.getEstadoComp().equals(Constantes.COD_ESTADO_VENTA_ANULADO) ? Constantes.COD_ESTADO_VENTA_PENDIENTE : comprobanteCpeBean.getEstadoComp());
						        		ventaEstadoBean.setUsuarioCreacion(usuarioSesion);
								        procesoCpeService.guardarVentaEstadoCpe(ventaEstadoBean);
						        	}
						        }
						        
						        //////////////////////////////////////////////////
//						        responseJson.append("Id Venta: " + venta.getIdVenta().toString() + "-"
//			    				+ "Id Empresa: " + venta.getIdEmpresa() + "-"
//			    				+ "Id Tipo Comp: " + venta.getIdTipoComp().toString()
//			    				+ "\r\n"
//			    				+ jsonGenerated
//			    				+ "\r\n"
//			    				+ jsonRequest
//			    				+ "\r\n"
//			    				+ output
//			    				+ "\r\n");
						        ////////////////////////////////////////////////					        
//						        StringBuilder unitResponseJson = new StringBuilder();
//						        unitResponseJson.append("Id Venta: " + venta.getIdVenta().toString() + "-"
//					    				+ "Id Empresa: " + venta.getIdEmpresa() + "-"
//					    				+ "Id Tipo Comp: " + venta.getIdTipoComp().toString()
//					    				+ "\r\n"
//					    				+ jsonGenerated
//					    				+ "\r\n"
//					    				+ jsonRequest
//					    				+ "\r\n"
//					    				+ output
//					    				+ "\r\n");
								/////////////////////////////////////////////////
//								try {
//									String root = "C:/JSON_CPE/" + "responseJson_"+venta.getIdVenta().toString();
//								    File archive = new File(root);
//								    BufferedWriter bufferedWriter;
//								    bufferedWriter = new BufferedWriter(new FileWriter(archive));
//									bufferedWriter.write(unitResponseJson.toString());
//								    bufferedWriter.close();
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
								////////////////////////////////////////////////
						        /*byte[] decoded = codec.decode(fileContent.getBytes());
						        File someFile = new File("C:/DocumentosSteve/JSON_CPE/" + filename);
						        FileOutputStream fos = new FileOutputStream(someFile);
						        fos.write(decoded);
						        fos.flush();
						        fos.close();*/
							} catch (Exception e) {
								e.printStackTrace();
							}
							
						}else{
							ventasNoFacturar.add(venta);
						}
					}
				}else{
					ventasNoFacturar.add(venta);
				}
			}
			/////////////////////////////////////////////////
//			try {
//				String root = "C:/JSON_CPE/" + "responseJsonTotal";
//			    File archive = new File(root);
//			    BufferedWriter bufferedWriter;
//			    bufferedWriter = new BufferedWriter(new FileWriter(archive));
//			    bufferedWriter.write(responseJson.toString());
//			    bufferedWriter.close();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
			////////////////////////////////////////////////
			
			ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
			procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
			procesoEstadoCpeBean.setEstadoProceso(flgErrores ? Constantes.COD_VALOR_ESTADO_PROCESO_PROCESADO_ERRORES : Constantes.COD_VALOR_ESTADO_PROCESO_PROCESADO);
			procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
			procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
			
			ProcesoCpeBean procesoRequest = new ProcesoCpeBean();
			procesoRequest.setTipoProceso(Constantes.CPE_CODIGO_TIPO_PROCESO_ONLINE);
			procesoRequest.setFlgProcesa("0");
			procesoRequest.setIdProceso(proceso.getIdProceso());
			
			procesoCpeService.actualizarProcesoMasivoCpe(procesoRequest);
			
			inicializarFiltrosProcesadosErrorOnline();
			inicializarResultadosProcesadosErrorOnline();
			cargarCbxProcesadosErrorOnline();
			
			inicializarFiltrosProcesadosCorrectosOnline();
			inicializarResultadosProcesadosCorrectosOnline();
			cargarCbxProcesadosCorrectosOnline();
			
			filtrarProcesadosErrorOnline();
			filtrarProcesadosCorrectosOnline();
			
			SimpleDateFormat fmtOnline = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			fechaProcesoOnline = fmtOnline.format(proceso.getFechaCreacion());
			
			List<ProcesoCpeBean> procesoList = procesoCpeService.obtenerProcesoById(proceso);
			if(procesoList.get(0).getNumeroLote() == null || procesoList.get(0).getNumeroLote().trim().length() == 0){
				loteOnline = armarLote(Constantes.TIPO_PROCESO_CE_ONLINE);
			}else{
				loteOnline = procesoList.get(0).getNumeroLote();
			}
			
			if(!flgErrores){
				for(VentaCpeBean venta : listVentaError){
					
					ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
					comprobante.setIdVenta(venta.getIdVenta());
					
					List<ComprobanteCpeBean> listCpnt = comprobanteCpeService.obtenerComprobante(comprobante);
					
					if((listCpnt == null || listCpnt.isEmpty())){
						ProcesoVentaCpeBean pvBean = new ProcesoVentaCpeBean();
						pvBean.setIdProceso(proceso.getIdProceso());
						pvBean.setIdVenta(venta.getIdVenta());
						pvBean.setEstado(Constantes.ACTIVO);
						
						List<ProcesoVentaCpeBean> listpvBean = procesoCpeService.listarProcesoVentaCpeBean(pvBean);
						
						UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
						updateVentaCpeBean.setIdVentaProceso(listpvBean.get(0).getIdVentaProceso());
						procesoCpeService.eliminarUpdateVentaCpe(updateVentaCpeBean);
						
						ProcesoVentaCpeBean procesoVenta = new ProcesoVentaCpeBean();
						procesoVenta.setIdVenta(venta.getIdVenta());
						procesoVenta.setIdProceso(proceso.getIdProceso());
						procesoCpeService.eliminarVentaProcesoCpe(procesoVenta);
					}
				}
			}
		}	/**TIP_PER0100_FASE02 INICIO 2019/11/26 - 11:32 - Se agrega la lógica para el proceso online resumen.*/
		else if (tipoProcesoCe.equals(Constantes.TIPO_PROCESO_CE_ONLINE_RESUMEN)){
			redirect = "toProcesoMasivoResumen";

			
			if (listVentaError.size() > 0){
				for(VentaCpeBean venta : listVentaError){
					
					ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
					comprobante.setIdVenta(venta.getIdVenta());
					
					List<ComprobanteCpeBean> listCpnt = comprobanteCpeService.obtenerComprobante(comprobante);
					
					if((listCpnt == null || listCpnt.isEmpty())){
						ProcesoVentaCpeBean pvBean = new ProcesoVentaCpeBean();
						pvBean.setIdProceso(proceso.getIdProceso());
						pvBean.setIdVenta(venta.getIdVenta());
						pvBean.setEstado(Constantes.ACTIVO);
						
						List<ProcesoVentaCpeBean> listpvBean = procesoCpeService.listarProcesoVentaCpeBean(pvBean);
						
						UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
						updateVentaCpeBean.setIdVentaProceso(listpvBean.get(0).getIdVentaProceso());
						procesoCpeService.eliminarUpdateVentaCpe(updateVentaCpeBean);
						
						ProcesoVentaCpeBean procesoVenta = new ProcesoVentaCpeBean();
						procesoVenta.setIdVenta(venta.getIdVenta());
						procesoVenta.setIdProceso(proceso.getIdProceso());
						procesoCpeService.eliminarVentaProcesoCpe(procesoVenta);
					}
				}
			}
			
			/**TIP_PER0100_FASE02 FIN 2019/12/26 - 11:55 - Se agrega la lógica para la actualización del número de lote.*/
			SimpleDateFormat fmtOnline = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			fechaProcesoOnline = fmtOnline.format(proceso.getFechaCreacion());
			
			List<ProcesoCpeBean> procesoList = procesoCpeService.obtenerProcesoById(proceso);
			String numeroLote = "";
			if(procesoList.get(0).getNumeroLote() == null || procesoList.get(0).getNumeroLote().trim().length() == 0){
				numeroLote = armarLote(Constantes.TIPO_PROCESO_CE_ONLINE_RESUMEN);
			}else{
				numeroLote = procesoList.get(0).getNumeroLote();
			}
			ProcesoCpeBean procesoRequest = new ProcesoCpeBean();
			procesoRequest.setNumeroLote(numeroLote);
			procesoRequest.setIdProceso(proceso.getIdProceso());
			
			procesoCpeService.actualizarProcesoLoteCpe(procesoRequest);
			/**TIP_PER0100_FASE02 FIN 2019/12/26 - 11:55 - Se agrega la lógica para la actualización del número de lote.*/
			
			procesoRequest = new ProcesoCpeBean();
			procesoRequest.setTipoProceso(Constantes.CPE_CODIGO_TIPO_PROCESO_ONLINE_RESUMEN);
			procesoRequest.setFlgProcesa(Constantes.CPE_FLG_PROCESAR_ONLINE_RESUMEN);
			procesoRequest.setIdProceso(proceso.getIdProceso());
			
			procesoCpeService.actualizarProcesoMasivoCpe(procesoRequest);
			
			ParametroCpeBean prmPackage = new ParametroCpeBean();
			prmPackage.setCodParam(Constantes.COD_PARAM_FLG_SSIS_CE);
			prmPackage.setTipParam(Constantes.TIP_PARAM_DETALLE);
			List<ParametroCpeBean> listPrmPkg = parametroCpeService.listarParametro(prmPackage);
			
			String indGenera = "";
			
			for(ParametroCpeBean prm : listPrmPkg){
				if(prm.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_PACKAGE_RESUMEN_FLG)){
					indGenera = prm.getNomValor().trim();
				}
			}
			
			if(indGenera.equalsIgnoreCase(Constantes.FLG_SSIS_GENERARESUMEN_ESCON_GENERAR)){
				try {
					logger.info("Inicio PACKAGE GENERA Online Resumen Seguros");
					ssisService.lanzarJob(Constantes.CPE_JOB_NAME_SAT_CPE_SERVICIOS_RESUMEN);	//SERVICIOS			
					ParametroCpeBean prmSSIS = new ParametroCpeBean();
					prmSSIS.setNomValor(Constantes.FLG_SSIS_GENERARESUMEN_ESCON_OCUPADO);
					prmSSIS.setUsuModifica(usuarioSesion);
					prmSSIS.setCodParam(Constantes.COD_PARAM_FLG_SSIS_CE);
					prmSSIS.setTipParam(Constantes.TIP_PARAM_DETALLE);
					prmSSIS.setCodValor(Constantes.COD_VALOR_PACKAGE_RESUMEN_FLG);
					parametroCpeService.actualizarParametro(prmSSIS);
					logger.info("Fin GENERA Online Resumen Seguros");
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(e.getMessage());
				}
			}
			
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_PROCESO_RESUMEN_ENVIADO);
		}/**TIP_PER0100_FASE02 FIN 2019/11/26 - 11:32 - Se agrega la lógica para el proceso online resumen.*/
		else{
			redirect = "toProcesoMasivo";
			
//			List<VentaCpeBean> ventasFacturar = new ArrayList<VentaCpeBean>();
//			List<VentaCpeBean> ventasNoFacturar = new ArrayList<VentaCpeBean>();
//			
//			for(VentaCpeBean venta : listaProcesarVentas){
//				setUbigeoDescACod(venta);
//				if((venta.getIdEmpresa() != null && venta.getIdEmpresa().trim().length() != 0) 
//						&& (venta.getIdSocio() != null)
//						&& (venta.getIdProducto() != null)
//						&& (venta.getIdTipoComp() != null && venta.getIdTipoComp().trim().length() != 0)){
//					if(venta.getIdTipoComp().trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA) 
//							&& venta.getNumDocCli().trim().length() != 11){
//						ventasNoFacturar.add(venta);
//					}else{
//						ConfiguracionCpeBean config = new ConfiguracionCpeBean();
//						config.setIdEmpresa(venta.getIdEmpresa());
//						config.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
//						config.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
//						config.setIdTipoComp(venta.getIdTipoComp());
//						config.setEstadoConfig(Constantes.ACTIVO);
//						
//						List<ConfiguracionCpeBean> listConfiguracion = configuracionCpeService.listarConfiguracionCpe(config);
//						
//						if(listConfiguracion != null && !listConfiguracion.isEmpty()){
//							ConfiguracionCpeBean conf = listConfiguracion.get(0);
//							String prefijo = "";
//							String serie = "";
//							int corrInt = 0;
//							String corrStr = "";
//							String numComprobante="";
//							Date fechaEmision = null;
//							
//							ComprobanteCpeBean compCpeBeanRequest = new ComprobanteCpeBean();
//							compCpeBeanRequest.setIdVenta(venta.getIdVenta());
//							List<ComprobanteCpeBean> listCompCpeBeanRequest = comprobanteCpeService.obtenerComprobante(compCpeBeanRequest);
//							
//							if(listCompCpeBeanRequest == null || listCompCpeBeanRequest.isEmpty() || listCompCpeBeanRequest.size() == 0){
//								
//								if(venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_CREDITO) 
//										|| venta.getIdTipoComp().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_NOTA_DEBITO)){
//									prefijo = venta.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA) 
//											? Constantes.CPE_PREFIJO_BOLETA : venta.getIdTipoCompRef().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA) 
//													? Constantes.CPE_PREFIJO_FACTURA : "";
//								}else{
//									prefijo = conf.getPrefijo() == null ? "" : conf.getPrefijo();
//								}
//								
//								serie = conf.getSerie().trim();
//								
//								corrInt = conf.getCorActual() == null ? conf.getCorInicial() : conf.getCorActual() + 1;
//								
//								corrStr = String.format("%08d", corrInt);
//								
//								numComprobante = prefijo + serie + "-" + corrStr;
//								
//								ConfiguracionCpeBean bean = new ConfiguracionCpeBean();
//								bean.setIdEmpresa(venta.getIdEmpresa());
//								bean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
//								bean.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
//								bean.setIdTipoComp(venta.getIdTipoComp());
//								bean.setEstadoConfig(Constantes.ACTIVO);
//								bean.setCorActual(corrInt);
//								bean.setUsuModifica(usuarioSesion);
//								
//								configuracionCpeService.actualizarCorrelativo(bean);
//								
//								ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
//								comprobante.setIdVenta(venta.getIdVenta());
//								comprobante.setIdTipoComp(venta.getIdTipoComp());
//								
//								ProcesoVentaCpeBean procesoVentaCpeBean = new ProcesoVentaCpeBean();
//								procesoVentaCpeBean.setIdProceso(proceso.getIdProceso());
//								procesoVentaCpeBean.setIdVenta(venta.getIdVenta());
//								procesoVentaCpeBean.setEstado(Constantes.ACTIVO);
//								List<ProcesoVentaCpeBean> listProcesoVenta = procesoCpeService.listarProcesoVentaCpeBean(procesoVentaCpeBean);
//								ProcesoVentaCpeBean procesoVentaCpeBeanResponse = listProcesoVenta.get(0);
//								
//								comprobante.setIdVentaProceso(procesoVentaCpeBeanResponse.getIdVentaProceso());
//								comprobante.setIdEmpresa(venta.getIdEmpresa());
//								comprobante.setIdSocio(venta.getIdSocio());
//								comprobante.setIdProducto(venta.getIdProducto());
//								comprobante.setSerieComp(serie);
//								comprobante.setCorrComp(corrStr);
//								
//								CargaVentaCabCpeBean cargaBean = new CargaVentaCabCpeBean();
//								cargaBean.setIdCarga(venta.getIdCarga());
//								List<CargaVentaCabCpeBean> listCarga = procesoCpeService.listarCargaVentaCab(cargaBean);
//								CargaVentaCabCpeBean cargaVentaCabCpeBeanResponseBean = listCarga.get(0);
//								if(cargaVentaCabCpeBeanResponseBean.getIdOrigen().trim().equals(Constantes.COD_ORIGEN_ARCHIVO)){
//									
//									ParametroCpeBean parametroCpeBean = new ParametroCpeBean();
//									parametroCpeBean.setCodParam(Constantes.COD_PARAM_CONTA_AUTH);
//									parametroCpeBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
//									List<ParametroCpeBean> listAuth = new ArrayList<ParametroCpeBean>();
//									listAuth = parametroCpeService.listarParametro(parametroCpeBean);
//									
//									ParametroCpeBean paramAuth = new ParametroCpeBean();
//									for(ParametroCpeBean auth : listAuth){
//										if(auth.getCodValor().trim().equalsIgnoreCase(Constantes.COD_PARAM_CONTA_AUTH_CONTA_AUTH)){
//											paramAuth = auth;
//										}
//									}
//									
//									String[] authArray = paramAuth.getNomValor().split("|");
//									boolean indAuth = false;
//									for(int i=0 ; i<authArray.length; i++){
//										if(authArray[i].trim().equalsIgnoreCase(cargaVentaCabCpeBeanResponseBean.getUsuarioCarga().trim())){
//											indAuth = true;
//											break;
//										}
//									}
//									
//									if(indAuth){
//										fechaEmision = getStringToDate(venta.getFechaEmision());
//									}else{
//										fechaEmision = new Date();
//									}
//									
//								}else{
//									fechaEmision = new Date();
//								}
//								
//								comprobante.setFecEmision(fmt.format(fechaEmision));
//								comprobante.setEstadoComp(Constantes.COD_ESTADO_VENTA_PENDIENTE);
//								comprobante.setUsuCrea(usuarioSesion);
//								comprobante.setNumComprobante(numComprobante);
//								
//								comprobanteCpeService.insertarComprobanteCpe(comprobante);
//							}else{
//								ComprobanteCpeBean comp = listCompCpeBeanRequest.get(0);
//								numComprobante = comp.getNumComprobante();
//								fechaEmision = comp.getFechaEmisionDate();
//							}
//							
//							ComprobanteCpeBean comprobanteCpeBean = new ComprobanteCpeBean();
//					        comprobanteCpeBean.setEstadoComp(Constantes.COD_ESTADO_VENTA_ENVIADO);
//					        comprobanteCpeBean.setNumComprobante(numComprobante);
//					        comprobanteCpeService.actualizarEstadoComprobanteCpe(comprobanteCpeBean);
//					        
//					        VentaEstadoCpeBean ventaEstadoCpeBean = new VentaEstadoCpeBean();
//					        ventaEstadoCpeBean.setIdVenta(venta.getIdVenta());
//					        ventaEstadoCpeBean.setEstadoVenta(Constantes.COD_ESTADO_VENTA_ENVIADO);
//					        ventaEstadoCpeBean.setUsuarioCreacion(usuarioSesion);
//					        procesoCpeService.guardarVentaEstadoCpe(ventaEstadoCpeBean);
//							
//						}else{
//							ventasNoFacturar.add(venta);
//						}
//					}
//				}else{
//					ventasNoFacturar.add(venta);
//				}
//			}
			
			if (listVentaError.size() > 0){
				for(VentaCpeBean venta : listVentaError){
					
					ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
					comprobante.setIdVenta(venta.getIdVenta());
					
					List<ComprobanteCpeBean> listCpnt = comprobanteCpeService.obtenerComprobante(comprobante);
					
					if((listCpnt == null || listCpnt.isEmpty())){
						ProcesoVentaCpeBean pvBean = new ProcesoVentaCpeBean();
						pvBean.setIdProceso(proceso.getIdProceso());
						pvBean.setIdVenta(venta.getIdVenta());
						pvBean.setEstado(Constantes.ACTIVO);
						
						List<ProcesoVentaCpeBean> listpvBean = procesoCpeService.listarProcesoVentaCpeBean(pvBean);
						
						UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
						updateVentaCpeBean.setIdVentaProceso(listpvBean.get(0).getIdVentaProceso());
						procesoCpeService.eliminarUpdateVentaCpe(updateVentaCpeBean);
						
						ProcesoVentaCpeBean procesoVenta = new ProcesoVentaCpeBean();
						procesoVenta.setIdVenta(venta.getIdVenta());
						procesoVenta.setIdProceso(proceso.getIdProceso());
						procesoCpeService.eliminarVentaProcesoCpe(procesoVenta);
					}
				}
			}
			
			ProcesoCpeBean procesoRequest = new ProcesoCpeBean();
			procesoRequest.setTipoProceso(Constantes.CPE_CODIGO_TIPO_PROCESO_MASIVO);
			procesoRequest.setFlgProcesa(Constantes.CPE_FLG_PROCESAR_MASIVO);
			procesoRequest.setIdProceso(proceso.getIdProceso());
			
			procesoCpeService.actualizarProcesoMasivoCpe(procesoRequest);
			
			ParametroCpeBean prmPackage = new ParametroCpeBean();
			prmPackage.setCodParam(Constantes.COD_PARAM_FLG_SSIS_CE);
			prmPackage.setTipParam(Constantes.TIP_PARAM_DETALLE);
			List<ParametroCpeBean> listPrmPkg = parametroCpeService.listarParametro(prmPackage);
			
			String indGenera = "";
			
			for(ParametroCpeBean prm : listPrmPkg){
				if(prm.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_PACKAGE_TXT_FLG)){
					indGenera = prm.getNomValor().trim();
				}
			}
			
			if(indGenera.equalsIgnoreCase(Constantes.FLG_SSIS_GENERATXT_ESCON_GENERAR)){
				try {
					logger.info("Inicio PACKAGE GENERATXT Servicios");
					ssisService.lanzarJob(Constantes.CPE_JOB_NAME_PACKAGE_TXT);					
					//ssisService.lanzarJob(
					//		listaProcesarVentas.get(0).getIdEmpresa().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS) ? 
					//				Constantes.CPE_JOB_NAME_SEGUROS_PACKAGE_TXT : Constantes.CPE_JOB_NAME_PACKAGE_TXT);					
					ParametroCpeBean prmSSIS = new ParametroCpeBean();
					prmSSIS.setNomValor(Constantes.FLG_SSIS_GENERATXT_ESCON_OCUPADO);
					prmSSIS.setUsuModifica(usuarioSesion);
					prmSSIS.setCodParam(Constantes.COD_PARAM_FLG_SSIS_CE);
					prmSSIS.setTipParam(Constantes.TIP_PARAM_DETALLE);
					prmSSIS.setCodValor(Constantes.COD_VALOR_PACKAGE_TXT_FLG);
					parametroCpeService.actualizarParametro(prmSSIS);
					logger.info("Fin PACKAGE GENERATXT");
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(e.getMessage());
				}
			}
			//POSTPROCESO
//			ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
//			procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
//			procesoEstadoCpeBean.setEstadoProceso(Constantes.COD_VALOR_ESTADO_PROCESO_PROCESADO);
//			procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
//			procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
			
			inicializarFiltrosProcesoMasivo();
			logger.error("Paso inicializarFiltrosProcesoMasivo");
			//filtrarProcesoMasivo();
			//logger.error("Paso filtrarProcesoMasivo");
			
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_PROCESO_MASIVO);
		}
		return redirect;
	}
	
	/**TIP_PER0100_CC14 INICIO 2019/06/18 - 10:39 - Se crea el método método obtenerDETFCBLStructuraJson que permite generar la lista de detalles de la escructura Json*/
	private List<StructureJsonDETCpeBean> obtenerDETFCBLStructuraJson(VentaCpeBean venta,ConfiguracionCpeBean conf, String codTipTributo ){
		List<StructureJsonDETCpeBean> listDet = new ArrayList<StructureJsonDETCpeBean>();
		DecimalFormat decimal = new DecimalFormat("0.00",  new DecimalFormatSymbols(Locale.US));
		
		CargaVentaItemCpeBean cargaVentaItemCpeBean = new CargaVentaItemCpeBean();
		cargaVentaItemCpeBean.setIdVenta(venta.getIdVenta());
		listDetalleItemComprobante = procesoCpeService.listarProcesoVentaDetalleItemCpeBean(cargaVentaItemCpeBean);
		
		String valorUnitario = "";
		BigDecimal igv = BigDecimal.ZERO;
		
		ProductoCpeBean productoBean = new ProductoCpeBean();
		productoBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
		productoBean.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
		List<ProductoCpeBean> listProducto = new ArrayList<ProductoCpeBean>();
		listProducto = productoCpeService.listarProducto(productoBean);
		ProductoCpeBean productoResponse = listProducto.get(0);
		
		ParametroCpeBean parametroRequest = new ParametroCpeBean();
		parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
		parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listPrm = parametroCpeService.listarParametro(parametroRequest);
		for(ParametroCpeBean prm : listPrm){
			if(prm.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_GENERAL_IGV)){
				igv = new BigDecimal(prm.getNomValor());
			}
		}
		
		String tipoAfectacion = "";
		
		if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_FACT_EXPORT;
		}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_BASE_IMPONIBLE;
		}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_IMP_EXONERADO;
		}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_INAFECTO;
		}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = venta.getTipoAfectacion().toString();
		}
		
		if(listDetalleItemComprobante!=null && listDetalleItemComprobante.size()>0){
			int cont = 1;
			boolean aplicaIGV = true;
			if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0
				|| (venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0)
				||venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0
				||venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
				aplicaIGV = false;
			}
			
			for(CargaVentaItemCpeBean item : listDetalleItemComprobante){
				
				List<StructureJsonTotalImpuestosDetCpeBean> listTlimp = new ArrayList<StructureJsonTotalImpuestosDetCpeBean>();
				StructureJsonTotalImpuestosDetCpeBean totalImpuestos = new StructureJsonTotalImpuestosDetCpeBean();
				StructureJsonDETCpeBean det = new StructureJsonDETCpeBean();
				
				valorUnitario = "";
				String onerosas = null;
				String precioVentaUnitario="";
				BigDecimal valorUnitarioBigD = new BigDecimal(0);
				BigDecimal precioVentaUnitarioBigD = new BigDecimal(0);
				BigDecimal porcentajeIGV = new BigDecimal(0);
				
				valorUnitarioBigD = item.getValorVenta().divide(new BigDecimal(item.getCantidad()),2, RoundingMode.HALF_UP);
				valorUnitario = decimal.format(valorUnitarioBigD); 
				
				if(aplicaIGV){
					precioVentaUnitarioBigD = valorUnitarioBigD.add(valorUnitarioBigD.multiply(igv)).setScale(2, RoundingMode.HALF_UP);
					precioVentaUnitario = decimal.format(precioVentaUnitarioBigD); 
					porcentajeIGV = igv.multiply(new BigDecimal(100.00));
				}else{
					precioVentaUnitarioBigD = valorUnitarioBigD;
					precioVentaUnitario = decimal.format(precioVentaUnitarioBigD);
				}
				
				det.setNumeroItem(String.valueOf(cont));
				det.setDescripcionProducto(item.getConcepto().toUpperCase());
				det.setCantidadItems(String.valueOf(item.getCantidad()));
				det.setUnidad(Constantes.COD_NUMBER_OF_INTERNATIONAL_UNITS);
				
				if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0)
				{
					det.setValorUnitario(valorUnitario);
					det.setPrecioVentaUnitario(precioVentaUnitario);
				}
				else
				{
					det.setValorUnitario(decimal.format(BigDecimal.ZERO));
					det.setPrecioVentaUnitario(decimal.format(BigDecimal.ZERO));
				}
				
				
				totalImpuestos.setIdImpuesto(codTipTributo);
				totalImpuestos.setMontoImpuesto(decimal.format(item.getIgv()));
				totalImpuestos.setTipoAfectacion(tipoAfectacion);
				totalImpuestos.setMontoBase(decimal.format(item.getValorVenta()));
				totalImpuestos.setPorcentaje(decimal.format(porcentajeIGV));
				listTlimp.add(totalImpuestos);
				det.setTotalImpuestos(listTlimp);
				det.setValorVenta(decimal.format(item.getValorVenta()));
				
				if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
					onerosas = decimal.format(item.getValorVenta());
					det.setValorVenta(decimal.format(BigDecimal.ZERO));
				}
				
				det.setValorRefOpOnerosas(onerosas);
				det.setCodProductoSunat(venta.getCodProdSunat() == null ? "" :String.valueOf(venta.getCodProdSunat()));
				det.setMontoTotalImpuestos(decimal.format(item.getIgv()));
				
				listDet.add(det);
				cont++;
			}
		}else{
			
			StructureJsonDETCpeBean det = new StructureJsonDETCpeBean();
			
			SocioCpeBean socioBean = new SocioCpeBean();
			socioBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
			List<SocioCpeBean> listSocio = new ArrayList<SocioCpeBean>();
			listSocio = socioCpeService.listarSocio(socioBean);
			SocioCpeBean socioResponse = listSocio.get(0);
			
			if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
				if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0)
					valorUnitario = decimal.format(venta.getImpTotal());
				else
					valorUnitario = decimal.format(venta.getBaseImponible());
			}else{
				if(conf.getAfectoIgv() == 0)
					valorUnitario = decimal.format(venta.getImpTotal());
				else
					valorUnitario = decimal.format(venta.getBaseImponible());
			}

			det.setNumeroItem("1");
	
			// Antigua validacion para el concepto de item del comprobnate
			if(venta.getTipoProducto().trim().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
				//Administrativo
				det.setDescripcionProducto(venta.getConcepto().toUpperCase());
			}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
				//Seguros
				det.setDescripcionProducto("PRIMA DE SEGUROS - " + socioResponse.getNomSocio().trim().toUpperCase() + " / " + productoResponse.getNomProducto().trim().toUpperCase());
			}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
				//Servicios
				det.setDescripcionProducto(venta.getConcepto().toUpperCase());
			}
			
			det.setCantidadItems("1.00");
			det.setUnidad(Constantes.COD_NUMBER_OF_INTERNATIONAL_UNITS);
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0)
			{
				det.setValorUnitario(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
				det.setPrecioVentaUnitario(decimal.format(venta.getImpTotal()));
			}
			else
			{
				det.setValorUnitario(decimal.format(BigDecimal.ZERO));
				det.setPrecioVentaUnitario(decimal.format(BigDecimal.ZERO));
			}
			
			StructureJsonTotalImpuestosDetCpeBean totalImpuestos = new StructureJsonTotalImpuestosDetCpeBean();
			totalImpuestos.setIdImpuesto(codTipTributo);
			totalImpuestos.setMontoImpuesto(decimal.format(venta.getIgv()));
			totalImpuestos.setTipoAfectacion(tipoAfectacion);
			
			String montoBase = "";
			
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
				montoBase = decimal.format(venta.getValOpGratuitas());
			}else{
				montoBase = valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario;
			}
			
			totalImpuestos.setMontoBase(montoBase);
			
			if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
				if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0){
					igv = new BigDecimal(0.00);
				}
			}else{
				if(conf.getAfectoIgv() == 0){
					igv = new BigDecimal(0.00);
				}
			}
			
			totalImpuestos.setPorcentaje(decimal.format(igv.multiply(new BigDecimal(100.00))));
			
			List<StructureJsonTotalImpuestosDetCpeBean> listTlimp = new ArrayList<StructureJsonTotalImpuestosDetCpeBean>();
			listTlimp.add(totalImpuestos);
			
			det.setTotalImpuestos(listTlimp);
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
				//det.setValorVenta(decimal.format(venta.getValOpGratuitas()));
				det.setValorVenta(decimal.format(BigDecimal.ZERO));
			else
				det.setValorVenta(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
			
			String onerosas = "";
			
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
				onerosas = decimal.format(venta.getValOpGratuitas());
			}else{
				onerosas = null;
			}
			
			det.setValorRefOpOnerosas(onerosas);
			det.setCodProductoSunat(venta.getCodProdSunat() == null ? "" :String.valueOf(venta.getCodProdSunat()));
	
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
				det.setMontoTotalImpuestos(decimal.format(BigDecimal.ZERO));
			else
				det.setMontoTotalImpuestos(decimal.format(venta.getIgv().add(venta.getIsc()).add(venta.getImpOtros())));
			
			listDet.add(det);
		}
		
		return listDet;
	}
	
	/**TIP_PER0100_CC14 INICIO*/

	
	/**TIP_PER0100_CC14 INICIO 2019/06/18 - 10:39 - Se crea el método método obtenerDETNCNDStructuraJson que permite generar la lista de detalles de la escructura Json*/
	private List<StructureJsonDETNCNDCpeBean> obtenerDETNCNDStructuraJson(VentaCpeBean venta,ConfiguracionCpeBean conf, String codTipTributo ){
		List<StructureJsonDETNCNDCpeBean> listDet = new ArrayList<StructureJsonDETNCNDCpeBean>();
		DecimalFormat decimal = new DecimalFormat("0.00",  new DecimalFormatSymbols(Locale.US));
		
		CargaVentaItemCpeBean cargaVentaItemCpeBean = new CargaVentaItemCpeBean();
		cargaVentaItemCpeBean.setIdVenta(venta.getIdVenta());
		listDetalleItemComprobante = procesoCpeService.listarProcesoVentaDetalleItemCpeBean(cargaVentaItemCpeBean);
		
		String valorUnitario = "";
		BigDecimal igv = BigDecimal.ZERO;
		
		ProductoCpeBean productoBean = new ProductoCpeBean();
		productoBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
		productoBean.setIdProducto(Integer.parseInt(venta.getIdProducto().toString()));
		List<ProductoCpeBean> listProducto = new ArrayList<ProductoCpeBean>();
		listProducto = productoCpeService.listarProducto(productoBean);
		ProductoCpeBean productoResponse = listProducto.get(0);
		
		ParametroCpeBean parametroRequest = new ParametroCpeBean();
		parametroRequest.setCodParam(Constantes.COD_PARAM_CPE_SIS_GENERAL_CFG);
		parametroRequest.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> listPrm = parametroCpeService.listarParametro(parametroRequest);
		for(ParametroCpeBean prm : listPrm){
			if(prm.getCodValor().trim().equalsIgnoreCase(Constantes.COD_VALOR_GENERAL_IGV)){
				igv = new BigDecimal(prm.getNomValor());
			}
		}
		
		String tipoAfectacion = "";
		
		if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_FACT_EXPORT;
		}else if(venta.getBaseImponible().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_BASE_IMPONIBLE;
		}else if(venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_IMP_EXONERADO;
		}else if(venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = Constantes.COD_VALOR_TIPO_AFECTACION_INAFECTO;
		}else if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
			tipoAfectacion = venta.getTipoAfectacion().toString();
		}
		
		if(listDetalleItemComprobante!=null && listDetalleItemComprobante.size()>0){
			int cont = 1;
			boolean aplicaIGV = true;
			if(venta.getValFactExport().compareTo(BigDecimal.ZERO) > 0
				|| (venta.getImpExonerado().compareTo(BigDecimal.ZERO) > 0)
				||venta.getImpInafecto().compareTo(BigDecimal.ZERO) > 0
				||venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
				aplicaIGV = false;
			}
			
			for(CargaVentaItemCpeBean item : listDetalleItemComprobante){
				
				List<StructureJsonTotalImpuestosDetNCNDCpeBean> listTlimp = new ArrayList<StructureJsonTotalImpuestosDetNCNDCpeBean>();
				StructureJsonTotalImpuestosDetNCNDCpeBean totalImpuestos = new StructureJsonTotalImpuestosDetNCNDCpeBean();
				StructureJsonDETNCNDCpeBean det = new StructureJsonDETNCNDCpeBean();
				
				valorUnitario = "";
				String onerosas = null;
				String precioVentaUnitario="";
				BigDecimal valorUnitarioBigD = new BigDecimal(0);
				BigDecimal precioVentaUnitarioBigD = new BigDecimal(0);
				BigDecimal porcentajeIGV = new BigDecimal(0);
				
				valorUnitarioBigD = item.getValorVenta().divide(new BigDecimal(item.getCantidad()),2, RoundingMode.HALF_UP);
				valorUnitario = decimal.format(valorUnitarioBigD); 
				
				if(aplicaIGV){						
					precioVentaUnitarioBigD = valorUnitarioBigD.add(valorUnitarioBigD.multiply(igv)).setScale(2, RoundingMode.HALF_UP);
					precioVentaUnitario = decimal.format(precioVentaUnitarioBigD); 
					porcentajeIGV = igv.multiply(new BigDecimal(100.00));		
				}else{		
					precioVentaUnitarioBigD = valorUnitarioBigD;		
					precioVentaUnitario = decimal.format(precioVentaUnitarioBigD);		
				}
				
				det.setNumeroItem(String.valueOf(cont));
				det.setDescripcionProducto(item.getConcepto().toUpperCase());
				det.setCantidadItems(String.valueOf(item.getCantidad()));
				det.setUnidad(Constantes.COD_NUMBER_OF_INTERNATIONAL_UNITS);
				det.setValorUnitario(valorUnitario);
				det.setPrecioVentaUnitario(precioVentaUnitario);

				if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) == 0)						
				{		
					det.setValorUnitario(valorUnitario);		
					det.setPrecioVentaUnitario(precioVentaUnitario);		
				}		
				else		
				{		
					det.setValorUnitario(decimal.format(BigDecimal.ZERO));		
					det.setPrecioVentaUnitario(decimal.format(BigDecimal.ZERO));		
				}
				
				totalImpuestos.setIdImpuesto(codTipTributo);
				totalImpuestos.setMontoImpuesto(decimal.format(item.getIgv()));
				totalImpuestos.setTipoAfectacion(tipoAfectacion);
				totalImpuestos.setMontoBase(decimal.format(item.getValorVenta()));
				totalImpuestos.setPorcentaje(decimal.format(porcentajeIGV));
				listTlimp.add(totalImpuestos);
				det.setTotalImpuestos(listTlimp);
				det.setValorVenta(decimal.format(item.getValorTotal()));
				
				if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
					onerosas = decimal.format(item.getValorVenta());
					det.setValorVenta(decimal.format(BigDecimal.ZERO));
				}
			
				det.setValorRefOpOnerosas(onerosas);
				det.setCodProductoSunat(venta.getCodProdSunat() == null ? "" :String.valueOf(venta.getCodProdSunat()));
				det.setMontoTotalImpuestos(decimal.format(item.getIgv()));
				
				listDet.add(det);
				cont++;
			}
		}else{
			
			SocioCpeBean socioBean = new SocioCpeBean();
			socioBean.setIdSocio(Integer.parseInt(venta.getIdSocio().toString()));
			List<SocioCpeBean> listSocio = new ArrayList<SocioCpeBean>();
			listSocio = socioCpeService.listarSocio(socioBean);
			SocioCpeBean socioResponse = listSocio.get(0);

			if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
				if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0 ){
					valorUnitario = decimal.format(venta.getImpTotal());
				}else{
					valorUnitario = decimal.format(venta.getBaseImponible());
				}
			}else{
				if(conf.getAfectoIgv() == 0){
					valorUnitario = decimal.format(venta.getImpTotal());
				}else{
					valorUnitario = decimal.format(venta.getBaseImponible());
				}
			}

			StructureJsonDETNCNDCpeBean det = new StructureJsonDETNCNDCpeBean();
			det.setNumeroItem("1");

			
			if(venta.getTipoProducto().trim().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)
				|| venta.getConcepNd().equals(Constantes.COD_MOTIVO_SUNAT_OTROS)){
				//Administrativo
				det.setDescripcionProducto(venta.getConcepto().toUpperCase());
			}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS)){
				//Seguros
				det.setDescripcionProducto("PRIMA DE SEGUROS - " + socioResponse.getNomSocio().trim().toUpperCase() + " / " + productoResponse.getNomProducto().trim().toUpperCase());
			}else if(venta.getIdEmpresa().trim().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS)){
				//Servicios
				det.setDescripcionProducto(venta.getConcepto().toUpperCase());
			}
			
			det.setCantidadItems("1.00");
			det.setUnidad(Constantes.COD_NUMBER_OF_INTERNATIONAL_UNITS);
			if (venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
			{
				det.setValorUnitario(decimal.format(BigDecimal.ZERO));
				det.setPrecioVentaUnitario(decimal.format(BigDecimal.ZERO));
			}else {
				det.setValorUnitario(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
				det.setPrecioVentaUnitario(decimal.format(venta.getImpTotal()));
			}
			
			StructureJsonTotalImpuestosDetNCNDCpeBean totalImpuestos = new StructureJsonTotalImpuestosDetNCNDCpeBean();
			totalImpuestos.setIdImpuesto(codTipTributo);
			totalImpuestos.setMontoImpuesto(decimal.format(venta.getIgv()));
			totalImpuestos.setTipoAfectacion(tipoAfectacion);
			
			String montoBase = "";
			
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
				montoBase = decimal.format(venta.getValOpGratuitas());
			}else{
				montoBase = valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario;
			}
			
			totalImpuestos.setMontoBase(montoBase);
			
			if(productoResponse.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO)){
				if(venta.getIgv().compareTo(BigDecimal.ZERO) == 0){
					igv = new BigDecimal(0.00);
				}
			}else{
				if(conf.getAfectoIgv() == 0){
					igv = new BigDecimal(0.00);
				}
			}
			
			totalImpuestos.setPorcentaje(decimal.format(igv.multiply(new BigDecimal(100.00))));
			
			List<StructureJsonTotalImpuestosDetNCNDCpeBean> listTlimp = new ArrayList<StructureJsonTotalImpuestosDetNCNDCpeBean>();
			listTlimp.add(totalImpuestos);
			
			det.setTotalImpuestos(listTlimp);
			//det.setValorVenta(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0)
				det.setValorVenta(decimal.format(BigDecimal.ZERO));
			else
				det.setValorVenta(valorUnitario == null ? null : valorUnitario.trim().length() == 0 ? null : valorUnitario);
			
			String onerosas = "";
			
			if(venta.getValOpGratuitas().compareTo(BigDecimal.ZERO) > 0){
				onerosas = decimal.format(venta.getValOpGratuitas());
			}else{
				onerosas = null;
			}
			
			det.setValorRefOpOnerosas(onerosas);
			det.setCodProductoSunat(venta.getCodProdSunat() == null ? "" :String.valueOf(venta.getCodProdSunat()));
			det.setMontoTotalImpuestos(decimal.format(venta.getIgv().add(venta.getIsc()).add(venta.getImpOtros())));
			
			listDet.add(det);
			
		}
		
		return listDet;
	}
	
	/**TIP_PER0100_CC14 INICIO*/
	public void filtrarProcesoMasivo(){
		
		ventaSeleccionada = new ProcesoMasivoCpeBean(); 
		
		ProcesoMasivoCpeBean procesoMasivoCpeBean = new ProcesoMasivoCpeBean();
		procesoMasivoCpeBean.setCodigoParametro1(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		procesoMasivoCpeBean.setCodigoParametro2(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		procesoMasivoCpeBean.setCodigoParametro3(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		procesoMasivoCpeBean.setCodigoParametro4(Constantes.COD_PARAM_CPE_ORIGEN_DATOS);
		procesoMasivoCpeBean.setTipoParametro(Constantes.TIP_PARAM_DETALLE);
		procesoMasivoCpeBean.setIdProceso(proceso.getIdProceso());
		procesoMasivoCpeBean.setBusqIdSocio(socioProcesoMasivoSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.valueOf(socioProcesoMasivoSelected));
		procesoMasivoCpeBean.setBusqIdProducto(productoProcesoMasivoSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.valueOf(productoProcesoMasivoSelected));
		procesoMasivoCpeBean.setBusqIdTipoComp(tipCompProcesoMasivoSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipCompProcesoMasivoSelected);
		procesoMasivoCpeBean.setBusqIdTipoDocCli(tipDocProcesoMasivoSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipDocProcesoMasivoSelected);
		procesoMasivoCpeBean.setBusqTipoMoneda(monedaProcesoMasivoSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : monedaProcesoMasivoSelected);
		procesoMasivoCpeBean.setBusqConcepto(conceptoProcesoMasivo == null ? null : conceptoProcesoMasivo.trim().equals(Constantes.TEXTO_DEFAULT) ? null : conceptoProcesoMasivo.trim());
		procesoMasivoCpeBean.setBusqCliente(clienteProcesoMasivo == null ? null : clienteProcesoMasivo.trim().equals(Constantes.TEXTO_DEFAULT) ? null : clienteProcesoMasivo.trim());
		procesoMasivoCpeBean.setBusqNumComp(numCompProcesoMasivo == null ? null : numCompProcesoMasivo.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numCompProcesoMasivo.trim());
		procesoMasivoCpeBean.setBusqFechaEmision(fecEmisionProcesoMasivo);
		procesoMasivoCpeBean.setBusqMonto(montoProcesoMasivo == null ? null : montoProcesoMasivo.trim().equals(Constantes.TEXTO_DEFAULT) ? null : montoProcesoMasivo.trim());
		procesoMasivoCpeBean.setBusqCertificado(certificadoProcesoMasivo == null ? null : certificadoProcesoMasivo.trim().equals(Constantes.TEXTO_DEFAULT) ? null : certificadoProcesoMasivo.trim());
		procesoMasivoCpeBean.setBusqNumDoc(numCompProcesoMasivo == null ? null : numCompProcesoMasivo.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numCompProcesoMasivo.trim());
		
		listaProcesoMasivo = new ArrayList<ProcesoMasivoCpeBean>();
		logger.error("Inicio Ejecucion filtrarProcesoMasivo");
		logger.error("IdProceso: " + procesoMasivoCpeBean.getIdProceso().toString());
		listaProcesoMasivo = comprobanteCpeService.filtrarProcesoMasivoCpe(procesoMasivoCpeBean);
		logger.error("Fin Ejecucion iltrarProcesoMasivo");
		
		regSeleccionados = listaProcesoMasivo.size();
		montoSeleccionados = BigDecimal.ZERO;
		for(ProcesoMasivoCpeBean bean : listaProcesoMasivo){
			montoSeleccionados = montoSeleccionados.add(bean.getImpTotal() == null ? BigDecimal.ZERO : bean.getImpTotal());
		}
	}
	
//	public void actualizarAction(){
//		try{
//			for(VentaCpeBean venta : listVentaError){
//				if(requiereCompletarDatos(venta)){
//					completarDatosPims(venta);
//				}
//				
//				if(requiereCompletarDatos(venta)){
//					completarDatosUpload(venta);
//				}
//				
//				if(venta.getNumDocCli() != null && venta.getNumDocCli().trim().length() > 0){
//					if(requiereCompletarDatos(venta)){
//						completarDatosRegVentasNuevo(venta);
//					}
//					if(requiereCompletarDatos(venta)){
//						completarDatosRegVentasAntiguo(venta);
//					}
//				}
//	//			if(venta.getIdVenta().equals(2200L)){
//	//				venta.setImpTotal(new BigDecimal("10000.12"));
//	//			}
//				setUbigeoDescACod(venta);
//				procesoCpeService.actualizarIncompletosVentaCpe(venta);
//				
//				ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
//				procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
//				procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
//				procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
//				
//				procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
//			}
//			
//			filtrarError();
//			filtrarProcesar();
//		} catch (Exception e) {
//			log.error(e.getMessage(), e);
//			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, ErrorConstants.MSJ_ERROR_GENERAL, null);
//			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
//		}
//	}
	
	public void actualizarActionRepos(){
		if(repoSelected.equalsIgnoreCase("Pims")){
			actualizarActionPims();
		}else if(repoSelected.equalsIgnoreCase("Upload")){
			actualizarActionUpload();
		}else if(repoSelected.equalsIgnoreCase("Reg_Ventas")){
			actualizarActionRegVentas();
		}
		/**TIP_PER0100_CC14 INICIO 2019/06/20 - 09:43 - Se agrega una condicional para Datamart*/
		else if(repoSelected.equalsIgnoreCase("DataMart")){
			actualizarActionDataMart();
		}
		/**TIP_PER0100_CC14 INICIO*/
	}
	
	public void actualizarActionPims(){
		
		try{
			
			if (listVentaError.size() > 0){
				
				procesoCpeService.eliminarTmpCompletarDatosCpe(listVentaError.get(0).getIdCarga());
				// Insertar datos en tabla temporal para completar datos
				InsertIncompletosError(listVentaError);
				completarDatosPimsUpload(listVentaError.get(0).getIdCarga(), 1);
				procesoCpeService.limpiarCaracterExtrano(listVentaError.get(0).getIdCarga());
			}
//			for(VentaCpeBean venta : listVentaError){
//				boolean flg = false;
//				if(requiereCompletarDatos(venta)){
//					flg = completarDatosPims(venta);
//				}
//				
//				if(flg){
//					setUbigeoDescACod(venta);
//					procesoCpeService.actualizarIncompletosVentaCpe(venta);
//				}
//			}
//			
//			ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
//			procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
//			procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
//			procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
//			
//			procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
			
			filtrarError();
			filtrarProcesar();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void actualizarActionUpload(){
		try{
			for(VentaCpeBean venta : listVentaError){
				boolean flg = false;
				if(requiereCompletarDatos(venta)){
					flg = completarDatosUpload(venta);
				}
				
				if(flg){
					setUbigeoDescACod(venta);
					procesoCpeService.actualizarIncompletosVentaCpe(venta);
				}
				
			}
			
			ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
			procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
			procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
			procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
			
			procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
			
			filtrarError();
			filtrarProcesar();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	public void actualizarActionRegVentas(){
		try{
			for(VentaCpeBean venta : listVentaError){
				boolean flg1 = false;
				boolean flg2 = false;
				if(venta.getNumDocCli() != null && venta.getNumDocCli().trim().length() > 0){
					if(requiereCompletarDatos(venta)){
						flg1 = completarDatosRegVentasNuevo(venta);
					}
					if(requiereCompletarDatos(venta)){
						flg2 = completarDatosRegVentasAntiguo(venta);
					}
				}

				if(flg1 || flg2){
					setUbigeoDescACod(venta);
					procesoCpeService.actualizarIncompletosVentaCpe(venta);
				}
				
			}
			
			ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
			procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
			procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
			procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
			
			procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
			
			filtrarError();
			filtrarProcesar();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/**TIP_PER0100_CC14 INICIO 2019/06/20 - 10:07 - Se define el método actualizarActionDataMart*/
	/**
	 * Método que permite actualizar la lista de ventas errados, completando los datos faltantes realizando una búsqueda
	 * de los registros en la base de dato del DataMart.
	 */
	public void actualizarActionDataMart(){
		try{
			List<VentaCpeBean> listaConsultaDatamartPorPoliza = new ArrayList<VentaCpeBean>();
			List<VentaCpeBean> listaConsultaDatamartPorDocumento = new ArrayList<VentaCpeBean>();
			List<VentaCpeBean> listaConsultaDatamart = new ArrayList<VentaCpeBean>();
			VentaCpeBean parametroSQL = new VentaCpeBean();
			
			if(listVentaError!=null && !listVentaError.isEmpty()){
				
				for(VentaCpeBean venta : listVentaError){
					//Como solo se va a actualizar los registros que carezcan de cualquiera de los3 campos
					//(Tipo de documento, Número de documento y nombre cliente/Razón Social)
					//Solo vamos a buscar aquellos registros que no presenten algunos de estos campos 
					String idProductoPims = null;
					idProductoPims = venta.getIdProductoPims()==null?"0":String.valueOf(venta.getIdProductoPims());
					venta.setIdStrProductoPims(idProductoPims);
					
					if((venta.getIdTipoDocCli()==null || venta.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT) || venta.getIdTipoDocCli().trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC))
						|| (venta.getNumDocCli()==null || venta.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT))
						|| (venta.getNomCliRazSoc()==null || venta.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT))){
						
							if(venta.getIdProductoPims()!=null && venta.getIdProductoPims()>0){
								if(venta.getNumPoliza()!=null && !venta.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
									listaConsultaDatamartPorPoliza.add(venta);
								}else if(venta.getNumDocCli()!=null && !venta.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
									listaConsultaDatamartPorDocumento.add(venta);
								}
							}
					}
				}
				
				parametroSQL.setListaConsultaDatamartPorPoliza(listaConsultaDatamartPorPoliza);
				parametroSQL.setListaConsultaDatamartPorDocumento(listaConsultaDatamartPorDocumento);
				
				if( (listaConsultaDatamartPorPoliza!=null && !listaConsultaDatamartPorPoliza.isEmpty()) 
					|| (listaConsultaDatamartPorDocumento!=null && !listaConsultaDatamartPorDocumento.isEmpty()) ){
					
					listaConsultaDatamart = ventaDataMartCpeService.obtenerListaVentaCpeDataMart(parametroSQL);
					
					if(listaConsultaDatamart!=null && !listaConsultaDatamart.isEmpty()){
						actualizarDatosDataMart(listaConsultaDatamart,listaConsultaDatamartPorPoliza,listaConsultaDatamartPorDocumento);
						
						ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
						procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
						procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
						procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
						
						procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
					}else{
						FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_NO_SE_ENCONTRARON_DATOS_EN_DATAMART), null);
						FacesContext.getCurrentInstance().addMessage(null, facesMsg);
					}
				}else{
					FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_LOS_REQUISITOS_MINIMOS_PARA_DATAMART_SON_POLIZA_IDPIMS_Y_NUMDOC), null);
					FacesContext.getCurrentInstance().addMessage(null, facesMsg);
				}
				
				
				
				
				filtrarError();
				filtrarProcesar();
			
			}else{
				FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_NO_EXISTEN_REGISTROS_EN_LISTA_ERRORES), null);
				FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, ErrorConstants.MSJ_ERROR_GENERAL, null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	/**TIP_PER0100_CC14 INICIO*/
	
	public void exportarTablaProcesoOnlineCorrectos() {

		/* Creación libro, hoja, fila y celda de documento Excel */
		XSSFWorkbook libro = new XSSFWorkbook();
		XSSFSheet hoja = libro.createSheet("Proceso Online Correctos");
		XSSFRow fila = null;
		XSSFCell celda = null;

		/*
		 * Creación de estilos de celda y fuente de texto para Titulo, Cabecera
		 * y Cuerpo
		 */
		CellStyle estilosLibroTitulo = libro.createCellStyle();
		CellStyle estilosLibroCabecera = libro.createCellStyle();
		CellStyle estilosLibroCuerpo = libro.createCellStyle();
		Font estiloTextoTitulo = libro.createFont();
		Font estiloTextoCabecera = libro.createFont();
		Font estiloTextoCuerpo = libro.createFont();

		/* Se agrega tamaño de fuente, negrita y alineamiento para Titulo */
		estiloTextoTitulo.setFontHeightInPoints((short) 14);
		estiloTextoTitulo.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		estilosLibroTitulo.setAlignment(CellStyle.ALIGN_CENTER);
		estilosLibroTitulo.setFont(estiloTextoTitulo);

		/*
		 * Se agrega tamaño de fuente, negrita, alineamiento y bordes de celda
		 * medianos para Cabecera
		 */
		estiloTextoCabecera.setFontHeightInPoints((short) 12);
		estiloTextoCabecera.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		estilosLibroCabecera.setAlignment(CellStyle.ALIGN_CENTER);
		estilosLibroCabecera.setFont(estiloTextoCabecera);
		estilosLibroCabecera.setBorderTop(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderLeft(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderRight(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderBottom(CellStyle.BORDER_MEDIUM);

		/*
		 * Se agrega tamaño de fuente, alineamiento y bordes de celda delgados
		 * para Cuerpo
		 */
		estiloTextoCuerpo.setFontHeightInPoints((short) 10);
		estilosLibroCuerpo.setAlignment(CellStyle.ALIGN_LEFT);
		estilosLibroCuerpo.setFont(estiloTextoCuerpo);
		estilosLibroCuerpo.setBorderLeft(CellStyle.BORDER_THIN);
		estilosLibroCuerpo.setBorderRight(CellStyle.BORDER_THIN);
		estilosLibroCuerpo.setBorderBottom(CellStyle.BORDER_THIN);

		try {

			/* Titulo */
			hoja.addMergedRegion(CellRangeAddress.valueOf("E2:F2"));
			String titulo = "Proceso Online Correctos";
			fila = hoja.createRow(1);
			celda = fila.createCell(4);
			celda.setCellValue(titulo);
			celda.setCellStyle(estilosLibroTitulo);

			/* Cabecera */
			fila = hoja.createRow(3);
			for (int i = 0; i <= 11; i++) {
				celda = fila.createCell(i);
				if (i == 0) {
					celda.setCellValue("Tipo Comprobante");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 1) {
					celda.setCellValue("Núm. Serie");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 2) {
					celda.setCellValue("Núm. Comprobante");
					hoja.setColumnWidth(i, 5000);
				} else if (i == 3) {
					celda.setCellValue("Socio");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 4) {
					celda.setCellValue("Producto");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 5) {
					celda.setCellValue("Cliente");
					hoja.setColumnWidth(i, 8000);
				} else if (i == 6) {
					celda.setCellValue("Moneda");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 7) {
					celda.setCellValue("Monto");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 8) {
					celda.setCellValue("IGV");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 9) {
					celda.setCellValue("Estado");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 10) {
					celda.setCellValue("Origen");
					hoja.setColumnWidth(i, 5000);
				} else if (i == 11) {
					celda.setCellValue("Fec. Carga");
					hoja.setColumnWidth(i, 5000);
				}
				
				celda.setCellStyle(estilosLibroCabecera);
			}

			/* Cuerpo */
			for (int i = 0; i < listProcesadosCorrectosOnline.size(); i++) {
				fila = hoja.createRow(i + 4);
				for (int j = 0; j <= 11; j++) {
					celda = fila.createCell(j);
					if (j == 0) {
						// Tipo Comprobante
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getNomTipoComp());
					} else if (j == 1) {
						// Núm. Serie
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getSerieComp());
					} else if (j == 2) {
						// Núm. Comprobante
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getCorrComp());
					} else if (j == 3) {
						// Socio
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getNomSocio());
					} else if (j == 4) {
						// Producto
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getNomProducto());
					} else if (j == 5) {
						// Cliente
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getNomCliRazSoc());
					} else if (j == 6) {
						// Moneda
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getNomMoneda());
					} else if (j == 7) {
						// Monto
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getImpTotal().equals(BigDecimal.ZERO) ? ""
								: String.valueOf(listProcesadosCorrectosOnline.get(i).getImpTotal()));
					} else if (j == 8) {
						// IGV
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getIgv().equals(BigDecimal.ZERO) ? ""
								: String.valueOf(listProcesadosCorrectosOnline.get(i).getIgv()));
					} else if (j == 9) {
						// Estado
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getNomEstadoComp());
					} else if (j == 10) {
						// Origen
						celda.setCellValue(listProcesadosCorrectosOnline.get(i).getNomTipoCarga());
					} else if (j == 11) {
						// Fec. Carga
						celda.setCellValue(formatoddMMaaaa.format(listProcesadosCorrectosOnline.get(i).getFechaCarga()));
					}
					celda.setCellStyle(estilosLibroCuerpo);
				}
			}

			/* Descargando el archivo */
			ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();

			HttpServletResponse response = (HttpServletResponse) contexto.getResponse();

			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
			libro.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.addHeader("Content-Disposition", "attachment; filename=" + "Proceso Online Correctos.xlsx");
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			ServletOutputStream out = response.getOutputStream();
			out.write(outArray);
			out.close();

			FacesContext.getCurrentInstance().responseComplete();

		} catch (Exception e) {

			log.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			log.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));

		}
	}
	
	public void exportarTablaProcesoOnlineError() {

		/* Creación libro, hoja, fila y celda de documento Excel */
		XSSFWorkbook libro = new XSSFWorkbook();
		XSSFSheet hoja = libro.createSheet("Proceso Online Error");
		XSSFRow fila = null;
		XSSFCell celda = null;

		/*
		 * Creación de estilos de celda y fuente de texto para Titulo, Cabecera
		 * y Cuerpo
		 */
		CellStyle estilosLibroTitulo = libro.createCellStyle();
		CellStyle estilosLibroCabecera = libro.createCellStyle();
		CellStyle estilosLibroCuerpo = libro.createCellStyle();
		Font estiloTextoTitulo = libro.createFont();
		Font estiloTextoCabecera = libro.createFont();
		Font estiloTextoCuerpo = libro.createFont();

		/* Se agrega tamaño de fuente, negrita y alineamiento para Titulo */
		estiloTextoTitulo.setFontHeightInPoints((short) 14);
		estiloTextoTitulo.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		estilosLibroTitulo.setAlignment(CellStyle.ALIGN_CENTER);
		estilosLibroTitulo.setFont(estiloTextoTitulo);

		/*
		 * Se agrega tamaño de fuente, negrita, alineamiento y bordes de celda
		 * medianos para Cabecera
		 */
		estiloTextoCabecera.setFontHeightInPoints((short) 12);
		estiloTextoCabecera.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		estilosLibroCabecera.setAlignment(CellStyle.ALIGN_CENTER);
		estilosLibroCabecera.setFont(estiloTextoCabecera);
		estilosLibroCabecera.setBorderTop(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderLeft(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderRight(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderBottom(CellStyle.BORDER_MEDIUM);

		/*
		 * Se agrega tamaño de fuente, alineamiento y bordes de celda delgados
		 * para Cuerpo
		 */
		estiloTextoCuerpo.setFontHeightInPoints((short) 10);
		estilosLibroCuerpo.setAlignment(CellStyle.ALIGN_LEFT);
		estilosLibroCuerpo.setFont(estiloTextoCuerpo);
		estilosLibroCuerpo.setBorderLeft(CellStyle.BORDER_THIN);
		estilosLibroCuerpo.setBorderRight(CellStyle.BORDER_THIN);
		estilosLibroCuerpo.setBorderBottom(CellStyle.BORDER_THIN);

		try {

			/* Titulo */
			hoja.addMergedRegion(CellRangeAddress.valueOf("E2:F2"));
			String titulo = "Proceso Online Error";
			fila = hoja.createRow(1);
			celda = fila.createCell(4);
			celda.setCellValue(titulo);
			celda.setCellStyle(estilosLibroTitulo);

			/* Cabecera */
			fila = hoja.createRow(3);
			for (int i = 0; i <= 12; i++) {
				celda = fila.createCell(i);
				if (i == 0) {
					celda.setCellValue("Tipo Comprobante");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 1) {
					celda.setCellValue("Núm. Serie");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 2) {
					celda.setCellValue("Núm. Comprobante");
					hoja.setColumnWidth(i, 5000);
				} else if (i == 3) {
					celda.setCellValue("Socio");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 4) {
					celda.setCellValue("Producto");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 5) {
					celda.setCellValue("Cliente");
					hoja.setColumnWidth(i, 8000);
				} else if (i == 6) {
					celda.setCellValue("Moneda");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 7) {
					celda.setCellValue("Monto");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 8) {
					celda.setCellValue("IGV");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 9) {
					celda.setCellValue("Estado");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 10) {
					celda.setCellValue("Origen");
					hoja.setColumnWidth(i, 5000);
				} else if (i == 11) {
					celda.setCellValue("Fec. Carga");
					hoja.setColumnWidth(i, 5000);
				} else if (i == 12) {
					celda.setCellValue("Motivo de Rechazo");
					hoja.setColumnWidth(i, 13000);
				}
				
				celda.setCellStyle(estilosLibroCabecera);
			}

			/* Cuerpo */
			for (int i = 0; i < listProcesadosErrorOnline.size(); i++) {
				fila = hoja.createRow(i + 4);
				for (int j = 0; j <= 12; j++) {
					celda = fila.createCell(j);
					if (j == 0) {
						// Tipo Comprobante
						celda.setCellValue(listProcesadosErrorOnline.get(i).getNomTipoComp());
					} else if (j == 1) {
						// Núm. Serie
						celda.setCellValue(listProcesadosErrorOnline.get(i).getSerieComp());
					} else if (j == 2) {
						// Núm. Comprobante
						celda.setCellValue(listProcesadosErrorOnline.get(i).getCorrComp());
					} else if (j == 3) {
						// Socio
						celda.setCellValue(listProcesadosErrorOnline.get(i).getNomSocio());
					} else if (j == 4) {
						// Producto
						celda.setCellValue(listProcesadosErrorOnline.get(i).getNomProducto());
					} else if (j == 5) {
						// Cliente
						celda.setCellValue(listProcesadosErrorOnline.get(i).getNomCliRazSoc());
					} else if (j == 6) {
						// Moneda
						celda.setCellValue(listProcesadosErrorOnline.get(i).getNomMoneda());
					} else if (j == 7) {
						// Monto
						celda.setCellValue(listProcesadosErrorOnline.get(i).getImpTotal().equals(BigDecimal.ZERO) ? ""
								: String.valueOf(listProcesadosErrorOnline.get(i).getImpTotal()));
					} else if (j == 8) {
						// IGV
						celda.setCellValue(listProcesadosErrorOnline.get(i).getIgv().equals(BigDecimal.ZERO) ? ""
								: String.valueOf(listProcesadosErrorOnline.get(i).getIgv()));
					} else if (j == 9) {
						// Estado
						celda.setCellValue(listProcesadosErrorOnline.get(i).getNomEstadoComp());
					} else if (j == 10) {
						// Origen
						celda.setCellValue(listProcesadosErrorOnline.get(i).getNomTipoCarga());
					} else if (j == 11) {
						// Fec. Carga
						celda.setCellValue(formatoddMMaaaa.format(listProcesadosErrorOnline.get(i).getFechaCarga()));
					} else if (j == 12) {
						// Motivo de Rechazo
						celda.setCellValue(listProcesadosErrorOnline.get(i).getDescError());
					}
					celda.setCellStyle(estilosLibroCuerpo);
				}
			}

			/* Descargando el archivo */
			ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();

			HttpServletResponse response = (HttpServletResponse) contexto.getResponse();

			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
			libro.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.addHeader("Content-Disposition", "attachment; filename=" + "Proceso Online Error.xlsx");
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			ServletOutputStream out = response.getOutputStream();
			out.write(outArray);
			out.close();

			FacesContext.getCurrentInstance().responseComplete();

		} catch (Exception e) {

			log.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			log.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));

		}
	}
	
	public void exportarTablaProcesoMasivo() {

		/* Creación libro, hoja, fila y celda de documento Excel */
		XSSFWorkbook libro = new XSSFWorkbook();
		XSSFSheet hoja = libro.createSheet("Proceso Masivo");
		XSSFRow fila = null;
		XSSFCell celda = null;

		/*
		 * Creación de estilos de celda y fuente de texto para Titulo, Cabecera
		 * y Cuerpo
		 */
		CellStyle estilosLibroTitulo = libro.createCellStyle();
		CellStyle estilosLibroCabecera = libro.createCellStyle();
		CellStyle estilosLibroCuerpo = libro.createCellStyle();
		Font estiloTextoTitulo = libro.createFont();
		Font estiloTextoCabecera = libro.createFont();
		Font estiloTextoCuerpo = libro.createFont();

		/* Se agrega tamaño de fuente, negrita y alineamiento para Titulo */
		estiloTextoTitulo.setFontHeightInPoints((short) 14);
		estiloTextoTitulo.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		estilosLibroTitulo.setAlignment(CellStyle.ALIGN_CENTER);
		estilosLibroTitulo.setFont(estiloTextoTitulo);

		/*
		 * Se agrega tamaño de fuente, negrita, alineamiento y bordes de celda
		 * medianos para Cabecera
		 */
		estiloTextoCabecera.setFontHeightInPoints((short) 12);
		estiloTextoCabecera.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		estilosLibroCabecera.setAlignment(CellStyle.ALIGN_CENTER);
		estilosLibroCabecera.setFont(estiloTextoCabecera);
		estilosLibroCabecera.setBorderTop(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderLeft(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderRight(CellStyle.BORDER_MEDIUM);
		estilosLibroCabecera.setBorderBottom(CellStyle.BORDER_MEDIUM);

		/*
		 * Se agrega tamaño de fuente, alineamiento y bordes de celda delgados
		 * para Cuerpo
		 */
		estiloTextoCuerpo.setFontHeightInPoints((short) 10);
		estilosLibroCuerpo.setAlignment(CellStyle.ALIGN_LEFT);
		estilosLibroCuerpo.setFont(estiloTextoCuerpo);
		estilosLibroCuerpo.setBorderLeft(CellStyle.BORDER_THIN);
		estilosLibroCuerpo.setBorderRight(CellStyle.BORDER_THIN);
		estilosLibroCuerpo.setBorderBottom(CellStyle.BORDER_THIN);

		try {

			/* Titulo */
			hoja.addMergedRegion(CellRangeAddress.valueOf("E2:F2"));
			String titulo = "Proceso Masivo";
			fila = hoja.createRow(1);
			celda = fila.createCell(4);
			celda.setCellValue(titulo);
			celda.setCellStyle(estilosLibroTitulo);

			/* Cabecera */
			fila = hoja.createRow(3);
			for (int i = 0; i <= 11; i++) {
				celda = fila.createCell(i);
				if (i == 0) {
					celda.setCellValue("Tipo Comprobante");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 1) {
					celda.setCellValue("Núm. Serie");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 2) {
					celda.setCellValue("Núm. Comprobante");
					hoja.setColumnWidth(i, 5000);
				} else if (i == 3) {
					celda.setCellValue("Socio");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 4) {
					celda.setCellValue("Producto");
					hoja.setColumnWidth(i, 6000);
				} else if (i == 5) {
					celda.setCellValue("Cliente");
					hoja.setColumnWidth(i, 8000);
				} else if (i == 6) {
					celda.setCellValue("Moneda");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 7) {
					celda.setCellValue("Monto");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 8) {
					celda.setCellValue("IGV");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 9) {
					celda.setCellValue("Estado");
					hoja.setColumnWidth(i, 4000);
				} else if (i == 10) {
					celda.setCellValue("Origen");
					hoja.setColumnWidth(i, 5000);
				} else if (i == 11) {
					celda.setCellValue("Fec. Carga");
					hoja.setColumnWidth(i, 5000);
				}
				
				celda.setCellStyle(estilosLibroCabecera);
			}

			/* Cuerpo */
			for (int i = 0; i < listaProcesoMasivo.size(); i++) {
				fila = hoja.createRow(i + 4);
				for (int j = 0; j <= 11; j++) {
					celda = fila.createCell(j);
					if (j == 0) {
						// Tipo Comprobante
						celda.setCellValue(listaProcesoMasivo.get(i).getNomTipoComp());
					} else if (j == 1) {
						// Núm. Serie
						celda.setCellValue(listaProcesoMasivo.get(i).getSerieComp());
					} else if (j == 2) {
						// Núm. Comprobante
						celda.setCellValue(listaProcesoMasivo.get(i).getCorrComp());
					} else if (j == 3) {
						// Socio
						celda.setCellValue(listaProcesoMasivo.get(i).getNomSocio());
					} else if (j == 4) {
						// Producto
						celda.setCellValue(listaProcesoMasivo.get(i).getNomProducto());
					} else if (j == 5) {
						// Cliente
						celda.setCellValue(listaProcesoMasivo.get(i).getNomCliRazSoc());
					} else if (j == 6) {
						// Moneda
						celda.setCellValue(listaProcesoMasivo.get(i).getNomMoneda());
					} else if (j == 7) {
						// Monto
						celda.setCellValue(listaProcesoMasivo.get(i).getImpTotal().equals(BigDecimal.ZERO) ? ""
								: String.valueOf(listaProcesoMasivo.get(i).getImpTotal()));
					} else if (j == 8) {
						// IGV
						celda.setCellValue(listaProcesoMasivo.get(i).getIgv().equals(BigDecimal.ZERO) ? ""
								: String.valueOf(listaProcesoMasivo.get(i).getIgv()));
					} else if (j == 9) {
						// Estado
						celda.setCellValue(listaProcesoMasivo.get(i).getNomEstadoComp());
					} else if (j == 10) {
						// Origen
						celda.setCellValue(listaProcesoMasivo.get(i).getNomTipoCarga());
					} else if (j == 11) {
						// Fec. Carga
						celda.setCellValue(formatoddMMaaaa.format(listaProcesoMasivo.get(i).getFechaCarga()));
					}
					celda.setCellStyle(estilosLibroCuerpo);
				}
			}

			/* Descargando el archivo */
			ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();

			HttpServletResponse response = (HttpServletResponse) contexto.getResponse();

			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
			libro.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();

			response.addHeader("Content-Disposition", "attachment; filename=" + "Proceso Masivo.xlsx");
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			ServletOutputStream out = response.getOutputStream();
			out.write(outArray);
			out.close();

			FacesContext.getCurrentInstance().responseComplete();

		} catch (Exception e) {

			log.error("Exception(" + e.getClass().getName() + ") - ERROR: " + e.getMessage());
			log.error("Exception(" + e.getClass().getName() + ") -->" + ExceptionUtils.getStackTrace(e));

		}
	}
	
	private Boolean requiereCompletarDatos(VentaCpeBean ventaCpeBean){
		if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT) ||
				ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT) ||
				((ventaCpeBean.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DNI) || ventaCpeBean.getIdTipoDocCli().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC)) ? !esNumDocvalido(ventaCpeBean.getNumDocCli(), getNumeroDigitosTipDoc(ventaCpeBean.getIdTipoDocCli())) : false)||
				ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT) ||
				((ventaCpeBean.getIdEmpresa().equals(Constantes.COD_EMPRESA_CARDIF_SERVICIOS) && (ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)))) ||
				((ventaCpeBean.getIdEmpresa().equals(Constantes.COD_EMPRESA_CARDIF_SEGUROS) && !ventaCpeBean.getTipoProducto().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO) && (ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)))) ||
				(validarTipoComprobanteConTipoDocumento(ventaCpeBean.getIdTipoComp(), ventaCpeBean.getIdTipoDocCli(), ventaCpeBean.getTipoProducto()))
				){
			return true;
		}else{
			return false;
		}
	}
	
	private boolean validarTipoComprobanteConTipoDocumento(String idTipoComprobante, String idTipoDocCli, String tipo_Producto){
		boolean resultado = false;
		if (!tipo_Producto.trim().equals(Constantes.COD_TIPO_PRODUCTO_ADMINISTRATIVO))
		{
			if(idTipoComprobante.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA) &&
					(!idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC))){
				resultado = true;
			}
			if(idTipoComprobante.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
				if (idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DNI) ||
					idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_CARNET_EXTRANJERIA) ||
					idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_PASAPORTE)){
					resultado = false;
				}else{
					resultado = true;
				}
			}	
		}
		else 
		{
			if(idTipoComprobante.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_FACTURA) &&
					(!idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_RUC) && !idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC))){
				resultado = true;
			}
			if(idTipoComprobante.trim().equals(Constantes.COD_VALOR_TIPO_COMPROBANTE_BOLETA)){
				if (idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DNI) ||
					idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_CARNET_EXTRANJERIA) ||
					idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_PASAPORTE) 
					//|| idTipoDocCli.trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC)
					){
					resultado = false;
				}else{
					resultado = true;
				}
			}	
			
		}
		return resultado;
	}
	
	private boolean esNumDocvalido(String numDoc, int numDig){
		boolean flg = false;
		if(numDoc.length() == numDig){
			try {
				Long.parseLong(numDoc);
				flg = true;
			} catch (Exception e) {
				flg = false;
			}
		}
		return flg;
	}
	
	private int getNumeroDigitosTipDoc(String idTipDoc){
		if(idTipDoc.equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DNI)){
			return 8;
		}else{	
			return 11;
		}
		
	}
	
	private String obtenerPrefijoAlta(VentaCpeBean ventaCpeBean){
		
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		productoCpeBean.setIdSocio(ventaCpeBean.getIdSocio().intValue());
		productoCpeBean.setIdProducto(ventaCpeBean.getIdProducto().intValue());
		productoCpeBean = productoCpeService.listarProducto(productoCpeBean).get(0);
		
		return productoCpeBean.getPrefijoAlta();
	}
	
	private boolean completarDatosUpload(VentaCpeBean ventaCpeBean){
		boolean flg = false;
		
		VentaUploadCpeBean ventaUploadCpeBean = new VentaUploadCpeBean();
		List<VentaUploadCpeBean> listaVentaUploadCpeBean = new ArrayList<VentaUploadCpeBean>();
		ventaUploadCpeBean.setPrefijoAlta(ventaCpeBean.getPrefijoAlta());
		if(ventaCpeBean.getNumDocCli() != null && !ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
			ventaUploadCpeBean.setNumPoliza(null);
			ventaUploadCpeBean.setNumDocCli(ventaCpeBean.getNumDocCli());
		}else{
			ventaUploadCpeBean.setNumPoliza(ventaCpeBean.getNumPoliza());
		}
		listaVentaUploadCpeBean = ventaUploadCpeService.listaCompletarDatosUpload(ventaUploadCpeBean);
		
		for(VentaUploadCpeBean bean : listaVentaUploadCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelfCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCli());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
//				ventaCpeBean.setImpTotal(bean.getImpTotal());
//				ventaCpeBean.setFlgUpload(Constantes.ACTIVO);
//			}
		}
		return flg;
	}
	/**TIP_PER0100_CC14 INICIO 2019/06/20 - 10:38 - Se define el método actualizarDatosDataMart*/
	/**
	 * Método que permite actualizar los datos de los registros de las listas {@code listaConsultaDatamartPorPoliza}, {@code listaConsultaDatamartPorDocumento}
	 * comparando con la información almacenada en la lista {@code listaConsultaDatamart} obtenida al consultar la base de datos de DataMart.
	 * @param listaConsultaDatamart Lista de registros encontrados en la base de datos de DataMart, tipo List<VentaCpeBean>.
	 * @param listaConsultaDatamartPorPoliza Lista de registros que no presentan los campos mínimos requeridos pero que presentan idProductoPims y número de póliza, tipo List<VentaCpeBean>. 
	 * @param listaConsultaDatamartPorDocumento Lista de registros que no presentan los campos mínimos requeridos pero que presentan idProductoPims y número de documento, tipo List<VentaCpeBean>.
	 * @throws Exception Exceptición generada al realizar la operación.
	 */
	private void actualizarDatosDataMart(List<VentaCpeBean> listaConsultaDatamart, List<VentaCpeBean> listaConsultaDatamartPorPoliza, List<VentaCpeBean> listaConsultaDatamartPorDocumento) throws Exception{
		
		try{
			if(listaConsultaDatamart!=null && listaConsultaDatamart.size()>0){
				for(VentaCpeBean ventaDM : listaConsultaDatamart){
					boolean completado = false;
					
					if(ventaDM.getTipoLista().equals("POLIZA")){
						for(VentaCpeBean ventaPol : listaConsultaDatamartPorPoliza){
							if(ventaPol.getIdProductoPims().equals(ventaDM.getIdProductoPims()) && ventaPol.getNumPoliza().equals(ventaDM.getNumPoliza())){
								completado = completarDatosDataMart(ventaDM,ventaPol,"POLIZA");
								if(completado){
									setUbigeoDescACod(ventaPol);
									procesoCpeService.actualizarIncompletosVentaCpe(ventaPol);
									listaConsultaDatamartPorPoliza.remove(ventaPol);
									break;
								}
							}
						}
					}else if(ventaDM.getTipoLista().equals("NUMDOC")){
						for(VentaCpeBean ventaDoc : listaConsultaDatamartPorDocumento){
							if(ventaDoc.getIdProductoPims().equals(ventaDM.getIdProductoPims()) && ventaDoc.getNumDocCli().equals(ventaDM.getNumDocCli())){
								completado = completarDatosDataMart(ventaDM,ventaDoc,"NUMDOC");
								if(completado){
									setUbigeoDescACod(ventaDoc);
									procesoCpeService.actualizarIncompletosVentaCpe(ventaDoc);
									listaConsultaDatamartPorPoliza.remove(ventaDoc);
									break;
								}
							}
						}
					}
				}
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		}
	}
	/**TIP_PER0100_CC14 FIN*/
	
	/**TIP_PER0100_CC14 INICIO 2019/06/27 - 18:47 - Se define el método completarDatosDataMart*/
	/**
	 * Método que permite completar los datos faltante en venta {@code venta}. Los datos serán obtenidos de la venta {@code ventaDataMart}.
	 * @param ventaDataMart Datos de la venta obtenidos de la base de datos de DataMart, tipo VentaCpeBean.
	 * @param venta Bean que contiene los datos faltantes, tipo VentaCpeBean.
	 * @param tipo Cadena que indica si los datos de venta {@code venta} fueron obtenidos a través de una búsqueda
	 *  por {@code POLIZA} o por {@code NUMDOC} en la base de datos del DataMart, tipo String.
	 * @return completado Indicador que será {@code true} en caso se haya completado por lo menos uno de los campos mínimos requeridos
	 * y {@code false} en caso contrario, tipo boolean.
	 * @throws Exception Excepción de la operación realizada.
	 */
	private boolean completarDatosDataMart(VentaCpeBean ventaDataMart, VentaCpeBean venta, String tipo)throws Exception{
		boolean completado = false;
		try{
			if(venta.getIdTipoDocCli() == null || venta.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT) || venta.getIdTipoDocCli().trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC)
					&& (ventaDataMart.getIdTipoDocCli()!=null && !ventaDataMart.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT) && !ventaDataMart.getIdTipoDocCli().trim().equals(Constantes.COD_VALOR_TIPO_DOC_CLIENTE_DOC_TRI_NO_DOM_SIN_RUC))){
				venta.setIdTipoDocCli(ventaDataMart.getIdTipoDocCli());
				venta.setFlgDataMart(Constantes.ACTIVO);
				completado=true;
			}
			if(venta.getNomCliRazSoc() == null || venta.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				venta.setNomCliRazSoc(ventaDataMart.getNomCliRazSoc());
				venta.setFlgDataMart(Constantes.ACTIVO);
				completado=true;
			}
			if(!tipo.equals("NUMDOC")){
				if(venta.getNumDocCli() == null || venta.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)
						&& (ventaDataMart.getNumDocCli()!=null &&  !ventaDataMart.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT))){
					venta.setNumDocCli(ventaDataMart.getNumDocCli());
					venta.setFlgDataMart(Constantes.ACTIVO);
					completado=true;
				}
			}
		}catch(Exception e){
			logger.error(e.getMessage(), e);
		}
		
		return completado;
	}
	/**TIP_PER0100_CC14 FIN*/
	private Integer obtenerIdProductoPims(VentaCpeBean ventaCpeBean){
		
		ProductoCpeBean productoCpeBean = new ProductoCpeBean();
		productoCpeBean.setIdSocio(ventaCpeBean.getIdSocio().intValue());
		productoCpeBean.setIdProducto(ventaCpeBean.getIdProducto().intValue());
		productoCpeBean = productoCpeService.listarProducto(productoCpeBean).get(0);
		
		return productoCpeBean.getIdProductoPims();
	}
	
	private boolean completarDatosPims(VentaCpeBean ventaCpeBean){
		boolean flg = false;
		
		VentaPimsCpeBean ventaPimsCpeBean = new VentaPimsCpeBean();
		List<VentaPimsCpeBean> listaVentaPimsCpeBean = new ArrayList<VentaPimsCpeBean>();
		ventaPimsCpeBean.setIdProductoPims(ventaCpeBean.getIdProductoPims());
		if(ventaCpeBean.getNumDocCli() != null && !ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
			ventaPimsCpeBean.setNumPoliza(null);
			ventaPimsCpeBean.setNumDocCli(ventaCpeBean.getNumDocCli());
		}else{
			ventaPimsCpeBean.setNumPoliza(ventaCpeBean.getNumPoliza());
		}
		listaVentaPimsCpeBean = ventaPimsCpeService.listaCompletarDatosPims(ventaPimsCpeBean);
		
		for(VentaPimsCpeBean bean : listaVentaPimsCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelfCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCli());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
//				ventaCpeBean.setImpTotal(bean.getImpTotal());
//				ventaCpeBean.setFlgPims(Constantes.ACTIVO);
//			}
		}
		return flg;
	}
	
	private boolean completarDatosRegVentasNuevo(VentaCpeBean ventaCpeBean){
		boolean flg = false;
		
		VentaCpeBean beanTmp = new VentaCpeBean();
		List<VentaCpeBean> listaVentaCpeBean = new ArrayList<VentaCpeBean>();
		beanTmp.setNumDocCli(ventaCpeBean.getNumDocCli());	
		listaVentaCpeBean = procesoCpeService.buscarVentaCompletarDatosCpe(beanTmp);
		
		for(VentaCpeBean bean : listaVentaCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelefCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
//				ventaCpeBean.setImpTotal(bean.getImpTotal());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
		}
		return flg;
	}
	
	private boolean completarDatosRegVentasAntiguo(VentaCpeBean ventaCpeBean){
		boolean flg = false;
		
		TstVentas beanTmp = new TstVentas();
		List<VentaCpeBean> listaVentaCpeBean = new ArrayList<VentaCpeBean>();
		beanTmp.setNumerodoccliente(ventaCpeBean.getNumDocCli());	
		listaVentaCpeBean = registroVentasSuscripcionService.listarRegistroVentas(beanTmp);
		
		for(VentaCpeBean bean : listaVentaCpeBean){
			if(ventaCpeBean.getTipoMoneda() == null || ventaCpeBean.getTipoMoneda().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTipoMoneda(bean.getTipoMoneda());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getFechaVenc() == null || ventaCpeBean.getFechaVenc().trim().equals(Constantes.TEXTO_DEFAULT)){
//				ventaCpeBean.setFechaVenc(getDateToString(bean.getFecVenc()));
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
			if(ventaCpeBean.getIdTipoDocCli() == null || ventaCpeBean.getIdTipoDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setIdTipoDocCli(bean.getIdTipoDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumDocCli() == null || ventaCpeBean.getNumDocCli().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumDocCli(bean.getNumDocCli());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNomCliRazSoc() == null || ventaCpeBean.getNomCliRazSoc().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNomCliRazSoc(bean.getNomCliRazSoc());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDirCliente() == null || ventaCpeBean.getDirCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDirCliente(bean.getDirCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDepartamento() == null || ventaCpeBean.getDepartamento().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDepartamento(bean.getDepartamento());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getProvincia() == null || ventaCpeBean.getProvincia().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setProvincia(bean.getProvincia());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getDistrito() == null || ventaCpeBean.getDistrito().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setDistrito(bean.getDistrito());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getTelefCliente() == null || ventaCpeBean.getTelefCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setTelefCliente(bean.getTelefCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getMailCliente() == null || ventaCpeBean.getMailCliente().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setMailCliente(bean.getMailCliente());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getConcepto() == null || ventaCpeBean.getConcepto().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setConcepto(bean.getConcepto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getIdProducto() == null || ventaCpeBean.getIdProducto() == Long.valueOf(0)){
				ventaCpeBean.setIdProducto(bean.getIdProducto());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
			if(ventaCpeBean.getNumPoliza() == null || ventaCpeBean.getNumPoliza().trim().equals(Constantes.TEXTO_DEFAULT)){
				ventaCpeBean.setNumPoliza(bean.getNumPoliza());
				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
				flg = true;
			}
//			if(ventaCpeBean.getValFactExport() == null || ventaCpeBean.getValFactExport() == BigDecimal.ZERO){
//				ventaCpeBean.setValFactExport(bean.getValFactExport());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getBaseImponible() == null || ventaCpeBean.getBaseImponible() == BigDecimal.ZERO){
//				ventaCpeBean.setBaseImponible(bean.getBaseImponible());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpExonerado() == null || ventaCpeBean.getImpExonerado() == BigDecimal.ZERO){
//				ventaCpeBean.setImpExonerado(bean.getImpExonerado());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpInafecto() == null || ventaCpeBean.getImpInafecto() == BigDecimal.ZERO){
//				ventaCpeBean.setImpInafecto(bean.getImpInafecto());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getValOpGratuitas() == null || ventaCpeBean.getValOpGratuitas() == BigDecimal.ZERO){
//				ventaCpeBean.setValOpGratuitas(bean.getValOpgratuitas());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIsc() == null || ventaCpeBean.getIsc() == BigDecimal.ZERO){
//				ventaCpeBean.setIsc(bean.getIsc());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getIgv() == null || ventaCpeBean.getIgv() == BigDecimal.ZERO){
//				ventaCpeBean.setIgv(bean.getIgv());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpOtros() == null || ventaCpeBean.getImpOtros() == BigDecimal.ZERO){
//				ventaCpeBean.setImpOtros(bean.getImpOtros());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
//			if(ventaCpeBean.getImpTotal() == null || ventaCpeBean.getImpTotal() == BigDecimal.ZERO){
//				ventaCpeBean.setImpTotal(bean.getImpTotal());
//				ventaCpeBean.setFlgRv(Constantes.ACTIVO);
//			}
		}
		return flg;
	}
	
	public void cargaArchivo(){
		
		if(listVentaCpe == null || listVentaCpe.size() == 0){
			//enviarMensaje(codMensaje);
			return;
		}
		if(listVentaError == null || listVentaError.size() == 0){
			//enviarMensaje(codMensaje);
			return;
		}
		
		boolean actualizarProceso = false;
		
		for(VentaCpeBean ventaError : listVentaError){
			for(VentaCpeBean ventaExcel : listVentaCpe){
				if(ventaError.getIdVenta().longValue() == ventaExcel.getIdVenta().longValue()){
					ventaError.setIdProducto(ventaExcel.getIdProducto());
					ventaError.setTipoMoneda(ventaExcel.getTipoMoneda());
					ventaError.setIdTipoDocCli(ventaExcel.getIdTipoDocCli());
					ventaError.setNumDocCli(ventaExcel.getNumDocCli());
					ventaError.setNomCliRazSoc(ventaExcel.getNomCliRazSoc());
					ventaError.setDirCliente(ventaExcel.getDirCliente());
					ventaError.setDepartamento(ventaExcel.getDepartamento());
					ventaError.setProvincia(ventaExcel.getProvincia());
					ventaError.setDistrito(ventaExcel.getDistrito());
					ventaError.setTelefCliente(ventaExcel.getTelefCliente());
					ventaError.setMailCliente(ventaExcel.getMailCliente());
					ventaError.setConcepto(ventaExcel.getConcepto());
					ventaError.setNumPoliza(ventaExcel.getNumPoliza());
					
					procesoCpeService.actualizarIncompletosVentaCpe(ventaError);
					actualizarProceso = true;
				}
			}
		}
		
		if(actualizarProceso){
			ProcesoEstadoCpeBean procesoEstadoCpeBean = new ProcesoEstadoCpeBean();
			procesoEstadoCpeBean.setIdProceso(proceso.getIdProceso());
			procesoEstadoCpeBean.setEstadoProceso(proceso.getCodEstado());
			procesoEstadoCpeBean.setUsuModifica(usuarioSesion);
			
			procesoCpeService.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
		}
		
		filtrarError();
		filtrarProcesar();
		
	}

	/*
	 * TODO BSC 12/09/2019
	 * La clase org.richfaces.event.UploadEvent fue eliminada en RichFaces 4.x. En su lugar, se usa org.richfaces.event.FileUploadEvent
	 * La clase org.richfaces.model.UploadItem fue eliminada en RichFaces 4.x. En su lugar, se usa org.richfaces.model.UploadedFile
	 * 
	 * El procesamiento cambia totalmente, ya que desde UploadedFile no se puede obtener el objeto java.io.File y en su lugar se usa arreglod bytes
	 */
	@SuppressWarnings("unchecked")
	public String listenerOnline(FileUploadEvent event) {
		String respuesta = null;
		try {
			listVentaCpe = new ArrayList<VentaCpeBean>();
			mensajeValidacionArchivo = "";
			archivo = event.getUploadedFile();
			nomArchivo = archivo.getName();
			int longitudNomArchivo = nomArchivo.length();
			if(!nomArchivo.substring(longitudNomArchivo - 5, longitudNomArchivo).equals(".xlsx")){
				//enviarMensaje(ErrorConstants.COD_ERROR_CARGA_NULO);
				mensajeValidacionArchivo = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_CARGA_NULO);
				FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
						null);
				FacesContext.getCurrentInstance().addMessage(null, facesMsg);
				return null;
			}
			mensajeValidacionArchivo = campoLayoutCpeService.validarArchivoCamposLayout(archivo, nomArchivo, 
					Constantes.ID_LAYOUT_ARCHIVO_ERROR);
			if(mensajeValidacionArchivo != null){
				clearUpload();
				listVentaCpe = new ArrayList<VentaCpeBean>();
				return null;
			}else{
				mensajeValidacionArchivo = null;
				disabledCargar = false;
				listVentaCpe = FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
									.get(Constantes.KEY_LIST_VENTA_XLSX) == null ? new ArrayList<VentaCpeBean>() 
											: (List<VentaCpeBean>) FacesContext.getCurrentInstance()
												.getExternalContext().getSessionMap().get(Constantes.KEY_LIST_VENTA_XLSX);
				for(VentaCpeBean venta : listVentaCpe){
					setUbigeos(venta);
				}					
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			mensajeValidacionArchivo = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ERR_CARGA_EXCEL);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	private void setUbigeos(VentaCpeBean venta){
		if((venta.getDepartamento() != null && !venta.getDepartamento().equals("")) 
				&& (venta.getProvincia() != null && !venta.getProvincia().equals(""))
				&& (venta.getDistrito() != null && !venta.getDistrito().equals(""))){
			
			if(obtenerDepartamento(venta)){
				if(obtenerProvincia(venta)){
					obtenerDistrito(venta);
				}
			}
			
		}else{
			setUbigeoNulls(venta);
		}
	}
	
	private boolean obtenerDepartamento(VentaCpeBean venta){
		boolean ind = false;
		List<UbigeoCpeBean> listDepartamento = new ArrayList<UbigeoCpeBean>();
		listDepartamento = ubigeoCpeService.listarDepartamento();
		
		for(UbigeoCpeBean dep : listDepartamento){
			if(dep.getNombreUbigeo().trim().equalsIgnoreCase(venta.getDepartamento().trim())){
				venta.setDepartamento(dep.getCodigoUbigeo());
				ind=true;
				break;
			}
		}
		if(!ind){
			setUbigeoNulls(venta);
		}
		
		return ind;
	}
	
	public void deshabilitarCargar(){
		disabledCargar = true;
	}
	
	private boolean obtenerProvincia(VentaCpeBean venta){
		boolean ind = false;
		UbigeoCpeBean ubigeo = new UbigeoCpeBean();
		ubigeo.setIdDepartamento(venta.getDepartamento().trim().substring(0, 2));
		List<UbigeoCpeBean> listProvincia = new ArrayList<UbigeoCpeBean>();
		listProvincia = ubigeoCpeService.listarProvincia(ubigeo);
		
		for(UbigeoCpeBean prov : listProvincia){
			if(prov.getNombreUbigeo().trim().equalsIgnoreCase(venta.getProvincia().trim())){
				venta.setProvincia(prov.getCodigoUbigeo());
				ind = true;
				break;
			}
		}
		if(!ind){
			setUbigeoNulls(venta);
		}
		
		return ind;
	}
	
	private boolean obtenerDistrito(VentaCpeBean venta){
		boolean ind = false;
		UbigeoCpeBean ubigeo = new UbigeoCpeBean();
		ubigeo.setIdProvincia(venta.getProvincia().substring(2, 4));
		ubigeo.setIdDepartamento(venta.getDepartamento().substring(0, 2));
		List<UbigeoCpeBean> listDistrito = new ArrayList<UbigeoCpeBean>();
		listDistrito = ubigeoCpeService.listarDistrito(ubigeo);
		
		for(UbigeoCpeBean dist : listDistrito){
			if(dist.getNombreUbigeo().trim().equalsIgnoreCase(venta.getDistrito().trim())){
				venta.setDistrito(dist.getCodigoUbigeo());
				ind = true;
				break;
			}
		}
		if(!ind){
			setUbigeoNulls(venta);
		}
		return ind;
	}
	
	private void setUbigeoNulls(VentaCpeBean venta){
		venta.setDepartamento("");
		venta.setProvincia("");
		venta.setDistrito("");
	}

	// TODO BSC 12/09/2019 Con RichFaces 4.x no se puede obtener el objeto java.io.File durante la carga.
	public String clearUpload() {
		String respuesta = null;
		try {
			if (archivo != null) {
				// BSC Se elimina validación de existencia de archivo directamente se borra el documento
				archivo.delete();
				archivo = null;
			}
			this.nomArchivo = null;
			this.disabledCargar = true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public void limpiaVariablesOnline() {
		nomArchivo = "";
		archivo = null;
		disabledCargar = true;
		listVentaCpe = new ArrayList<VentaCpeBean>();
		nroRegistros = 0;
	}
	
	public String mostrarMensajeUploadFile() {
		String respuesta = null;
		try {
			if (mensajeValidacionArchivo != null) {
				clearUpload();
				SateliteUtil.mostrarMensaje(FacesMessage.SEVERITY_INFO, mensajeValidacionArchivo);
				mensajeValidacionArchivo = null;
				idFileUploadComponent = "uploaderCarga";
			} else {
				idFileUploadComponent = "txtHidden";
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
			respuesta = ErrorConstants.MSJ_ERROR;
		}
		return respuesta;
	}
	
	public void ejecutarSeleccionarTodoError(){
		if(seleccionarTodosError){
			for(VentaCpeBean bean : listVentaError){
				bean.setSeleccionado(true);
			}
		}else{
			for(VentaCpeBean bean : listVentaError){
				bean.setSeleccionado(false);
			}
		}
	}
	
	public void eliminarSeleccionadosError(){
		boolean mostrarMensajeSeleccionar = true;
		
		List<VentaCpeBean> listRemove = new ArrayList<VentaCpeBean>();
		
		for(VentaCpeBean beanRemove : listVentaError){
				ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
				comprobante.setIdVenta(beanRemove.getIdVenta());
				
				List<ComprobanteCpeBean> listCpnt = comprobanteCpeService.obtenerComprobante(comprobante);
			
			if((beanRemove.isSeleccionado()) && (listCpnt == null || listCpnt.isEmpty())){
				listRemove.add(beanRemove);
				mostrarMensajeSeleccionar = false;
			}
			else if((beanRemove.isSeleccionado()) && (listCpnt != null || !listCpnt.isEmpty())) 
			{
				mostrarMensajeSeleccionar = false;
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_ELIMINA_VENTA);
				break;
			}
		}
		
		for(VentaCpeBean temp : listRemove){
			ProcesoVentaCpeBean pvBean = new ProcesoVentaCpeBean();
			pvBean.setIdProceso(proceso.getIdProceso());
			pvBean.setIdVenta(temp.getIdVenta());
			pvBean.setEstado(Constantes.ACTIVO);
			
			List<ProcesoVentaCpeBean> listpvBean = procesoCpeService.listarProcesoVentaCpeBean(pvBean);
			
			UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
			updateVentaCpeBean.setIdVentaProceso(listpvBean.get(0).getIdVentaProceso());
			procesoCpeService.eliminarUpdateVentaCpe(updateVentaCpeBean);
			
			ProcesoVentaCpeBean procesoVenta = new ProcesoVentaCpeBean();
			procesoVenta.setIdVenta(temp.getIdVenta());
			procesoVenta.setIdProceso(proceso.getIdProceso());
			procesoCpeService.eliminarVentaProcesoCpe(procesoVenta);
		}
		
		seleccionarTodosError = false;		
		filtrarError();
		
		if(mostrarMensajeSeleccionar)
			enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
	}
	
	public void ejecutarSeleccionarTodoProcesar(){
		if(seleccionarTodosProcesar){
			for(VentaCpeBean bean : listVentaProcesar){
				bean.setSeleccionado(true);
			}
		}else{
			for(VentaCpeBean bean : listVentaProcesar){
				bean.setSeleccionado(false);
			}
		}
	}
	
	public void eliminarSeleccionadosProcesar(){
		
		boolean mostrarMensajeSeleccionar = true;
		
		List<VentaCpeBean> listRemove = new ArrayList<VentaCpeBean>();
		
		for(VentaCpeBean beanRemove : listVentaProcesar){
				ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
				comprobante.setIdVenta(beanRemove.getIdVenta());
				
				List<ComprobanteCpeBean> listCpnt = comprobanteCpeService.obtenerComprobante(comprobante);
			
			if((beanRemove.isSeleccionado()) && (listCpnt == null || listCpnt.isEmpty())){
				listRemove.add(beanRemove);
				mostrarMensajeSeleccionar = false;
			}
			else if(beanRemove.isSeleccionado() && (listCpnt != null || !listCpnt.isEmpty())) 
			{
				mostrarMensajeSeleccionar = false;
				enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_ELIMINA_VENTA);
				break;
			}
		}		
		
		for(VentaCpeBean temp : listRemove){
			ProcesoVentaCpeBean pvBean = new ProcesoVentaCpeBean();
			pvBean.setIdProceso(proceso.getIdProceso());
			pvBean.setIdVenta(temp.getIdVenta());
			pvBean.setEstado(Constantes.ACTIVO);
			
			List<ProcesoVentaCpeBean> listpvBean = procesoCpeService.listarProcesoVentaCpeBean(pvBean);
			
			UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
			updateVentaCpeBean.setIdVentaProceso(listpvBean.get(0).getIdVentaProceso());
			procesoCpeService.eliminarUpdateVentaCpe(updateVentaCpeBean);
			
			ProcesoVentaCpeBean procesoVenta = new ProcesoVentaCpeBean();
			procesoVenta.setIdVenta(temp.getIdVenta());
			procesoVenta.setIdProceso(proceso.getIdProceso());
			procesoCpeService.eliminarVentaProcesoCpe(procesoVenta);
		}
		
		seleccionarTodosProcesar = false;
		filtrarProcesar();
		
		if(mostrarMensajeSeleccionar)
			enviarMensaje(ErrorConstants.COD_ERROR_SELECCION);
	}
	
	public void eliminarVentaGrillaProcesar(){
		
		VentaCpeBean venta = (VentaCpeBean) FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaProcesar}", VentaCpeBean.class);
		
		ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
		comprobante.setIdVenta(venta.getIdVenta());
		
		List<ComprobanteCpeBean> listCpnt = comprobanteCpeService.obtenerComprobante(comprobante);
		
		if((listCpnt == null || listCpnt.isEmpty())){
			ProcesoVentaCpeBean pvBean = new ProcesoVentaCpeBean();
			pvBean.setIdProceso(proceso.getIdProceso());
			pvBean.setIdVenta(venta.getIdVenta());
			pvBean.setEstado(Constantes.ACTIVO);
			
			List<ProcesoVentaCpeBean> listpvBean = procesoCpeService.listarProcesoVentaCpeBean(pvBean);
			
			UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
			updateVentaCpeBean.setIdVentaProceso(listpvBean.get(0).getIdVentaProceso());
			procesoCpeService.eliminarUpdateVentaCpe(updateVentaCpeBean);
			
			ProcesoVentaCpeBean procesoVenta = new ProcesoVentaCpeBean();
			procesoVenta.setIdVenta(venta.getIdVenta());
			procesoVenta.setIdProceso(proceso.getIdProceso());
			procesoCpeService.eliminarVentaProcesoCpe(procesoVenta);
		}
		else
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_ELIMINA_VENTA);
		
		filtrarProcesar();
	}
	
	public void eliminarVentaGrillaError(){
		
		VentaCpeBean venta = (VentaCpeBean) FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaError}", VentaCpeBean.class);
		
		ComprobanteCpeBean comprobante = new ComprobanteCpeBean();
		comprobante.setIdVenta(venta.getIdVenta());
		
		List<ComprobanteCpeBean> listCpnt = comprobanteCpeService.obtenerComprobante(comprobante);
		
		if((listCpnt == null || listCpnt.isEmpty())){
			ProcesoVentaCpeBean pvBean = new ProcesoVentaCpeBean();
			pvBean.setIdProceso(proceso.getIdProceso());
			pvBean.setIdVenta(venta.getIdVenta());
			pvBean.setEstado(Constantes.ACTIVO);
			
			List<ProcesoVentaCpeBean> listpvBean = procesoCpeService.listarProcesoVentaCpeBean(pvBean);
			
			UpdateVentaCpeBean updateVentaCpeBean = new UpdateVentaCpeBean();
			updateVentaCpeBean.setIdVentaProceso(listpvBean.get(0).getIdVentaProceso());
			procesoCpeService.eliminarUpdateVentaCpe(updateVentaCpeBean);
			
			ProcesoVentaCpeBean procesoVenta = new ProcesoVentaCpeBean();
			procesoVenta.setIdVenta(venta.getIdVenta());
			procesoVenta.setIdProceso(proceso.getIdProceso());
			procesoCpeService.eliminarVentaProcesoCpe(procesoVenta);
		}
		else
			enviarMensaje(ErrorConstants.COD_ERROR_MSJ_NO_ELIMINA_VENTA);
		
		filtrarError();
	}
	
	public void filtrarProcesadosErrorOnline(){
		ProcesoMasivoCpeBean procesoOnlineCpeBean = new ProcesoMasivoCpeBean();
		procesoOnlineCpeBean.setCodigoParametro1(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		procesoOnlineCpeBean.setCodigoParametro2(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		procesoOnlineCpeBean.setCodigoParametro3(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		procesoOnlineCpeBean.setCodigoParametro4(Constantes.COD_PARAM_CPE_ORIGEN_DATOS);
		procesoOnlineCpeBean.setTipoParametro(Constantes.TIP_PARAM_DETALLE);
		procesoOnlineCpeBean.setIdProceso(proceso.getIdProceso());
		procesoOnlineCpeBean.setBusqIdSocio(socioProcesadosErrorOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.valueOf(socioProcesadosErrorOnlineSelected));
		procesoOnlineCpeBean.setBusqIdProducto(productoProcesadosErrorOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.valueOf(productoProcesadosErrorOnlineSelected));
		procesoOnlineCpeBean.setBusqIdTipoComp(tipComprobanteProcesadosErrorOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipComprobanteProcesadosErrorOnlineSelected);
		procesoOnlineCpeBean.setBusqIdTipoDocCli(tipDocProcesadosOnlineErrorSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipDocProcesadosOnlineErrorSelected);
		procesoOnlineCpeBean.setBusqTipoMoneda(monedaProcesadosErrorOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : monedaProcesadosErrorOnlineSelected);
		procesoOnlineCpeBean.setBusqConcepto(conceptoProcesadosErrorOnline == null ? null : conceptoProcesadosErrorOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : conceptoProcesadosErrorOnline.trim());
		procesoOnlineCpeBean.setBusqCliente(clienteProcesadosErrorOnline == null ? null : clienteProcesadosErrorOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : clienteProcesadosErrorOnline.trim());
		procesoOnlineCpeBean.setBusqNumComp(numCompProcesadosErrorOnline == null ? null : numCompProcesadosErrorOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numCompProcesadosErrorOnline.trim());
		procesoOnlineCpeBean.setBusqFechaEmision(fechaEmisionProcesadosErrorOnline);
		procesoOnlineCpeBean.setBusqMonto(montoProcesadosErrorOnline == null ? null : montoProcesadosErrorOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : montoProcesadosErrorOnline.trim());
		procesoOnlineCpeBean.setBusqCertificado(certificadoProcesadosErrorOnline == null ? null : certificadoProcesadosErrorOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : certificadoProcesadosErrorOnline.trim());
		procesoOnlineCpeBean.setBusqNumDoc(numDocProcesadosErrorOnline == null ? null : numDocProcesadosErrorOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numDocProcesadosErrorOnline.trim());
		procesoOnlineCpeBean.setEstadoComp(Constantes.COD_ESTADO_VENTA_RECHAZADO);
		
		listProcesadosErrorOnline = new ArrayList<ProcesoMasivoCpeBean>();
		listProcesadosErrorOnline = comprobanteCpeService.filtrarProcesoMasivoCpe(procesoOnlineCpeBean);
		
		nroRegistrosProcesadosErrorOnline = listProcesadosErrorOnline.size();
		montoTotalProcesadosErrorOnline = BigDecimal.ZERO;
		for(ProcesoMasivoCpeBean bean : listProcesadosErrorOnline){
			montoTotalProcesadosErrorOnline = montoTotalProcesadosErrorOnline.add(bean.getImpTotal() == null ? BigDecimal.ZERO : bean.getImpTotal());
		}
	}
	
	public void filtrarProcesadosCorrectosOnline(){
		ProcesoMasivoCpeBean procesoOnlineCpeBean = new ProcesoMasivoCpeBean();
		procesoOnlineCpeBean.setCodigoParametro1(Constantes.COD_PARAM_CPE_TIPO_COMPROBANTES);
		procesoOnlineCpeBean.setCodigoParametro2(Constantes.COD_PARAM_CPE_TIPO_MONEDA);
		procesoOnlineCpeBean.setCodigoParametro3(Constantes.COD_PARAM_CPE_ESTADO_VENTA);
		procesoOnlineCpeBean.setCodigoParametro4(Constantes.COD_PARAM_CPE_ORIGEN_DATOS);
		procesoOnlineCpeBean.setTipoParametro(Constantes.TIP_PARAM_DETALLE);
		procesoOnlineCpeBean.setIdProceso(proceso.getIdProceso());
		procesoOnlineCpeBean.setBusqIdSocio(socioProcesadosCorrectosOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.valueOf(socioProcesadosCorrectosOnlineSelected));
		procesoOnlineCpeBean.setBusqIdProducto(productoProcesadosCorrectosOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : Long.valueOf(productoProcesadosCorrectosOnlineSelected));
		procesoOnlineCpeBean.setBusqIdTipoComp(tipComprobanteProcesadosCorrectosOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipComprobanteProcesadosCorrectosOnlineSelected);
		procesoOnlineCpeBean.setBusqIdTipoDocCli(tipDocProcesadosOnlineCorrectosSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : tipDocProcesadosOnlineCorrectosSelected);
		procesoOnlineCpeBean.setBusqTipoMoneda(monedaProcesadosCorrectosOnlineSelected.equals(Constantes.VALOR_DEFECTO_CBX) ? null : monedaProcesadosCorrectosOnlineSelected);
		procesoOnlineCpeBean.setBusqConcepto(conceptoProcesadosCorrectosOnline == null ? null : conceptoProcesadosCorrectosOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : conceptoProcesadosCorrectosOnline.trim());
		procesoOnlineCpeBean.setBusqCliente(clienteProcesadosCorrectosOnline == null ? null : clienteProcesadosCorrectosOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : clienteProcesadosCorrectosOnline.trim());
		procesoOnlineCpeBean.setBusqNumComp(numCompProcesadosCorrectosOnline == null ? null : numCompProcesadosCorrectosOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numCompProcesadosCorrectosOnline.trim());
		procesoOnlineCpeBean.setBusqFechaEmision(fechaEmisionProcesadosCorrectosOnline);
		procesoOnlineCpeBean.setBusqMonto(montoProcesadosCorrectosOnline == null ? null : montoProcesadosCorrectosOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : montoProcesadosCorrectosOnline.trim());
		procesoOnlineCpeBean.setBusqCertificado(certificadoProcesadosCorrectosOnline == null ? null : certificadoProcesadosCorrectosOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : certificadoProcesadosCorrectosOnline.trim());
		procesoOnlineCpeBean.setBusqNumDoc(numDocProcesadosCorrectosOnline == null ? null : numDocProcesadosCorrectosOnline.trim().equals(Constantes.TEXTO_DEFAULT) ? null : numDocProcesadosCorrectosOnline.trim());
		procesoOnlineCpeBean.setEstadoComp(Constantes.COD_ESTADO_VENTA_VALIDADO);
		
		listProcesadosCorrectosOnline = new ArrayList<ProcesoMasivoCpeBean>();
		listProcesadosCorrectosOnline = comprobanteCpeService.filtrarProcesoMasivoCpe(procesoOnlineCpeBean);
		
		nroRegistrosProcesadosCorrectosOnline = listProcesadosCorrectosOnline.size();
		montoTotalProcesadosCorrectosOnline = BigDecimal.ZERO;
		for(ProcesoMasivoCpeBean bean : listProcesadosCorrectosOnline){
			montoTotalProcesadosCorrectosOnline = montoTotalProcesadosCorrectosOnline.add(bean.getImpTotal() == null ? BigDecimal.ZERO : bean.getImpTotal());
		}
	}


	/********************************************************************************************************************/
	/************************************* INSERT TABLA TEMPORAL DE COMPLETADOS *****************************************/
	/********************************************************************************************************************/
	private void InsertIncompletosError(List<VentaCpeBean> list){

		try{
			
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "INSERT INTO CPE_TMP_COMPLETARDATOS "
	        				+"(ID_VENTA,ID_CARGA,ID_EMPRESA,ID_SOCIO,ID_PRODUCTO,ID_PRODUCTO_PIMS,NUMDOC_CLI,NUM_POLIZA,FEC_CREA)"
	        				+"VALUES(?, ?, ?, ?, ?, ?, ?, ?, SYSDATE)";
	        
	        PreparedStatement ps = c.prepareStatement(plsql);
	        
	        for(VentaCpeBean bean : list){
	        	ps.setObject(1, bean.getIdVenta());
	        	ps.setObject(2, bean.getIdCarga());
				ps.setObject(3, bean.getIdEmpresa()); 
				ps.setObject(4, bean.getIdSocio());
				ps.setObject(5, bean.getIdProducto());
				ps.setObject(6, bean.getIdProductoPims());
				ps.setString(7, bean.getNumDocCli());
				ps.setString(8, bean.getNumPoliza());				
				
				ps.addBatch();
	        }
	        
	        ps.executeBatch();
	        ps.close();
	        c.close();
	        
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/********************************************************************************************************************/
	/************************************ FIN INSERT TABLA TEMPORAL DE COMPLETADOS **************************************/
	/********************************************************************************************************************/
	

	/********************************************************************************************************************/
	/************************************ PLSQL COMPLETAR DATOS ACSEL-E  Y UPLOAD ***************************************/
	/********************************************************************************************************************/
	private void completarDatosPimsUpload(Long idCarga, int flgUpd){

		try{
			
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "" +
	        	"	DECLARE " +
				"	  V_IDVENTA       CPE_CARGAVENTA_DET.ID_VENTA%TYPE; " +
				"	  V_IDCARGA       CPE_CARGAVENTA_DET.ID_CARGA%TYPE; " +
				"	  V_NUMPOLIZA     CPE_CARGAVENTA_DET.NUM_POLIZA%TYPE; " +
				"	  V_TIPOMONEDA    CPE_CARGAVENTA_DET.TIPO_MONEDA%TYPE; " +
				"	  V_IDTIPODOCCLI  CPE_CARGAVENTA_DET.ID_TIPODOC_CLI%TYPE; " +
				"	  V_NUMDOCCLI     CPE_CARGAVENTA_DET.NUMDOC_CLI%TYPE; " +
				"	  V_NOMCLIRAZSOC  CPE_CARGAVENTA_DET.NOMCLI_RAZSOC%TYPE; " +
				"	  V_DIRCLI        CPE_CARGAVENTA_DET.DIR_CLI%TYPE; " +
				"	  V_DEPARTAMENTO  CPE_CARGAVENTA_DET.DEPARTAMENTO%TYPE; " +
				"	  V_PROVINCIA     CPE_CARGAVENTA_DET.PROVINCIA%TYPE; " +
				"	  V_DISTRITO      CPE_CARGAVENTA_DET.DISTRITO%TYPE; " +
				""	  +
				"	  CURSOR C_VENTAS  IS " + 
				"	    SELECT TCD.ID_VENTA,TCD.ID_CARGA,PDCO.POD_POLICYNUMBER AS NUM_POLIZA, "+
				"				    CASE POL.POLICYCURRENCYCODEVALUE WHEN  '105' THEN 'PEN' WHEN '125' THEN 'USD' END AS TIPO_MONEDA, " +
				"				    CASE TO_NUMBER(NP.THIRDPARTYDOCUMENTTYPEVALUE,'999.99') WHEN 2 THEN 4 WHEN 4 THEN 6 WHEN 3 THEN 7 WHEN 0 THEN 0 " + 
				"	          ELSE TO_NUMBER(NP.THIRDPARTYDOCUMENTTYPEVALUE,'999.99') END AS ID_TIPODOC_CLI, " +
				"				    TP.THIRDPARTYNBINPUT AS NUMDOC_CLI, TP.THIRDPARTYFULLNAMEINPUT AS NOMCLI_RAZSOC, REPLACE(PA.ADDRESSNAMEINPUT,'}','') AS DIR_CLI, " +
				"				    CASE WHEN UDEP.ID IS NOT NULL THEN UDEP.ID_DEPARTAMENTO || '0000' ELSE NULL END  AS DEPARTAMENTO, " +
				"				    CASE WHEN UPRO.ID IS NOT NULL THEN UPRO.ID_DEPARTAMENTO || UPRO.ID_PROVINCIA || '00' ELSE NULL END AS PROVINCIA , " + 
				"				    CASE WHEN UDIS.ID IS NOT NULL THEN UDIS.ID_DEPARTAMENTO || UDIS.ID_PROVINCIA || UDIS.ID_DISTRITO ELSE NULL END AS DISTRITO " +
				"				FROM BRAXTS_CFG.POLICYDCO PDCO " +
				"				    INNER JOIN BRAXTS_CFG.AGREGATEDPOLICY AGP         ON AGP.AGREGATEDPOLICYID = PDCO.AGREGATEDOBJECTID AND AGP.OPERATIONPK = PDCO.OPERATIONPK " +
				"	          LEFT JOIN  BRAXTS_CFG.STATE ST                    ON ST.STATEID = PDCO.STATEID " +
				"				    INNER JOIN BRAXTS_CFG.CCOPTPPOLICY    POL         ON PDCO.DCOID = POL.PK " +
				"				    INNER JOIN BRAXTS_CFG.RISKUNITDCO RU              ON    RU.AGREGATEDPARENTID  = PDCO.AGREGATEDOBJECTID  AND RU.OPERATIONPK =PDCO.OPERATIONPK " +
				"				    INNER JOIN BRAXTS_CFG.INSURANCEOBJECTDCO IOD      ON    IOD.AGREGATEDPARENTID = RU.AGREGATEDOBJECTID AND IOD.OPERATIONPK = PDCO.OPERATIONPK " +
				"				    INNER JOIN BRAXTS_CFG.PARTICIPATIONVERSIONINSURANCE PVI ON 		PVI.OPERATIONPK = PDCO.OPERATIONPK AND PVI.STATUS=2 AND IOD.AGREGATEDOBJECTID = PVI.AGREGATEDPARENTID " +
				"				    INNER JOIN BRAXTS_CFG.CCOPTPTHIRDPARTY TP 						ON 		TP.STATIC 	  = PVI.THIRDPARTYID " +
				"				    INNER JOIN BRAXTS_CFG.NATURALPERSON NP 								ON 		NP.STATIC 		  = PVI.THIRDPARTYID " +
				"	          INNER JOIN CPE_TMP_COMPLETARDATOS TCD          ON TCD.ID_PRODUCTO_PIMS = AGP.PRODUCTID AND PDCO.POD_POLICYNUMBER = TCD.NUM_POLIZA " +
				"				    LEFT JOIN BRAXTS_CFG.STTE_THIRDPARTYADDRESSBOOK TAB 		ON 		TAB.TPT_ID 			= TP.STATIC AND TAB.TAB_TYPE = 3 " +
				"				    LEFT JOIN BRAXTS_CFG.CCOXTPPOSTALADDRESS PA 						ON 		PA.STATIC 			= TAB.TAB_ID " +
				"	          LEFT JOIN CPE_UBIGEO UDEP   ON UPPER(UDEP.NOM_UBIGEO) = UPPER(PA.STATENAMEINPUT) AND UDEP.ID_PROVINCIA = '00' AND UDEP.ID_DISTRITO = '00' " +
				"	          LEFT JOIN CPE_UBIGEO UPRO   ON UPPER(UPRO.NOM_UBIGEO) = UPPER(PA.TOWNNAMEINPUT) AND UPRO.ID_DISTRITO = '00' AND UDEP.ID_DEPARTAMENTO = UPRO.ID_DEPARTAMENTO AND UPRO.ID_PROVINCIA <> '00' " +
				"	          LEFT JOIN CPE_UBIGEO UDIS   ON UPPER(UDIS.NOM_UBIGEO) = UPPER(PA.NEIGHBOURHOODNAMEINPUT) AND UDIS.ID_PROVINCIA = UPRO.ID_PROVINCIA AND UDIS.ID_DEPARTAMENTO = UPRO.ID_DEPARTAMENTO " +			
				"				WHERE PDCO.STATUS = 2 " +
				"	          AND ST.DESCRIPTION = 'In force' " +
				"	          AND TCD.ID_CARGA = " + idCarga +
				
				" 	   			;" +	
				"	BEGIN " +
				"	  OPEN C_VENTAS; " +
				"	  LOOP " +
				"	  FETCH C_VENTAS INTO V_IDVENTA,V_IDCARGA,V_NUMPOLIZA,V_TIPOMONEDA,V_IDTIPODOCCLI,V_NUMDOCCLI,V_NOMCLIRAZSOC,V_DIRCLI,V_DEPARTAMENTO,V_PROVINCIA,V_DISTRITO; " +
				"	  EXIT WHEN C_VENTAS%NOTFOUND; " +
				""	      +	
				"	      UPDATE CPE_CARGAVENTA_DET SET " + 
				"	      NUM_POLIZA = CASE WHEN NUM_POLIZA IS NULL THEN V_NUMPOLIZA ELSE NUM_POLIZA END, " + 
				"	      TIPO_MONEDA = CASE WHEN TIPO_MONEDA IS NULL THEN V_TIPOMONEDA ELSE TIPO_MONEDA END, " +
				"	      ID_TIPODOC_CLI = CASE WHEN ID_TIPODOC_CLI IS NULL OR TRIM(ID_TIPODOC_CLI) <> TRIM(V_IDTIPODOCCLI) THEN '0'||TRIM(V_IDTIPODOCCLI) ELSE ID_TIPODOC_CLI END, " + 
				"	      ID_TIPO_COMP = CASE WHEN TRIM(V_IDTIPODOCCLI) = '6' THEN '01' ELSE ID_TIPO_COMP END, " +
				"	      NUMDOC_CLI = CASE WHEN NUMDOC_CLI IS NULL THEN V_NUMDOCCLI ELSE NUMDOC_CLI END, " +
				"	      NOMCLI_RAZSOC = CASE WHEN NOMCLI_RAZSOC IS NULL THEN V_NOMCLIRAZSOC ELSE NOMCLI_RAZSOC END, " + 
				"	      DIR_CLI = CASE WHEN DIR_CLI IS NULL THEN V_DIRCLI ELSE DIR_CLI END, " +
				"	      DEPARTAMENTO = V_DEPARTAMENTO, " +
				"	      PROVINCIA = V_PROVINCIA, " +
				"	      DISTRITO = V_DISTRITO, " +
				"	      FLG_PIMS = 1 " +
				"	      WHERE ID_VENTA = V_IDVENTA AND ID_CARGA = V_IDCARGA; " +				
				""	     +
				"	  END LOOP; " +
				"	  CLOSE C_VENTAS; " +
	        	"	  EXCEPTION " +
	        	"	  	WHEN OTHERS THEN " +
	        	"	    SYS.DBMS_OUTPUT.PUT_LINE(SQLERRM); " +
	        	"	END; ";
	        
	        CallableStatement cs = c.prepareCall(plsql);	
	        cs.execute();
	        cs.close();
	        c.close();
	        
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/********************************************************************************************************************/
	/*************************************** FIN PLSQL COMPLETAR DATOS ACSEL-E ******************************************/
	/********************************************************************************************************************/
	
	/********************************************************************************************************************/
	/********************************** PLSQL INSERT MASIVO CPE_PROCESOCE_VENTA  ****************************************/
	/********************************************************************************************************************/
	
	private void insertProcesoVentaPLSQL(List<VentaCpeBean> list, int estado){
	
		try{
			final Connection c = dataSourceSatelite.getDataSourceCpe().getConnection();
	        String plsql = "INSERT INTO CPE_PROCESOCE_VENTA"
	        				+"(ID_VENTAPROCESO, ID_PROCESO, ID_VENTA, ESTADO)"
	        				+"VALUES(SEC_CPE_PROCESOCE_VENTA.NEXTVAL, ?, ?, ?)";
	        
	        PreparedStatement ps = c.prepareStatement(plsql);
	        
	        for(VentaCpeBean bean : list){
	        	ps.setObject(1, bean.getIdProceso());
	        	ps.setObject(2, bean.getIdVenta());
	        	ps.setObject(3, estado);
				ps.addBatch();
	        }
	        
	        ps.executeBatch();
	        ps.close();
	        c.close();
	        
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, ErrorConstants.MSJ_ERROR_GENERAL,
					null);
			FacesContext.getCurrentInstance().addMessage(null, facesMsg);
		}
	}
	
	/********************************************************************************************************************/
	/********************************* FIN PLSQL INSERT MASIVO CPE_PROCESOCE_VENTA  *************************************/
	/********************************************************************************************************************/
	
	private String listarParametro(String codParametro, String codValor){
		ParametroCpeBean parametroBean = new ParametroCpeBean();
		parametroBean.setCodParam(codParametro);
		parametroBean.setTipParam(Constantes.TIP_PARAM_DETALLE);
		parametroBean.setCodValor(codValor);
		parametroBean = parametroCpeService.listarParametro(parametroBean).get(0);
		return parametroBean.getNomValor();
	}
	
	public String goToCompRef(){
		inicializarFiltrosRef();
		inicializarResultadosRef();
		cargarCbxRef();
		
		return "toCompRef";
	}
	
	private Date sumarDia(Date fecha){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fecha);
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		return calendar.getTime();
	}
	
	public void filtrarRef(){
		
	}
	
	public void obtenerFilaAgrupadoBus(){
		cabBusquedaAgrupDet = (CargaVentaCabCpeBean)FacesContext.getCurrentInstance()
								.getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_agru}", CargaVentaCabCpeBean.class);
	}
	
	public void obtenerFilaDetalladoBus(){
		detBusquedaDetallado = (VentaCpeBean)FacesContext.getCurrentInstance()
								.getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_det}", VentaCpeBean.class);
	}
	
	public void obtenerFilaDetalladoBusProc(){
		detBusquedaDetalladoProc = (VentaCpeBean)FacesContext.getCurrentInstance()
								.getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_regProcesar}", VentaCpeBean.class);
	}
	
	public void obtenerFilaDetalladoPreProcError(){
		detPreProcError = (VentaCpeBean)FacesContext.getCurrentInstance()
								.getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaError}", VentaCpeBean.class);
	}
	
	public void obtenerFilaDetalladoPreProcOk(){
		detPreProcOk = (VentaCpeBean)FacesContext.getCurrentInstance()
								.getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_ventaProcesar}", VentaCpeBean.class);
	}
	
	public void scrolListenerSelected(){
		VentaCpeBean bean = (VentaCpeBean)FacesContext.getCurrentInstance().getApplication().evaluateExpressionGet(FacesContext.getCurrentInstance(), "#{_regProcesar}", VentaCpeBean.class);
		if(!bean.isSeleccionado()){
			allSelectedRegProc = false;
		}
	}
	
	public List<SelectItem> getUsuarioItems() {
		return usuarioItems;
	}

	public void setUsuarioItems(List<SelectItem> usuarioItems) {
		this.usuarioItems = usuarioItems;
	}
	
	public List<SelectItem> getEstadoItems() {
		return estadoItems;
	}

	public void setEstadoItems(List<SelectItem> estadoItems) {
		this.estadoItems = estadoItems;
	}
	
	public String getUsuarioSelected() {
		return usuarioSelected;
	}

	public void setUsuarioSelected(String usuarioSelected) {
		this.usuarioSelected = usuarioSelected;
	}

	public String getEstadoSelected() {
		return estadoSelected;
	}

	public void setEstadoSelected(String estadoSelected) {
		this.estadoSelected = estadoSelected;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getConReg() {
		return conReg;
	}

	public void setConReg(String conReg) {
		this.conReg = conReg;
	}
	
	public List<ProcesoCpeBean> getListProcesoCpe() {
		return listProcesoCpe;
	}

	public void setListProcesoCpe(List<ProcesoCpeBean> listProcesoCpe) {
		this.listProcesoCpe = listProcesoCpe;
	}
	
	public int getNroRegistros() {
		return nroRegistros;
	}

	public void setNroRegistros(int nroRegistros) {
		this.nroRegistros = nroRegistros;
	}
	
	public String getUsuarioSesion() {
		return usuarioSesion;
	}

	public void setUsuarioSesion(String usuarioSesion) {
		this.usuarioSesion = usuarioSesion;
	}
	
	public String getUsuarioTransaction() {
		return usuarioTransaction;
	}

	public void setUsuarioTransaction(String usuarioTransaction) {
		this.usuarioTransaction = usuarioTransaction;
	}

	public String getNombreProcesoTransaction() {
		return nombreProcesoTransaction;
	}

	public void setNombreProcesoTransaction(String nombreProcesoTransaction) {
		this.nombreProcesoTransaction = nombreProcesoTransaction;
	}

	public String getEstadoTransaction() {
		return estadoTransaction;
	}

	public void setEstadoTransaction(String estadoTransaction) {
		this.estadoTransaction = estadoTransaction;
	}
	
	public String getEliminarProcesoPregunta(){
		return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ELIMINAR_PROCESO_PREGUNTA);
	}
	
	public String getEliminarProcesoConfirmacion(){
		return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ELIMINAR_PROCESO_CONFIRMACION);
	}
	
	public String getNoEliminarProcesoConfirmacion(){
		return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_NO_ELIMINAR_PROCESO);
	}
	
	public String getRegistroCompletadoComprobanteManual(){
		return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_REGISTRO_COMPLETADO_COMPROBANTE_MANUAL);
	}
	
	public Long getIdProcesoTransaction() {
		return idProcesoTransaction;
	}

	public void setIdProcesoTransaction(Long idProcesoTransaction) {
		this.idProcesoTransaction = idProcesoTransaction;
	}
	
	public ProcesoCpeBean getProceso() {
		return proceso;
	}

	public void setProceso(ProcesoCpeBean proceso) {
		this.proceso = proceso;
	}
	
	public List<SelectItem> getSocioRegistrosErrorItems() {
		return socioRegistrosErrorItems;
	}

	public void setSocioRegistrosErrorItems(
			List<SelectItem> socioRegistrosErrorItems) {
		this.socioRegistrosErrorItems = socioRegistrosErrorItems;
	}
	
	public List<SelectItem> getTipCompRegistrosErrorItems() {
		return tipCompRegistrosErrorItems;
	}

	public void setTipCompRegistrosErrorItems(
			List<SelectItem> tipCompRegistrosErrorItems) {
		this.tipCompRegistrosErrorItems = tipCompRegistrosErrorItems;
	}
	
	public List<SelectItem> getMonedaRegistrosErrorItems() {
		return monedaRegistrosErrorItems;
	}

	public void setMonedaRegistrosErrorItems(
			List<SelectItem> monedaRegistrosErrorItems) {
		this.monedaRegistrosErrorItems = monedaRegistrosErrorItems;
	}
	
	public List<SelectItem> getTipDocRegistrosErrosItems() {
		return tipDocRegistrosErrosItems;
	}

	public void setTipDocRegistrosErrosItems(
			List<SelectItem> tipDocRegistrosErrosItems) {
		this.tipDocRegistrosErrosItems = tipDocRegistrosErrosItems;
	}
	
	public List<SelectItem> getProductoRegistrosErrorItems() {
		return productoRegistrosErrorItems;
	}

	public void setProductoRegistrosErrorItems(
			List<SelectItem> productoRegistrosErrorItems) {
		this.productoRegistrosErrorItems = productoRegistrosErrorItems;
	}
	
	public String getSocioErrorSelected() {
		return socioErrorSelected;
	}

	public void setSocioErrorSelected(String socioErrorSelected) {
		this.socioErrorSelected = socioErrorSelected;
	}
	
	public Date getFecEmisionError() {
		return fecEmisionError;
	}

	public void setFecEmisionError(Date fecEmisionError) {
		this.fecEmisionError = fecEmisionError;
	}
	
	public String getProductoErrorSelected() {
		return productoErrorSelected;
	}

	public void setProductoErrorSelected(String productoErrorSelected) {
		this.productoErrorSelected = productoErrorSelected;
	}

	public String getConceptoError() {
		return conceptoError;
	}

	public void setConceptoError(String conceptoError) {
		this.conceptoError = conceptoError;
	}

	public String getClienteError() {
		return clienteError;
	}

	public void setClienteError(String clienteError) {
		this.clienteError = clienteError;
	}

	public String getTipCompErrorSelected() {
		return tipCompErrorSelected;
	}

	public void setTipCompErrorSelected(String tipCompErrorSelected) {
		this.tipCompErrorSelected = tipCompErrorSelected;
	}

	public String getNumCompError() {
		return numCompError;
	}

	public void setNumCompError(String numCompError) {
		this.numCompError = numCompError;
	}

	public String getTipDocErrorSelected() {
		return tipDocErrorSelected;
	}

	public void setTipDocErrorSelected(String tipDocErrorSelected) {
		this.tipDocErrorSelected = tipDocErrorSelected;
	}

	public String getMonedaErrorSelected() {
		return monedaErrorSelected;
	}

	public void setMonedaErrorSelected(String monedaErrorSelected) {
		this.monedaErrorSelected = monedaErrorSelected;
	}

	public String getMontoError() {
		return montoError;
	}

	public void setMontoError(String montoError) {
		this.montoError = montoError;
	}

	public String getCertificadoError() {
		return certificadoError;
	}

	public void setCertificadoError(String certificadoError) {
		this.certificadoError = certificadoError;
	}

	public String getNumDocError() {
		return numDocError;
	}

	public void setNumDocError(String numDocError) {
		this.numDocError = numDocError;
	}
	
	public String getSocioProcesarSelected() {
		return socioProcesarSelected;
	}

	public void setSocioProcesarSelected(String socioProcesarSelected) {
		this.socioProcesarSelected = socioProcesarSelected;
	}

	public Date getFecEmisionProcesar() {
		return fecEmisionProcesar;
	}

	public void setFecEmisionProcesar(Date fecEmisionProcesar) {
		this.fecEmisionProcesar = fecEmisionProcesar;
	}

	public String getProductoProcesarSelected() {
		return productoProcesarSelected;
	}

	public void setProductoProcesarSelected(String productoProcesarSelected) {
		this.productoProcesarSelected = productoProcesarSelected;
	}

	public String getConceptoProcesar() {
		return conceptoProcesar;
	}

	public void setConceptoProcesar(String conceptoProcesar) {
		this.conceptoProcesar = conceptoProcesar;
	}

	public String getClienteProcesar() {
		return clienteProcesar;
	}

	public void setClienteProcesar(String clienteProcesar) {
		this.clienteProcesar = clienteProcesar;
	}

	public String getTipCompProcesarSelected() {
		return tipCompProcesarSelected;
	}

	public void setTipCompProcesarSelected(String tipCompProcesarSelected) {
		this.tipCompProcesarSelected = tipCompProcesarSelected;
	}

	public String getNumCompProcesar() {
		return numCompProcesar;
	}

	public void setNumCompProcesar(String numCompProcesar) {
		this.numCompProcesar = numCompProcesar;
	}

	public String getTipDocProcesarSelected() {
		return tipDocProcesarSelected;
	}

	public void setTipDocProcesarSelected(String tipDocProcesarSelected) {
		this.tipDocProcesarSelected = tipDocProcesarSelected;
	}

	public String getMonedaProcesarSelected() {
		return monedaProcesarSelected;
	}

	public void setMonedaProcesarSelected(String monedaProcesarSelected) {
		this.monedaProcesarSelected = monedaProcesarSelected;
	}

	public String getMontoProcesar() {
		return montoProcesar;
	}

	public void setMontoProcesar(String montoProcesar) {
		this.montoProcesar = montoProcesar;
	}

	public String getCertificadoProcesar() {
		return certificadoProcesar;
	}

	public void setCertificadoProcesar(String certificadoProcesar) {
		this.certificadoProcesar = certificadoProcesar;
	}

	public String getNumDocProcesar() {
		return numDocProcesar;
	}

	public void setNumDocProcesar(String numDocProcesar) {
		this.numDocProcesar = numDocProcesar;
	}

	public List<SelectItem> getSocioRegistrosProcesarItems() {
		return socioRegistrosProcesarItems;
	}

	public void setSocioRegistrosProcesarItems(
			List<SelectItem> socioRegistrosProcesarItems) {
		this.socioRegistrosProcesarItems = socioRegistrosProcesarItems;
	}

	public List<SelectItem> getTipCompRegistrosProcesarItems() {
		return tipCompRegistrosProcesarItems;
	}

	public void setTipCompRegistrosProcesarItems(
			List<SelectItem> tipCompRegistrosProcesarItems) {
		this.tipCompRegistrosProcesarItems = tipCompRegistrosProcesarItems;
	}

	public List<SelectItem> getMonedaRegistrosProcesarItems() {
		return monedaRegistrosProcesarItems;
	}

	public void setMonedaRegistrosProcesarItems(
			List<SelectItem> monedaRegistrosProcesarItems) {
		this.monedaRegistrosProcesarItems = monedaRegistrosProcesarItems;
	}

	public List<SelectItem> getTipDocRegistrosProcesarItems() {
		return tipDocRegistrosProcesarItems;
	}

	public void setTipDocRegistrosProcesarItems(
			List<SelectItem> tipDocRegistrosProcesarItems) {
		this.tipDocRegistrosProcesarItems = tipDocRegistrosProcesarItems;
	}
	
	public List<SelectItem> getProductoRegistrosProcesarItems() {
		return productoRegistrosProcesarItems;
	}

	public void setProductoRegistrosProcesarItems(
			List<SelectItem> productoRegistrosProcesarItems) {
		this.productoRegistrosProcesarItems = productoRegistrosProcesarItems;
	}
	
	public List<VentaCpeBean> getListVentaProcesar() {
		return listVentaProcesar;
	}

	public void setListVentaProcesar(List<VentaCpeBean> listVentaProcesar) {
		this.listVentaProcesar = listVentaProcesar;
	}
	
	public int getNroRegistrosProcesar() {
		return nroRegistrosProcesar;
	}

	public void setNroRegistrosProcesar(int nroRegistrosProcesar) {
		this.nroRegistrosProcesar = nroRegistrosProcesar;
	}
	
	public String getLabelMonedaProcesar() {
		return labelMonedaProcesar;
	}

	public void setLabelMonedaProcesar(String labelMonedaProcesar) {
		this.labelMonedaProcesar = labelMonedaProcesar;
	}
	
	public SimpleDateFormat getFormatoddMMaaaa() {
		return formatoddMMaaaa;
	}

	public void setFormatoddMMaaaa(SimpleDateFormat formatoddMMaaaa) {
		this.formatoddMMaaaa = formatoddMMaaaa;
	}
	
	public List<VentaCpeBean> getListVentaError() {
		return listVentaError;
	}

	public void setListVentaError(List<VentaCpeBean> listVentaError) {
		this.listVentaError = listVentaError;
	}

	public int getNroRegistrosError() {
		return nroRegistrosError;
	}

	public void setNroRegistrosError(int nroRegistrosError) {
		this.nroRegistrosError = nroRegistrosError;
	}
	
	public List<SelectItem> getSocioComprobanteItems() {
		return socioComprobanteItems;
	}

	public void setSocioComprobanteItems(List<SelectItem> socioComprobanteItems) {
		this.socioComprobanteItems = socioComprobanteItems;
	}

	public List<SelectItem> getTipCompComprobanteItems() {
		return tipCompComprobanteItems;
	}

	public void setTipCompComprobanteItems(List<SelectItem> tipCompComprobanteItems) {
		this.tipCompComprobanteItems = tipCompComprobanteItems;
	}

	public List<SelectItem> getProductoComprobanteItems() {
		return productoComprobanteItems;
	}

	public void setProductoComprobanteItems(
			List<SelectItem> productoComprobanteItems) {
		this.productoComprobanteItems = productoComprobanteItems;
	}

	public List<SelectItem> getEstadoComprobanteItems() {
		return estadoComprobanteItems;
	}

	public void setEstadoComprobanteItems(List<SelectItem> estadoComprobanteItems) {
		this.estadoComprobanteItems = estadoComprobanteItems;
	}

	public List<SelectItem> getTipDocComprobanteItems() {
		return tipDocComprobanteItems;
	}

	public void setTipDocComprobanteItems(List<SelectItem> tipDocComprobanteItems) {
		this.tipDocComprobanteItems = tipDocComprobanteItems;
	}

	public List<SelectItem> getDepartamentoComprobanteItems() {
		return departamentoComprobanteItems;
	}

	public void setDepartamentoComprobanteItems(
			List<SelectItem> departamentoComprobanteItems) {
		this.departamentoComprobanteItems = departamentoComprobanteItems;
	}

	public List<SelectItem> getProvinciaComprobanteItems() {
		return provinciaComprobanteItems;
	}

	public void setProvinciaComprobanteItems(
			List<SelectItem> provinciaComprobanteItems) {
		this.provinciaComprobanteItems = provinciaComprobanteItems;
	}

	public List<SelectItem> getDistritoComprobanteItems() {
		return distritoComprobanteItems;
	}

	public void setDistritoComprobanteItems(
			List<SelectItem> distritoComprobanteItems) {
		this.distritoComprobanteItems = distritoComprobanteItems;
	}
	
	public String getSocioComprobanteSelected() {
		return socioComprobanteSelected;
	}

	public void setSocioComprobanteSelected(String socioComprobanteSelected) {
		this.socioComprobanteSelected = socioComprobanteSelected;
	}

	public String getProductoComprobanteSelected() {
		return productoComprobanteSelected;
	}

	public void setProductoComprobanteSelected(String productoComprobanteSelected) {
		this.productoComprobanteSelected = productoComprobanteSelected;
	}
	
	public List<SelectItem> getTipCompRefComprobanteItems() {
		return tipCompRefComprobanteItems;
	}

	public void setTipCompRefComprobanteItems(
			List<SelectItem> tipCompRefComprobanteItems) {
		this.tipCompRefComprobanteItems = tipCompRefComprobanteItems;
	}
	
	public String getReferenciaComprobanteSelected() {
		return referenciaComprobanteSelected;
	}

	public void setReferenciaComprobanteSelected(
			String referenciaComprobanteSelected) {
		this.referenciaComprobanteSelected = referenciaComprobanteSelected;
	}
	
	public boolean isReferenciaBoolean() {
		return referenciaBoolean;
	}

	public void setReferenciaBoolean(boolean referenciaBoolean) {
		this.referenciaBoolean = referenciaBoolean;
	}
	
	public String getTipDocComprobanteSelected() {
		return tipDocComprobanteSelected;
	}

	public void setTipDocComprobanteSelected(String tipDocComprobanteSelected) {
		this.tipDocComprobanteSelected = tipDocComprobanteSelected;
	}

	public String getTipCompComprobanteSelected() {
		return tipCompComprobanteSelected;
	}

	public void setTipCompComprobanteSelected(String tipCompComprobanteSelected) {
		this.tipCompComprobanteSelected = tipCompComprobanteSelected;
	}
	
	public String getEstadoComprobanteSelected() {
		return estadoComprobanteSelected;
	}

	public void setEstadoComprobanteSelected(String estadoComprobanteSelected) {
		this.estadoComprobanteSelected = estadoComprobanteSelected;
	}
	
	public Date getFechaRegistroComprobante() {
		return fechaRegistroComprobante;
	}

	public void setFechaRegistroComprobante(Date fechaRegistroComprobante) {
		this.fechaRegistroComprobante = fechaRegistroComprobante;
	}
	
	public Date getFechaVencimientoComprobante() {
		return fechaVencimientoComprobante;
	}

	public void setFechaVencimientoComprobante(Date fechaVencimientoComprobante) {
		this.fechaVencimientoComprobante = fechaVencimientoComprobante;
	}
	
	public String getNumDocComprobante() {
		return numDocComprobante;
	}

	public void setNumDocComprobante(String numDocComprobante) {
		this.numDocComprobante = numDocComprobante;
	}

	public String getClienteComprobante() {
		return clienteComprobante;
	}

	public void setClienteComprobante(String clienteComprobante) {
		this.clienteComprobante = clienteComprobante;
	}

	public String getDireccionComprobante() {
		return direccionComprobante;
	}

	public void setDireccionComprobante(String direccionComprobante) {
		this.direccionComprobante = direccionComprobante;
	}

	public String getDepartamentoComprobante() {
		return departamentoComprobante;
	}

	public void setDepartamentoComprobante(String departamentoComprobante) {
		this.departamentoComprobante = departamentoComprobante;
	}

	public String getProvinciaComprobante() {
		return provinciaComprobante;
	}

	public void setProvinciaComprobante(String provinciaComprobante) {
		this.provinciaComprobante = provinciaComprobante;
	}

	public String getDistritoComprobante() {
		return distritoComprobante;
	}

	public void setDistritoComprobante(String distritoComprobante) {
		this.distritoComprobante = distritoComprobante;
	}

	public String getCodProdSunat() {
		return codProdSunat;
	}

	public void setCodProdSunat(String codProdSunat) {
		this.codProdSunat = codProdSunat;
	}
	
	public boolean isDisabledCodProdSunat() {
		return disabledCodProdSunat;
	}

	public void setDisabledCodProdSunat(boolean disabledCodProdSunat) {
		this.disabledCodProdSunat = disabledCodProdSunat;
	}
	
	public String getConceptoComprobante() {
		return conceptoComprobante;
	}

	public void setConceptoComprobante(String conceptoComprobante) {
		this.conceptoComprobante = conceptoComprobante;
	}

	public String getNumeroSerieComprobante() {
		return numeroSerieComprobante;
	}

	public void setNumeroSerieComprobante(String numeroSerieComprobante) {
		this.numeroSerieComprobante = numeroSerieComprobante;
	}

	public String getNumeroCorrelativoComprobante() {
		return numeroCorrelativoComprobante;
	}

	public void setNumeroCorrelativoComprobante(String numeroCorrelativoComprobante) {
		this.numeroCorrelativoComprobante = numeroCorrelativoComprobante;
	}

	public String getTipCompRefComprobanteSelected() {
		return tipCompRefComprobanteSelected;
	}

	public void setTipCompRefComprobanteSelected(
			String tipCompRefComprobanteSelected) {
		this.tipCompRefComprobanteSelected = tipCompRefComprobanteSelected;
	}

	public Date getFechaEmisionComprobante() {
		return fechaEmisionComprobante;
	}

	public void setFechaEmisionComprobante(Date fechaEmisionComprobante) {
		this.fechaEmisionComprobante = fechaEmisionComprobante;
	}

	public String getValFactExportComprobante() {
		return valFactExportComprobante;
	}

	public void setValFactExportComprobante(String valFactExportComprobante) {
		this.valFactExportComprobante = valFactExportComprobante;
	}

	public String getBaseImponibleComprobante() {
		return baseImponibleComprobante;
	}

	public void setBaseImponibleComprobante(String baseImponibleComprobante) {
		this.baseImponibleComprobante = baseImponibleComprobante;
	}

	public String getImpInafectoComprobante() {
		return impInafectoComprobante;
	}

	public void setImpInafectoComprobante(String impInafectoComprobante) {
		this.impInafectoComprobante = impInafectoComprobante;
	}

	public String getImpExoneradoComprobante() {
		return impExoneradoComprobante;
	}

	public void setImpExoneradoComprobante(String impExoneradoComprobante) {
		this.impExoneradoComprobante = impExoneradoComprobante;
	}

	public String getIscComprobante() {
		return iscComprobante;
	}

	public void setIscComprobante(String iscComprobante) {
		this.iscComprobante = iscComprobante;
	}

	public String getIgvComprobante() {
		return igvComprobante;
	}

	public void setIgvComprobante(String igvComprobante) {
		this.igvComprobante = igvComprobante;
	}

	public String getOtrosImportesComprobante() {
		return otrosImportesComprobante;
	}

	public void setOtrosImportesComprobante(String otrosImportesComprobante) {
		this.otrosImportesComprobante = otrosImportesComprobante;
	}

	public String getImporteTotalComprobante() {
		return importeTotalComprobante;
	}

	public void setImporteTotalComprobante(String importeTotalComprobante) {
		this.importeTotalComprobante = importeTotalComprobante;
	}
	
	public BigDecimal getMontoTotalProcesar() {
		return montoTotalProcesar;
	}

	public void setMontoTotalProcesar(BigDecimal montoTotalProcesar) {
		this.montoTotalProcesar = montoTotalProcesar;
	}
	
	public List<SelectItem> getMonedaComprobanteItems() {
		return monedaComprobanteItems;
	}

	public void setMonedaComprobanteItems(List<SelectItem> monedaComprobanteItems) {
		this.monedaComprobanteItems = monedaComprobanteItems;
	}

	public String getMonedaComprobanteSelected() {
		return monedaComprobanteSelected;
	}

	public void setMonedaComprobanteSelected(String monedaComprobanteSelected) {
		this.monedaComprobanteSelected = monedaComprobanteSelected;
	}
	
	public List<SelectItem> getEmpresaComprobanteItems() {
		return empresaComprobanteItems;
	}

	public void setEmpresaComprobanteItems(List<SelectItem> empresaComprobanteItems) {
		this.empresaComprobanteItems = empresaComprobanteItems;
	}

	public String getEmpresaComprobanteSelected() {
		return empresaComprobanteSelected;
	}

	public void setEmpresaComprobanteSelected(String empresaComprobanteSelected) {
		this.empresaComprobanteSelected = empresaComprobanteSelected;
	}
	
	public String getTelefonoComprobante() {
		return telefonoComprobante;
	}

	public void setTelefonoComprobante(String telefonoComprobante) {
		this.telefonoComprobante = telefonoComprobante;
	}

	public String getCorreoComprobante() {
		return correoComprobante;
	}

	public void setCorreoComprobante(String correoComprobante) {
		this.correoComprobante = correoComprobante;
	}
	
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
	public Long getIdVentaEdicion() {
		return idVentaEdicion;
	}

	public void setIdVentaEdicion(Long idVentaEdicion) {
		this.idVentaEdicion = idVentaEdicion;
	}
	
	public List<SelectItem> getSocioBusquedaItems() {
		return socioBusquedaItems;
	}

	public void setSocioBusquedaItems(List<SelectItem> socioBusquedaItems) {
		this.socioBusquedaItems = socioBusquedaItems;
	}

	public List<SelectItem> getMonedaBusquedaItems() {
		return monedaBusquedaItems;
	}

	public void setMonedaBusquedaItems(List<SelectItem> monedaBusquedaItems) {
		this.monedaBusquedaItems = monedaBusquedaItems;
	}

	public List<SelectItem> getTipCompBusquedaItems() {
		return tipCompBusquedaItems;
	}

	public void setTipCompBusquedaItems(List<SelectItem> tipCompBusquedaItems) {
		this.tipCompBusquedaItems = tipCompBusquedaItems;
	}
	
	public List<SelectItem> getEstadoBusquedaItems() {
		return estadoBusquedaItems;
	}

	public void setEstadoBusquedaItems(List<SelectItem> estadoBusquedaItems) {
		this.estadoBusquedaItems = estadoBusquedaItems;
	}

	public List<SelectItem> getOrigenBusquedaItems() {
		return origenBusquedaItems;
	}

	public void setOrigenBusquedaItems(List<SelectItem> origenBusquedaItems) {
		this.origenBusquedaItems = origenBusquedaItems;
	}

	public List<SelectItem> getTipDocBusquedaItems() {
		return tipDocBusquedaItems;
	}

	public void setTipDocBusquedaItems(List<SelectItem> tipDocBusquedaItems) {
		this.tipDocBusquedaItems = tipDocBusquedaItems;
	}
	
	public String getSocioBusquedaSelected() {
		return socioBusquedaSelected;
	}

	public void setSocioBusquedaSelected(String socioBusquedaSelected) {
		this.socioBusquedaSelected = socioBusquedaSelected;
	}

	public String getProductoBusquedaSelected() {
		return productoBusquedaSelected;
	}

	public void setProductoBusquedaSelected(String productoBusquedaSelected) {
		this.productoBusquedaSelected = productoBusquedaSelected;
	}
	
	public List<SelectItem> getProductoBusquedaItems() {
		return productoBusquedaItems;
	}

	public void setProductoBusquedaItems(List<SelectItem> productoBusquedaItems) {
		this.productoBusquedaItems = productoBusquedaItems;
	}
	
	public String getEstadoBusquedaSelected() {
		return estadoBusquedaSelected;
	}

	public void setEstadoBusquedaSelected(String estadoBusquedaSelected) {
		this.estadoBusquedaSelected = estadoBusquedaSelected;
	}
	
	public String getOrigenBusquedaSelected() {
		return origenBusquedaSelected;
	}

	public void setOrigenBusquedaSelected(String origenBusquedaSelected) {
		this.origenBusquedaSelected = origenBusquedaSelected;
	}
	
	public boolean isDisabledUpload() {
		return disabledUpload;
	}

	public void setDisabledUpload(boolean disabledUpload) {
		this.disabledUpload = disabledUpload;
	}
	
	public String getTipBusqueda() {
		return tipBusqueda;
	}

	public void setTipBusqueda(String tipBusqueda) {
		this.tipBusqueda = tipBusqueda;
	}
	
	public String getClienteBusqueda() {
		return clienteBusqueda;
	}

	public void setClienteBusqueda(String clienteBusqueda) {
		this.clienteBusqueda = clienteBusqueda;
	}
	
	public String getTipDocBusqueda() {
		return tipDocBusqueda;
	}

	public void setTipDocBusqueda(String tipDocBusqueda) {
		this.tipDocBusqueda = tipDocBusqueda;
	}
	
	public String getNumDocBusqueda() {
		return numDocBusqueda;
	}

	public void setNumDocBusqueda(String numDocBusqueda) {
		this.numDocBusqueda = numDocBusqueda;
	}
	
	public Date getFechaDesdeBusqueda() {
		return fechaDesdeBusqueda;
	}

	public void setFechaDesdeBusqueda(Date fechaDesdeBusqueda) {
		this.fechaDesdeBusqueda = fechaDesdeBusqueda;
	}

	public Date getFechaHastaBusqueda() {
		return fechaHastaBusqueda;
	}

	public void setFechaHastaBusqueda(Date fechaHastaBusqueda) {
		this.fechaHastaBusqueda = fechaHastaBusqueda;
	}
	
	public String getCertificadoBusqueda() {
		return certificadoBusqueda;
	}

	public void setCertificadoBusqueda(String certificadoBusqueda) {
		this.certificadoBusqueda = certificadoBusqueda;
	}
	public String getMonedaBusquedaSelected() {
		return monedaBusquedaSelected;
	}

	public void setMonedaBusquedaSelected(String monedaBusquedaSelected) {
		this.monedaBusquedaSelected = monedaBusquedaSelected;
	}
	
	public String getCodUploadBusqueda() {
		return codUploadBusqueda;
	}

	public void setCodUploadBusqueda(String codUploadBusqueda) {
		this.codUploadBusqueda = codUploadBusqueda;
	}
	
	public String getTipCompBusquedaSelected() {
		return tipCompBusquedaSelected;
	}

	public void setTipCompBusquedaSelected(String tipCompBusquedaSelected) {
		this.tipCompBusquedaSelected = tipCompBusquedaSelected;
	}
	
	public String getNumCompBusqueda() {
		return numCompBusqueda;
	}

	public void setNumCompBusqueda(String numCompBusqueda) {
		this.numCompBusqueda = numCompBusqueda;
	}
	
	public String getLoteBusqueda() {
		return loteBusqueda;
	}

	public void setLoteBusqueda(String loteBusqueda) {
		this.loteBusqueda = loteBusqueda;
	}
	
	public boolean isAgrupado() {
		return agrupado;
	}

	public void setAgrupado(boolean agrupado) {
		this.agrupado = agrupado;
	}

	public boolean isDetallado() {
		return detallado;
	}

	public void setDetallado(boolean detallado) {
		this.detallado = detallado;
	}
	
	public List<VentaCpeBean> getListDetallada() {
		return listDetallada;
	}

	public void setListDetallada(List<VentaCpeBean> listDetallada) {
		this.listDetallada = listDetallada;
	}

	public List<CargaVentaCabCpeBean> getListAgrupada() {
		return listAgrupada;
	}

	public void setListAgrupada(List<CargaVentaCabCpeBean> listAgrupada) {
		this.listAgrupada = listAgrupada;
	}
	
	public int getNroRegistrosDetallado() {
		return nroRegistrosDetallado;
	}

	public void setNroRegistrosDetallado(int nroRegistrosDetallado) {
		this.nroRegistrosDetallado = nroRegistrosDetallado;
	}

	public int getNroRegistrosAgrupado() {
		return nroRegistrosAgrupado;
	}

	public void setNroRegistrosAgrupado(int nroRegistrosAgrupado) {
		this.nroRegistrosAgrupado = nroRegistrosAgrupado;
	}
	
	public boolean isAllSelectedDet() {
		return allSelectedDet;
	}

	public void setAllSelectedDet(boolean allSelectedDet) {
		this.allSelectedDet = allSelectedDet;
	}
	
	public List<VentaCpeBean> getListRegProcesar() {
		return listRegProcesar;
	}

	public void setListRegProcesar(List<VentaCpeBean> listRegProcesar) {
		this.listRegProcesar = listRegProcesar;
	}
	
	public int getNroRegistrosBusVenProcesar() {
		return nroRegistrosBusVenProcesar;
	}

	public void setNroRegistrosBusVenProcesar(int nroRegistrosBusVenProcesar) {
		this.nroRegistrosBusVenProcesar = nroRegistrosBusVenProcesar;
	}
	
	public boolean isAllSelectedAgrup() {
		return allSelectedAgrup;
	}

	public void setAllSelectedAgrup(boolean allSelectedAgrup) {
		this.allSelectedAgrup = allSelectedAgrup;
	}
	
	public boolean isAllSelectedRegProc() {
		return allSelectedRegProc;
	}

	public void setAllSelectedRegProc(boolean allSelectedRegProc) {
		this.allSelectedRegProc = allSelectedRegProc;
	}
	
	public String getTipoProcesoCe() {
		return tipoProcesoCe;
	}

	public void setTipoProcesoCe(String tipoProcesoCe) {
		this.tipoProcesoCe = tipoProcesoCe;
	}

	public UsuarioService getUsuarioService() {
		return usuarioService;
	}

	public void setUsuarioService(UsuarioService usuarioService) {
		this.usuarioService = usuarioService;
	}

	public ParametroCpeService getParametroCpeService() {
		return parametroCpeService;
	}

	public void setParametroCpeService(ParametroCpeService parametroCpeService) {
		this.parametroCpeService = parametroCpeService;
	}

	public ProcesoCpeService getProcesoCpeService() {
		return procesoCpeService;
	}

	public void setProcesoCpeService(ProcesoCpeService procesoCpeService) {
		this.procesoCpeService = procesoCpeService;
	}

	public SocioCpeService getSocioCpeService() {
		return socioCpeService;
	}

	public void setSocioCpeService(SocioCpeService socioCpeService) {
		this.socioCpeService = socioCpeService;
	}

	public ProductoCpeService getProductoCpeService() {
		return productoCpeService;
	}

	public void setProductoCpeService(ProductoCpeService productoCpeService) {
		this.productoCpeService = productoCpeService;
	}

	public UbigeoCpeService getUbigeoCpeService() {
		return ubigeoCpeService;
	}

	public void setUbigeoCpeService(UbigeoCpeService ubigeoCpeService) {
		this.ubigeoCpeService = ubigeoCpeService;
	}

	public ConfiguracionCpeService getConfiguracionCpeService() {
		return configuracionCpeService;
	}

	public void setConfiguracionCpeService(
			ConfiguracionCpeService configuracionCpeService) {
		this.configuracionCpeService = configuracionCpeService;
	}

	public ComprobanteCpeService getComprobanteCpeService() {
		return comprobanteCpeService;
	}

	public void setComprobanteCpeService(ComprobanteCpeService comprobanteCpeService) {
		this.comprobanteCpeService = comprobanteCpeService;
	}

	public SsisService getSsisService() {
		return ssisService;
	}

	public void setSsisService(SsisService ssisService) {
		this.ssisService = ssisService;
	}

	public VentaUploadCpeService getVentaUploadCpeService() {
		return ventaUploadCpeService;
	}

	public void setVentaUploadCpeService(VentaUploadCpeService ventaUploadCpeService) {
		this.ventaUploadCpeService = ventaUploadCpeService;
	}

	public VentaPimsCpeService getVentaPimsCpeService() {
		return ventaPimsCpeService;
	}

	public void setVentaPimsCpeService(VentaPimsCpeService ventaPimsCpeService) {
		this.ventaPimsCpeService = ventaPimsCpeService;
	}

	public RegistroVentasSuscripcionService getRegistroVentasSuscripcionService() {
		return registroVentasSuscripcionService;
	}

	public void setRegistroVentasSuscripcionService(
			RegistroVentasSuscripcionService registroVentasSuscripcionService) {
		this.registroVentasSuscripcionService = registroVentasSuscripcionService;
	}

	public CampoLayoutCpeService getCampoLayoutCpeService() {
		return campoLayoutCpeService;
	}

	public void setCampoLayoutCpeService(CampoLayoutCpeService campoLayoutCpeService) {
		this.campoLayoutCpeService = campoLayoutCpeService;
	}

	public List<VentaCpeBean> getListVentaCpe() {
		return listVentaCpe;
	}

	public void setListVentaCpe(List<VentaCpeBean> listVentaCpe) {
		this.listVentaCpe = listVentaCpe;
	}

	public String getMensajeValidacionArchivo() {
		return mensajeValidacionArchivo;
	}

	public void setMensajeValidacionArchivo(String mensajeValidacionArchivo) {
		this.mensajeValidacionArchivo = mensajeValidacionArchivo;
	}

	public String getNomArchivo() {
		return nomArchivo;
	}

	public void setNomArchivo(String nomArchivo) {
		this.nomArchivo = nomArchivo;
	}

	/*
	 * TODO BSC 12/09/2019 No se usa
	public File getArchivo() {
		return archivo;
	}

	public void setArchivo(File archivo) {
		this.archivo = archivo;
	}
	 */

	public boolean isDisabledCargar() {
		return disabledCargar;
	}

	public void setDisabledCargar(boolean disabledCargar) {
		this.disabledCargar = disabledCargar;
	}

	public String getIdFileUploadComponent() {
		return idFileUploadComponent;
	}

	public void setIdFileUploadComponent(String idFileUploadComponent) {
		this.idFileUploadComponent = idFileUploadComponent;
	}

	public boolean isMostrarImportarDatos() {
		return mostrarImportarDatos;
	}

	public void setMostrarImportarDatos(boolean mostrarImportarDatos) {
		this.mostrarImportarDatos = mostrarImportarDatos;
	}

	public Boolean getSeleccionarTodosError() {
		return seleccionarTodosError;
	}

	public void setSeleccionarTodosError(Boolean seleccionarTodosError) {
		this.seleccionarTodosError = seleccionarTodosError;
	}

	public Boolean getSeleccionarTodosProcesar() {
		return seleccionarTodosProcesar;
	}

	public void setSeleccionarTodosProcesar(Boolean seleccionarTodosProcesar) {
		this.seleccionarTodosProcesar = seleccionarTodosProcesar;
	}

	public List<SelectItem> getSocioProcesoMasivoItems() {
		return socioProcesoMasivoItems;
	}

	public void setSocioProcesoMasivoItems(List<SelectItem> socioProcesoMasivoItems) {
		this.socioProcesoMasivoItems = socioProcesoMasivoItems;
	}

	public List<SelectItem> getProductoProcesoMasivoItems() {
		return productoProcesoMasivoItems;
	}

	public void setProductoProcesoMasivoItems(
			List<SelectItem> productoProcesoMasivoItems) {
		this.productoProcesoMasivoItems = productoProcesoMasivoItems;
	}

	public List<SelectItem> getTipCompProcesoMasivoItems() {
		return tipCompProcesoMasivoItems;
	}

	public void setTipCompProcesoMasivoItems(
			List<SelectItem> tipCompProcesoMasivoItems) {
		this.tipCompProcesoMasivoItems = tipCompProcesoMasivoItems;
	}

	public List<SelectItem> getTipDocProcesoMasivoItems() {
		return tipDocProcesoMasivoItems;
	}

	public void setTipDocProcesoMasivoItems(
			List<SelectItem> tipDocProcesoMasivoItems) {
		this.tipDocProcesoMasivoItems = tipDocProcesoMasivoItems;
	}

	public List<SelectItem> getMonedaProcesoMasivoItems() {
		return monedaProcesoMasivoItems;
	}

	public void setMonedaProcesoMasivoItems(
			List<SelectItem> monedaProcesoMasivoItems) {
		this.monedaProcesoMasivoItems = monedaProcesoMasivoItems;
	}

	public String getSocioProcesoMasivoSelected() {
		return socioProcesoMasivoSelected;
	}

	public void setSocioProcesoMasivoSelected(String socioProcesoMasivoSelected) {
		this.socioProcesoMasivoSelected = socioProcesoMasivoSelected;
	}

	public String getProductoProcesoMasivoSelected() {
		return productoProcesoMasivoSelected;
	}

	public void setProductoProcesoMasivoSelected(
			String productoProcesoMasivoSelected) {
		this.productoProcesoMasivoSelected = productoProcesoMasivoSelected;
	}

	public String getTipCompProcesoMasivoSelected() {
		return tipCompProcesoMasivoSelected;
	}

	public void setTipCompProcesoMasivoSelected(String tipCompProcesoMasivoSelected) {
		this.tipCompProcesoMasivoSelected = tipCompProcesoMasivoSelected;
	}

	public String getTipDocProcesoMasivoSelected() {
		return tipDocProcesoMasivoSelected;
	}

	public void setTipDocProcesoMasivoSelected(String tipDocProcesoMasivoSelected) {
		this.tipDocProcesoMasivoSelected = tipDocProcesoMasivoSelected;
	}

	public String getMonedaProcesoMasivoSelected() {
		return monedaProcesoMasivoSelected;
	}

	public void setMonedaProcesoMasivoSelected(String monedaProcesoMasivoSelected) {
		this.monedaProcesoMasivoSelected = monedaProcesoMasivoSelected;
	}

	public String getConceptoProcesoMasivo() {
		return conceptoProcesoMasivo;
	}

	public void setConceptoProcesoMasivo(String conceptoProcesoMasivo) {
		this.conceptoProcesoMasivo = conceptoProcesoMasivo;
	}

	public String getClienteProcesoMasivo() {
		return clienteProcesoMasivo;
	}

	public void setClienteProcesoMasivo(String clienteProcesoMasivo) {
		this.clienteProcesoMasivo = clienteProcesoMasivo;
	}

	public String getNumCompProcesoMasivo() {
		return numCompProcesoMasivo;
	}

	public void setNumCompProcesoMasivo(String numCompProcesoMasivo) {
		this.numCompProcesoMasivo = numCompProcesoMasivo;
	}

	public Date getFecEmisionProcesoMasivo() {
		return fecEmisionProcesoMasivo;
	}

	public void setFecEmisionProcesoMasivo(Date fecEmisionProcesoMasivo) {
		this.fecEmisionProcesoMasivo = fecEmisionProcesoMasivo;
	}

	public String getMontoProcesoMasivo() {
		return montoProcesoMasivo;
	}

	public void setMontoProcesoMasivo(String montoProcesoMasivo) {
		this.montoProcesoMasivo = montoProcesoMasivo;
	}

	public String getCertificadoProcesoMasivo() {
		return certificadoProcesoMasivo;
	}

	public void setCertificadoProcesoMasivo(String certificadoProcesoMasivo) {
		this.certificadoProcesoMasivo = certificadoProcesoMasivo;
	}

	public String getNumDocProcesoMasivo() {
		return numDocProcesoMasivo;
	}

	public void setNumDocProcesoMasivo(String numDocProcesoMasivo) {
		this.numDocProcesoMasivo = numDocProcesoMasivo;
	}

	public List<ProcesoMasivoCpeBean> getListaProcesoMasivo() {
		return listaProcesoMasivo;
	}

	public void setListaProcesoMasivo(List<ProcesoMasivoCpeBean> listaProcesoMasivo) {
		this.listaProcesoMasivo = listaProcesoMasivo;
	}

	public Integer getRegSeleccionados() {
		return regSeleccionados;
	}

	public void setRegSeleccionados(Integer regSeleccionados) {
		this.regSeleccionados = regSeleccionados;
	}

	public BigDecimal getMontoSeleccionados() {
		return montoSeleccionados;
	}

	public void setMontoSeleccionados(BigDecimal montoSeleccionados) {
		this.montoSeleccionados = montoSeleccionados;
	}

	public String getFechaProcesoMasivo() {
		return fechaProcesoMasivo;
	}

	public void setFechaProcesoMasivo(String fechaProcesoMasivo) {
		this.fechaProcesoMasivo = fechaProcesoMasivo;
	}
	
	public List<SelectItem> getSocioProcesadosErrorOnlineItems() {
		return socioProcesadosErrorOnlineItems;
	}

	public void setSocioProcesadosErrorOnlineItems(
			List<SelectItem> socioProcesadosErrorOnlineItems) {
		this.socioProcesadosErrorOnlineItems = socioProcesadosErrorOnlineItems;
	}

	public List<SelectItem> getProductoProcesadosErrorOnlineItems() {
		return productoProcesadosErrorOnlineItems;
	}

	public void setProductoProcesadosErrorOnlineItems(
			List<SelectItem> productoProcesadosErrorOnlineItems) {
		this.productoProcesadosErrorOnlineItems = productoProcesadosErrorOnlineItems;
	}

	public List<SelectItem> getTipComprobanteProcesadosErrorOnlineItems() {
		return tipComprobanteProcesadosErrorOnlineItems;
	}

	public void setTipComprobanteProcesadosErrorOnlineItems(
			List<SelectItem> tipComprobanteProcesadosErrorOnlineItems) {
		this.tipComprobanteProcesadosErrorOnlineItems = tipComprobanteProcesadosErrorOnlineItems;
	}

	public List<SelectItem> getTipDocProcesadosErrorOnlineItems() {
		return tipDocProcesadosErrorOnlineItems;
	}

	public void setTipDocProcesadosErrorOnlineItems(
			List<SelectItem> tipDocProcesadosErrorOnlineItems) {
		this.tipDocProcesadosErrorOnlineItems = tipDocProcesadosErrorOnlineItems;
	}

	public List<SelectItem> getMonedaProcesadosErrorOnlineItems() {
		return monedaProcesadosErrorOnlineItems;
	}

	public void setMonedaProcesadosErrorOnlineItems(
			List<SelectItem> monedaProcesadosErrorOnlineItems) {
		this.monedaProcesadosErrorOnlineItems = monedaProcesadosErrorOnlineItems;
	}

	public String getSocioProcesadosErrorOnlineSelected() {
		return socioProcesadosErrorOnlineSelected;
	}

	public void setSocioProcesadosErrorOnlineSelected(
			String socioProcesadosErrorOnlineSelected) {
		this.socioProcesadosErrorOnlineSelected = socioProcesadosErrorOnlineSelected;
	}

	public String getProductoProcesadosErrorOnlineSelected() {
		return productoProcesadosErrorOnlineSelected;
	}

	public void setProductoProcesadosErrorOnlineSelected(
			String productoProcesadosErrorOnlineSelected) {
		this.productoProcesadosErrorOnlineSelected = productoProcesadosErrorOnlineSelected;
	}

	public String getConceptoProcesadosErrorOnline() {
		return conceptoProcesadosErrorOnline;
	}

	public void setConceptoProcesadosErrorOnline(
			String conceptoProcesadosErrorOnline) {
		this.conceptoProcesadosErrorOnline = conceptoProcesadosErrorOnline;
	}

	public String getClienteProcesadosErrorOnline() {
		return clienteProcesadosErrorOnline;
	}

	public void setClienteProcesadosErrorOnline(String clienteProcesadosErrorOnline) {
		this.clienteProcesadosErrorOnline = clienteProcesadosErrorOnline;
	}

	public String getTipComprobanteProcesadosErrorOnlineSelected() {
		return tipComprobanteProcesadosErrorOnlineSelected;
	}

	public void setTipComprobanteProcesadosErrorOnlineSelected(
			String tipComprobanteProcesadosErrorOnlineSelected) {
		this.tipComprobanteProcesadosErrorOnlineSelected = tipComprobanteProcesadosErrorOnlineSelected;
	}

	public String getNumCompProcesadosErrorOnline() {
		return numCompProcesadosErrorOnline;
	}

	public void setNumCompProcesadosErrorOnline(String numCompProcesadosErrorOnline) {
		this.numCompProcesadosErrorOnline = numCompProcesadosErrorOnline;
	}

	public Date getFechaEmisionProcesadosErrorOnline() {
		return fechaEmisionProcesadosErrorOnline;
	}

	public void setFechaEmisionProcesadosErrorOnline(
			Date fechaEmisionProcesadosErrorOnline) {
		this.fechaEmisionProcesadosErrorOnline = fechaEmisionProcesadosErrorOnline;
	}

	public String getTipDocProcesadosOnlineErrorSelected() {
		return tipDocProcesadosOnlineErrorSelected;
	}

	public void setTipDocProcesadosOnlineErrorSelected(
			String tipDocProcesadosOnlineErrorSelected) {
		this.tipDocProcesadosOnlineErrorSelected = tipDocProcesadosOnlineErrorSelected;
	}

	public String getMonedaProcesadosErrorOnlineSelected() {
		return monedaProcesadosErrorOnlineSelected;
	}

	public void setMonedaProcesadosErrorOnlineSelected(
			String monedaProcesadosErrorOnlineSelected) {
		this.monedaProcesadosErrorOnlineSelected = monedaProcesadosErrorOnlineSelected;
	}

	public String getMontoProcesadosErrorOnline() {
		return montoProcesadosErrorOnline;
	}

	public void setMontoProcesadosErrorOnline(String montoProcesadosErrorOnline) {
		this.montoProcesadosErrorOnline = montoProcesadosErrorOnline;
	}

	public String getCertificadoProcesadosErrorOnline() {
		return certificadoProcesadosErrorOnline;
	}

	public void setCertificadoProcesadosErrorOnline(
			String certificadoProcesadosErrorOnline) {
		this.certificadoProcesadosErrorOnline = certificadoProcesadosErrorOnline;
	}

	public String getNumDocProcesadosErrorOnline() {
		return numDocProcesadosErrorOnline;
	}

	public void setNumDocProcesadosErrorOnline(String numDocProcesadosErrorOnline) {
		this.numDocProcesadosErrorOnline = numDocProcesadosErrorOnline;
	}
	
	public List<ProcesoMasivoCpeBean> getListProcesadosErrorOnline() {
		return listProcesadosErrorOnline;
	}

	public void setListProcesadosErrorOnline(
			List<ProcesoMasivoCpeBean> listProcesadosErrorOnline) {
		this.listProcesadosErrorOnline = listProcesadosErrorOnline;
	}

	public int getNroRegistrosProcesadosErrorOnline() {
		return nroRegistrosProcesadosErrorOnline;
	}

	public void setNroRegistrosProcesadosErrorOnline(
			int nroRegistrosProcesadosErrorOnline) {
		this.nroRegistrosProcesadosErrorOnline = nroRegistrosProcesadosErrorOnline;
	}

	public BigDecimal getMontoTotalProcesadosErrorOnline() {
		return montoTotalProcesadosErrorOnline;
	}

	public void setMontoTotalProcesadosErrorOnline(
			BigDecimal montoTotalProcesadosErrorOnline) {
		this.montoTotalProcesadosErrorOnline = montoTotalProcesadosErrorOnline;
	}
	
	public List<SelectItem> getSocioProcesadosCorrectosOnlineItems() {
		return socioProcesadosCorrectosOnlineItems;
	}

	public void setSocioProcesadosCorrectosOnlineItems(
			List<SelectItem> socioProcesadosCorrectosOnlineItems) {
		this.socioProcesadosCorrectosOnlineItems = socioProcesadosCorrectosOnlineItems;
	}

	public List<SelectItem> getProductoProcesadosCorrectosOnlineItems() {
		return productoProcesadosCorrectosOnlineItems;
	}

	public void setProductoProcesadosCorrectosOnlineItems(
			List<SelectItem> productoProcesadosCorrectosOnlineItems) {
		this.productoProcesadosCorrectosOnlineItems = productoProcesadosCorrectosOnlineItems;
	}

	public List<SelectItem> getTipComprobanteProcesadosCorrectosOnlineItems() {
		return tipComprobanteProcesadosCorrectosOnlineItems;
	}

	public void setTipComprobanteProcesadosCorrectosOnlineItems(
			List<SelectItem> tipComprobanteProcesadosCorrectosOnlineItems) {
		this.tipComprobanteProcesadosCorrectosOnlineItems = tipComprobanteProcesadosCorrectosOnlineItems;
	}

	public List<SelectItem> getTipDocProcesadosCorrectosOnlineItems() {
		return tipDocProcesadosCorrectosOnlineItems;
	}

	public void setTipDocProcesadosCorrectosOnlineItems(
			List<SelectItem> tipDocProcesadosCorrectosOnlineItems) {
		this.tipDocProcesadosCorrectosOnlineItems = tipDocProcesadosCorrectosOnlineItems;
	}

	public List<SelectItem> getMonedaProcesadosCorrectosOnlineItems() {
		return monedaProcesadosCorrectosOnlineItems;
	}

	public void setMonedaProcesadosCorrectosOnlineItems(
			List<SelectItem> monedaProcesadosCorrectosOnlineItems) {
		this.monedaProcesadosCorrectosOnlineItems = monedaProcesadosCorrectosOnlineItems;
	}

	public String getSocioProcesadosCorrectosOnlineSelected() {
		return socioProcesadosCorrectosOnlineSelected;
	}

	public void setSocioProcesadosCorrectosOnlineSelected(
			String socioProcesadosCorrectosOnlineSelected) {
		this.socioProcesadosCorrectosOnlineSelected = socioProcesadosCorrectosOnlineSelected;
	}

	public String getProductoProcesadosCorrectosOnlineSelected() {
		return productoProcesadosCorrectosOnlineSelected;
	}

	public void setProductoProcesadosCorrectosOnlineSelected(
			String productoProcesadosCorrectosOnlineSelected) {
		this.productoProcesadosCorrectosOnlineSelected = productoProcesadosCorrectosOnlineSelected;
	}

	public String getConceptoProcesadosCorrectosOnline() {
		return conceptoProcesadosCorrectosOnline;
	}

	public void setConceptoProcesadosCorrectosOnline(
			String conceptoProcesadosCorrectosOnline) {
		this.conceptoProcesadosCorrectosOnline = conceptoProcesadosCorrectosOnline;
	}

	public String getClienteProcesadosCorrectosOnline() {
		return clienteProcesadosCorrectosOnline;
	}

	public void setClienteProcesadosCorrectosOnline(
			String clienteProcesadosCorrectosOnline) {
		this.clienteProcesadosCorrectosOnline = clienteProcesadosCorrectosOnline;
	}

	public String getTipComprobanteProcesadosCorrectosOnlineSelected() {
		return tipComprobanteProcesadosCorrectosOnlineSelected;
	}

	public void setTipComprobanteProcesadosCorrectosOnlineSelected(
			String tipComprobanteProcesadosCorrectosOnlineSelected) {
		this.tipComprobanteProcesadosCorrectosOnlineSelected = tipComprobanteProcesadosCorrectosOnlineSelected;
	}

	public String getNumCompProcesadosCorrectosOnline() {
		return numCompProcesadosCorrectosOnline;
	}

	public void setNumCompProcesadosCorrectosOnline(
			String numCompProcesadosCorrectosOnline) {
		this.numCompProcesadosCorrectosOnline = numCompProcesadosCorrectosOnline;
	}

	public Date getFechaEmisionProcesadosCorrectosOnline() {
		return fechaEmisionProcesadosCorrectosOnline;
	}

	public void setFechaEmisionProcesadosCorrectosOnline(
			Date fechaEmisionProcesadosCorrectosOnline) {
		this.fechaEmisionProcesadosCorrectosOnline = fechaEmisionProcesadosCorrectosOnline;
	}

	public String getTipDocProcesadosOnlineCorrectosSelected() {
		return tipDocProcesadosOnlineCorrectosSelected;
	}

	public void setTipDocProcesadosOnlineCorrectosSelected(
			String tipDocProcesadosOnlineCorrectosSelected) {
		this.tipDocProcesadosOnlineCorrectosSelected = tipDocProcesadosOnlineCorrectosSelected;
	}

	public String getMonedaProcesadosCorrectosOnlineSelected() {
		return monedaProcesadosCorrectosOnlineSelected;
	}

	public void setMonedaProcesadosCorrectosOnlineSelected(
			String monedaProcesadosCorrectosOnlineSelected) {
		this.monedaProcesadosCorrectosOnlineSelected = monedaProcesadosCorrectosOnlineSelected;
	}

	public String getMontoProcesadosCorrectosOnline() {
		return montoProcesadosCorrectosOnline;
	}

	public void setMontoProcesadosCorrectosOnline(
			String montoProcesadosCorrectosOnline) {
		this.montoProcesadosCorrectosOnline = montoProcesadosCorrectosOnline;
	}

	public String getCertificadoProcesadosCorrectosOnline() {
		return certificadoProcesadosCorrectosOnline;
	}

	public void setCertificadoProcesadosCorrectosOnline(
			String certificadoProcesadosCorrectosOnline) {
		this.certificadoProcesadosCorrectosOnline = certificadoProcesadosCorrectosOnline;
	}

	public String getNumDocProcesadosCorrectosOnline() {
		return numDocProcesadosCorrectosOnline;
	}

	public void setNumDocProcesadosCorrectosOnline(
			String numDocProcesadosCorrectosOnline) {
		this.numDocProcesadosCorrectosOnline = numDocProcesadosCorrectosOnline;
	}

	public List<ProcesoMasivoCpeBean> getListProcesadosCorrectosOnline() {
		return listProcesadosCorrectosOnline;
	}

	public void setListProcesadosCorrectosOnline(
			List<ProcesoMasivoCpeBean> listProcesadosCorrectosOnline) {
		this.listProcesadosCorrectosOnline = listProcesadosCorrectosOnline;
	}

	public int getNroRegistrosProcesadosCorrectosOnline() {
		return nroRegistrosProcesadosCorrectosOnline;
	}

	public void setNroRegistrosProcesadosCorrectosOnline(
			int nroRegistrosProcesadosCorrectosOnline) {
		this.nroRegistrosProcesadosCorrectosOnline = nroRegistrosProcesadosCorrectosOnline;
	}

	public BigDecimal getMontoTotalProcesadosCorrectosOnline() {
		return montoTotalProcesadosCorrectosOnline;
	}

	public void setMontoTotalProcesadosCorrectosOnline(
			BigDecimal montoTotalProcesadosCorrectosOnline) {
		this.montoTotalProcesadosCorrectosOnline = montoTotalProcesadosCorrectosOnline;
	}
	
	public String getFechaProcesoOnline() {
		return fechaProcesoOnline;
	}

	public void setFechaProcesoOnline(String fechaProcesoOnline) {
		this.fechaProcesoOnline = fechaProcesoOnline;
	}
	
	public ProcesoMasivoCpeBean getVentaSeleccionada() {
		return ventaSeleccionada;
	}

	public void setVentaSeleccionada(ProcesoMasivoCpeBean ventaSeleccionada) {
		this.ventaSeleccionada = ventaSeleccionada;
	}
	
	
	public List<SelectItem> getSocioRefItems() {
		return socioRefItems;
	}

	public void setSocioRefItems(List<SelectItem> socioRefItems) {
		this.socioRefItems = socioRefItems;
	}

	public List<SelectItem> getProductoRefItems() {
		return productoRefItems;
	}

	public void setProductoRefItems(List<SelectItem> productoRefItems) {
		this.productoRefItems = productoRefItems;
	}

	public List<SelectItem> getTipComprobanteRefItems() {
		return tipComprobanteRefItems;
	}

	public void setTipComprobanteRefItems(List<SelectItem> tipComprobanteRefItems) {
		this.tipComprobanteRefItems = tipComprobanteRefItems;
	}

	public List<SelectItem> getTipDocRefItems() {
		return tipDocRefItems;
	}

	public void setTipDocRefItems(List<SelectItem> tipDocRefItems) {
		this.tipDocRefItems = tipDocRefItems;
	}

	public List<SelectItem> getMonedaRefItems() {
		return monedaRefItems;
	}

	public void setMonedaRefItems(List<SelectItem> monedaRefItems) {
		this.monedaRefItems = monedaRefItems;
	}

	public String getSocioRefSelected() {
		return socioRefSelected;
	}

	public void setSocioRefSelected(String socioRefSelected) {
		this.socioRefSelected = socioRefSelected;
	}

	public String getProductoRefSelected() {
		return productoRefSelected;
	}

	public void setProductoRefSelected(String productoRefSelected) {
		this.productoRefSelected = productoRefSelected;
	}

	public String getClienteRef() {
		return clienteRef;
	}

	public void setClienteRef(String clienteRef) {
		this.clienteRef = clienteRef;
	}

	public String getTipComprobanteRefSelected() {
		return tipComprobanteRefSelected;
	}

	public void setTipComprobanteRefSelected(String tipComprobanteRefSelected) {
		this.tipComprobanteRefSelected = tipComprobanteRefSelected;
	}

	public String getNumCompRef() {
		return numCompRef;
	}

	public void setNumCompRef(String numCompRef) {
		this.numCompRef = numCompRef;
	}

	public Date getFechaEmisionRef() {
		return fechaEmisionRef;
	}

	public void setFechaEmisionRef(Date fechaEmisionRef) {
		this.fechaEmisionRef = fechaEmisionRef;
	}

	public String getTipDocRefSelected() {
		return tipDocRefSelected;
	}

	public void setTipDocRefSelected(String tipDocRefSelected) {
		this.tipDocRefSelected = tipDocRefSelected;
	}

	public String getMonedaRefSelected() {
		return monedaRefSelected;
	}

	public void setMonedaRefSelected(String monedaRefSelected) {
		this.monedaRefSelected = monedaRefSelected;
	}

	public String getMontoRef() {
		return montoRef;
	}

	public void setMontoRef(String montoRef) {
		this.montoRef = montoRef;
	}

	public String getCertificadoRef() {
		return certificadoRef;
	}

	public void setCertificadoRef(String certificadoRef) {
		this.certificadoRef = certificadoRef;
	}

	public String getNumDocRef() {
		return numDocRef;
	}

	public void setNumDocRef(String numDocRef) {
		this.numDocRef = numDocRef;
	}

	public int getRegSeleccionadosRef() {
		return regSeleccionadosRef;
	}

	public void setRegSeleccionadosRef(int regSeleccionadosRef) {
		this.regSeleccionadosRef = regSeleccionadosRef;
	}

	public BigDecimal getMontoTotalSeleccionadosRef() {
		return montoTotalSeleccionadosRef;
	}

	public void setMontoTotalSeleccionadosRef(BigDecimal montoTotalSeleccionadosRef) {
		this.montoTotalSeleccionadosRef = montoTotalSeleccionadosRef;
	}
	
	public List<ComprobanteCpeBean> getListRef() {
		return listRef;
	}

	public void setListRef(List<ComprobanteCpeBean> listRef) {
		this.listRef = listRef;
	}
	
	public CargaVentaCabCpeBean getCabBusquedaAgrupDet() {
		return cabBusquedaAgrupDet;
	}

	public void setCabBusquedaAgrupDet(CargaVentaCabCpeBean cabBusquedaAgrupDet) {
		this.cabBusquedaAgrupDet = cabBusquedaAgrupDet;
	}
	
	public VentaCpeBean getDetBusquedaDetallado() {
		return detBusquedaDetallado;
	}

	public void setDetBusquedaDetallado(VentaCpeBean detBusquedaDetallado) {
		this.detBusquedaDetallado = detBusquedaDetallado;
	}
	
	public VentaCpeBean getDetBusquedaDetalladoProc() {
		return detBusquedaDetalladoProc;
	}

	public void setDetBusquedaDetalladoProc(VentaCpeBean detBusquedaDetalladoProc) {
		this.detBusquedaDetalladoProc = detBusquedaDetalladoProc;
	}
	
	public VentaCpeBean getDetPreProcError() {
		return detPreProcError;
	}

	public void setDetPreProcError(VentaCpeBean detPreProcError) {
		this.detPreProcError = detPreProcError;
	}
	
	public VentaCpeBean getDetPreProcOk() {
		return detPreProcOk;
	}

	public void setDetPreProcOk(VentaCpeBean detPreProcOk) {
		this.detPreProcOk = detPreProcOk;
	}
	
	public String getMsjProcesoEliminar() {
		return msjProcesoEliminar;
	}

	public void setMsjProcesoEliminar(String msjProcesoEliminar) {
		this.msjProcesoEliminar = msjProcesoEliminar;
	}
	
	public int getNumMaximoOnline() {
		return numMaximoOnline;
	}

	public void setNumMaximoOnline(int numMaximoOnline) {
		this.numMaximoOnline = numMaximoOnline;
	}
	
	public String getLoteProcesoMasivo() {
		return loteProcesoMasivo;
	}

	public void setLoteProcesoMasivo(String loteProcesoMasivo) {
		this.loteProcesoMasivo = loteProcesoMasivo;
	}

	public boolean isFlagComprobanteCorrecto() {
		return flagComprobanteCorrecto;
	}

	public void setFlagComprobanteCorrecto(boolean flagComprobanteCorrecto) {
		this.flagComprobanteCorrecto = flagComprobanteCorrecto;
	}
	
	public boolean isBloqAgrup() {
		return bloqAgrup;
	}

	public void setBloqAgrup(boolean bloqAgrup) {
		this.bloqAgrup = bloqAgrup;
	}
	
	public String getNumPolizaComprobante() {
		return numPolizaComprobante;
	}

	public void setNumPolizaComprobante(String numPolizaComprobante) {
		this.numPolizaComprobante = numPolizaComprobante;
	}
	
	public boolean isDisabledPoliza() {
		return disabledPoliza;
	}

	public void setDisabledPoliza(boolean disabledPoliza) {
		this.disabledPoliza = disabledPoliza;
	}
	
	public String getRepoSelected() {
		return repoSelected;
	}

	public void setRepoSelected(String repoSelected) {
		this.repoSelected = repoSelected;
	}
	
	public String getLoteOnline() {
		return loteOnline;
	}

	public void setLoteOnline(String loteOnline) {
		this.loteOnline = loteOnline;
	}
	
	public boolean isDisabledUploadSelected() {
		return disabledUploadSelected;
	}

	public void setDisabledUploadSelected(boolean disabledUploadSelected) {
		this.disabledUploadSelected = disabledUploadSelected;
	}

	public boolean isFlg_valida() {
		return flg_valida;
	}

	public void setFlg_valida(boolean flg_valida) {
		this.flg_valida = flg_valida;
	}

	public boolean isDisabledOnline() {
		return disabledOnline;
	}

	public void setDisabledOnline(boolean disabledOnline) {
		this.disabledOnline = disabledOnline;
	}

	public boolean isDisabledMasivo() {
		return disabledMasivo;
	}

	public void setDisabledMasivo(boolean disabledMasivo) {
		this.disabledMasivo = disabledMasivo;
	}

	/**TIP_PER0100_CC14 INICIO 2019/06/17 - 09:20 - Se agrega atributos para edición de detalle de item de comprobante*/

	/**
	 * Método que permite obtener la lista de detalle item perteneciente a un comprobante.
	 * @return listDetalleItemComprobante Lista de detalle item perteneciente a un comprobante, tipo List<CargaVentaItemCpeBean>.
	 */
	public List<CargaVentaItemCpeBean> getListDetalleItemComprobante() {
		return listDetalleItemComprobante;
	}

	/**
	 * Método que permite actualizar la lista de detalle item perteneciente a un comprobante. 
	 * @param listDetalleItemComprobante Lista de detalle item perteneciente a un comprobante, tipo List<CargaVentaItemCpeBean>.
	 */
	public void setListDetalleItemComprobante(List<CargaVentaItemCpeBean> listDetalleItemComprobante) {
		this.listDetalleItemComprobante = listDetalleItemComprobante;
	}
	
	/**
	 * Método que permite obtener el concepto del detalle item perteneciente a un comprobante.
	 * @return conceptoItem Concepto del detalle item perteneciente a un comprobante, tipo String.
	 */
	public String getConceptoItem() {
		return conceptoItem;
	}


	/**
	 * Método que permite actualizar el concepto del detalle item perteneciente a un comprobante. 
	 * @param conceptoItem Concepto del detalle item perteneciente a un comprobante, tipo String.
	 */
	public void setConceptoItem(String conceptoItem) {
		this.conceptoItem = conceptoItem;
	}

	/**
	 * Método que permite obtener la cantidad de item.
	 * @return cantidadItem Cantidad de item, tipo int.
	 */
	public int getCantidadItem() {
		return cantidadItem;
	}

	/**
	 * Método que permite actualizar la cantidad de item. 
	 * @param cantidadItem Cantidad de item, tipo int.
	 */
	public void setCantidadItem(int cantidadItem) {
		this.cantidadItem = cantidadItem;
	}

	/**
	 * Método que permite obtener el precio de venta de detalle de Item de un comprobante.
	 * @return precioVentaItem Precio de venta de detalle de Item de un comprobante, tipo BigDecimal.
	 */
	public BigDecimal getPrecioVentaItem() {
		return precioVentaItem;
	}

	/**
	 * Método que permite actualizar el precio de venta de detalle de Item de un comprobante.
	 * @param precioVentaItem Precio de venta de detalle de Item de un comprobante, tipo BigDecimal.
	 */
	public void setPrecioVentaItem(BigDecimal precioVentaItem) {
		this.precioVentaItem = precioVentaItem;
	}
	
	/**Atributo que almacena el valor de la venta total, monto que no considera el IGV*/

	/**
	 * Método que permite obtener el valor de la venta total, monto que no considera el IGV.
	 * @return valorVentaTotal Valor de la venta total, monto que no considera el IGV, tipo BigDecimal.
	 */
	public BigDecimal getValorVentaTotal() {
		return valorVentaTotal;
	}

	/**
	 * Método que permite actualizar el valor de la venta total, monto que no considera el IGV.
	 * @param valorVentaTotal Valor de la venta total, monto que no considera el IGV, tipo BigDecimal.
	 */
	public void setValorVentaTotal(BigDecimal valorVentaTotal) {
		this.valorVentaTotal = valorVentaTotal;
	}

	/**
	 * Método que permite obtener el valor de operaciones gratuitas.
	 * @return impValOpGratuitas Valor de operaciones gratuitas, tipo BigDecimal.
	 */
	public BigDecimal getImpValOpGratuitas() {
		return impValOpGratuitas;
	}

	/**
	 * Método que permite actualizar el valor de operaciones gratuitas. 
	 * @param impValOpGratuitas Valor de operaciones gratuitas, tipo BigDecimal.
	 */
	public void setImpValOpGratuitas(BigDecimal impValOpGratuitas) {
		this.impValOpGratuitas = impValOpGratuitas;
	}

	/**
	 * Método que permite obtener la referencia  la interfaz de servicios de DataMart.
	 * @return ventaDataMartCpeService Referencia  la interfaz de servicios de DataMart, tipo VentaDataMartCpeService.
	 */
	public VentaDataMartCpeService getVentaDataMartCpeService() {
		return ventaDataMartCpeService;
	}

	/**
	 * Método que permite actualizar la referencia  la interfaz de servicios de DataMart.
	 * @param ventaDataMartCpeService Referencia  la interfaz de servicios de DataMart, tipo VentaDataMartCpeService.
	 */
	public void setVentaDataMartCpeService(VentaDataMartCpeService ventaDataMartCpeService) {
		this.ventaDataMartCpeService = ventaDataMartCpeService;
	}

	/**
	 * Método que permite obtener indicador de aplica IGV sobre un registro de venta seleccionado.
	 * @return ventaAplicaIGV Indicador de aplica IGV sobre un registro de venta seleccionado, tipo boolean.
	 */
	public boolean isVentaAplicaIGV() {
		return ventaAplicaIGV;
	}

	/**
	 * Método que permite obtener indicador de aplica IGV sobre un registro de venta seleccionado.
	 * @param ventaAplicaIGV Indicador de aplica IGV sobre un registro de venta seleccionado, tipo boolean.
	 */
	public void setVentaAplicaIGV(boolean ventaAplicaIGV) {
		this.ventaAplicaIGV = ventaAplicaIGV;
	}

	/**TIP_PER0100_CC14 INICIO*/

	/**TIP_PER0100_FASE02 INICIO 2019/11/22 - 12:44 - Se agrega los métodos get y set del atributo disabledResumen.*/
	
	/**
	 * Método que permite obtener el indicador que habilita la opción de Resumen.
	 * @return disabledResumen Indicador que habilita la opción de Resumen, tipo boolean.
	 */
	public boolean isDisabledResumen() {
		return disabledResumen;
	}

	/**
	 * Método que permite actualizar el indicador que habilita la opción de Resumen. 
	 * @param disabledResumen Indicador que habilita la opción de Resumen, tipo boolean.
	 */
	public void setDisabledResumen(boolean disabledResumen) {
		this.disabledResumen = disabledResumen;
	}
	
	/**TIP_PER0100_FASE02 FIN 2019/11/22 - 12:44 - Se agrega los métodos get y set del atributo disabledResumen. */
	
}
