package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.CampoLayoutCpeBean;
import com.cardif.satelite.cpe.bean.LayoutCabCpeBean;

public interface CampoLayoutCpeMapper {

	public List<CampoLayoutCpeBean> listarLayoutDet(CampoLayoutCpeBean campoLayoutCpeBean);
	
	public List<LayoutCabCpeBean> listarLayoutCab(LayoutCabCpeBean layoutCabCpeBean);
	
}
