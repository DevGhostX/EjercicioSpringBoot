package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.CargaVentaCabCpeBean;

public interface CargaVentaCabCpeMapper {

	public void insertarCargaVentaCab(CargaVentaCabCpeBean cargaVentaCabCpeBean);
	
	public List<CargaVentaCabCpeBean> listarCargaVentaCab(CargaVentaCabCpeBean cargaVentaCabCpeBean);
	
}
