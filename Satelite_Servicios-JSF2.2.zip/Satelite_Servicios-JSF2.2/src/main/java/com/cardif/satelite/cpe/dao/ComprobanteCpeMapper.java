package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.ComprobanteCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoMasivoCpeBean;

public interface ComprobanteCpeMapper {

	public void insertarComprobanteCpe(ComprobanteCpeBean comprobanteCpeBean);
	
	public List<ProcesoMasivoCpeBean> filtrarProcesoMasivoCpe(ProcesoMasivoCpeBean procesoMasivoCpeBean);
	
	public void actualizarEstadoComprobanteCpe(ComprobanteCpeBean comprobanteCpeBean);
	
	public List<ComprobanteCpeBean> obtenerComprobante(ComprobanteCpeBean comprobanteCpeBean);
	
}
