package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.ConfiguracionCpeBean;

public interface ConfiguracionCpeMapper {
	
	public List<ConfiguracionCpeBean> listarConfiguracion(ConfiguracionCpeBean configuracionCpeBean);
	public void insertarConfiguracion(ConfiguracionCpeBean configuracionCpeBean);
	public void actualizarConfiguracion(ConfiguracionCpeBean configuracionCpeBean);
	public void actualizarConfiguracionSerieCorrelativo(ConfiguracionCpeBean configuracionCpeBean);
	public void inactivarConfiguracion(ConfiguracionCpeBean configuracionCpeBean);
	public void eliminarConfiguracion(ConfiguracionCpeBean configuracionCpeBean);
	public List<ConfiguracionCpeBean> listarConfiguracionCpe(ConfiguracionCpeBean configuracionCpeBean);
	public void actualizarCorrelativo(ConfiguracionCpeBean configuracionCpeBean);
}
