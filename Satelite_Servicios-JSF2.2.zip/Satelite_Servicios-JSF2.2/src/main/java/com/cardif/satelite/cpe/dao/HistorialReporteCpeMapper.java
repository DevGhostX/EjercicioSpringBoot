package com.cardif.satelite.cpe.dao;

import com.cardif.satelite.cpe.bean.HistorialReporteCpeBean;

public interface HistorialReporteCpeMapper {

	public HistorialReporteCpeBean obtenerHistorialPorPeriodo(HistorialReporteCpeBean historialReporteCpeBean);
	
	public void insertarHistorialReporte(HistorialReporteCpeBean historialReporteCpeBean);
	
	public void actualizarHistorialReporte(HistorialReporteCpeBean historialReporteCpeBean);
	
}
