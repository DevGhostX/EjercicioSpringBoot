package com.cardif.satelite.cpe.dao;

import java.util.List;
import com.cardif.satelite.cpe.bean.ParametroSUNATCpeBean;

public interface ParametroSUNATCpeMapper {
	
	public List<ParametroSUNATCpeBean> listarParametro(ParametroSUNATCpeBean parametroSunatBean);

}
