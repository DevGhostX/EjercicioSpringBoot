package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.CargaVentaCabCpeBean;
import com.cardif.satelite.cpe.bean.CargaVentaItemCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoEstadoCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoVentaCpeBean;
import com.cardif.satelite.cpe.bean.UpdateVentaCpeBean;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.bean.VentaEstadoCpeBean;

public interface ProcesoCpeMapper {

	public List<ProcesoCpeBean> buscarProcesoCpe(ProcesoCpeBean procesoCpeBean);
	
	public void guardarProcesoCpe(ProcesoCpeBean procesoCpeBean);
	
	public void guardarProcesoEstadoCpe(ProcesoEstadoCpeBean procesoEstadoCpeBean);
	
	public void eliminarProcesoCpe(ProcesoCpeBean procesoCpeBean);
	
	public void eliminarProcesoEstadoCpe(ProcesoCpeBean procesoCpeBean);
	
	public List<VentaCpeBean> buscarVentaCpe(VentaCpeBean ventaCpeBean);
	
	public int guardarVentaCpe(VentaCpeBean ventaCpeBean);
	
	public void guardarVentaEstadoCpe(VentaEstadoCpeBean ventaEstadoCpeBean);
	
	public void guardarProcesoVentaCpe(ProcesoVentaCpeBean procesoVentaCpeBean);
	
	public void guardarUpdateVenta(UpdateVentaCpeBean updateVentaCpeBean);
	
	public void actualizarUpdateVenta(UpdateVentaCpeBean updateVentaCpeBean);
	
	public List<ProcesoVentaCpeBean> listarProcesoVentaCpeBean(ProcesoVentaCpeBean procesoVentaCpeBean);
	
	public List<UpdateVentaCpeBean> listarUpdateVentaCpe(UpdateVentaCpeBean updateVentaCpeBean);
	
	public List<VentaCpeBean> buscarVentaPimsUploadCpe(VentaCpeBean ventaCpeBean);
	
	public void actualizarVentaPimsCpe(VentaCpeBean ventaCpeBean);
	
	public List<VentaCpeBean> buscarVentaDetalladoCpe(VentaCpeBean ventaCpeBean);
	
	public List<CargaVentaCabCpeBean> listarCargaVentaCab(CargaVentaCabCpeBean cargaVentaCabCpeBean);
	
	public void actualizarIncompletosVentaCpe(VentaCpeBean ventaCpeBean);
	
	public void actualizarProcesoMasivoCpe(ProcesoCpeBean procesoCpeBean);
	
	public void eliminarVentaProcesoCpe(ProcesoVentaCpeBean procesoVentaCpeBean);
	
	public void eliminarUpdateVentaCpe(UpdateVentaCpeBean updateVentaCpeBean);
	
	public void eliminarProcesoVentaProcesoCpe(ProcesoVentaCpeBean procesoVentaCpeBean);
	
	public void actualizarProcesoLoteCpe(ProcesoCpeBean procesoCpeBean);
	
	public void actualizarVentaIdAgrupado(VentaCpeBean ventaCpeBean);
	
	public List<VentaCpeBean> buscarVentaCompletarDatosCpe(VentaCpeBean ventaCpeBean);
	
	public void actualizarProcesoVentaCpe(ProcesoVentaCpeBean procesoVentaCpeBean);
	
	public void actualizarNumDocCliVenta(VentaCpeBean ventaCpeBean);
	
	public List<VentaCpeBean> listarAgrupadoChild(VentaCpeBean ventaCpeBean);
	
	public List<ProcesoCpeBean> obtenerProcesoById(ProcesoCpeBean procesoCpeBean);
	
	public List<CargaVentaCabCpeBean> listarAgrupadoUpload(VentaCpeBean ventaCpeBean);
	
	public List<VentaCpeBean> listarVentaByIdCarga(VentaCpeBean ventaCpeBean);

	public void eliminarTmpCompletarDatosCpe(Long idCarga);
	
	public void limpiarCaracterExtrano(long idCarga);
	
	/**TIP_PER0100_CC14 INICIO 2019/06/17 - 14:32 - Se adiciona la declaración de los métodos listarProcesoVentaDetalleItemCpeBean, insertarProcesoVentaDetalleItemCpeBean y eliminarProcesoVentaDetalleItemCpeBean*/
	public List<CargaVentaItemCpeBean> listarProcesoVentaDetalleItemCpeBean(CargaVentaItemCpeBean cargaVentaItemCpeBean);
	public void insertarProcesoVentaDetalleItemCpeBean(CargaVentaItemCpeBean cargaVentaItemCpeBean);
	public void eliminarProcesoVentaDetalleItemCpeBean(CargaVentaItemCpeBean cargaVentaItemCpeBean);
	/**TIP_PER0100_CC14 FIN */
	
	/**TIP_PER0100_CC15 INICIO 2019/06/24 - 14:13 - Se agrega declaración del método guardarVentaCpeRef13*/
	public int guardarVentaCpeRef13(VentaCpeBean ventaCpeBean);
	/**TIP_PER0100_CC15 FIN*/
}
