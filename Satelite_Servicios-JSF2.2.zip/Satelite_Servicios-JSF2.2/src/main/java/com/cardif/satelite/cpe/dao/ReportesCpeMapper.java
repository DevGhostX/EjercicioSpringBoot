package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.ComprobanteCpeBean;
import com.cardif.satelite.cpe.bean.ReporteComprobantesElectronicosBean;
import com.cardif.satelite.cpe.bean.ReporteRegistroVentasBean;
import com.cardif.satelite.cpe.bean.ReporteRegistroVentasPleBean;

public interface ReportesCpeMapper {

	public List<ReporteComprobantesElectronicosBean> listarReporteComprobantesElectronicos
		(ReporteComprobantesElectronicosBean reporteComprobantesElectronicosBean);
	
	public List<ReporteRegistroVentasPleBean> listarReporteRegistroVentasPle
		(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean);
	
	public List<ReporteRegistroVentasPleBean> listarReporteRegistroVentasPleGenerado
	(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean);
	
	public List<ReporteRegistroVentasBean> listarReporteRegistroVentas
		(ReporteRegistroVentasBean reporteRegistroVentasBean);
	
	public void actualizarComprobantePleCpe(ComprobanteCpeBean comprobanteCpeBean);
	
	public int contadorComprobantes(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean);
	
	public void actualizarComprobantesPleCpe(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean);

	public Long maxRegistroPLE(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean);
	
}
