package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.SerieHistorialCpeBean;

public interface SerieHistorialCpeMapper {

	public List<SerieHistorialCpeBean> listarSerieHistorial(SerieHistorialCpeBean serieHistorialCpeBean);
	public void insertarSerieHistorial(SerieHistorialCpeBean serieHistorialCpeBean);
	
}
