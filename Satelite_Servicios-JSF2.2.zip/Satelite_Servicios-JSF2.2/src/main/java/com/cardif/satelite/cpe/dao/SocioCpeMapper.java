package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.SocioCpeBean;

public interface SocioCpeMapper {

	public List<SocioCpeBean> listarSocio(SocioCpeBean socioCpeBean);
	
}
