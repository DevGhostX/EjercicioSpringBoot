package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.TipoCambioCpeBean;

public interface TipoCambioCpeMapper {
	
	public List<TipoCambioCpeBean> listaTipoCambioCpe(TipoCambioCpeBean tipoCambioCpeBean);
	
	public void insertarTipoCambioCpe(TipoCambioCpeBean tipoCambioCpeBean);

}
