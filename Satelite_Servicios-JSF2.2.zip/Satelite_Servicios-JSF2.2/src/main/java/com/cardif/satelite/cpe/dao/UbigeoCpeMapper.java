package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.UbigeoCpeBean;

public interface UbigeoCpeMapper {

	public List<UbigeoCpeBean> listarDepartamento();
	
	public List<UbigeoCpeBean> listarProvincia(UbigeoCpeBean ubigeoCpeBean);
	
	public List<UbigeoCpeBean> listarDistrito(UbigeoCpeBean ubigeoCpeBean);
	
	public List<UbigeoCpeBean> obtenerUbigeo(UbigeoCpeBean ubigeoCpeBean);
	
	public List<UbigeoCpeBean> listarUbigeo();
	
}
