package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.UsuarioBean;

public interface UsuarioMapper {

	public List<UsuarioBean> listarUsuario(UsuarioBean usuarioBean);
	public void insertarUsuario(UsuarioBean usuarioBean);
	public void actualizarUsuario(UsuarioBean usuarioBean);
	public void eliminarUsuario(UsuarioBean usuarioBean);
	
}
