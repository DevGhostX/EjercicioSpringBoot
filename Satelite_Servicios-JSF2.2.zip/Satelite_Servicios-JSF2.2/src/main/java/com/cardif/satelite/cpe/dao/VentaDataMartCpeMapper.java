/**------------------------------------------------------------------------------------------------ 
	Nombre: 		VentaDataMartCpeMapper.java
	Tipo: 			Creación
	Proyecto: 		TIP_PER0100_CC14
	Fecha:			2019/06/20 14:00
	Autor:			TIPROYEC
	Descripción: 	Interface que define los métodos asociados a consultas de ventas en la base de
					Datos del DataMart.
 -----------------------------------------------------------------------------------------------*/
package com.cardif.satelite.cpe.dao;

import java.util.List;

import com.cardif.satelite.cpe.bean.VentaCpeBean;

public interface VentaDataMartCpeMapper {

	/**TIP_PER0100_CC14 INICIO 2019/06/20 - 14:00 - Se agrega la declaración del método obtenerListaVentaCpeDataMart*/
	public List<VentaCpeBean> obtenerListaVentaCpeDataMart(VentaCpeBean ventaCpeBean);
	/**TIP_PER0100_CC14 FIN*/
}
