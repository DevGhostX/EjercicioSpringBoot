package com.cardif.satelite.cpe.dao;

import java.util.List;

import javax.faces.context.FacesContext;

import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.cpe.bean.VentaPimsCpeBean;

public interface VentaPimsCpeMapper {
	
	public List<VentaPimsCpeBean> listarVentasColectivoPims(VentaPimsCpeBean ventaPimsCpeBean);
	public List<VentaPimsCpeBean> listarVentasIndividualPims(VentaPimsCpeBean ventaPimsCpeBean);
	public List<VentaPimsCpeBean> listaCompletarDatosPims(VentaPimsCpeBean ventaPimsCpeBean);
	
}
