package com.cardif.satelite.cpe.service;

import java.util.List;

import org.richfaces.model.UploadedFile;

import com.cardif.satelite.cpe.bean.CampoLayoutCpeBean;
import com.cardif.satelite.cpe.bean.LayoutCabCpeBean;

public interface CampoLayoutCpeService {
	
	public List<CampoLayoutCpeBean> listarLayoutDet(CampoLayoutCpeBean campoLayoutCpeBean);
	
	public String validarArchivoCamposLayout(UploadedFile archivoLayout, String nombreArchivo, String layoutId) throws Exception;
	
	public List<LayoutCabCpeBean> listarLayoutCab(LayoutCabCpeBean layoutCabCpeBean);
	
}
