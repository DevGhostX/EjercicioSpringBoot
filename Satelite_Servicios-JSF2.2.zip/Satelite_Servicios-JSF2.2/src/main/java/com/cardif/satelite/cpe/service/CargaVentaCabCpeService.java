package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.CargaVentaCabCpeBean;

public interface CargaVentaCabCpeService {
	
	public void insertarCargaVentaCab(CargaVentaCabCpeBean cargaVentaCabCpeBean);
	
	public List<CargaVentaCabCpeBean> listarCargaVentaCab(CargaVentaCabCpeBean cargaVentaCabCpeBean);
	
}
