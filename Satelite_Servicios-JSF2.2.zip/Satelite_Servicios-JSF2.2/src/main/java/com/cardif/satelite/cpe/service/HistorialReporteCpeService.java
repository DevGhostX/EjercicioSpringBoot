package com.cardif.satelite.cpe.service;

import com.cardif.satelite.cpe.bean.HistorialReporteCpeBean;

public interface HistorialReporteCpeService {

	public HistorialReporteCpeBean obtenerHistorialPorPeriodo(HistorialReporteCpeBean historialReporteCpeBean);
	
	public void insertarHistorialReporte(HistorialReporteCpeBean historialReporteCpeBean);
	
	public void actualizarHistorialReporte(HistorialReporteCpeBean historialReporteCpeBean);
	
}
