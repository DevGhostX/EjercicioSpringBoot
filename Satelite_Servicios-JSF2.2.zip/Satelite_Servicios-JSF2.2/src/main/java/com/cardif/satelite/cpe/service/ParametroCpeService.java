package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.ParametroCpeBean;

public interface ParametroCpeService {

	public List<ParametroCpeBean> listarParametro(ParametroCpeBean parametroBean);
	public void actualizarParametro(ParametroCpeBean parametroBean);
	
}
