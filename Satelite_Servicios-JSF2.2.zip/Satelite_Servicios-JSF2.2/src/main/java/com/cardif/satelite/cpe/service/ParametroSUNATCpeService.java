package com.cardif.satelite.cpe.service;

import java.util.List;
import com.cardif.satelite.cpe.bean.ParametroSUNATCpeBean;


public interface ParametroSUNATCpeService {
	
	public List<ParametroSUNATCpeBean> listarParametro(ParametroSUNATCpeBean parametroSunatBean);

}
