package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.ProductoCpeBean;

public interface ProductoCpeService {

	public List<ProductoCpeBean> listarProducto(ProductoCpeBean productoCpeBean);
	
}
