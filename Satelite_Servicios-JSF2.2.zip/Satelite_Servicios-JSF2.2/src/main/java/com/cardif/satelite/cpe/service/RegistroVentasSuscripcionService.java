package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.model.TstVentas;

public interface RegistroVentasSuscripcionService {

	public List<VentaCpeBean> listarRegistroVentas(TstVentas tstVentas);
	
}
