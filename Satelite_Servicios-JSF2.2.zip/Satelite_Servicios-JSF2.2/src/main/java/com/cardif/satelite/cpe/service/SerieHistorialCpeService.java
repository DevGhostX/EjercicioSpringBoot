package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.SerieHistorialCpeBean;

public interface SerieHistorialCpeService {

	public List<SerieHistorialCpeBean> listarSerieHistorial(SerieHistorialCpeBean serieHistorialCpeBean); 
	public void insertarSerieHistorial(SerieHistorialCpeBean serieHistorialCpeBean);
	
}
