package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.SocioCpeBean;

public interface SocioCpeService {
	
	public List<SocioCpeBean> listarSocio(SocioCpeBean socioCpeBean);

}
