package com.cardif.satelite.cpe.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.ws.soap.SOAPFaultException;

import org.xml.sax.SAXException;

import com.cardif.satelite.cpe.bean.TipoCambioCpeBean;

public interface TipoCambioCpeService {
	
	public List<TipoCambioCpeBean> listaTipoCambioCpe(TipoCambioCpeBean tipoCambioCpeBean);
	
	public void insertarTipoCambioCpe(TipoCambioCpeBean tipoCambioCpeBean);
	
	public List<TipoCambioCpeBean> obtenerTipoCambioMes(String fechaInicio, String fechaFin, String token)
			throws SOAPFaultException, ParserConfigurationException, SAXException, IOException, TransformerException;

}
