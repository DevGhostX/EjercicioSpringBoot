package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.UbigeoCpeBean;

public interface UbigeoCpeService {

	public List<UbigeoCpeBean> listarDepartamento();
	
	public List<UbigeoCpeBean> listarProvincia(UbigeoCpeBean ubigeoCpeBean);
	
	public List<UbigeoCpeBean> listarDistrito(UbigeoCpeBean ubigeoCpeBean);
	
	public List<UbigeoCpeBean> obtenerUbigeo(UbigeoCpeBean ubigeoCpeBean);
	
	public List<UbigeoCpeBean> listarUbigeo();
	
}