package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.UsuarioBean;

public interface UsuarioService {
	
	public List<UsuarioBean> listarUsuario(UsuarioBean usuarioBean);
	public void insertarUsuario(UsuarioBean usuarioBean);
	public void actualizarUsuario(UsuarioBean usuarioBean);
	public void eliminarUsuario(UsuarioBean usuarioBean);
	
}
