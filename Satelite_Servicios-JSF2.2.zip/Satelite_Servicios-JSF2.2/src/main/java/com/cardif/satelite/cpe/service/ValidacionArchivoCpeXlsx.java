package com.cardif.satelite.cpe.service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.CampoLayoutCpeBean;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.util.SateliteConstants;
import com.cardif.satelite.util.SateliteUtil;

public class ValidacionArchivoCpeXlsx implements SheetContentsHandler {

	private static final Logger LOGGER = Logger.getLogger(ValidacionArchivoCpeXlsx.class);

	private boolean leerCabecera = false;
	private boolean leerCuerpo = false;
	private int col = 0;
	private List<CampoLayoutCpeBean> listaCamposLayout;
	private int contFilas = 0;
	private HashMap<String, String> mapColumnsValues = new HashMap<String, String>();
	
	private List<VentaCpeBean> listVentaXlsx = new ArrayList<VentaCpeBean>();

	/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 15:52 - Se agrega atributo listaParamEmpresasAplicaDetraccion*/
	private List<ParametroCpeBean> listaParamEmpresasAplicaDetraccion;
	/*TIP_PER0100_CC09_13 FIN*/
	
	
	public ValidacionArchivoCpeXlsx() {
		super();
	}

	public ValidacionArchivoCpeXlsx(List<CampoLayoutCpeBean> listaCamposLayout) {
		super();
		this.listaCamposLayout = listaCamposLayout;
	}

	@Override
	public void startRow(int rowNum) {
		try {
			contFilas++;
			mapColumnsValues = obtenerColumnsValues();
			if (rowNum == 0) {
				leerCabecera = true;
			}
			if (rowNum == 1) {
				leerCabecera = false;
				leerCuerpo = true;
				col = 0;
			}
		} catch (Exception e) {
			throw new RuntimeException(
					PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL));
		}
	}

	@Override
	public void endRow() {
		if (leerCuerpo) {
			for (int i = 0; i < listaCamposLayout.size(); i++) {
				
				/*TIP_PER0100_CC09_13 INICIO 2019/05/03 - 09:15 - Se agrega validación para mensaje de error por validación de longitud de dato*/
				if(listaCamposLayout.get(i).getLongitud()!=null){
					if(mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i))!=null
						&&	!mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)).trim().equals("")
						&& mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)).length()>listaCamposLayout.get(i).getLongitud().intValue()){
						String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_LONGITUD_CAMPO_MAXIMA_SUPERADA);
						mensaje = mensaje.replaceAll("NOMBRE_CAMPO",listaCamposLayout.get(i).getNomCol().toUpperCase());
						mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
						mensaje = mensaje.replaceAll("CAMPO_LENGTH",String.valueOf(listaCamposLayout.get(i).getLongitud().intValue()));
						
						throw new RuntimeException(mensaje);
					}
				}
				/*TIP_PER0100_CC09_13 FIN*/
				
				if (listaCamposLayout.get(i).getFlgObl().trim().equals("1")) {
					
					boolean validacion = validarCampoObligatorio(listaCamposLayout.get(i),
							mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
					if (!validacion) {
						throw new RuntimeException("CAMPO " +listaCamposLayout.get(i).getNomCol().toUpperCase()+": "+
								PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
					}
					/*TIP_PER0100_CC09_13 INICIO 2019/05/07 - 10:25 - Se agrega validación para orden de compra en caso el código de empresa sea 1, la orden de compra se setea a null */
					if(listaCamposLayout.get(i).getNomCol().equals("OrdenCompra")){
						for(int j = 0; j < listaCamposLayout.size(); j++){
							if(listaCamposLayout.get(j).getNomCol().equals("EmpresaEmisora")){
								String empresa = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j));
								if (empresa.equals("1")) {
									mapColumnsValues.put(SateliteUtil.obtenerCabecerasExcel().get(i),null);
								}
							}
						}
					}
					/*TIP_PER0100_CC09_13 FIN*/
					
					/*TIP_PER0100_CC09_13 INICIO 2019/05/06 - 18:30 - Se agrega validación por interdependencia entre los campos TituloAdicional y ValorAdicional*/
					if(listaCamposLayout.get(i).getNomCol().equals("TituloAdicional")){
						String campoTituloAdicional = listaCamposLayout.get(i).getNomCol().toUpperCase();
						for(int j = 0; j < listaCamposLayout.size(); j++){
							if(listaCamposLayout.get(j).getNomCol().equals("ValorAdicional")){
								validacion = validarCampoObligatorio(listaCamposLayout.get(j),
										mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j)));
								String campoValorAdicional = listaCamposLayout.get(j).getNomCol().toUpperCase();
								if (!validacion) {
									String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_CAMPOS_DEPENDIENTES);
									mensaje = mensaje.replaceAll("CAMPO_1",campoTituloAdicional);
									mensaje = mensaje.replaceAll("CAMPO_2",campoValorAdicional);
									mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
									throw new RuntimeException(mensaje);
								}
							}
						}
					}else if(listaCamposLayout.get(i).getNomCol().equals("ValorAdicional")){
						String campoValorAdicional = listaCamposLayout.get(i).getNomCol().toUpperCase();
						for(int j = 0; j < listaCamposLayout.size(); j++){
							if(listaCamposLayout.get(j).getNomCol().equals("TituloAdicional")){
								String campoTituloAdicional = listaCamposLayout.get(j).getNomCol().toUpperCase();
								validacion = validarCampoObligatorio(listaCamposLayout.get(j),
										mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j)));
								if (!validacion) {
									String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_CAMPOS_DEPENDIENTES);
									mensaje = mensaje.replaceAll("CAMPO_1",campoTituloAdicional);
									mensaje = mensaje.replaceAll("CAMPO_2",campoValorAdicional);
									mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
									throw new RuntimeException(mensaje);
								}
							}
						}
					}else if(listaCamposLayout.get(i).getNomCol().equals("AplicaDetraccion")){
						String campoAplicaDetraccion = listaCamposLayout.get(i).getNomCol().toUpperCase();
						String aplicaDetraccion = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i));
								if (!aplicaDetraccion.toUpperCase().equals("S") && !aplicaDetraccion.toUpperCase().equals("N")) {
									String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_VALORES_PERMITIDOS_DEL_CAMPO);
									mensaje = mensaje.replaceAll("NOMBRE_CAMPO",campoAplicaDetraccion);
									mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
									mensaje = mensaje.replaceAll("VALORES_PERMITIDOS","S y N");
									throw new RuntimeException(mensaje);
								}
					}
					/*TIP_PER0100_CC09_13 FIN*/
					
				} else {
					boolean validacion = validarCampoNoObligatorio(listaCamposLayout.get(i),
							mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)));
					if (!validacion) {
						throw new RuntimeException("CAMPO " +listaCamposLayout.get(i).getNomCol().toUpperCase()+": "+
								PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
					}
					
					/*TIP_PER0100_CC09_13 INICIO 2019/05/06 - 19:00 - Se agrega validación por interdependencia entre los campos TituloAdicional y ValorAdicional*/
//					if(listaCamposLayout.get(i).getNomCol().equals("TituloAdicional")){
//						String tituloAdicional = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i));
//						for(int j = 0; j < listaCamposLayout.size(); j++){
//							if(listaCamposLayout.get(j).getNomCol().equals("ValorAdicional")){
//								if (tituloAdicional==null || tituloAdicional.trim().equals("")) {
//									mapColumnsValues.put(SateliteUtil.obtenerCabecerasExcel().get(j),null);
//								}
//							}
//						}
//					}else if(listaCamposLayout.get(i).getNomCol().equals("ValorAdicional")){
//						String valorAdicional = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i));
//						for(int j = 0; j < listaCamposLayout.size(); j++){
//							if(listaCamposLayout.get(j).getNomCol().equals("TituloAdicional")){
//								if (valorAdicional==null || valorAdicional.trim().equals("")) {
//									mapColumnsValues.put(SateliteUtil.obtenerCabecerasExcel().get(j),null);
//								}
//							}
//						}
//					}
					/*TIP_PER0100_CC09_13 FIN*/
					
					
					/*TIP_PER0100_CC09_13 INICIO 2019/05/29 - 16:30 - Se agrega validación por interdependencia entre los campos TituloAdicional y ValorAdicional*/
					if(listaCamposLayout.get(i).getNomCol().equals("TituloAdicional")){
						String campoTituloAdicional = listaCamposLayout.get(i).getNomCol().toUpperCase();
						String tituloAdicional = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i));
						for(int j = 0; j < listaCamposLayout.size(); j++){
							if(listaCamposLayout.get(j).getNomCol().equals("ValorAdicional")){
								String campoValorAdicional = listaCamposLayout.get(j).getNomCol().toUpperCase();
								String valorAdicional = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j));
								if (tituloAdicional!=null && !tituloAdicional.trim().equals("")) {
									if( valorAdicional==null || valorAdicional.trim().equals("")){
									String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_CAMPOS_DEPENDIENTES);
									mensaje = mensaje.replaceAll("CAMPO_1",campoTituloAdicional);
									mensaje = mensaje.replaceAll("CAMPO_2",campoValorAdicional);
									mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
									throw new RuntimeException(mensaje);
									}
								}
							}
						}
					}else if(listaCamposLayout.get(i).getNomCol().equals("ValorAdicional")){
						String campoValorAdicional = listaCamposLayout.get(i).getNomCol().toUpperCase();
						String valorAdicional = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i));
						for(int j = 0; j < listaCamposLayout.size(); j++){
							if(listaCamposLayout.get(j).getNomCol().equals("TituloAdicional")){
								String campoTituloAdicional = listaCamposLayout.get(j).getNomCol().toUpperCase();
								String tituloAdicional = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j));
								if (valorAdicional!=null && !valorAdicional.trim().equals("")) {
									if( tituloAdicional==null || tituloAdicional.trim().equals("")){
									String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_CAMPOS_DEPENDIENTES);
									mensaje = mensaje.replaceAll("CAMPO_1",campoTituloAdicional);
									mensaje = mensaje.replaceAll("CAMPO_2",campoValorAdicional);
									mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
									throw new RuntimeException(mensaje);
									}
								}
							}
						}
					}
					/*TIP_PER0100_CC09_13 FIN*/
				}
				
				
				/*TIP_PER0100_CC09_13 INICIO 2019/05/13 - 15:16 - Se agrega validación para porcentaje de detracción de detracción*/
				if(listaCamposLayout.get(i).getNomCol().equals("PorcDetraccion")){
					if(mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i))!=null
						&&	!mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)).trim().equals("")){
						String campoPorcDetraccion = listaCamposLayout.get(i).getNomCol().toUpperCase();
						BigDecimal campoBigDecimal = null;
						BigDecimal valor100 = new BigDecimal("100");
						try{
							campoBigDecimal = new BigDecimal(mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)).replaceAll(",", "."));
						}catch(Exception e){
							
							String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_VALORES_PERMITIDOS_DEL_CAMPO);
							mensaje = mensaje.replaceAll("NOMBRE_CAMPO",campoPorcDetraccion);
							mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
							throw new RuntimeException(mensaje);
						}
						
						if((campoBigDecimal.compareTo(BigDecimal.ONE)>=0) && (campoBigDecimal.compareTo(valor100)<=0)){
							for(int j = 0; j < listaCamposLayout.size(); j++){
								if(listaCamposLayout.get(j).getNomCol().equals("AplicaDetraccion")){
									String campoAplicaDetraccion = listaCamposLayout.get(j).getNomCol().toUpperCase();
									String aplicaDetraccion = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j));
									if (aplicaDetraccion==null || aplicaDetraccion.trim().equals("") || aplicaDetraccion.trim().toUpperCase().equals("N")) {
										
										String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_CAMPOS_DEPENDIENTES_NO_GUARDAN_RELACION);
										mensaje = mensaje.replaceAll("NOMBRE_CAMPO_1",campoPorcDetraccion);
										mensaje = mensaje.replaceAll("NOMBRE_CAMPO_2",campoAplicaDetraccion);
										mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
										throw new RuntimeException(mensaje);
									}
								}
							}
						}else{
							if(campoBigDecimal.compareTo(BigDecimal.ZERO)==0){
								for(int j = 0; j < listaCamposLayout.size(); j++){
									if(listaCamposLayout.get(j).getNomCol().equals("AplicaDetraccion")){
										String campoAplicaDetraccion = listaCamposLayout.get(j).getNomCol().toUpperCase();
										String aplicaDetraccion = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j));
										if (aplicaDetraccion!=null && aplicaDetraccion.trim().toUpperCase().equals("S")) {
											
											String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_CAMPOS_DEPENDIENTES_NO_GUARDAN_RELACION);
											mensaje = mensaje.replaceAll("NOMBRE_CAMPO_1",campoPorcDetraccion);
											mensaje = mensaje.replaceAll("NOMBRE_CAMPO_2",campoAplicaDetraccion);
											mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
											throw new RuntimeException(mensaje);
										}
									}
								}
							}else if(campoBigDecimal.compareTo(BigDecimal.ZERO)!=0){
								String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_RANGO_VALORES_PERMITIDOS_DEL_CAMPO);
								mensaje = mensaje.replaceAll("NOMBRE_CAMPO",campoPorcDetraccion);
								mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
								mensaje = mensaje.replaceAll("RANGO","1 y 100");
								throw new RuntimeException(mensaje);
							}
						}
					}
				}
				
				if(listaCamposLayout.get(i).getNomCol().equals("AplicaDetraccion")){
					if(mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i))!=null
						&&	!mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i)).trim().equals("")){
						String aplicaDetraccion = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(i));
						String campoAplicaDetraccion = listaCamposLayout.get(i).getNomCol().toUpperCase();
						
						//Valimos si Empresa aplica calcular detracción
						String empresa=null;
						String listaEmpresas = "";
						String aplica_Detraccion = "0"; // 0= No aplica, 1= Si aplica
						
						for(int K = 0; K < listaCamposLayout.size(); K++){
							if(listaCamposLayout.get(K).getNomCol().equals("EmpresaEmisora")){
								empresa = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(K));
							}
						}
						
						for(ParametroCpeBean param :listaParamEmpresasAplicaDetraccion){
							if(param.getNomValor().equals("1")){
								listaEmpresas = listaEmpresas + param.getCodValor()+", ";
								if(param.getCodValor().equals(empresa)){
									aplica_Detraccion = "1";
								}
							}
						}
						
						int index = listaEmpresas.trim().lastIndexOf(",");
						
						if(index>0){
							listaEmpresas = listaEmpresas.substring(0, index);
							
							index = listaEmpresas.trim().lastIndexOf(",");
							if(index>0){
								String lista1 = listaEmpresas.substring(0, index);
								String lista2 = listaEmpresas.substring(index+1, listaEmpresas.length()).trim(); 
								listaEmpresas = lista1 + " y " + lista2;
							}
						}
						
						if (aplicaDetraccion.trim().toUpperCase().equals("S") && 
								(aplica_Detraccion.trim().equals("0"))) {
							
							if(listaEmpresas!=null && !listaEmpresas.trim().equals("")){
								String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_COD_EMPRESA_NO_APLICA_DETRACCION);
								mensaje = mensaje.replaceAll("LIST_COD_EMPRESA",listaEmpresas);
								throw new RuntimeException(mensaje);
							}else{
								String mensaje = "No existen empresas registradas que apliquen detracción";
								throw new RuntimeException(mensaje);
							}
						}
						
						
						for(int j = 0; j < listaCamposLayout.size(); j++){
							if(listaCamposLayout.get(j).getNomCol().equals("PorcDetraccion")){
								String porcDetraccion = mapColumnsValues.get(SateliteUtil.obtenerCabecerasExcel().get(j));
								if (aplicaDetraccion.trim().toUpperCase().equals("S") && 
										(porcDetraccion==null || porcDetraccion.trim().equals(""))) {
									String campoPorcDetraccion = listaCamposLayout.get(j).getNomCol().toUpperCase();
									String mensaje = PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MSJ_CAMPOS_DEPENDIENTES_NO_GUARDAN_RELACION);
									mensaje = mensaje.replaceAll("NOMBRE_CAMPO_1",campoAplicaDetraccion);
									mensaje = mensaje.replaceAll("NOMBRE_CAMPO_2",campoPorcDetraccion);
									mensaje = mensaje.replaceAll("NUM_FILA",String.valueOf(contFilas));
									throw new RuntimeException(mensaje);
								}
							}
						}
					}
				}
				/*TIP_PER0100_CC09_13 FIN*/
				
			}
			listVentaXlsx.add(getObjectinRow(mapColumnsValues));
			mapColumnsValues.clear();
		}
	}

	@Override
	public void cell(String cellReference, String formattedValue) {
		String column = "";
		if (leerCabecera) {
			boolean esCabeceraValida = validarCabeceraOrdenYNombreCol(listaCamposLayout, col, formattedValue);
			if (!esCabeceraValida) {
				throw new RuntimeException(
						PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAB_EXCEL));
			}
			col++;
		} else if (leerCuerpo) {
			if (!getLength(cellReference)) {
				column = cellReference.substring(0, 1);
				mapColumnsValues.put(column, formattedValue);
			} else {
				column = cellReference.substring(0, 2);
				mapColumnsValues.put(column, formattedValue);
			}
		}
	}

	@Override
	public void headerFooter(String text, boolean isHeader, String tagName) {
	}

	private boolean validarCabeceraOrdenYNombreCol(List<CampoLayoutCpeBean> listaCamposLayout, int nroOrdenCampo,
			String nombreColumna) {
		if(nroOrdenCampo != listaCamposLayout.size()){
			if (listaCamposLayout.get(nroOrdenCampo).getNomCol().trim().equalsIgnoreCase(nombreColumna)) {
				return true;
			}
		}
		return false;
	}

	private boolean validarCampoObligatorio(CampoLayoutCpeBean campo, String valorCelda) {
		try {
			// Si la celda esta vacia y el campo es obligatorio
			if (valorCelda == null || valorCelda.trim().length() == 0) {
				return false;
			}
			// si la longitud de la celda es mayor a la longitud del campo
			else if((campo.getIdLayout().toString().equalsIgnoreCase(Constantes.ID_LAYOUT_ARCHIVO_ERROR)) ? false : (valorCelda.trim().length() > campo.getLongitud())){
				return false;
			}
			// Si es alfanumerico
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_ALFANUMERICO)) {
				//return valorCelda == null ? false : valorCelda.trim().length() == 0 ? false : true;
				if(valorCelda == null || valorCelda.trim().length() == 0){
					return false;
				}else{
					if(campo.getFormatoCol() != null){
						return validarFecha(valorCelda);
					}
					return true;
				}
			}
			// Si es Numerico
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {
				Double.parseDouble(valorCelda.replaceAll(",", "."));
				return true;
			}
			// Si es tipo Fecha
			else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
				SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoCol());
				sdf.format(sdf.parse(valorCelda));
				return true;
			}
			
			return true;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}
	}

	private boolean validarCampoNoObligatorio(CampoLayoutCpeBean campo, String valorCelda) {
		try {
			// Si no es obligatorio pero la celda tiene valor
			if (valorCelda != null && valorCelda.trim().length() > 0) {

				// si la longitud de la celda es mayor a la longitud del campo
				if((campo.getIdLayout().toString().equalsIgnoreCase(Constantes.ID_LAYOUT_ARCHIVO_ERROR)) ? false : (valorCelda.trim().length() > campo.getLongitud())){
					return false;
				}				
				// Si es Numerico
				else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_NUMERICO)) {
					Double.parseDouble(valorCelda.replaceAll(",", "."));
					return true;
				}
				// Si es tipo Fecha
				else if (campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_FECHA)) {
					SimpleDateFormat sdf = new SimpleDateFormat(campo.getFormatoCol());
					sdf.format(sdf.parse(valorCelda));
					return true;
				}else if(campo.getTipoDato().equalsIgnoreCase(SateliteConstants.TIPO_DATO_ALFANUMERICO) &&
							campo.getFormatoCol() != null){
					if(campo.getFormatoCol().trim().equals(Constantes.CPE_FORMATO_FECHA_STR)){
						return validarFecha(valorCelda);
					}
				}
			}
			return true;
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return false;
		}
	}
	
	public static boolean validarFecha(String fecha) {
        try {
            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyyMMdd");
            formatoFecha.setLenient(false);
            formatoFecha.parse(fecha);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }

	private static synchronized boolean getLength(String cell) {
		boolean res = false;
		int sum = cell.replaceAll("(?i)[^AEIOU]", "").length()
				+ cell.replaceAll("(?i)[^BCDFGHJKLMNPQRSTVWXYZ]", "").length();
		if (sum == 2) {
			res = true;
		}
		return res;
		// return true;
	}

	private HashMap<String, String> obtenerColumnsValues() {
		mapColumnsValues.put("A", "");
		mapColumnsValues.put("B", "");
		mapColumnsValues.put("C", "");
		mapColumnsValues.put("D", "");
		mapColumnsValues.put("E", "");
		mapColumnsValues.put("F", "");
		mapColumnsValues.put("G", "");
		mapColumnsValues.put("H", "");
		mapColumnsValues.put("I", "");
		mapColumnsValues.put("J", "");
		mapColumnsValues.put("K", "");
		mapColumnsValues.put("L", "");
		mapColumnsValues.put("M", "");
		mapColumnsValues.put("N", "");
		mapColumnsValues.put("O", "");
		mapColumnsValues.put("P", "");
		mapColumnsValues.put("Q", "");
		mapColumnsValues.put("R", "");
		mapColumnsValues.put("S", "");
		mapColumnsValues.put("T", "");
		mapColumnsValues.put("U", "");
		mapColumnsValues.put("V", "");
		mapColumnsValues.put("W", "");
		mapColumnsValues.put("X", "");
		mapColumnsValues.put("Y", "");
		mapColumnsValues.put("Z", "");
		mapColumnsValues.put("AA", "");
		mapColumnsValues.put("AB", "");
		mapColumnsValues.put("AC", "");
		mapColumnsValues.put("AD", "");
		mapColumnsValues.put("AE", "");
		mapColumnsValues.put("AF", "");
		mapColumnsValues.put("AG", "");
		mapColumnsValues.put("AH", "");
		mapColumnsValues.put("AI", "");
		mapColumnsValues.put("AJ", "");
		mapColumnsValues.put("AK", "");
		mapColumnsValues.put("AL", "");
		mapColumnsValues.put("AM", "");
		mapColumnsValues.put("AN", "");
		mapColumnsValues.put("AO", "");
		mapColumnsValues.put("AP", "");
		mapColumnsValues.put("AQ", "");
		mapColumnsValues.put("AR", "");
		mapColumnsValues.put("AS", "");
		mapColumnsValues.put("AT", "");
		mapColumnsValues.put("AU", "");
		mapColumnsValues.put("AV", "");
		mapColumnsValues.put("AW", "");
		mapColumnsValues.put("AX", "");
		mapColumnsValues.put("AY", "");
		mapColumnsValues.put("AZ", "");
		return mapColumnsValues;
	}
	
	@SuppressWarnings("unchecked")
	private VentaCpeBean getObjectinRow(HashMap<String, String> map){
		VentaCpeBean venta = new VentaCpeBean();
		try {
			/*TIP_PER0100_CC09_13 INICIO 2019/05/02 - 10:30 - Se comenta calculo de longitud de la lista*/
//			int size = listaCamposLayout.size();
			/*TIP_PER0100_CC09_13 FIN 2019/05/02 - 10:30 - Se comenta calculo de longitud de la lista*/
			
			/*TIP_PER0100_CC09_13 INICIO 2019/05/02 - 10:35 - Se optimiza la obtención de los datos de las celdas*/
			Collections.sort(listaCamposLayout);
			for(CampoLayoutCpeBean campo : listaCamposLayout){
				int orden = campo.getOrdCampo().intValue();
				String campoCadena = "";
				Long campoLong = null;
				BigDecimal campoBigDecimal = null;
				
				if(campo.getNomCol().equals("EmpresaEmisora") || campo.getNomCol().equals("FechaEmision")
					|| campo.getNomCol().equals("TipoComprobante")|| campo.getNomCol().equals("ConceptoNC/ND")
					|| campo.getNomCol().equals("TipoMoneda")|| campo.getNomCol().equals("FechaVencimiento")
					|| campo.getNomCol().equals("TipoDocCliente")|| campo.getNomCol().equals("NumDocCliente")
					|| campo.getNomCol().equals("Nombres-RazonSocial")|| campo.getNomCol().equals("Direccion")
					|| campo.getNomCol().equals("Departamento")|| campo.getNomCol().equals("Provincia")
					|| campo.getNomCol().equals("Distrito")|| campo.getNomCol().equals("Telefono")
					|| campo.getNomCol().equals("Correo")|| campo.getNomCol().equals("TipoComprobanteRef")
					|| campo.getNomCol().equals("FechaEmisionRef")|| campo.getNomCol().equals("Concepto")
					|| campo.getNomCol().equals("NumeroPoliza")|| campo.getNomCol().equals("OpenItem")
					|| campo.getNomCol().equals("OpenItemRef")|| campo.getNomCol().equals("Area")
					|| campo.getNomCol().equals("Observaciones")|| campo.getNomCol().equals("Colect_indiv")
					|| campo.getNomCol().equals("Linea")|| campo.getNomCol().equals("TipoAfectacion")
					|| campo.getNomCol().equals("OrdenCompra")|| campo.getNomCol().equals("AplicaDetraccion")
					|| campo.getNomCol().equals("TituloAdicional")|| campo.getNomCol().equals("ValorAdicional")
					/**TIP_PER0100_CC15 INICIO 2019/06/24 - 12:34 - Se valida los campos SerieComprobanteRef y CorrelativoSerieOrig en formato cadena*/
					|| campo.getNomCol().equals("SerieComprobanteRef") || campo.getNomCol().equals("CorrelativoSerieOrig")
					/**TIP_PER0100_CC15 FIN*/
						){
					campoCadena = map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1));
				}
				
				if(campo.getNomCol().equals("Socio") || campo.getNomCol().equals("Producto")
					|| campo.getNomCol().equals("SerieComprobanteRef") || campo.getNomCol().equals("CorrelativoSerieOrig")
					|| campo.getNomCol().equals("ProductoSunat") || campo.getNomCol().equals("Id Venta")){
					campoLong = map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)).trim().length() == 0 ? 
									null : Long.parseLong(map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)));
				}
				
				
				if(campo.getNomCol().equals("ValorFactExport") || campo.getNomCol().equals("BaseImponible")
					|| campo.getNomCol().equals("ImporteExonerado") || campo.getNomCol().equals("ImporteInafecto")
					|| campo.getNomCol().equals("ValorOpGratuitas") || campo.getNomCol().equals("ISC")
					|| campo.getNomCol().equals("IGV") || campo.getNomCol().equals("Otros Importes")
					|| campo.getNomCol().equals("Importe Total") || campo.getNomCol().equals("PorcDetraccion")){
					campoBigDecimal = map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(orden-1)).replaceAll(",", "."));
				}
				
				if(campo.getNomCol().equals("EmpresaEmisora"))venta.setIdEmpresa(campoCadena);
				if(campo.getNomCol().equals("Socio"))venta.setIdSocio(campoLong);
				if(campo.getNomCol().equals("Producto"))venta.setIdProducto(campoLong);
				if(campo.getNomCol().equals("FechaEmision"))venta.setFechaEmision(campoCadena);
				if(campo.getNomCol().equals("OrdenCompra"))venta.setOrdenCompra(venta.getIdEmpresa().equals("1")?null:campoCadena);
				if(campo.getNomCol().equals("TipoComprobante"))venta.setIdTipoComp(campoCadena);
				if(campo.getNomCol().equals("ConceptoNC/ND"))venta.setConcepNd(campoCadena);
				if(campo.getNomCol().equals("TipoMoneda"))venta.setTipoMoneda(campoCadena);
				if(campo.getNomCol().equals("FechaVencimiento"))venta.setFechaVenc(campoCadena);
				if(campo.getNomCol().equals("TipoDocCliente"))venta.setIdTipoDocCli(campoCadena);
				if(campo.getNomCol().equals("NumDocCliente"))venta.setNumDocCli(campoCadena);
				if(campo.getNomCol().equals("Nombres-RazonSocial"))venta.setNomCliRazSoc(campoCadena);
				if(campo.getNomCol().equals("Direccion"))venta.setDirCliente(campoCadena);
				if(campo.getNomCol().equals("Departamento"))venta.setDepartamento(campoCadena);
				if(campo.getNomCol().equals("Provincia"))venta.setProvincia(campoCadena);
				if(campo.getNomCol().equals("Distrito"))venta.setDistrito(campoCadena);
				if(campo.getNomCol().equals("Telefono"))venta.setTelefCliente(campoCadena);
				if(campo.getNomCol().equals("Correo"))venta.setMailCliente(campoCadena);
				if(campo.getNomCol().equals("TipoComprobanteRef"))venta.setIdTipoCompRef(campoCadena);
				if(campo.getNomCol().equals("FechaEmisionRef"))venta.setFechaEmisionRef(campoCadena);
				/**TIP_PER0100_CC15 INICIO 2019/06/24 - 12:37 - Se almacena los campos SerieComprobanteRef y CorrelativoSerieOrig en formato cadena*/
				if(campo.getNomCol().equals("SerieComprobanteRef")){
					venta.setNumSerieRef(campoLong);
					venta.setStrNumSerieRef(campoCadena);
					};
				if(campo.getNomCol().equals("CorrelativoSerieOrig")){
					venta.setNumCorRef(campoLong);
					venta.setStrNumCorRef(campoCadena);
					};
				/**TIP_PER0100_CC15 FIN*/
				if(campo.getNomCol().equals("Concepto"))venta.setConcepto(campoCadena);
				if(campo.getNomCol().equals("ProductoSunat"))venta.setCodProdSunat(campoLong);
				if(campo.getNomCol().equals("NumeroPoliza"))venta.setNumPoliza(campoCadena);
				if(campo.getNomCol().equals("AplicaDetraccion"))venta.setAplicaDetraccion(campoCadena);
				if(campo.getNomCol().equals("PorcDetraccion"))venta.setPorcDetraccion(campoBigDecimal);
				if(campo.getNomCol().equals("ValorFactExport"))venta.setValFactExport(campoBigDecimal);
				if(campo.getNomCol().equals("BaseImponible"))venta.setBaseImponible(campoBigDecimal);
				if(campo.getNomCol().equals("ImporteExonerado"))venta.setImpExonerado(campoBigDecimal);
				if(campo.getNomCol().equals("ImporteInafecto"))venta.setImpInafecto(campoBigDecimal);
				if(campo.getNomCol().equals("ValorOpGratuitas"))venta.setValOpGratuitas(campoBigDecimal);
				if(campo.getNomCol().equals("ISC"))venta.setIsc(campoBigDecimal);
				if(campo.getNomCol().equals("IGV"))venta.setIgv(campoBigDecimal);
				if(campo.getNomCol().equals("Otros Importes"))venta.setImpOtros(campoBigDecimal);
				if(campo.getNomCol().equals("Importe Total"))venta.setImpTotal(campoBigDecimal);
				if(campo.getNomCol().equals("OpenItem"))venta.setOpenItem(campoCadena);
				if(campo.getNomCol().equals("OpenItemRef"))venta.setOpenItemRef(campoCadena);
				if(campo.getNomCol().equals("Area"))venta.setArea(campoCadena);
				if(campo.getNomCol().equals("Observaciones"))venta.setObservacion(campoCadena);
				if(campo.getNomCol().equals("Colect_indiv"))venta.setColectIndiv(campoCadena);
				if(campo.getNomCol().equals("Linea"))venta.setLinea(campoCadena);
				if(campo.getNomCol().equals("TipoAfectacion"))venta.setTipoAfectacion(campoCadena);
				if(campo.getNomCol().equals("TituloAdicional"))venta.setTituloAdicional(campoCadena);
				if(campo.getNomCol().equals("ValorAdicional"))venta.setValorAdicional(campoCadena);
				if(campo.getNomCol().equals("Id Venta"))venta.setIdVenta(campoLong);
				
			}
			/*TIP_PER0100_CC09_13 FIN 2019/05/02 - 10:35 - Se optimiza la obtención de los datos de las celdas*/
			
			/*TIP_PER0100_CC09_13 INICIO 2019/05/02 - 12:47 - Se comenta lógica anterior*/
			/*
			for(int i = 1 ; i<=size ; i++ ){
				
				if(i==1){
					venta.setIdEmpresa(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==2){
					venta.setIdSocio(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : Long.parseLong(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1))));
				}else if(i==3){
					venta.setIdProducto(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : Long.parseLong(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1))));
				}else if(i==4){
					venta.setFechaEmision(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==5){
					venta.setIdTipoComp(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==6){
					venta.setConcepNd(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==7){
					venta.setTipoMoneda(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==8){
					venta.setFechaVenc(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==9){
					venta.setIdTipoDocCli(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==10){
					venta.setNumDocCli(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==11){
					venta.setNomCliRazSoc(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==12){
					venta.setDirCliente(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==13){
					venta.setDepartamento(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==14){
					venta.setProvincia(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==15){
					venta.setDistrito(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==16){
					venta.setTelefCliente(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==17){
					venta.setMailCliente(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==18){
					venta.setIdTipoCompRef(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==19){
					venta.setFechaEmisionRef(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==20){
					venta.setNumSerieRef(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : Long.parseLong(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1))));
				}else if(i==21){
					venta.setNumCorRef(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : Long.parseLong(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1))));
				}else if(i==22){
					venta.setConcepto(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==23){
					venta.setCodProdSunat(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : Long.parseLong(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1))));
					
				}else if(i==24){
					venta.setNumPoliza(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==25){
					venta.setValFactExport(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==26){
					venta.setBaseImponible(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==27){
					venta.setImpExonerado(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==28){
					venta.setImpInafecto(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==29){
					venta.setValOpGratuitas(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==30){
					venta.setIsc(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==31){
					venta.setIgv(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==32){
					venta.setImpOtros(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==33){
					venta.setImpTotal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
//				}else if(i==34){
//					venta.setTipoCambio(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
//							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
//									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
//				}else if(i==35){
//					venta.setEstado(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
//							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
//									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==34){
					venta.setOpenItem(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==35){
					venta.setOpenItemRef(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==36){
					venta.setArea(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==37){
					venta.setObservacion(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
//				}else if(i==40){
//					venta.setMontoUsd(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
//							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
//									null : new BigDecimal(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).replaceAll(",", ".")));
				}else if(i==38){
					venta.setColectIndiv(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==39){
					venta.setLinea(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
//				}else if(i==43){
//					venta.setPeriodo(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
//							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
//									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));
				}else if(i==40){
					venta.setTipoAfectacion(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)));					
				}else if(i==41){
					venta.setIdVenta(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)) == null ? 
							null : map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1)).trim().length() == 0 ? 
									null : Long.valueOf(map.get(SateliteUtil.obtenerCabecerasExcel().get(i-1))));
				}
			}
			*/
			/*TIP_PER0100_CC09_13 Fin 2019/05/02 - 12:47 - Se comenta lógica anterior*/
		} catch (Exception e) {
			throw new RuntimeException(
					PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_CAMPOS_EXCEL));
		}
		return venta;
	}

	public List<CampoLayoutCpeBean> getListaCamposLayout() {
		return listaCamposLayout;
	}

	public void setListaCamposLayout(List<CampoLayoutCpeBean> listaCamposLayout) {
		this.listaCamposLayout = listaCamposLayout;
	}

	public int getContFilas() {
		return contFilas;
	}

	public void setContFilas(int contFilas) {
		this.contFilas = contFilas;
	}
	
	public List<VentaCpeBean> getListVentaXlsx() {
		return listVentaXlsx;
	}

	public void setListVentaXlsx(List<VentaCpeBean> listVentaXlsx) {
		this.listVentaXlsx = listVentaXlsx;
	}

	/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 14:55 - Se agrega los set y get del atributo parametroCpeService*/
	/**
	 * Método que permite obtener la lista de la tabla paramétrica para validar empresas que aplican detracción.
	 * @return listaCodEmpresasAplicaDetraccion Lista de la tabla paramétrica para validar empresas que aplican detracción, tipo List<ParametroCpeBean>.
	 */
	public List<ParametroCpeBean> getListaParamEmpresasAplicaDetraccion() {
		return listaParamEmpresasAplicaDetraccion;
	}

	/**
	 * Método que permite actualizar la lista de la tabla paramétrica para validar empresas que aplican detracción.
	 * @param listaCodEmpresasAplicaDetraccion Lista de la tabla paramétrica para validar empresas que aplican detracción, tipo List<ParametroCpeBean>.
	 */
	public void setListaParamEmpresasAplicaDetraccion(List<ParametroCpeBean> listaParamEmpresasAplicaDetraccion) {
		this.listaParamEmpresasAplicaDetraccion = listaParamEmpresasAplicaDetraccion;
	}
	/*TIP_PER0100_CC09_13 FIN*/
}
