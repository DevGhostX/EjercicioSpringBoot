package com.cardif.satelite.cpe.service;

import java.util.List;

import com.cardif.satelite.cpe.bean.VentaPimsCpeBean;

public interface VentaPimsCpeService {

	public List<VentaPimsCpeBean> listarVentasColectivoPims(VentaPimsCpeBean ventaPimsCpeBean);
	public List<VentaPimsCpeBean> listarVentasIndividualPims(VentaPimsCpeBean ventaPimsCpeBean);
	public List<VentaPimsCpeBean> listaCompletarDatosPims(VentaPimsCpeBean ventaPimsCpeBean);
	
}
