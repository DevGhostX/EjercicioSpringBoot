package com.cardif.satelite.cpe.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.OldExcelFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.richfaces.model.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.cardif.framework.excepcion.PropertiesErrorUtil;
import com.cardif.satelite.constantes.Constantes;
import com.cardif.satelite.constantes.ErrorConstants;
import com.cardif.satelite.cpe.bean.CampoLayoutCpeBean;
import com.cardif.satelite.cpe.bean.LayoutCabCpeBean;
import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.dao.CampoLayoutCpeMapper;
import com.cardif.satelite.cpe.service.CampoLayoutCpeService;
import com.cardif.satelite.cpe.service.ParametroCpeService;
import com.cardif.satelite.cpe.service.ValidacionArchivoCpeXlsx;

@Service("campoLayoutCpeService")
public class CampoLayoutCpeServiceImpl implements CampoLayoutCpeService{
	
	private static final Logger logger = Logger.getLogger(CampoLayoutCpeServiceImpl.class);
	
	@Autowired
	private CampoLayoutCpeMapper campoLayoutCpeMapper;

	/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 15:52 - Se define la inyección de dependencia del servicio ParametroCpeService*/
	@Autowired
	private ParametroCpeService parametroCpeService;
	/*TIP_PER0100_CC09_13 FIN*/
	
	@Override
	public List<CampoLayoutCpeBean> listarLayoutDet(CampoLayoutCpeBean campoLayoutCpeBean) {
		return campoLayoutCpeMapper.listarLayoutDet(campoLayoutCpeBean);
	}

	/*
	 * TODO BSC
	 */
	@Override
	public String validarArchivoCamposLayout(UploadedFile archivoLayout, String nombreArchivo, String layoutId)throws Exception {
		try {
			CampoLayoutCpeBean layout = new CampoLayoutCpeBean();
			layout.setIdLayout(Long.parseLong(layoutId));
			List<CampoLayoutCpeBean> listCampos = this.listarLayoutDet(layout);
			
			if(listCampos != null && listCampos.size() > 0){
				boolean xlsx = FilenameUtils.getExtension(nombreArchivo).equalsIgnoreCase("xlsx");
				if(xlsx){
					return validarXlsx(archivoLayout, listCampos);
				}else{
					//LEER .XLS CON HSSF
				}
			}else{
				return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
			}
			return null;
		} catch (OldExcelFormatException e) {
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_ANTIGUO_FORMATO_EXCEL);
		} catch (Exception e) {
			throw e;
		}
	}

	/*
	 * TODO BSC
	 */
	private String validarXlsx(UploadedFile archivoLayout, List<CampoLayoutCpeBean> camposLayout) throws Exception{
		InputStream stream = null;
		try {
			OPCPackage container = OPCPackage.open(archivoLayout.getInputStream());
			ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(container);
			XSSFReader xssfReader = new XSSFReader(container);
			StylesTable styles = xssfReader.getStylesTable();
			stream = xssfReader.getSheet(Constantes.ID_FIRST_SHEET_XLSX);
			return this.procesarValidacionXlsx(styles, strings, stream, camposLayout);
		} catch (Exception e) {
			e.printStackTrace();
			return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
		}finally{
			if(stream != null){
				stream.close();
			}
		}
	}

	@Override
	public List<LayoutCabCpeBean> listarLayoutCab(LayoutCabCpeBean layoutCabCpeBean) {
		return campoLayoutCpeMapper.listarLayoutCab(layoutCabCpeBean);
	}
	
	private String procesarValidacionXlsx(StylesTable styles, ReadOnlySharedStringsTable strings, 
			InputStream sheetInputStream, List<CampoLayoutCpeBean> camposLayout){
		InputSource sheetSource = new InputSource(sheetInputStream);
		SAXParserFactory saxFactory = SAXParserFactory.newInstance();
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(Constantes.KEY_LIST_VENTA_XLSX, null);
		try {
			SAXParser saxParser = saxFactory.newSAXParser();
			XMLReader sheetParser = saxParser.getXMLReader();
			ValidacionArchivoCpeXlsx xlsxHandler = new ValidacionArchivoCpeXlsx(camposLayout);
			/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 15:52 - Se actualiza lista listaCodEmpresasAplicaDetraccion*/
			xlsxHandler.setListaParamEmpresasAplicaDetraccion(obtenerListaParametrosEmpresaAplicaDetracion());
			/*TIP_PER0100_CC09_13 FIN*/
			ContentHandler handler = new XSSFSheetXMLHandler(styles, strings, xlsxHandler, false);
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			int contFilas = xlsxHandler.getContFilas();
			if(contFilas < 2){
				return PropertiesErrorUtil.getProperty(ErrorConstants.COD_ERROR_MAL_ESTRUCTURA_ARCHIVO_EXCEL);
			}
			List<VentaCpeBean> listVentaXlsx = xlsxHandler.getListVentaXlsx();
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put(Constantes.KEY_LIST_VENTA_XLSX, listVentaXlsx);
			return null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return e.getMessage();
		}
	}
	
	/*TIP_PER0100_CC09_13 INICIO 2019/05/20 - 15:52 - Se crea método que consulta en la tabla paramétrica las empresas que aplican detracción*/
	private List<ParametroCpeBean> obtenerListaParametrosEmpresaAplicaDetracion(){
		ParametroCpeBean param = new ParametroCpeBean();
		param.setCodParam(Constantes.COD_PARAM_CPE_EMPRESA_CON_DETRACCION);
		param.setTipParam(Constantes.TIP_PARAM_DETALLE);
		List<ParametroCpeBean> lstParam = new ArrayList<ParametroCpeBean>();
		lstParam = parametroCpeService.listarParametro(param);
		
		return lstParam;
	}
	
	/*TIP_PER0100_CC09_13 FIN*/

}
