package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.CargaVentaCabCpeBean;
import com.cardif.satelite.cpe.dao.CargaVentaCabCpeMapper;
import com.cardif.satelite.cpe.service.CargaVentaCabCpeService;

@Service("cargaVentaCabCpeService")
public class CargaVentaCabCpeServiceImpl implements CargaVentaCabCpeService{
	
	@Autowired
	private CargaVentaCabCpeMapper cargaVentaCabCpeMapper;

	@Override
	public void insertarCargaVentaCab(CargaVentaCabCpeBean cargaVentaCabCpeBean) {
		cargaVentaCabCpeMapper.insertarCargaVentaCab(cargaVentaCabCpeBean);
	}

	@Override
	public List<CargaVentaCabCpeBean> listarCargaVentaCab(
			CargaVentaCabCpeBean cargaVentaCabCpeBean) {
		return cargaVentaCabCpeMapper.listarCargaVentaCab(cargaVentaCabCpeBean);
	}
}
