package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.ComprobanteCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoMasivoCpeBean;
import com.cardif.satelite.cpe.dao.ComprobanteCpeMapper;
import com.cardif.satelite.cpe.service.ComprobanteCpeService;

@Service("comprobanteCpeService")
public class ComprobanteCpeServiceImpl implements ComprobanteCpeService{

	@Autowired
	private ComprobanteCpeMapper comprobanteCpeMapper;
	
	@Override
	public void insertarComprobanteCpe(ComprobanteCpeBean comprobanteCpeBean) {
		comprobanteCpeMapper.insertarComprobanteCpe(comprobanteCpeBean);
	}

	@Override
	public List<ProcesoMasivoCpeBean> filtrarProcesoMasivoCpe(ProcesoMasivoCpeBean procesoMasivoCpeBean) {
		return comprobanteCpeMapper.filtrarProcesoMasivoCpe(procesoMasivoCpeBean);
	}

	@Override
	public void actualizarEstadoComprobanteCpe(
			ComprobanteCpeBean comprobanteCpeBean) {
		comprobanteCpeMapper.actualizarEstadoComprobanteCpe(comprobanteCpeBean);
	}

	@Override
	public List<ComprobanteCpeBean> obtenerComprobante(ComprobanteCpeBean comprobanteCpeBean) {
		return comprobanteCpeMapper.obtenerComprobante(comprobanteCpeBean);
	}
	
}
