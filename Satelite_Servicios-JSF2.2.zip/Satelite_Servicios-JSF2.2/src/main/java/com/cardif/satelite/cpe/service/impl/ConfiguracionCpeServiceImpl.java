package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.ConfiguracionCpeBean;
import com.cardif.satelite.cpe.dao.ConfiguracionCpeMapper;
import com.cardif.satelite.cpe.service.ConfiguracionCpeService;

@Service("configuracionCpeService")
public class ConfiguracionCpeServiceImpl implements ConfiguracionCpeService{
	
	@Autowired
	private ConfiguracionCpeMapper configuracionCpeMapper;

	@Override
	public List<ConfiguracionCpeBean> listarConfiguracion(ConfiguracionCpeBean configuracionCpeBean) {
		return configuracionCpeMapper.listarConfiguracion(configuracionCpeBean);
	}

	@Override
	public void insertarConfiguracion(ConfiguracionCpeBean configuracionCpeBean) {
		configuracionCpeMapper.insertarConfiguracion(configuracionCpeBean);		
	}

	@Override
	public void actualizarConfiguracion(ConfiguracionCpeBean configuracionCpeBean) {
		configuracionCpeMapper.actualizarConfiguracion(configuracionCpeBean);	
	}
	
	@Override
	public void actualizarConfiguracionSerieCorrelativo(ConfiguracionCpeBean configuracionCpeBean) {
		configuracionCpeMapper.actualizarConfiguracionSerieCorrelativo(configuracionCpeBean);	
	}
	
	@Override
	public void inactivarConfiguracion(ConfiguracionCpeBean configuracionCpeBean) {
		configuracionCpeMapper.inactivarConfiguracion(configuracionCpeBean);
	}

	@Override
	public void eliminarConfiguracion(ConfiguracionCpeBean configuracionCpeBean) {
		configuracionCpeMapper.eliminarConfiguracion(configuracionCpeBean);		
	}

	@Override
	public List<ConfiguracionCpeBean> listarConfiguracionCpe(
			ConfiguracionCpeBean configuracionCpeBean) {
		return configuracionCpeMapper.listarConfiguracionCpe(configuracionCpeBean);
	}

	@Override
	public void actualizarCorrelativo(ConfiguracionCpeBean configuracionCpeBean) {
		configuracionCpeMapper.actualizarCorrelativo(configuracionCpeBean);
	}
}
