package com.cardif.satelite.cpe.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.HistorialReporteCpeBean;
import com.cardif.satelite.cpe.dao.HistorialReporteCpeMapper;
import com.cardif.satelite.cpe.service.HistorialReporteCpeService;

@Service("historialReporteCpeService")
public class HistorialReporteCpeServiceImpl implements HistorialReporteCpeService{

	@Autowired
	private HistorialReporteCpeMapper historialReporteCpeMapper;
	
	@Override
	public HistorialReporteCpeBean obtenerHistorialPorPeriodo(HistorialReporteCpeBean historialReporteCpeBean) {
		return historialReporteCpeMapper.obtenerHistorialPorPeriodo(historialReporteCpeBean);
	}

	@Override
	public void insertarHistorialReporte(HistorialReporteCpeBean historialReporteCpeBean) {
		historialReporteCpeMapper.insertarHistorialReporte(historialReporteCpeBean);
	}

	@Override
	public void actualizarHistorialReporte(HistorialReporteCpeBean historialReporteCpeBean) {
		historialReporteCpeMapper.actualizarHistorialReporte(historialReporteCpeBean);
	}

}
