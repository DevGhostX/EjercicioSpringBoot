package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.dao.ParametroCpeMapper;
import com.cardif.satelite.cpe.service.ParametroCpeService;

@Service("parametroCpeService")
public class ParametroCpeServiceImpl implements ParametroCpeService{
	
	@Autowired
	private ParametroCpeMapper parametroCpeMapper;

	@Override
	public List<ParametroCpeBean> listarParametro(ParametroCpeBean parametroBean) {
		return parametroCpeMapper.listarParametro(parametroBean);
	}

	@Override
	public void actualizarParametro(ParametroCpeBean parametroBean) {
		parametroCpeMapper.actualizarParametro(parametroBean);
	}

}
