package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.ParametroCpeBean;
import com.cardif.satelite.cpe.bean.ParametroSUNATCpeBean;
import com.cardif.satelite.cpe.dao.ParametroSUNATCpeMapper;
import com.cardif.satelite.cpe.service.ParametroSUNATCpeService;

@Service("ParametroSUNATCpeService")
public class ParametroSUNATCpeServiceImpl implements ParametroSUNATCpeService {

	@Autowired
	private ParametroSUNATCpeMapper parametroSunatCpeMapper;
		
	@Override
	public List<ParametroSUNATCpeBean> listarParametro(ParametroSUNATCpeBean parametroBean) {
		return parametroSunatCpeMapper.listarParametro(parametroBean);
	}
}
