package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.CargaVentaCabCpeBean;
import com.cardif.satelite.cpe.bean.CargaVentaItemCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoEstadoCpeBean;
import com.cardif.satelite.cpe.bean.ProcesoVentaCpeBean;
import com.cardif.satelite.cpe.bean.UpdateVentaCpeBean;
import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.bean.VentaEstadoCpeBean;
import com.cardif.satelite.cpe.dao.ProcesoCpeMapper;
import com.cardif.satelite.cpe.service.ProcesoCpeService;

@Service("procesoCpeService")
public class ProcesoCpeServiceImpl implements ProcesoCpeService {

	
	@Autowired
	private ProcesoCpeMapper procesoCpeMapper;
	
	@Override
	public List<ProcesoCpeBean> buscarProcesoCpe(ProcesoCpeBean procesoCpeBean) {
		return procesoCpeMapper.buscarProcesoCpe(procesoCpeBean);
	}

	@Override
	public void guardarProcesoCpe(ProcesoCpeBean procesoCpeBean) {
		procesoCpeMapper.guardarProcesoCpe(procesoCpeBean);
	}

	@Override
	public void guardarProcesoEstadoCpe(ProcesoEstadoCpeBean procesoEstadoCpeBean) {
		procesoCpeMapper.guardarProcesoEstadoCpe(procesoEstadoCpeBean);
	}

	@Override
	public void eliminarProcesoCpe(ProcesoCpeBean procesoCpeBean) {
		procesoCpeMapper.eliminarProcesoCpe(procesoCpeBean);
	}

	@Override
	public void eliminarProcesoEstadoCpe(ProcesoCpeBean procesoCpeBean) {
		procesoCpeMapper.eliminarProcesoEstadoCpe(procesoCpeBean);
	}

	@Override
	public List<VentaCpeBean> buscarVentaCpe(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.buscarVentaCpe(ventaCpeBean);
	}

	@Override
	public int guardarVentaCpe(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.guardarVentaCpe(ventaCpeBean);
	}

	@Override
	public void guardarVentaEstadoCpe(VentaEstadoCpeBean ventaEstadoCpeBean) {
		procesoCpeMapper.guardarVentaEstadoCpe(ventaEstadoCpeBean);
	}

	@Override
	public void guardarProcesoVentaCpe(ProcesoVentaCpeBean procesoVentaCpeBean) {
		procesoCpeMapper.guardarProcesoVentaCpe(procesoVentaCpeBean);
	}
	
	@Override
	public void guardarUpdateVenta(UpdateVentaCpeBean updateVentaCpeBean) {
		procesoCpeMapper.guardarUpdateVenta(updateVentaCpeBean);
	}

	@Override
	public void actualizarUpdateVenta(UpdateVentaCpeBean updateVentaCpeBean) {
		procesoCpeMapper.actualizarUpdateVenta(updateVentaCpeBean);
	}

	@Override
	public List<ProcesoVentaCpeBean> listarProcesoVentaCpeBean(
			ProcesoVentaCpeBean procesoVentaCpeBean) {
		return procesoCpeMapper.listarProcesoVentaCpeBean(procesoVentaCpeBean);
	}

	@Override
	public List<UpdateVentaCpeBean> listarUpdateVentaCpe(
			UpdateVentaCpeBean updateVentaCpeBean) {
		return procesoCpeMapper.listarUpdateVentaCpe(updateVentaCpeBean);
	}

	@Override
	public List<VentaCpeBean> buscarVentaPimsUploadCpe(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.buscarVentaPimsUploadCpe(ventaCpeBean);
	}

	@Override
	public void actualizarVentaPimsCpe(VentaCpeBean ventaCpeBean) {
		procesoCpeMapper.actualizarVentaPimsCpe(ventaCpeBean);
	}

	@Override
	public List<VentaCpeBean> buscarVentaDetalladoCpe(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.buscarVentaDetalladoCpe(ventaCpeBean);
	}

	@Override
	public List<CargaVentaCabCpeBean> listarCargaVentaCab(
			CargaVentaCabCpeBean cargaVentaCabCpeBean) {
		return procesoCpeMapper.listarCargaVentaCab(cargaVentaCabCpeBean);
	}

	@Override
	public void actualizarIncompletosVentaCpe(VentaCpeBean ventaCpeBean) {
		procesoCpeMapper.actualizarIncompletosVentaCpe(ventaCpeBean);
	}

	@Override
	public void actualizarProcesoMasivoCpe(ProcesoCpeBean procesoCpeBean) {
		procesoCpeMapper.actualizarProcesoMasivoCpe(procesoCpeBean);
	}

	@Override
	public void eliminarVentaProcesoCpe(ProcesoVentaCpeBean procesoVentaCpeBean) {
		procesoCpeMapper.eliminarVentaProcesoCpe(procesoVentaCpeBean);
	}

	@Override
	public void eliminarUpdateVentaCpe(UpdateVentaCpeBean updateVentaCpeBean) {
		procesoCpeMapper.eliminarUpdateVentaCpe(updateVentaCpeBean);
	}

	@Override
	public void eliminarProcesoVentaProcesoCpe(
			ProcesoVentaCpeBean procesoVentaCpeBean) {
		procesoCpeMapper.eliminarProcesoVentaProcesoCpe(procesoVentaCpeBean);
	}

	@Override
	public void actualizarProcesoLoteCpe(ProcesoCpeBean procesoCpeBean) {
		procesoCpeMapper.actualizarProcesoLoteCpe(procesoCpeBean);
	}

	@Override
	public void actualizarVentaIdAgrupado(VentaCpeBean ventaCpeBean) {
		procesoCpeMapper.actualizarVentaIdAgrupado(ventaCpeBean);
	}
	
	@Override
	public List<VentaCpeBean> buscarVentaCompletarDatosCpe(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.buscarVentaCompletarDatosCpe(ventaCpeBean);
	}

	@Override
	public void actualizarProcesoVentaCpe(ProcesoVentaCpeBean procesoVentaCpeBean) {
		procesoCpeMapper.actualizarProcesoVentaCpe(procesoVentaCpeBean);
	}

	@Override
	public void actualizarNumDocCliVenta(VentaCpeBean ventaCpeBean) {
		procesoCpeMapper.actualizarNumDocCliVenta(ventaCpeBean);
	}

	@Override
	public List<VentaCpeBean> listarAgrupadoChild(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.listarAgrupadoChild(ventaCpeBean);
	}

	@Override
	public List<ProcesoCpeBean> obtenerProcesoById(ProcesoCpeBean procesoCpeBean) {
		return procesoCpeMapper.obtenerProcesoById(procesoCpeBean);
	}

	@Override
	public List<CargaVentaCabCpeBean> listarAgrupadoUpload(
			VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.listarAgrupadoUpload(ventaCpeBean);
	}

	@Override
	public List<VentaCpeBean> listarVentaByIdCarga(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.listarVentaByIdCarga(ventaCpeBean);
	}

	@Override
	public void eliminarTmpCompletarDatosCpe(Long idCarga) {
		procesoCpeMapper.eliminarTmpCompletarDatosCpe(idCarga);
	}
	
	@Override
	public void limpiarCaracterExtrano(long idCarga) {
		procesoCpeMapper.limpiarCaracterExtrano(idCarga);
	}

	/**TIP_PER0100_CC14 INICIO 2019/06/17 - 10:15 - Se adiciona la definiciones de los métodos método listarProcesoVentaDetalleItemCpeBean y insertarProcesoVentaDetalleItemCpeBean */
	@Override
	public List<CargaVentaItemCpeBean> listarProcesoVentaDetalleItemCpeBean(CargaVentaItemCpeBean cargaVentaItemCpeBean) {
		return procesoCpeMapper.listarProcesoVentaDetalleItemCpeBean(cargaVentaItemCpeBean);
		
	}
	

	@Override
	public void insertarProcesoVentaDetalleItemCpeBean(CargaVentaItemCpeBean cargaVentaItemCpeBean) {
		procesoCpeMapper.insertarProcesoVentaDetalleItemCpeBean(cargaVentaItemCpeBean);
		
	}

	@Override
	public void eliminarProcesoVentaDetalleItemCpeBean(CargaVentaItemCpeBean cargaVentaItemCpeBean) {
		procesoCpeMapper.eliminarProcesoVentaDetalleItemCpeBean(cargaVentaItemCpeBean);	
	}

	/**TIP_PER0100_CC14 FIN */
	
	/**TIP_PER0100_CC15 INICIO 2019/06/24 - 14:10 - Se agrega definición del método guardarVentaCpeRef13*/
	@Override
	public int guardarVentaCpeRef13(VentaCpeBean ventaCpeBean) {
		return procesoCpeMapper.guardarVentaCpeRef13(ventaCpeBean);
	}
	/**TIP_PER0100_CC15 FIN*/
}
