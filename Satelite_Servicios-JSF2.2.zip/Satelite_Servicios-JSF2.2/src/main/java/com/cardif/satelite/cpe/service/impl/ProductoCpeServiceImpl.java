package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.ProductoCpeBean;
import com.cardif.satelite.cpe.dao.ProductoCpeMapper;
import com.cardif.satelite.cpe.service.ProductoCpeService;

@Service("productoCpeService")
public class ProductoCpeServiceImpl implements ProductoCpeService{
	
	@Autowired
	private ProductoCpeMapper productoCpeMapper;

	@Override
	public List<ProductoCpeBean> listarProducto(ProductoCpeBean productoCpeBean) {
		return productoCpeMapper.listarProducto(productoCpeBean);
	}

}
