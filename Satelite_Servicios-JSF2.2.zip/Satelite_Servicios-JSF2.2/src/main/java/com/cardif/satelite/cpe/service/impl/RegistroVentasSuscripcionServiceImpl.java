package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.dao.RegistroVentasSuscripcionMapper;
import com.cardif.satelite.cpe.service.RegistroVentasSuscripcionService;
import com.cardif.satelite.model.TstVentas;

@Service("registroVentasSuscripcionService")
public class RegistroVentasSuscripcionServiceImpl implements RegistroVentasSuscripcionService{

	@Autowired
	private RegistroVentasSuscripcionMapper registroVentasSuscripcionMapper;
	
	@Override
	public List<VentaCpeBean> listarRegistroVentas(TstVentas tstVentas) {
		return registroVentasSuscripcionMapper.listarRegistroVentas(tstVentas);
	}

}
