package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.ComprobanteCpeBean;
import com.cardif.satelite.cpe.bean.ReporteComprobantesElectronicosBean;
import com.cardif.satelite.cpe.bean.ReporteRegistroVentasBean;
import com.cardif.satelite.cpe.bean.ReporteRegistroVentasPleBean;
import com.cardif.satelite.cpe.dao.ReportesCpeMapper;
import com.cardif.satelite.cpe.service.ReportesCpeService;

@Service("reportesCpeService")
public class ReportesCpeServiceImpl implements ReportesCpeService{
	
	@Autowired
	ReportesCpeMapper reportesCpeMapper;

	@Override
	public List<ReporteComprobantesElectronicosBean> listarReporteComprobantesElectronicos(
			ReporteComprobantesElectronicosBean reporteComprobantesElectronicosBean) {
		return reportesCpeMapper.listarReporteComprobantesElectronicos(reporteComprobantesElectronicosBean);
	}

	@Override
	public List<ReporteRegistroVentasPleBean> listarReporteRegistroVentasPle(
			ReporteRegistroVentasPleBean reporteRegistroVentasPleBean) {
		return reportesCpeMapper.listarReporteRegistroVentasPle(reporteRegistroVentasPleBean);
	}
	
	@Override
	public List<ReporteRegistroVentasPleBean> listarReporteRegistroVentasPleGenerado(
			ReporteRegistroVentasPleBean reporteRegistroVentasPleBean) {
		return reportesCpeMapper.listarReporteRegistroVentasPleGenerado(reporteRegistroVentasPleBean);
	}

	@Override
	public List<ReporteRegistroVentasBean> listarReporteRegistroVentas(
			ReporteRegistroVentasBean reporteRegistroVentasBean) {
		return reportesCpeMapper.listarReporteRegistroVentas(reporteRegistroVentasBean);
	}

	@Override
	public void actualizarComprobantePleCpe(ComprobanteCpeBean comprobanteCpeBean) {
		reportesCpeMapper.actualizarComprobantePleCpe(comprobanteCpeBean);
	}

	@Override
	public int contadorComprobantes(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean) {
		return reportesCpeMapper.contadorComprobantes(reporteRegistroVentasPleBean);
	}

	@Override
	public void actualizarComprobantesPleCpe(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean) {
		reportesCpeMapper.actualizarComprobantesPleCpe(reporteRegistroVentasPleBean);
	}
	
	@Override
	public Long maxRegistroPLE(ReporteRegistroVentasPleBean reporteRegistroVentasPleBean){
		return reportesCpeMapper.maxRegistroPLE(reporteRegistroVentasPleBean);
	};

}
