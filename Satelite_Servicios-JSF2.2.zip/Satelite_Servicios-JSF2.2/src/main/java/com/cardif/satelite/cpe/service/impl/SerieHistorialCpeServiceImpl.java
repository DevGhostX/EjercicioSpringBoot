package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.SerieHistorialCpeBean;
import com.cardif.satelite.cpe.dao.SerieHistorialCpeMapper;
import com.cardif.satelite.cpe.service.SerieHistorialCpeService;

@Service("serieHistorialCpeService")
public class SerieHistorialCpeServiceImpl implements SerieHistorialCpeService{
	
	@Autowired
	private SerieHistorialCpeMapper serieHistorialCpeMapper;

	@Override
	public List<SerieHistorialCpeBean> listarSerieHistorial(SerieHistorialCpeBean serieHistorialCpeBean) {
		return serieHistorialCpeMapper.listarSerieHistorial(serieHistorialCpeBean);
	}

	@Override
	public void insertarSerieHistorial(SerieHistorialCpeBean serieHistorialCpeBean) {
		serieHistorialCpeMapper.insertarSerieHistorial(serieHistorialCpeBean);
	}

}
