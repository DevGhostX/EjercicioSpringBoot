package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.SocioCpeBean;
import com.cardif.satelite.cpe.dao.SocioCpeMapper;
import com.cardif.satelite.cpe.service.SocioCpeService;

@Service("SocioCpeService")
public class SocioCpeServiceImpl implements SocioCpeService{

	@Autowired
	private SocioCpeMapper socioCpeMapper;
	
	@Override
	public List<SocioCpeBean> listarSocio(SocioCpeBean socioCpeBean) {
		return socioCpeMapper.listarSocio(socioCpeBean);
	}

}
