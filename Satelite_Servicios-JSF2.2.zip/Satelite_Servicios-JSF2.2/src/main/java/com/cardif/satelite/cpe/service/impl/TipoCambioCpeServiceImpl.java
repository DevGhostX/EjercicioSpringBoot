package com.cardif.satelite.cpe.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import com.cardif.satelite.cpe.bean.TipoCambioCpeBean;
import com.cardif.satelite.cpe.dao.TipoCambioCpeMapper;
import com.cardif.satelite.cpe.service.TipoCambioCpeService;
import com.cardif.sunsystems.controller.SunsystemsController;

@Service("tipoCambioCpeService")
public class TipoCambioCpeServiceImpl implements TipoCambioCpeService{
	
	@Autowired
	private TipoCambioCpeMapper tipoCambioCpeMapper;
	
	private SunsystemsController controlSun = SunsystemsController.getInstance();

	@Override
	public List<TipoCambioCpeBean> listaTipoCambioCpe(TipoCambioCpeBean tipoCambioCpeBean) {
		return tipoCambioCpeMapper.listaTipoCambioCpe(tipoCambioCpeBean);
	}

	@Override
	public void insertarTipoCambioCpe(TipoCambioCpeBean tipoCambioCpeBean) {
		tipoCambioCpeMapper.insertarTipoCambioCpe(tipoCambioCpeBean);
	}
	
	@Override
	public List<TipoCambioCpeBean> obtenerTipoCambioMes(String fechaInicio, String fechaFin, String token)
			throws NullPointerException, ParserConfigurationException, SAXException, IOException, TransformerFactoryConfigurationError, TransformerException {
		List<TipoCambioCpeBean> val = new ArrayList<TipoCambioCpeBean>();
		val = controlSun.extraerTipoCambioMensual(fechaInicio, fechaFin, token);
		return val;
	}
}