package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.UbigeoCpeBean;
import com.cardif.satelite.cpe.dao.UbigeoCpeMapper;
import com.cardif.satelite.cpe.service.UbigeoCpeService;

@Service("ubigeoCpeService")
public class UbigeoCpeServiceImpl implements UbigeoCpeService{

	@Autowired
	private UbigeoCpeMapper ubigeoCpeMapper;
	
	@Override
	public List<UbigeoCpeBean> listarDepartamento() {
		return ubigeoCpeMapper.listarDepartamento();
	}

	@Override
	public List<UbigeoCpeBean> listarProvincia(UbigeoCpeBean ubigeoCpeBean) {
		return ubigeoCpeMapper.listarProvincia(ubigeoCpeBean);
	}

	@Override
	public List<UbigeoCpeBean> listarDistrito(UbigeoCpeBean ubigeoCpeBean) {
		return ubigeoCpeMapper.listarDistrito(ubigeoCpeBean);
	}

	@Override
	public List<UbigeoCpeBean> obtenerUbigeo(UbigeoCpeBean ubigeoCpeBean) {
		return ubigeoCpeMapper.obtenerUbigeo(ubigeoCpeBean);
	}

	@Override
	public List<UbigeoCpeBean> listarUbigeo() {
		return ubigeoCpeMapper.listarUbigeo();
	}

}
