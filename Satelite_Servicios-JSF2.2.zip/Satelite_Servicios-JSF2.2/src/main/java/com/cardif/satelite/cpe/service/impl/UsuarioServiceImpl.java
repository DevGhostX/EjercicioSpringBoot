package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.UsuarioBean;
import com.cardif.satelite.cpe.dao.UsuarioMapper;
import com.cardif.satelite.cpe.service.UsuarioService;

@Service("usuarioService")
public class UsuarioServiceImpl implements UsuarioService{
	
	@Autowired
	private UsuarioMapper usuarioMapper;

	@Override
	public List<UsuarioBean> listarUsuario(UsuarioBean usuarioBean) {
		return usuarioMapper.listarUsuario(usuarioBean);
	}

	@Override
	public void insertarUsuario(UsuarioBean usuarioBean) {
		usuarioMapper.insertarUsuario(usuarioBean);
	}

	@Override
	public void actualizarUsuario(UsuarioBean usuarioBean) {
		usuarioMapper.actualizarUsuario(usuarioBean);
	}

	@Override
	public void eliminarUsuario(UsuarioBean usuarioBean) {
		usuarioMapper.eliminarUsuario(usuarioBean);
	}

}
