/**------------------------------------------------------------------------------------------------ 
	Nombre: 		VentaDataMartCpeServiceImpl.java
	Tipo: 			Creación
	Proyecto: 		TIP_PER0100_CC14
	Fecha:			2019/06/20 14:40
	Autor:			TIPROYEC
	Descripción: 	Clase que implementa los métodos asociados a los servicios de ventas en la base de
					Datos del DataMart.
 -----------------------------------------------------------------------------------------------*/
package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.VentaCpeBean;
import com.cardif.satelite.cpe.dao.VentaDataMartCpeMapper;
import com.cardif.satelite.cpe.service.VentaDataMartCpeService;

@Service("ventaDataMartCpeService")
public class VentaDataMartCpeServiceImpl implements VentaDataMartCpeService {

	@Autowired
	private VentaDataMartCpeMapper ventaDataMartCpeMapper;

	/**TIP_PER0100_CC14 INICIO 2019/06/27 - 14:53 - Se agrega la declaración del método obtenerListaVentaCpeDataMart*/
	@Override
	public List<VentaCpeBean> obtenerListaVentaCpeDataMart(VentaCpeBean ventaCpeBean) {
		return ventaDataMartCpeMapper.obtenerListaVentaCpeDataMart(ventaCpeBean);
	}
	/**TIP_PER0100_CC14 FIN*/
	
}
