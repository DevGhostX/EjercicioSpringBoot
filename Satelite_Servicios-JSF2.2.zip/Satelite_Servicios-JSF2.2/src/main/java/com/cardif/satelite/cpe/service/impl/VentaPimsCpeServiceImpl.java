package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.VentaPimsCpeBean;
import com.cardif.satelite.cpe.dao.VentaPimsCpeMapper;
import com.cardif.satelite.cpe.service.VentaPimsCpeService;

@Service("ventaPimsCpeService")
public class VentaPimsCpeServiceImpl implements VentaPimsCpeService{

	@Autowired
	private VentaPimsCpeMapper ventaPimsCpeMapper;

	@Override
	public List<VentaPimsCpeBean> listarVentasColectivoPims(VentaPimsCpeBean ventaPimsCpeBean) {
		return ventaPimsCpeMapper.listarVentasColectivoPims(ventaPimsCpeBean);
	}

	@Override
	public List<VentaPimsCpeBean> listarVentasIndividualPims(VentaPimsCpeBean ventaPimsCpeBean) {
		return ventaPimsCpeMapper.listarVentasIndividualPims(ventaPimsCpeBean);
	}

	@Override
	public List<VentaPimsCpeBean> listaCompletarDatosPims(VentaPimsCpeBean ventaPimsCpeBean) {
		return ventaPimsCpeMapper.listaCompletarDatosPims(ventaPimsCpeBean);
	}
	
}
