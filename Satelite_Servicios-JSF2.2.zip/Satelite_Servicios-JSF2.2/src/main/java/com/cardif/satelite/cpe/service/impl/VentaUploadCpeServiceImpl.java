package com.cardif.satelite.cpe.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardif.satelite.cpe.bean.VentaUploadAgrupadoCpeBean;
import com.cardif.satelite.cpe.bean.VentaUploadCpeBean;
import com.cardif.satelite.cpe.dao.VentaUploadCpeMapper;
import com.cardif.satelite.cpe.service.VentaUploadCpeService;

@Service("ventaUploadCpeService")
public class VentaUploadCpeServiceImpl implements VentaUploadCpeService{
	
	@Autowired
	private VentaUploadCpeMapper ventaUploadCpeMapper;

	@Override
	public List<VentaUploadCpeBean> listarVentasDetalladoUpload(VentaUploadCpeBean ventaUploadCpeBean) {
		return ventaUploadCpeMapper.listarVentasDetalladoUpload(ventaUploadCpeBean);
	}

	@Override
	public List<VentaUploadAgrupadoCpeBean> listarVentasAgrupadoUpload(VentaUploadAgrupadoCpeBean ventaUploadAgrupadoCpeBean) {
		return ventaUploadCpeMapper.listarVentasAgrupadoUpload(ventaUploadAgrupadoCpeBean);
	}

	@Override
	public List<VentaUploadCpeBean> listaCompletarDatosUpload(VentaUploadCpeBean ventaUploadCpeBean) {
		return ventaUploadCpeMapper.listaCompletarDatosUpload(ventaUploadCpeBean);
	}

}
