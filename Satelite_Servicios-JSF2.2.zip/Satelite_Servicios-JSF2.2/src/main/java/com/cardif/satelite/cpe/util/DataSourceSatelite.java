package com.cardif.satelite.cpe.util;

import javax.sql.DataSource;

public interface DataSourceSatelite {

	public DataSource getDataSourceCpe();
	
	public DataSource getDataSourceUpload();
	
}
