package com.cardif.satelite.cpe.util;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("dataSourceSatelite")
public class DataSourceSateliteImpl implements DataSourceSatelite{

	@Autowired
	private DataSource dataSourceCPE;
	
	@Autowired
	private DataSource dataSourceUpload;
	
	@Override
	public DataSource getDataSourceCpe() {
		return dataSourceCPE;
	}

	@Override
	public DataSource getDataSourceUpload() {
		return dataSourceUpload;
	}

}
