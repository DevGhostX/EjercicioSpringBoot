package com.cardif.satelite.cpe.util;

import java.net.URI;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class JerseyClientCpe {

	public static final Logger logger = Logger.getLogger(JerseyClientCpe.class);
	
	public JerseyClientCpe(){}
	
	public String sendCEPost(String jsonRequest, String URL){
		String output = null;
		
		try {
			
			URI uri = new URI(URL);
			
			Client client = Client.create();
			
			WebResource webResource = client.resource(uri);
			ClientResponse response = webResource.accept(MediaType.APPLICATION_JSON)
										.type(MediaType.APPLICATION_JSON).post(ClientResponse.class, jsonRequest);
			output = response.getEntity(String.class);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return output;
	}
	
	public String getService(String URL){
		
		String output = null;
		
		try {
		
		URI uri = new URI(URL);
		
		Client client = Client.create();

		WebResource webResource = client.resource(uri);
		
		ClientResponse response = webResource.accept(MediaType.APPLICATION_JSON)
									.type(MediaType.APPLICATION_JSON).get(ClientResponse.class);
		
		output = response.getEntity(String.class);
		
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		
		return output;
		
	}
	
	public int testConnectionService(String URL) {
	    int output = 0;

	    try {
	      URI uri = new URI(URL);
	      
	      Client client = Client.create();
	      
	      WebResource webResource = client.resource(uri);
	      
	      ClientResponse response = (ClientResponse)((WebResource.Builder)webResource.accept(new String[] { "application/json"
	          }).type("application/json")).get(ClientResponse.class);
	      
	      output = response.getStatus();
	    }
	    catch (Exception e) {
	      e.printStackTrace();
	      logger.error(e.getMessage());
	    } 
	    
	    return output;
	}
	
	public int testConnection(String jsonRequest, String URL){
		int output = 0;
		
		try {
			
			URI uri = new URI(URL);
			
			Client client = Client.create();
			
			WebResource webResource = client.resource(uri);
			ClientResponse response = webResource.accept(MediaType.APPLICATION_JSON)
										.type(MediaType.APPLICATION_JSON).post(ClientResponse.class, jsonRequest);
			output = response.getStatus();
			logger.info("Comunicación con " + URL + ": Status " + output);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Comunicación con " + URL + " fallido", e);
			e.printStackTrace();
			return 99999;
		}
		
		return output;
	}
}
