package com.cardif.satelite.model;

import java.util.Date;

public class ConciliacionSoat implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Long idConciSoat;
	private Integer idSocio;
	private String periodo;
	private Date fechaCreacion;
	private String usuarioCreacion;
	private Integer estado;
	private String proceso;

	public Long getIdConciSoat() {
		return idConciSoat;
	}

	public void setIdConciSoat(Long idConciSoat) {
		this.idConciSoat = idConciSoat;
	}

	public Integer getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(Integer idSocio) {
		this.idSocio = idSocio;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Integer getEstado() {
		return estado;
	}

	public void setEstado(Integer estado) {
		this.estado = estado;
	}

	public String getProceso() {
		return proceso;
	}

	public void setProceso(String proceso) {
		this.proceso = proceso;
	}

}
