package com.cardif.satelite.model.reportesbs;

import java.io.Serializable;
import java.util.Date;

public class DinamicaCab implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long codDinConta;
	private Long codEmpresa;
	private Long codSocio;
	private Long codProducto;
	private String codDetCuenta;
	private String codTipo;
	private String codTipoRea;
	private String codTipoMov;
	private String codMoneda;
	private String nomDinConta;
	private String estadoDinConta;
	private String afectoIgv;
	private String afectoDcto;
	private String codSocioProducto;
	private String tipoDiario;
	private String canalDinConta;
	private String ccDinConta;
	private String specDinConta;
	private String depDinConta;
	private Long depCodDinConta;
	private String usuCrea;
	private Date fecCrea;
	private String usuModifica;
	private Date fecModifica;

	public Long getCodDinConta() {
		return codDinConta;
	}

	public void setCodDinConta(Long codDinConta) {
		this.codDinConta = codDinConta;
	}

	public Long getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(Long codEmpresa) {
		this.codEmpresa = codEmpresa;
	}

	public Long getCodSocio() {
		return codSocio;
	}

	public void setCodSocio(Long codSocio) {
		this.codSocio = codSocio;
	}

	public Long getCodProducto() {
		return codProducto;
	}

	public void setCodProducto(Long codProducto) {
		this.codProducto = codProducto;
	}

	public String getCodDetCuenta() {
		return codDetCuenta;
	}

	public void setCodDetCuenta(String codDetCuenta) {
		this.codDetCuenta = codDetCuenta;
	}

	public String getCodTipo() {
		return codTipo;
	}

	public void setCodTipo(String codTipo) {
		this.codTipo = codTipo;
	}

	public String getCodTipoRea() {
		return codTipoRea;
	}

	public void setCodTipoRea(String codTipoRea) {
		this.codTipoRea = codTipoRea;
	}

	public String getCodTipoMov() {
		return codTipoMov;
	}

	public void setCodTipoMov(String codTipoMov) {
		this.codTipoMov = codTipoMov;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getNomDinConta() {
		return nomDinConta;
	}

	public void setNomDinConta(String nomDinConta) {
		this.nomDinConta = nomDinConta;
	}

	public String getEstadoDinConta() {
		return estadoDinConta;
	}

	public void setEstadoDinConta(String estadoDinConta) {
		this.estadoDinConta = estadoDinConta;
	}

	public String getAfectoIgv() {
		return afectoIgv;
	}

	public void setAfectoIgv(String afectoIgv) {
		this.afectoIgv = afectoIgv;
	}

	public String getAfectoDcto() {
		return afectoDcto;
	}

	public void setAfectoDcto(String afectoDcto) {
		this.afectoDcto = afectoDcto;
	}

	public String getCodSocioProducto() {
		return codSocioProducto;
	}

	public void setCodSocioProducto(String codSocioProducto) {
		this.codSocioProducto = codSocioProducto;
	}

	public String getTipoDiario() {
		return tipoDiario;
	}

	public void setTipoDiario(String tipoDiario) {
		this.tipoDiario = tipoDiario;
	}

	public String getCanalDinConta() {
		return canalDinConta;
	}

	public void setCanalDinConta(String canalDinConta) {
		this.canalDinConta = canalDinConta;
	}

	public String getCcDinConta() {
		return ccDinConta;
	}

	public void setCcDinConta(String ccDinConta) {
		this.ccDinConta = ccDinConta;
	}

	public String getSpecDinConta() {
		return specDinConta;
	}

	public void setSpecDinConta(String specDinConta) {
		this.specDinConta = specDinConta;
	}

	public String getDepDinConta() {
		return depDinConta;
	}

	public void setDepDinConta(String depDinConta) {
		this.depDinConta = depDinConta;
	}

	public Long getDepCodDinConta() {
		return depCodDinConta;
	}

	public void setDepCodDinConta(Long depCodDinConta) {
		this.depCodDinConta = depCodDinConta;
	}

	public String getUsuCrea() {
		return usuCrea;
	}

	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public String getUsuModifica() {
		return usuModifica;
	}

	public void setUsuModifica(String usuModifica) {
		this.usuModifica = usuModifica;
	}

	public Date getFecModifica() {
		return fecModifica;
	}

	public void setFecModifica(Date fecModifica) {
		this.fecModifica = fecModifica;
	}

}
