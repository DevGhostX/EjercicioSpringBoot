package com.cardif.satelite.model.reportesbs;

import java.io.Serializable;

public class DinamicaDet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long codDinConta;
	private Long numCuenta;
	private String descCuenta;
	private String marcadorCuenta;
	private String igvCuenta;
	private String dctoCuenta;

	public Long getCodDinConta() {
		return codDinConta;
	}

	public void setCodDinConta(Long codDinConta) {
		this.codDinConta = codDinConta;
	}

	public Long getNumCuenta() {
		return numCuenta;
	}

	public void setNumCuenta(Long numCuenta) {
		this.numCuenta = numCuenta;
	}

	public String getDescCuenta() {
		return descCuenta;
	}

	public void setDescCuenta(String descCuenta) {
		this.descCuenta = descCuenta;
	}

	public String getMarcadorCuenta() {
		return marcadorCuenta;
	}

	public void setMarcadorCuenta(String marcadorCuenta) {
		this.marcadorCuenta = marcadorCuenta;
	}

	public String getIgvCuenta() {
		return igvCuenta;
	}

	public void setIgvCuenta(String igvCuenta) {
		this.igvCuenta = igvCuenta;
	}

	public String getDctoCuenta() {
		return dctoCuenta;
	}

	public void setDctoCuenta(String dctoCuenta) {
		this.dctoCuenta = dctoCuenta;
	}

}
