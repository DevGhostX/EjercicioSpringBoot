package com.cardif.satelite.model.reportesbs;

import java.io.Serializable;
import java.util.Date;

public class Empresa implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long codEmpresa;
	private String descripcion;
	private String codSbs;
	private Long estado;

	private String paisOrigen;
	private Long clasificadoraId;
	private Long clasificacionId;
	private Date fechaClasificacion;

	public Empresa() {
	}

	public Long getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(Long codEmpresa) {
		this.codEmpresa = codEmpresa;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCodSbs() {
		return codSbs;
	}

	public void setCodSbs(String codSbs) {
		this.codSbs = codSbs;
	}

	public Long getEstado() {
		return estado;
	}

	public void setEstado(Long estado) {
		this.estado = estado;
	}

	public String getPaisOrigen() {
		return paisOrigen;
	}

	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	public Long getClasificadoraId() {
		return clasificadoraId;
	}

	public void setClasificadoraId(Long clasificadoraId) {
		this.clasificadoraId = clasificadoraId;
	}

	public Long getClasificacionId() {
		return clasificacionId;
	}

	public void setClasificacionId(Long clasificacionId) {
		this.clasificacionId = clasificacionId;
	}

	public Date getFechaClasificacion() {
		return fechaClasificacion;
	}

	public void setFechaClasificacion(Date fechaClasificacion) {
		this.fechaClasificacion = fechaClasificacion;
	}
}
