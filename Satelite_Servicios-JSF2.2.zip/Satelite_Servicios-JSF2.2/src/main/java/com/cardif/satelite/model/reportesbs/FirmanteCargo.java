package com.cardif.satelite.model.reportesbs;

public class FirmanteCargo {
	private String codFirmante;
	private String nomFirmante;
	private String codCargo;
	private String nomCargo;

	public String getCodFirmante() {
		return codFirmante;
	}

	public void setCodFirmante(String codFirmante) {
		this.codFirmante = codFirmante;
	}

	public String getNomFirmante() {
		return nomFirmante;
	}

	public void setNomFirmante(String nomFirmante) {
		this.nomFirmante = nomFirmante;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public String getNomCargo() {
		return nomCargo;
	}

	public void setNomCargo(String nomCargo) {
		this.nomCargo = nomCargo;
	}

}
