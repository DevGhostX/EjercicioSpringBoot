package com.cardif.satelite.model.reportesbs;

public class LogError {
	private Long codLogError;
	private Long codProcesoArchivo;
	private String socio;
	private String asegurado;
	private String producto;
	private String bo_planilla;
	private String numPolizaSiniestro;
	private String usuCreacion;
	private String fecCreacion;
	private String descripcionError1;

	public String getDescripcionError2() {
		return descripcionError2;
	}

	public void setDescripcionError2(String descripcionError2) {
		this.descripcionError2 = descripcionError2;
	}

	public String getDescripcionError3() {
		return descripcionError3;
	}

	public void setDescripcionError3(String descripcionError3) {
		this.descripcionError3 = descripcionError3;
	}

	public String getDescripcionError4() {
		return descripcionError4;
	}

	public void setDescripcionError4(String descripcionError4) {
		this.descripcionError4 = descripcionError4;
	}

	public String getDescripcionError5() {
		return descripcionError5;
	}

	public void setDescripcionError5(String descripcionError5) {
		this.descripcionError5 = descripcionError5;
	}

	private String descripcionError2;
	private String descripcionError3;
	private String descripcionError4;
	private String descripcionError5;

	public Long getCodLogError() {
		return codLogError;
	}

	public void setCodLogError(Long codLogError) {
		this.codLogError = codLogError;
	}

	public Long getCodProcesoArchivo() {
		return codProcesoArchivo;
	}

	public void setCodProcesoArchivo(Long codProcesoArchivo) {
		this.codProcesoArchivo = codProcesoArchivo;
	}

	public String getSocio() {
		return socio;
	}

	public void setSocio(String socio) {
		this.socio = socio;
	}

	public String getAsegurado() {
		return asegurado;
	}

	public void setAsegurado(String asegurado) {
		this.asegurado = asegurado;
	}

	public String getProducto() {
		return producto;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public String getBo_planilla() {
		return bo_planilla;
	}

	public void setBo_planilla(String bo_planilla) {
		this.bo_planilla = bo_planilla;
	}

	public String getNumPolizaSiniestro() {
		return numPolizaSiniestro;
	}

	public void setNumPolizaSiniestro(String numPolizaSiniestro) {
		this.numPolizaSiniestro = numPolizaSiniestro;
	}

	public String getUsuCreacion() {
		return usuCreacion;
	}

	public void setUsuCreacion(String usuCreacion) {
		this.usuCreacion = usuCreacion;
	}

	public String getFecCreacion() {
		return fecCreacion;
	}

	public void setFecCreacion(String fecCreacion) {
		this.fecCreacion = fecCreacion;
	}

	public String getDescripcionError1() {
		return descripcionError1;
	}

	public void setDescripcionError1(String descripcionError1) {
		this.descripcionError1 = descripcionError1;
	}

}
