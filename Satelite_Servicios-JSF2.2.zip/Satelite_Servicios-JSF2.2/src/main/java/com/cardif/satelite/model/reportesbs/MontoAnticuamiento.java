package com.cardif.satelite.model.reportesbs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MontoAnticuamiento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long anio;
	private String trimestre;
	private String tipoContrato;
	private Long codEmpresa;
	private BigDecimal otrasCobrarReaCoa;
	private BigDecimal seisMesesAnt;
	private BigDecimal doceMesesAnt;
	private BigDecimal totalPartidasProvisionar;
	private String usuarioCrea;
	private Date fechaCrea;
	private String usuarioModifica;
	private Date fechaModifica;

	public Long getAnio() {
		return anio;
	}

	public void setAnio(Long anio) {
		this.anio = anio;
	}

	public String getTrimestre() {
		return trimestre;
	}

	public void setTrimestre(String trimestre) {
		this.trimestre = trimestre;
	}

	public String getTipoContrato() {
		return tipoContrato;
	}

	public void setTipoContrato(String tipoContrato) {
		this.tipoContrato = tipoContrato;
	}

	public Long getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(Long codEmpresa) {
		this.codEmpresa = codEmpresa;
	}

	public BigDecimal getOtrasCobrarReaCoa() {
		return otrasCobrarReaCoa;
	}

	public void setOtrasCobrarReaCoa(BigDecimal otrasCobrarReaCoa) {
		this.otrasCobrarReaCoa = otrasCobrarReaCoa;
	}

	public BigDecimal getSeisMesesAnt() {
		return seisMesesAnt;
	}

	public void setSeisMesesAnt(BigDecimal seisMesesAnt) {
		this.seisMesesAnt = seisMesesAnt;
	}

	public BigDecimal getDoceMesesAnt() {
		return doceMesesAnt;
	}

	public void setDoceMesesAnt(BigDecimal doceMesesAnt) {
		this.doceMesesAnt = doceMesesAnt;
	}

	public BigDecimal getTotalPartidasProvisionar() {
		return totalPartidasProvisionar;
	}

	public void setTotalPartidasProvisionar(BigDecimal totalPartidasProvisionar) {
		this.totalPartidasProvisionar = totalPartidasProvisionar;
	}

	public String getUsuarioCrea() {
		return usuarioCrea;
	}

	public void setUsuarioCrea(String usuarioCrea) {
		this.usuarioCrea = usuarioCrea;
	}

	public Date getFechaCrea() {
		return fechaCrea;
	}

	public void setFechaCrea(Date fechaCrea) {
		this.fechaCrea = fechaCrea;
	}

	public String getUsuarioModifica() {
		return usuarioModifica;
	}

	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}

	public Date getFechaModifica() {
		return fechaModifica;
	}

	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}

}
