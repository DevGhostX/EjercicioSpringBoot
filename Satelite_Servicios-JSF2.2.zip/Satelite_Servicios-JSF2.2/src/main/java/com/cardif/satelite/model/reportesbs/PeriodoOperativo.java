package com.cardif.satelite.model.reportesbs;

import java.io.Serializable;
import java.util.Date;

public class PeriodoOperativo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer anio;
	private Integer mes;
	private String estado;
	private Date fecApertura;
	private String usuApertura;
	private String accion;
	private String comentario;

	public Integer getAnio() {
		return anio;
	}

	public void setAnio(Integer anio) {
		this.anio = anio;
	}

	public Integer getMes() {
		return mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFecApertura() {
		return fecApertura;
	}

	public void setFecApertura(Date fecApertura) {
		this.fecApertura = fecApertura;
	}

	public String getUsuApertura() {
		return usuApertura;
	}

	public void setUsuApertura(String usuApertura) {
		this.usuApertura = usuApertura;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

}
