package com.cardif.satelite.model.reportesbs;

import java.io.Serializable;
import java.util.Date;

public class PeriodoOperativoDet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private Integer anio;
	private Integer mes;
	private Date fecCierre;
	private String usuCierre;
	private Date fecReabierto;
	private String usuReabierto;
	private String reabiertoComent;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getAnio() {
		return anio;
	}

	public void setAnio(Integer anio) {
		this.anio = anio;
	}

	public Integer getMes() {
		return mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

	public String getUsuCierre() {
		return usuCierre;
	}

	public void setUsuCierre(String usuCierre) {
		this.usuCierre = usuCierre;
	}

	public Date getFecCierre() {
		return fecCierre;
	}

	public void setFecCierre(Date fecCierre) {
		this.fecCierre = fecCierre;
	}

	public Date getFecReabierto() {
		return fecReabierto;
	}

	public void setFecReabierto(Date fecReabierto) {
		this.fecReabierto = fecReabierto;
	}

	public String getUsuReabierto() {
		return usuReabierto;
	}

	public void setUsuReabierto(String usuReabierto) {
		this.usuReabierto = usuReabierto;
	}

	public String getReabiertoComent() {
		return reabiertoComent;
	}

	public void setReabiertoComent(String reabiertoComent) {
		this.reabiertoComent = reabiertoComent;
	}

}
