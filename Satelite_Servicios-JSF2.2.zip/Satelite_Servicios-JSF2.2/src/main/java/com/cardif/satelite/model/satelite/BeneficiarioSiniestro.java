package com.cardif.satelite.model.satelite;

import java.math.BigDecimal;
import java.util.Date;

public class BeneficiarioSiniestro implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	private boolean idCheck;
	private boolean idSelectCheck;

	public Long beneficiarioID;
	public String siniestroID;
	public String beneApePat;
	public String beneApeMat;
	public String beneNom;
	public String beneDocTip;
	public String beneNumDoc;
	public String benePais;
	public String beneDepartamento;
	public String beneProvincia;
	public String beneDistrito;
	public String beneEma;
	public String beneCtaBanco;
	public String beneTel;
	public String beneTel2;
	public String beneDir;
	public String beneParentesco;
	public BigDecimal benePart;
	public BigDecimal beneMonto;
	public Date fecOpConta;
	public String beneEstado;
	public String beneEstadoDesc;
	public Date beneFecPendiente;
	public Date beneFecEnvOpContable;
	public Date beneFecProvisionado;
	public Date beneFecRegPago;
	public Date beneFecAsigFirmante;
	public Date beneFecProcesado;
	public Date beneFecCobrado;
	public String loteId;
	public String usuCrea;
	public Date fecCrea;
	public String usuModifica;
	public Date fecModifica;

	// Campos descripcion
	public String benePaisDesc;
	public String beneDepartamentoDesc;
	public String beneProvinciaDesc;
	public String beneDistritoDesc;

	// Campos extra de la grilla de consulta
	private String socioDesc;
	private String productoDesc;
	private String beneNomCompleto;
	private String beneNomCompletoExport;
	private Date beneSiniFecOcurr;
	private Date beneFecAprRe;
	private String flagAsegSocio;

	// Campos extra de la exportacion
	private Date fecNotificacion;
	private Date fecUltimaDocRecibida;
	private String nroPoliza;
	private String nroPlanilla;
	private String beneDocTipDesc;
	private String beneParentescoDesc;
	private String monedaDesc;
	private Date fecAprobRechazo;
	private String mesAprobRechazoCartaSolDoc;
	private Date fecEntregaLiqOPC;
	private Date fecContabilizado;
	private Date fecCargaBancoBene;

	// Datos de siniestro
	private Date fecOcurrSini;
	private String coberturaDesc;
	private String tipDocAsegurado;
	private String nroDocAsegurado;
	private String nomCompletoAsegurado;
	private Date fecRecepSocioSini;
	private Double pagoSini;
	private Date fecAprobRechSini;
	private String estadoSini;
	private String nroPlanillaSini;
	private String nomMonedaSini;
	private String codSocioSini;
	private Date fecUltDocumentacionSini;
	private String tipRefCafaeSini;
	private String refCafaeSini;
	private String usuCreacionSini;
	private Date fecCreacionSini;

	public Long getBeneficiarioID() {
		return beneficiarioID;
	}

	public void setBeneficiarioID(Long beneficiarioID) {
		this.beneficiarioID = beneficiarioID;
	}

	public String getSiniestroID() {
		return siniestroID;
	}

	public void setSiniestroID(String siniestroID) {
		this.siniestroID = siniestroID;
	}

	public String getBeneApePat() {
		return beneApePat;
	}

	public void setBeneApePat(String beneApePat) {
		this.beneApePat = beneApePat;
	}

	public String getBeneApeMat() {
		return beneApeMat;
	}

	public void setBeneApeMat(String beneApeMat) {
		this.beneApeMat = beneApeMat;
	}

	public String getBeneNom() {
		return beneNom;
	}

	public void setBeneNom(String beneNom) {
		this.beneNom = beneNom;
	}

	public String getBeneDocTip() {
		return beneDocTip;
	}

	public void setBeneDocTip(String beneDocTip) {
		this.beneDocTip = beneDocTip;
	}

	public String getBeneNumDoc() {
		if (beneDocTip != null) {// Existe Beneficiario
			return beneNumDoc;
		} else {// Beneficiario Socio
			return "-";
		}
	}

	public void setBeneNumDoc(String beneNumDoc) {
		this.beneNumDoc = beneNumDoc;
	}

	public String getBenePais() {
		return benePais;
	}

	public void setBenePais(String benePais) {
		this.benePais = benePais;
	}

	public String getBeneEma() {
		return beneEma;
	}

	public void setBeneEma(String beneEma) {
		this.beneEma = beneEma;
	}

	public String getBeneCtaBanco() {
		return beneCtaBanco;
	}

	public void setBeneCtaBanco(String beneCtaBanco) {
		this.beneCtaBanco = beneCtaBanco;
	}

	public String getBeneTel() {
		return beneTel;
	}

	public void setBeneTel(String beneTel) {
		this.beneTel = beneTel;
	}

	public String getBeneDir() {
		return beneDir;
	}

	public void setBeneDir(String beneDir) {
		this.beneDir = beneDir;
	}

	public String getBeneParentesco() {
		return beneParentesco;
	}

	public void setBeneParentesco(String beneParentesco) {
		this.beneParentesco = beneParentesco;
	}

	public BigDecimal getBenePart() {
		if (beneDocTip != null) {// Existe Beneficiario
			return benePart;
		} else {// Beneficiario Socio
			return new BigDecimal(100);
		}
	}

	public void setBenePart(BigDecimal benePart) {
		this.benePart = benePart;
	}

	public BigDecimal getBeneMonto() {
		return beneMonto;
	}

	public void setBeneMonto(BigDecimal beneMonto) {
		this.beneMonto = beneMonto;
	}

	public Date getFecOpConta() {
		return fecOpConta;
	}

	public void setFecOpConta(Date fecOpConta) {
		this.fecOpConta = fecOpConta;
	}

	public String getBeneEstado() {
		return beneEstado;
	}

	public void setBeneEstado(String beneEstado) {
		this.beneEstado = beneEstado;
	}

	public Date getBeneFecPendiente() {
		return beneFecPendiente;
	}

	public void setBeneFecPendiente(Date beneFecPendiente) {
		this.beneFecPendiente = beneFecPendiente;
	}

	public Date getBeneFecEnvOpContable() {
		return beneFecEnvOpContable;
	}

	public void setBeneFecEnvOpContable(Date beneFecEnvOpContable) {
		this.beneFecEnvOpContable = beneFecEnvOpContable;
	}

	public Date getBeneFecProvisionado() {
		return beneFecProvisionado;
	}

	public void setBeneFecProvisionado(Date beneFecProvisionado) {
		this.beneFecProvisionado = beneFecProvisionado;
	}

	public Date getBeneFecRegPago() {
		return beneFecRegPago;
	}

	public void setBeneFecRegPago(Date beneFecRegPago) {
		this.beneFecRegPago = beneFecRegPago;
	}

	public Date getBeneFecAsigFirmante() {
		return beneFecAsigFirmante;
	}

	public void setBeneFecAsigFirmante(Date beneFecAsigFirmante) {
		this.beneFecAsigFirmante = beneFecAsigFirmante;
	}

	public Date getBeneFecProcesado() {
		return beneFecProcesado;
	}

	public void setBeneFecProcesado(Date beneFecProcesado) {
		this.beneFecProcesado = beneFecProcesado;
	}

	public Date getBeneFecCobrado() {
		return beneFecCobrado;
	}

	public void setBeneFecCobrado(Date beneFecCobrado) {
		this.beneFecCobrado = beneFecCobrado;
	}

	public String getLoteId() {
		return loteId;
	}

	public void setLoteId(String loteId) {
		this.loteId = loteId;
	}

	public String getUsuCrea() {
		return usuCrea;
	}

	public void setUsuCrea(String usuCrea) {
		this.usuCrea = usuCrea;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public String getUsuModifica() {
		return usuModifica;
	}

	public void setUsuModifica(String usuModifica) {
		this.usuModifica = usuModifica;
	}

	public Date getFecModifica() {
		return fecModifica;
	}

	public void setFecModifica(Date fecModifica) {
		this.fecModifica = fecModifica;
	}

	public String getBeneDepartamento() {
		return beneDepartamento;
	}

	public void setBeneDepartamento(String beneDepartamento) {
		this.beneDepartamento = beneDepartamento;
	}

	public String getBeneProvincia() {
		return beneProvincia;
	}

	public void setBeneProvincia(String beneProvincia) {
		this.beneProvincia = beneProvincia;
	}

	public String getBeneDistrito() {
		return beneDistrito;
	}

	public void setBeneDistrito(String beneDistrito) {
		this.beneDistrito = beneDistrito;
	}

	public String getBenePaisDesc() {
		return benePaisDesc;
	}

	public void setBenePaisDesc(String benePaisDesc) {
		this.benePaisDesc = benePaisDesc;
	}

	public String getBeneDepartamentoDesc() {
		return beneDepartamentoDesc;
	}

	public void setBeneDepartamentoDesc(String beneDepartamentoDesc) {
		this.beneDepartamentoDesc = beneDepartamentoDesc;
	}

	public String getBeneProvinciaDesc() {
		return beneProvinciaDesc;
	}

	public void setBeneProvinciaDesc(String beneProvinciaDesc) {
		this.beneProvinciaDesc = beneProvinciaDesc;
	}

	public String getBeneDistritoDesc() {
		return beneDistritoDesc;
	}

	public void setBeneDistritoDesc(String beneDistritoDesc) {
		this.beneDistritoDesc = beneDistritoDesc;
	}

	public String getSocioDesc() {
		return socioDesc;
	}

	public void setSocioDesc(String socioDesc) {
		this.socioDesc = socioDesc;
	}

	public String getProductoDesc() {
		return productoDesc;
	}

	public void setProductoDesc(String productoDesc) {
		this.productoDesc = productoDesc;
	}

	public String getBeneNomCompleto() {
		if (beneDocTip != null) {// Existe Beneficiario
			return getBeneNom() + " " + getBeneApePat() + " " + getBeneApeMat();
		} else {
			return socioDesc;
		}
	}

	public String getBeneNomCompletoExport() {
		if (beneDocTip != null) {// Existe Beneficiario
			return getBeneApePat() + " " + getBeneApeMat() + ", " + getBeneNom();
		} else {
			return socioDesc;
		}
	}

	public Date getBeneSiniFecOcurr() {
		return beneSiniFecOcurr;
	}

	public void setBeneSiniFecOcurr(Date beneSiniFecOcurr) {
		this.beneSiniFecOcurr = beneSiniFecOcurr;
	}

	public Date getBeneFecAprRe() {
		return beneFecAprRe;
	}

	public void setBeneFecAprRe(Date beneFecAprRe) {
		this.beneFecAprRe = beneFecAprRe;
	}

	public Date getFecNotificacion() {
		return fecNotificacion;
	}

	public void setFecNotificacion(Date fecNotificacion) {
		this.fecNotificacion = fecNotificacion;
	}

	public Date getFecUltimaDocRecibida() {
		return fecUltimaDocRecibida;
	}

	public void setFecUltimaDocRecibida(Date fecUltimaDocRecibida) {
		this.fecUltimaDocRecibida = fecUltimaDocRecibida;
	}

	public String getNroPoliza() {
		return nroPoliza;
	}

	public void setNroPoliza(String nroPoliza) {
		this.nroPoliza = nroPoliza;
	}

	public String getNroPlanilla() {
		return nroPlanilla;
	}

	public void setNroPlanilla(String nroPlanilla) {
		this.nroPlanilla = nroPlanilla;
	}

	public String getBeneDocTipDesc() {
		if (beneDocTip != null) {// Existe Beneficiario
			return beneDocTipDesc;
		} else {
			return "-";
		}
	}

	public void setBeneDocTipDesc(String beneDocTipDesc) {
		this.beneDocTipDesc = beneDocTipDesc;
	}

	public String getBeneParentescoDesc() {
		return beneParentescoDesc;
	}

	public void setBeneParentescoDesc(String beneParentescoDesc) {
		this.beneParentescoDesc = beneParentescoDesc;
	}

	public String getMonedaDesc() {
		return monedaDesc;
	}

	public void setMonedaDesc(String monedaDesc) {
		this.monedaDesc = monedaDesc;
	}

	public Date getFecAprobRechazo() {
		return fecAprobRechazo;
	}

	public void setFecAprobRechazo(Date fecAprobRechazo) {
		this.fecAprobRechazo = fecAprobRechazo;
	}

	public String getMesAprobRechazoCartaSolDoc() {
		return mesAprobRechazoCartaSolDoc;
	}

	public void setMesAprobRechazoCartaSolDoc(String mesAprobRechazoCartaSolDoc) {
		this.mesAprobRechazoCartaSolDoc = mesAprobRechazoCartaSolDoc;
	}

	public Date getFecEntregaLiqOPC() {
		return fecEntregaLiqOPC;
	}

	public void setFecEntregaLiqOPC(Date fecEntregaLiqOPC) {
		this.fecEntregaLiqOPC = fecEntregaLiqOPC;
	}

	public Date getFecContabilizado() {
		return fecContabilizado;
	}

	public void setFecContabilizado(Date fecContabilizado) {
		this.fecContabilizado = fecContabilizado;
	}

	public Date getFecCargaBancoBene() {
		return fecCargaBancoBene;
	}

	public void setFecCargaBancoBene(Date fecCargaBancoBene) {
		this.fecCargaBancoBene = fecCargaBancoBene;
	}

	public Date getFecOcurrSini() {
		return fecOcurrSini;
	}

	public void setFecOcurrSini(Date fecOcurrSini) {
		this.fecOcurrSini = fecOcurrSini;
	}

	public String getCoberturaDesc() {
		return coberturaDesc;
	}

	public void setCoberturaDesc(String coberturaDesc) {
		this.coberturaDesc = coberturaDesc;
	}

	public String getTipDocAsegurado() {
		return tipDocAsegurado;
	}

	public void setTipDocAsegurado(String tipDocAsegurado) {
		this.tipDocAsegurado = tipDocAsegurado;
	}

	public String getNroDocAsegurado() {
		return nroDocAsegurado;
	}

	public void setNroDocAsegurado(String nroDocAsegurado) {
		this.nroDocAsegurado = nroDocAsegurado;
	}

	public String getNomCompletoAsegurado() {
		return nomCompletoAsegurado;
	}

	public void setNomCompletoAsegurado(String nomCompletoAsegurado) {
		this.nomCompletoAsegurado = nomCompletoAsegurado;
	}

	public Date getFecRecepSocioSini() {
		return fecRecepSocioSini;
	}

	public void setFecRecepSocioSini(Date fecRecepSocioSini) {
		this.fecRecepSocioSini = fecRecepSocioSini;
	}

	public Double getPagoSini() {
		return pagoSini;
	}

	public void setPagoSini(Double pagoSini) {
		this.pagoSini = pagoSini;
	}

	public Date getFecAprobRechSini() {
		return fecAprobRechSini;
	}

	public void setFecAprobRechSini(Date fecAprobRechSini) {
		this.fecAprobRechSini = fecAprobRechSini;
	}

	public String getEstadoSini() {
		return estadoSini;
	}

	public void setEstadoSini(String estadoSini) {
		this.estadoSini = estadoSini;
	}

	public String getNroPlanillaSini() {
		return nroPlanillaSini;
	}

	public void setNroPlanillaSini(String nroPlanillaSini) {
		this.nroPlanillaSini = nroPlanillaSini;
	}

	public String getNomMonedaSini() {
		return nomMonedaSini;
	}

	public void setNomMonedaSini(String nomMonedaSini) {
		this.nomMonedaSini = nomMonedaSini;
	}

	public String getCodSocioSini() {
		return codSocioSini;
	}

	public void setCodSocioSini(String codSocioSini) {
		this.codSocioSini = codSocioSini;
	}

	public Date getFecUltDocumentacionSini() {
		return fecUltDocumentacionSini;
	}

	public void setFecUltDocumentacionSini(Date fecUltDocumentacionSini) {
		this.fecUltDocumentacionSini = fecUltDocumentacionSini;
	}

	public String getTipRefCafaeSini() {
		return tipRefCafaeSini;
	}

	public void setTipRefCafaeSini(String tipRefCafaeSini) {
		this.tipRefCafaeSini = tipRefCafaeSini;
	}

	public String getRefCafaeSini() {
		return refCafaeSini;
	}

	public void setRefCafaeSini(String refCafaeSini) {
		this.refCafaeSini = refCafaeSini;
	}

	public String getUsuCreacionSini() {
		return usuCreacionSini;
	}

	public void setUsuCreacionSini(String usuCreacionSini) {
		this.usuCreacionSini = usuCreacionSini;
	}

	public Date getFecCreacionSini() {
		return fecCreacionSini;
	}

	public void setFecCreacionSini(Date fecCreacionSini) {
		this.fecCreacionSini = fecCreacionSini;
	}

	public boolean isIdCheck() {
		return idCheck;
	}

	public void setIdCheck(boolean idCheck) {
		this.idCheck = idCheck;
	}

	public boolean isIdSelectCheck() {
		return idSelectCheck;
	}

	public void setIdSelectCheck(boolean idSelectCheck) {
		this.idSelectCheck = idSelectCheck;
	}

	public String getBeneEstadoDesc() {
		return beneEstadoDesc;
	}

	public void setBeneEstadoDesc(String beneEstadoDesc) {
		this.beneEstadoDesc = beneEstadoDesc;
	}

	public String getBeneTel2() {
		return beneTel2;
	}

	public void setBeneTel2(String beneTel2) {
		this.beneTel2 = beneTel2;
	}

	public String getFlagAsegSocio() {
		return flagAsegSocio;
	}

	public void setFlagAsegSocio(String flagAsegSocio) {
		this.flagAsegSocio = flagAsegSocio;
	}

	public void setBeneNomCompleto(String beneNomCompleto) {
		this.beneNomCompleto = beneNomCompleto;
	}

}
