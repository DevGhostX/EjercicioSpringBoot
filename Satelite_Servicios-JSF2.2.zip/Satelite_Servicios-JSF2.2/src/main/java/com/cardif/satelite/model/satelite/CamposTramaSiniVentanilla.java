package com.cardif.satelite.model.satelite;

public class CamposTramaSiniVentanilla {

	private Long campoId;
	private String bancoId;
	private String tramaId;
	private Integer numOrdCampo;
	private String desCampo;
	private String tipoDato;
	private String oblCampo;
	private Integer posInicial;
	private Integer posFinal;
	private Integer longCampo;

	public Long getCampoId() {
		return campoId;
	}

	public void setCampoId(Long campoId) {
		this.campoId = campoId;
	}

	public String getBancoId() {
		return bancoId;
	}

	public void setBancoId(String bancoId) {
		this.bancoId = bancoId;
	}

	public String getTramaId() {
		return tramaId;
	}

	public void setTramaId(String tramaId) {
		this.tramaId = tramaId;
	}

	public Integer getNumOrdCampo() {
		return numOrdCampo;
	}

	public void setNumOrdCampo(Integer numOrdCampo) {
		this.numOrdCampo = numOrdCampo;
	}

	public String getDesCampo() {
		return desCampo;
	}

	public void setDesCampo(String desCampo) {
		this.desCampo = desCampo;
	}

	public String getTipoDato() {
		return tipoDato;
	}

	public void setTipoDato(String tipoDato) {
		this.tipoDato = tipoDato;
	}

	public String getOblCampo() {
		return oblCampo;
	}

	public void setOblCampo(String oblCampo) {
		this.oblCampo = oblCampo;
	}

	public Integer getPosInicial() {
		return posInicial;
	}

	public void setPosInicial(Integer posInicial) {
		this.posInicial = posInicial;
	}

	public Integer getPosFinal() {
		return posFinal;
	}

	public void setPosFinal(Integer posFinal) {
		this.posFinal = posFinal;
	}

	public Integer getLongCampo() {
		return longCampo;
	}

	public void setLongCampo(Integer longCampo) {
		this.longCampo = longCampo;
	}

}
